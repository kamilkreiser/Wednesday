const [pjf,lkf,name]=process.argv.slice(2);
const pj=require(pjf), lk=require(lkf);
const pk=lk.packages||{}; let n=0,reg=0,integ=0,other=[],scripts=[],links=[];
for (const [k,v] of Object.entries(pk)){ if(k==="")continue; n++;
 if(v.link){links.push(k+"->"+v.resolved);continue}
 if(v.resolved&&v.resolved.startsWith("https://registry.npmjs.org/"))reg++; else other.push(k+" "+v.resolved);
 if(v.integrity)integ++; if(v.hasInstallScript)scripts.push(k);}
console.log(name,"fmt:",!!(pj.scripts||{})["format:check"],"lockv",lk.lockfileVersion,"entries",n,"registry",reg,"integrity",integ,"other",JSON.stringify(other.slice(0,8)),"links",JSON.stringify(links),"installScripts",JSON.stringify(scripts),"rootLifecycle",JSON.stringify(Object.keys(pj.scripts||{}).filter(s=>/^(pre|post)?(install|prepare)$/.test(s))));
