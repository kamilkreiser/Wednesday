#!/bin/bash
# T11: the full hand-off .githooks/pre-push -> gate, on a scratch repo with a bare remote.
. /private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/087c4316-bb15-4161-a5ec-601b737a6e98/scratchpad/g1532/bin/fx.sh
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_AUTHOR_NAME=t GIT_AUTHOR_EMAIL=t@t.t GIT_COMMITTER_NAME=t GIT_COMMITTER_EMAIL=t@t.t
HOOK_SRC="${HOOK_SRC:-$W/head/.githooks/pre-push}"
GATE_SRC="${GATE_SRC:-$GATE_HEAD}"
B=$(mktemp -d $W/f/t11.XXXX); R=$B/work; BARE=$B/remote.git
git init -q --bare $BARE
mk_root $R "$GATE_SRC"; mkdir -p $R/.githooks; cp "$HOOK_SRC" $R/.githooks/pre-push; chmod +x $R/.githooks/pre-push
P=$(mk_tgz prettier-fake prettier "")
mk_pkg $R pk $P          # installable offline
mk_pkg $R pk2 $P         # installable offline (used for the deletion-only push)
mkdir -p $R/systemTest/pknet/src; echo 'export const n = 1;' > $R/systemTest/pknet/src/a.ts
cat > $R/systemTest/pknet/package.json <<J
{ "name": "fx-pknet", "version": "0.0.0", "private": true, "scripts": { "format:check": "node_modules/.bin/prettier --check ." }, "devDependencies": { "prettier": "3.3.3" } }
J
cat > $R/systemTest/pknet/package-lock.json <<J
{ "name": "fx-pknet", "version": "0.0.0", "lockfileVersion": 3, "requires": true, "packages": {
  "": { "name": "fx-pknet", "version": "0.0.0", "devDependencies": { "prettier": "3.3.3" } },
  "node_modules/prettier": { "version": "3.3.3", "resolved": "https://registry.npmjs.org/prettier/-/prettier-3.3.3.tgz", "integrity": "sha512-i2tDNA0O5IrMO757lfrdQZCc2jPNDVntV0m/+4whiDfWaTKfMNgR7Qz0NAeGz/nRqF4m5/6CLzbP4/liHt12Ew==", "dev": true, "bin": { "prettier": "bin/prettier.cjs" } } } }
J
echo readme > $R/README.md
git -C $R init -q -b develop; git -C $R config core.hooksPath .githooks; git -C $R remote add origin $BARE
git -C $R add -A; git -C $R commit -qm base
git -C $R push -q --no-verify origin develop 2>&1
git -C $R fetch -q origin
st() { git -C $R status --porcelain | grep -v '^?? \.' ; }
remote_has() { git --git-dir=$BARE rev-parse -q --verify "$1" >/dev/null 2>&1 && echo LANDED || echo "not on remote"; }
push() { local label="$1"; shift; echo "=== $label: git push $*"; local before="$(st)"; git -C $R push "$@" 2>&1 | grep -E 'format-gate|pre-push|->|rejected|error:' | grep -vE '^\[format-gate\]   \|' | sed 's/^/    /'; echo "    rc=${PIPESTATUS[0]}  | git status changed: $([ "$before" = "$(st)" ] && echo no || echo YES) | stages=$(stages $R)"; }

# 1. new branch, no upstream, touching pk (absent node_modules) -> install
git -C $R checkout -q -b feat; echo 'export const a = 2;' > $R/systemTest/pk/src/a.ts; git -C $R commit -qam 'feat: pk'
push "1 new branch (no upstream)" -u origin feat; echo "    remote feat: $(remote_has refs/heads/feat) | pk prettier: $([ -x $R/systemTest/pk/node_modules/.bin/prettier ] && echo yes)"
# 2. existing branch, upstream = own counterpart
echo 'export const a = 3;' > $R/systemTest/pk/src/a.ts; git -C $R commit -qam 'feat: pk 2'
push "2 existing branch (upstream origin/feat)" origin feat
# 3. touch pknet (registry unreachable) on a branch whose upstream is its own counterpart -> refused, no stale hint
echo 'export const n = 2;' > $R/systemTest/pknet/src/a.ts; git -C $R commit -qam 'feat: pknet'
H3=$(git -C $R rev-parse HEAD)
echo "=== 3 own-counterpart upstream, pknet uninstallable"; git -C $R push origin feat 2>&1 | grep -E 'REFUSED|stale|FAILED' | sed 's/^/    /'; echo "    remote feat at H3: $([ "$(git --git-dir=$BARE rev-parse refs/heads/feat)" = "$H3" ] && echo LANDED || echo 'not landed')"
# 4. branch whose upstream is origin/develop (checkout -b x origin/develop) -> stale hint
git -C $R checkout -q -b x origin/develop; echo 'export const n = 3;' > $R/systemTest/pknet/src/a.ts; git -C $R commit -qam 'x: pknet'
echo "=== 4 upstream is origin/develop (not own counterpart), pknet uninstallable"; git -C $R push origin x 2>&1 | grep -E 'REFUSED|stale|FAILED' | sed 's/^/    /'; echo "    remote x: $(remote_has refs/heads/x)"
# 5. deletion push of a remote branch while HEAD (x) carries the uninstallable package
git -C $R push -q --no-verify origin develop:refs/heads/todelete
push "5 delete remote branch 'todelete' while HEAD=x has pknet changes" origin :todelete; echo "    remote todelete: $(remote_has refs/heads/todelete)"
# 6. tag push while HEAD=x
git -C $R tag v1 develop
push "6 tag push (tag on develop) while HEAD=x" origin v1; echo "    remote v1: $(remote_has refs/tags/v1)"
# 7. deletion-only push under pk2 (node_modules absent): counts as "a file of the package is in the push"
git -C $R checkout -q feat 2>/dev/null; git -C $R reset -q --hard origin/feat
git -C $R rm -q systemTest/pk2/src/a.ts; git -C $R commit -qm 'delete only under pk2'
push "7 deletion-only push under pk2" origin feat; echo "    pk2 prettier after: $([ -x $R/systemTest/pk2/node_modules/.bin/prettier ] && echo yes || echo no)"
# 8. hollow node_modules + dangling symlink: npm ci never run (argv log via PATH stub)
mkdir -p $W/shim_log; cat > $W/shim_log/npm <<'S'
#!/bin/sh
[ "$1" = ci ] && echo "ci in $PWD" >> "$NPM_CI_LOG"
exec "$REAL_NPM" "$@"
S
chmod +x $W/shim_log/npm; export REAL_NPM NPM_CI_LOG=$B/npm_ci.log; : > $NPM_CI_LOG
mkdir -p $R/systemTest/pk2/node_modules; : > $R/systemTest/pk2/node_modules/.marker
ln -s $B/does-not-exist $R/systemTest/pk/node_modules.tmp; mv $R/systemTest/pk/node_modules $B/pk_nm_aside; mv $R/systemTest/pk/node_modules.tmp $R/systemTest/pk/node_modules
echo 'export const a = 9;' > $R/systemTest/pk/src/a.ts; echo 'export const b = 9;' > $R/systemTest/pk2/src/b.ts; git -C $R add -A; git -C $R commit -qm 'touch pk + pk2'
echo "=== 8 hollow pk2 + dangling-symlink pk"; PATH=$W/shim_log:$PATH git -C $R push origin feat 2>&1 | grep -E 'REFUSED|fix:|stale' | sed 's/^/    /'; echo "    npm ci invocations: $(wc -l < $NPM_CI_LOG | tr -d ' ') | marker kept: $([ -f $R/systemTest/pk2/node_modules/.marker ] && echo yes) | dangling link kept: $([ -L $R/systemTest/pk/node_modules ] && echo yes)"
echo "--- --all mode on the same tree (named SKIPs, KS-1063 only when nothing checked)"
PATH=$W/shim_log:$PATH bash $R/systemTest/scripts/check-package-format.sh --all 2>&1 | grep -E 'SKIP|NOTHING|checked|REFUSED' | cut -c1-200 | sed 's/^/    /'; echo "    rc=${PIPESTATUS[0]} npm ci invocations now: $(wc -l < $NPM_CI_LOG | tr -d ' ')"
