# fx.sh - sourced. Fixture builders for the QA gate of PR #1532 (bash 3.2).
W=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/087c4316-bb15-4161-a5ec-601b737a6e98/scratchpad/g1532
GATE_HEAD="$W/head/systemTest/scripts/check-package-format.sh"
REAL_NPM="$(command -v npm)"
FXC="$W/fxcache"; mkdir -p "$FXC" "$W/tgz"
export npm_config_cache="$FXC" npm_config_registry="http://127.0.0.1:9/" npm_config_update_notifier=false
now_ms() { node -e 'process.stdout.write(String(Date.now()))'; }

# mk_tgz <name> <bin-or-empty> <postinstall-cmd-or-empty> : prints tgz path
mk_tgz() {
    local name="$1" bin="$2" post="$3" d="$W/tgz/src-$1"
    rm -rf "$d"; mkdir -p "$d"
    node -e '
      const [n,b,p]=process.argv.slice(1); const j={name:n,version:"1.0.0"};
      if(b){j.bin={[b]:"bin.js"}} if(p){j.scripts={postinstall:p}}
      require("fs").writeFileSync(process.argv[4]+"/package.json",JSON.stringify(j));' "$name" "$bin" "$post" "$d"
    printf '#!/usr/bin/env node\nprocess.exit(0)\n' > "$d/bin.js"; chmod +x "$d/bin.js"
    rm -f "$W/tgz/$name-1.0.0.tgz"
    "$REAL_NPM" pack "$d" --pack-destination "$W/tgz" --silent >/dev/null 2>&1
    printf '%s' "$W/tgz/$name-1.0.0.tgz"
}
# mk_pkg <root> <pkg> <tgz...>: package whose lockfile pins the given offline tarballs
mk_pkg() {
    local root="$1" pkg="$2"; shift 2
    mkdir -p "$root/systemTest/$pkg/src"
    echo 'export const a = 1;' > "$root/systemTest/$pkg/src/a.ts"
    node -e '
      const c=require("crypto"),fs=require("fs");
      const [dir,pkg,...tgzs]=process.argv.slice(1);
      const deps={}, pk={"":{name:"fx-"+pkg,version:"0.0.0",devDependencies:deps}};
      for(const t of tgzs){ const raw=JSON.parse(require("child_process").execSync("tar -xOzf "+JSON.stringify(t)+" package/package.json"));
        deps[raw.name]="file:"+t;
        const e={version:"1.0.0",resolved:"file:"+t,integrity:"sha512-"+c.createHash("sha512").update(fs.readFileSync(t)).digest("base64"),dev:true};
        if(raw.bin)e.bin=raw.bin; if(raw.scripts&&raw.scripts.postinstall)e.hasInstallScript=true;
        pk["node_modules/"+raw.name]=e; }
      fs.writeFileSync(dir+"/package.json",JSON.stringify({name:"fx-"+pkg,version:"0.0.0",private:true,scripts:{"format:check":"node_modules/.bin/prettier --check ."},devDependencies:deps},null,2));
      fs.writeFileSync(dir+"/package-lock.json",JSON.stringify({name:"fx-"+pkg,version:"0.0.0",lockfileVersion:3,requires:true,packages:pk},null,2));
    ' "$root/systemTest/$pkg" "$pkg" "$@"
}
# mk_root <root> [gate-file]: fixture repo with a gate copy, committed
mk_root() {
    local root="$1" gate="${2:-$GATE_HEAD}"
    mkdir -p "$root/systemTest/scripts"
    cp "$gate" "$root/systemTest/scripts/check-package-format.sh"
    printf 'node_modules/\nsystemTest/.format-gate-stage.*/\n' > "$root/.gitignore"
}
commit_root() {
    ( export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
      git -C "$1" init -q . && git -C "$1" add -A && git -C "$1" -c user.email=t@t.t -c user.name=t commit -qm fixture ) >/dev/null 2>&1
}
gate() { local root="$1"; shift; bash "$root/systemTest/scripts/check-package-format.sh" "$@"; }
stages() { ls -A "$1/systemTest" 2>/dev/null | grep -c '^\.format-gate-stage\.' ; }
