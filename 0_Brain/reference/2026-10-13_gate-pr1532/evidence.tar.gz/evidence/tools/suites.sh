#!/bin/bash
# suites.sh <tree> <label>
W=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/087c4316-bb15-4161-a5ec-601b737a6e98/scratchpad/g1532
T=$1; L=$2; export TMPDIR=$W/tmp
for s in systemTest/__tests__/package_format_gate.test.sh Blockchain/Dev/scripts/__tests__/ks998_pre_push_stale_base_hint.test.sh Blockchain/Dev/scripts/__tests__/pre_push_hook_base.test.sh; do
  n=$(basename $s .test.sh); t0=$(date +%s)
  /bin/bash $T/$s > $W/ev/$L.$n.log 2>&1; rc=$?
  echo "$L $n rc=$rc secs=$(( $(date +%s)-t0 )) $(grep -cE '^ *(ok|PASS)' $W/ev/$L.$n.log) $(tail -2 $W/ev/$L.$n.log | tr '\n' ' ')"
done
