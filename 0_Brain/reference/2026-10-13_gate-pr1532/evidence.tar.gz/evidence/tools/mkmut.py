import sys, os
W = "/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/087c4316-bb15-4161-a5ec-601b737a6e98/scratchpad/g1532"
gate = open(f"{W}/head/systemTest/scripts/check-package-format.sh").read()
hook = open(f"{W}/head/.githooks/pre-push").read()
os.makedirs(f"{W}/mut", exist_ok=True)

G = {
 # --- controls: each harness must be able to fail
 "C1_gate_always_passes": [("set -uo pipefail\n", "set -uo pipefail\nexit 0\n")],
 # --- the author's five survivors, re-derived
 "m13a_sweep_symlink_guard_dropped": [('        [ -L "$d" ] && continue\n', "")],
 "m23_no_term_trap": [("trap '_fg_cleanup; exit 143' TERM\n", "")],
 "m23b_no_exit_trap": [("trap '_fg_cleanup' EXIT\n", "")],
 "m25_rm_prefix_guard_dropped": [('    case "$d" in "$STAGE_PREFIX"*) ;; *) return 1 ;; esac\n', "")],
 "m35_nothing_checked_fires_on_refusal": [('[ "$skipped" -gt 0 ] && [ "$refused" -eq 0 ]; then', '[ "$skipped" -gt 0 ]; then')],
 # --- mine
 "Q1_rename_replaced_by_copy": [('elif mv "$stage/node_modules" "$dir/node_modules" 2>/dev/null; then', 'elif cp -R "$stage/node_modules" "$dir/node_modules" 2>/dev/null; then')],
 "Q2_watchdog_kill_removed_marker_kept": [('        : > "$marker"\n        kill -TERM "$_FG_NPM_PID" 2>/dev/null\n        sleep 2\n        kill -KILL "$_FG_NPM_PID" 2>/dev/null\n', '        : > "$marker"\n')],
 "Q3_exit_code_dropped_executable_kept": [('    elif [ "$INST_RC" -ne 0 ]; then\n        INST_STATE="failed"\n', '    elif false; then\n        INST_STATE="failed"\n')],
 "Q4_stage_outside_package_fs_in_TMPDIR": [('STAGE_PREFIX="$REPO_ROOT/systemTest/.format-gate-stage."', 'STAGE_PREFIX="${TMPDIR:-/tmp}/.format-gate-stage."')],
 "Q5_no_exec_so_pid_is_subshell": [('( cd "$stage" && exec npm ci', '( cd "$stage" && npm ci')],
 "Q6_watchdog_TERM_only_no_KILL": [('        sleep 2\n        kill -KILL "$_FG_NPM_PID" 2>/dev/null\n', '')],
 "Q7_cleanup_no_KILL_escalation": [('        kill -KILL "$_FG_NPM_PID" 2>/dev/null\n        _FG_NPM_PID=""\n    fi\n', '        _FG_NPM_PID=""\n    fi\n')],
 "Q8_noprettier_test_uses_exists_not_exec": [('    elif [ ! -x "$stage/node_modules/.bin/prettier" ]; then', '    elif [ ! -e "$stage/node_modules/.bin/prettier" ]; then')],
 "Q9_post_move_check_uses_exists": [('        if [ -x "$dir/node_modules/.bin/prettier" ]; then\n            INST_STATE="ok"', '        if [ -e "$dir/node_modules" ]; then\n            INST_STATE="ok"')],
 "Q10_breaker_never_consulted": [('        elif [ -n "$BREAKER_PKG" ]; then\n            unready="notattempted"\n', '        elif false; then\n            unready="notattempted"\n')],
 "Q11_raced_keeps_hollow_as_checked": [('                    [ -x "$dir/node_modules/.bin/prettier" ] || unready="hollow"\n', '')],
 "Q12_npmrc_not_copied": [("for f in package.json package-lock.json npm-shrinkwrap.json .npmrc; do", "for f in package.json package-lock.json npm-shrinkwrap.json; do")],
 "Q13_ceiling_length_guard_dropped": [('[ "${#FORMAT_GATE_INSTALL_TIMEOUT}" -gt 6 ] && _bad=1', ':')],
 "Q14_sweep_before_install_removed_AND_dead_pid_check_inverted": [("        ps -p \"$pid\" >/dev/null 2>&1 && continue\n", "        ps -p \"$pid\" >/dev/null 2>&1 || continue\n")],
}
H = {
 "C2_hook_gate_call_removed": [('printf \'%s\\n\' "$all_changed" | FORMAT_GATE_BASE_MAY_BE_STALE="$st_base_stale" bash "$_fmt_gate" || {', 'true || {')],
 "C3_hook_exits_0_first": [("#!/bin/sh\n", "#!/bin/sh\nexit 0\n")],
 "QH1_no_upstream_not_flagged_stale": [("    st_base_stale=1   # KS-998 item 1: a merge-base", "    st_base_stale=0   # KS-998 item 1: a merge-base")],
 "QH2_flag_compares_full_upstream_name": [('if [ -n "$_st_up" ] && [ "${_st_up#*/}" != "$_st_br" ]; then st_base_stale=1; fi', 'if [ -n "$_st_up" ] && [ "$_st_up" != "$_st_br" ]; then st_base_stale=1; fi')],
}
for name, reps in G.items():
    s = gate
    for a, b in reps:
        n = s.count(a); assert n == 1, (name, n, a)
        s = s.replace(a, b)
    open(f"{W}/mut/{name}.gate.sh", "w").write(s)
for name, reps in H.items():
    s = hook
    for a, b in reps:
        n = s.count(a); assert n == 1, (name, n, a)
        s = s.replace(a, b)
    open(f"{W}/mut/{name}.hook.sh", "w").write(s)
print("ok", len(G), len(H))
