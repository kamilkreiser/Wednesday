#!/bin/bash
# runmut.sh: run each mutant through the suites; one line per mutant.
W=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/087c4316-bb15-4161-a5ec-601b737a6e98/scratchpad/g1532
export TMPDIR=$W/tmp
H=$W/head
GS=$H/systemTest/__tests__/package_format_gate.test.sh
KS=$H/Blockchain/Dev/scripts/__tests__/ks998_pre_push_stale_base_hint.test.sh
PB=$H/Blockchain/Dev/scripts/__tests__/pre_push_hook_base.test.sh
mkdir -p $W/ev/mut
summ() { local log=$1; local t; t=$(grep -E '[0-9]+ passed, [0-9]+ failed' $log | tail -1 | grep -oE '[0-9]+ passed, [0-9]+ failed'); echo "${t:-NO-TRAILER}"; }
first() { grep -E '^\s*FAIL ' $1 | head -2 | sed 's/^ *FAIL //' | cut -c1-110 | tr '\n' '|'; }
for m in ${ONLY:-$(ls $W/mut)}; do
  n=${m%%.*}
  if [[ $m == *.gate.sh ]]; then
    PACKAGE_FORMAT_GATE_SH=$W/mut/$m /bin/bash $GS > $W/ev/mut/$n.gate_suite.log 2>&1; r1=$?
    PACKAGE_FORMAT_GATE_SH=$W/mut/$m /bin/bash $KS > $W/ev/mut/$n.hook_suite.log 2>&1; r2=$?
    echo "$n | gate suite rc=$r1 [$(summ $W/ev/mut/$n.gate_suite.log)] first: $(first $W/ev/mut/$n.gate_suite.log) | hook suite rc=$r2 [$(summ $W/ev/mut/$n.hook_suite.log)]"
  else
    HOOK_SH=$W/mut/$m /bin/bash $KS > $W/ev/mut/$n.hook_suite.log 2>&1; r1=$?
    HOOK_SH=$W/mut/$m /bin/bash $PB > $W/ev/mut/$n.base_suite.log 2>&1; r2=$?
    echo "$n | hook suite rc=$r1 [$(summ $W/ev/mut/$n.hook_suite.log)] first: $(first $W/ev/mut/$n.hook_suite.log) | base suite rc=$r2 [$(summ $W/ev/mut/$n.base_suite.log)] first: $(first $W/ev/mut/$n.base_suite.log)"
  fi
done
