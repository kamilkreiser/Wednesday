#!/usr/bin/env bash
# =============================================================================
# The systemTest/* formatting gate (KS-989)
# =============================================================================
# THE DEFECT THIS EXISTS FOR: nothing between a developer's keyboard and
# `develop` ran the per-package format gates for `systemTest/*`. So a docs-only
# or test-only edit under `systemTest/` could turn `npm run format:check` red in
# a package, the author who made it never saw a failure, and the next unrelated
# author to touch that package inherited the red — usually days later, with no
# link back to the commit that caused it.
#
# Three places could have caught it and none of them looked:
#   * `.githooks/pre-push` scopes itself to `^Blockchain/Dev/` — DELIBERATELY,
#     and its own header says so ("skips instantly for vault-only / docs-only /
#     systemTest-only pushes"). The design priced a systemTest-only push as
#     costless. It is not.
#   * `preflight.sh` is invoked BY that hook, so it never ran for these pushes.
#   * GitHub Actions is retired (Kam, 2026-08-27), so there was no backstop.
#
# SIX instances in nine days, three of them found and fixed by someone other
# than the author who caused them (KS-702/#754, KS-706/#755, KS-711/#758,
# KS-707, instance 5 on the trunk at 400517aaf, instance 6 on the trunk at
# 986c592d5). Instance 6 is the one that earned this script: it entered on
# `42e778203` and rode to develop in merge `512480ef1` (#892) — a merge whose
# whole PR lived under `systemTest/`, so the hook skipped it exactly as designed
# and a red sat on the trunk for three hours with nothing looking at it.
#
# --- WHY `format:check` AND NOT `quality` (KS-990) ---------------------------
# `npm run quality` CANNOT PASS in `systemTest/performance` or `systemTest/akto`
# today, for pre-existing reasons unrelated to formatting (a TS2540 read-only
# assignment; two unused knip exports). Wiring `quality` here would produce a
# gate that can never pass — and a gate that can never pass gets bypassed, which
# is the behaviour this ticket exists to stop. It would manufacture it.
# `format:check` is the leg that fires in every instance above, it is green in
# every package as of this commit, and it costs 0–2s per package.
# When KS-990 is closed, widening this to `quality` is a one-word change here.
#
# --- USAGE -------------------------------------------------------------------
#     printf '%s\n' "$paths" | bash systemTest/scripts/check-package-format.sh
#     bash systemTest/scripts/check-package-format.sh --all
#     bash systemTest/scripts/check-package-format.sh --list
#
# Paths on stdin are repo-relative (what `git diff --name-only` emits). Only the
# packages those paths land in are checked. `--all` checks every package and is
# what the caller uses when it cannot compute a reliable changed set — see the
# KS-854/KS-882 note in the hook: an uncomputable base is not a clean tree.
#
# --- PACKAGES ARE DISCOVERED, NOT LISTED -------------------------------------
# Any `systemTest/*/package.json` carrying a `format:check` script is in scope.
# A hardcoded list is a second implementation that something has to keep in
# agreement with reality, and nothing would — the same reasoning that makes
# `run-shell-suites.sh` a glob rather than three pasted copies. Add a package
# with a `format:check` script and it is gated automatically.
# =============================================================================

# --- KS-998 ITEM 1: AN ABSENT node_modules IS INSTALLED, NOT SKIPPED ----------
# Kam's card (secuura-ks998-formatting-gate-fails-open-on-missing-prettier, option
# a): "Hard-fail only when a tracked file of the package is in the push" - and
# "install it also". Before this, a package whose deps were absent was a named
# SKIP, and a push could pass having checked nothing in it. Now:
#
#   node_modules ABSENT   -> `npm ci` runs in a STAGING DIR on the same filesystem
#                            (systemTest/.format-gate-stage.<pid>.<random>, gitignored),
#                            and node_modules is RENAMED into the package only if the
#                            install succeeded and prettier is executable. A failed,
#                            timed-out or KILLED install therefore never leaves a
#                            partial node_modules in the package for the next push to
#                            read as "present, no prettier". Four named outcomes:
#                              INSTALLED
#                              could not install  -> SKIP (--all) / REFUSED (normal)
#                              install timed out after <n>s -> SKIP / REFUSED
#                              install not attempted (the breaker, below) -> SKIP / REFUSED
#   node_modules PRESENT, no prettier -> NEVER reinstalled over (`npm ci` wipes it):
#                            REFUSED in normal mode with the command printed, a named
#                            SKIP in --all mode.
#
# WHY normal mode REFUSES and --all SKIPS. In normal mode every selected package was
# selected BECAUSE a path of it is in the push - that is Kam's condition, evaluated.
# --all is what the hook uses when the changed set cannot be computed (KS-854/KS-882:
# no base, or a base that contains HEAD). There the condition "a tracked file of the
# package is in the push" CANNOT BE EVALUATED, so the named SKIP stays and only
# KS-1063 refuses, when NOTHING was checked.
#
# THE WATCHDOG. A wall-clock ceiling (default 120 s, FORMAT_GATE_INSTALL_TIMEOUT to
# override) kills the install. It is not redundant with `--fetch-timeout=20000`:
# measured on npm 11.5.1 against a registry that ACCEPTS the connection and never
# answers, that flag did NOT end the install (it ran to a 100 s cap and was TERMed).
# The ceiling is the only bound for that shape; nothing is claimed for the flag. (The shape
# was a listener that accepts TCP connections and sends nothing; tarball fetches and the
# update check both stalled on it.) The
# outcome is keyed on the EXIT CODE and on the artefact (prettier executable), never
# on what npm printed. `--fetch-retries=0` is what makes a plainly-unreachable
# registry fail in under two seconds: npm's own retry schedule took 70.4 s for the
# same install. `--no-update-notifier` is a deliberate addition to the ruled command
# line: with a cold cache against the real registry, default `npm ci` makes exactly ONE
# request outside the lockfile's resolved set in each of the four packages -
# `GET https://registry.npmjs.org/npm`, the update check, made even with stdout not a
# TTY - and with the flag that count is 0 in all four. It also removes one place to stall.
#
# THE BREAKER. One install that TIMES OUT means the registry is silent, and every
# further install would wait out the ceiling too (4 packages x 120 s = 8 minutes, on
# top of a preflight that already takes ~8 and an SSH idle cutoff near 6). After a
# timeout the remaining absent packages are NOT attempted, and say so. A fast failure
# does not trip it.
#
# WHAT THE INSTALL RUNS. `npm ci` with no --ignore-scripts, so the lockfile-pinned
# dependencies' lifecycle scripts run on the developer's push (fsevents in all four
# lockfiles; esbuild in performance and playwright; tsx/esbuild in akto) - exactly what
# the printed remedy `npm ci` does by hand. --ignore-scripts was not added because a
# node_modules whose scripts never ran looks complete and is not. The stage holds only
# package.json, the lockfile and .npmrc, so a root lifecycle script or a dependency that
# resolves relative to the package directory cannot be installed there; none of the four
# packages has either (a relative link to ../../observability resolves identically from
# the stage, which sits at the same depth as a package).
#
# INTERRUPTION. SIGTERM / SIGINT / SIGHUP kill npm and remove the stage. SIGKILL (or
# the machine dying) cannot be trapped: what survives is one orphaned, gitignored
# stage dir - never a partial node_modules in a package - and the next run sweeps a
# stage whose pid is dead.
#
# THE HOOK TELLS THE GATE WHEN THE BASE MAY BE STALE (KS-1422): FORMAT_GATE_BASE_MAY_BE_
# STALE=1 means the changed set was computed against a ref that is not the pushed
# branch's own remote counterpart (a stale origin/develop then names packages the
# author never touched). A refusal then says so and what to do. It changes no decision.
#
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

MODE="stdin"
case "${1:-}" in
    --all)   MODE="all" ;;
    --list)  MODE="list" ;;
    "")      MODE="stdin" ;;
    *) echo "usage: check-package-format.sh [--all|--list]  (default: repo-relative paths on stdin)" >&2; exit 2 ;;
esac

# --- KS-998 item 1: the install ceiling, validated rather than guessed at ----------
# Unset or set-but-empty is the default. Anything else must be a whole number of
# seconds >= 1 (no leading zero: `08` is an octal error in bash arithmetic).
INSTALL_CEILING=120
if [ -n "${FORMAT_GATE_INSTALL_TIMEOUT:-}" ]; then
    case "$FORMAT_GATE_INSTALL_TIMEOUT" in
        *[!0-9]*|0*) _bad=1 ;;
        *)           _bad=0; [ "${#FORMAT_GATE_INSTALL_TIMEOUT}" -gt 6 ] && _bad=1 ;;
    esac
    if [ "$_bad" -ne 0 ]; then
        echo "[format-gate] FORMAT_GATE_INSTALL_TIMEOUT must be a whole number of seconds, 1 or more (got '${FORMAT_GATE_INSTALL_TIMEOUT}')." >&2
        exit 2
    fi
    INSTALL_CEILING="$FORMAT_GATE_INSTALL_TIMEOUT"
fi
# Set by the hook (see the header): the changed set came from a ref that may be stale.
BASE_MAY_BE_STALE=0
[ "${FORMAT_GATE_BASE_MAY_BE_STALE:-0}" = "1" ] && BASE_MAY_BE_STALE=1

# --- the toolchain, or an honest skip ----------------------------------------
# npm/node missing is an ENVIRONMENT condition, not a finding. KS-991 exists
# because an environment condition was presented as a gate failure and cost a
# diagnosis five times in one day. Say which it is.
if ! command -v npm >/dev/null 2>&1 || ! command -v node >/dev/null 2>&1; then
    echo "[format-gate] SKIP (advisory) — node/npm not on PATH; cannot check systemTest formatting."
    exit 0
fi

# --- KS-998 item 1: the install machinery --------------------------------------
now_ms()    { node -e 'process.stdout.write(String(Date.now()))'; }
fmt_secs()  { printf '%d.%d' $(( $1 / 1000 )) $(( ($1 % 1000) / 100 )); }

# Staging dirs live in systemTest/ (same filesystem as every package, so the final
# move is a rename, not a copy) and are gitignored. A leading dot keeps them out of
# the `systemTest/*/package.json` discovery glob above (bash's `*` skips dotfiles).
STAGE_PREFIX="$REPO_ROOT/systemTest/.format-gate-stage."

# The ONLY place this script deletes a directory, and it deletes only what it made:
# the path must be a single component under systemTest/ with exactly that prefix,
# must exist, and must not be a symlink (a symlink is never followed).
_rm_stage() {
    local d="${1:-}" rest
    case "$d" in "$STAGE_PREFIX"*) ;; *) return 1 ;; esac
    rest="${d#"$STAGE_PREFIX"}"
    case "$rest" in ''|*/*|*..*) return 1 ;; esac
    [ -d "$d" ] && [ ! -L "$d" ] || return 1
    rm -rf "$d"
}

# A stage whose pid is DEAD was left by a run that was killed (SIGKILL cannot be
# trapped). Swept, with the same guards. A live pid, a non-numeric pid (death cannot
# be proved) and a symlink are all left alone. `ps -p` rather than `kill -0`: the
# latter reports EPERM, i.e. "failed", for a live process owned by someone else.
_sweep_dead_stages() {
    local d rest pid
    for d in "$REPO_ROOT"/systemTest/.format-gate-stage.*; do
        [ -L "$d" ] && continue
        [ -d "$d" ] || continue
        rest="${d#"$STAGE_PREFIX"}"
        pid="${rest%%.*}"
        case "$pid" in ''|*[!0-9]*) continue ;; esac
        ps -p "$pid" >/dev/null 2>&1 && continue
        _rm_stage "$d"
    done
}

_FG_NPM_PID=""; _FG_WD_PID=""; _FG_STAGE=""
_fg_cleanup() {
    local i=0
    if [ -n "$_FG_WD_PID" ]; then kill "$_FG_WD_PID" 2>/dev/null; _FG_WD_PID=""; fi
    if [ -n "$_FG_NPM_PID" ]; then
        kill -TERM "$_FG_NPM_PID" 2>/dev/null
        while kill -0 "$_FG_NPM_PID" 2>/dev/null && [ "$i" -lt 20 ]; do sleep 0.1; i=$((i + 1)); done
        kill -KILL "$_FG_NPM_PID" 2>/dev/null
        _FG_NPM_PID=""
    fi
    if [ -n "$_FG_STAGE" ]; then _rm_stage "$_FG_STAGE"; _FG_STAGE=""; fi
}
trap '_fg_cleanup' EXIT
trap '_fg_cleanup; exit 130' INT
trap '_fg_cleanup; exit 143' TERM
trap '_fg_cleanup; exit 129' HUP

# run_install <pkg> <dir>
# Sets INST_STATE: ok | raced | noprettier | mvfail | failed | timeout
#      INST_RC, INST_MS, INST_TAIL (the last lines npm printed - shown, never read).
run_install() {
    local p="$1" dir="$2" stage marker log f wd t0 t1
    INST_STATE="failed"; INST_RC=0; INST_MS=0; INST_TAIL=""
    stage="$(mktemp -d "${STAGE_PREFIX}$$.XXXXXX" 2>/dev/null)" || {
        INST_STATE="nostage"; INST_RC=1; return 0
    }
    _FG_STAGE="$stage"
    for f in package.json package-lock.json npm-shrinkwrap.json .npmrc; do
        [ -f "$dir/$f" ] && cp "$dir/$f" "$stage/$f"
    done
    marker="$stage/.timed-out"
    log="$stage/.npm-ci.log"
    t0="$(now_ms)"
    # `exec` so $! is npm itself; stdin from /dev/null so a child that reads stdin cannot
    # swallow the package list this script is looping over (KS-998 robustness note).
    ( cd "$stage" && exec npm ci --no-audit --no-fund --no-update-notifier --fetch-retries=0 --fetch-timeout=20000 ) </dev/null >"$log" 2>&1 &
    _FG_NPM_PID=$!
    # The watchdog polls once a second and exits on its own when npm does; its stdio is
    # closed so it can never hold a caller's $(...) pipe open.
    (
        _i=0
        while [ "$_i" -lt "$INSTALL_CEILING" ]; do
            sleep 1
            kill -0 "$_FG_NPM_PID" 2>/dev/null || exit 0
            _i=$((_i + 1))
        done
        : > "$marker"
        kill -TERM "$_FG_NPM_PID" 2>/dev/null
        sleep 2
        kill -KILL "$_FG_NPM_PID" 2>/dev/null
    ) </dev/null >/dev/null 2>&1 &
    _FG_WD_PID=$!
    wait "$_FG_NPM_PID" 2>/dev/null; INST_RC=$?
    kill "$_FG_WD_PID" 2>/dev/null; wait "$_FG_WD_PID" 2>/dev/null
    _FG_NPM_PID=""; _FG_WD_PID=""
    t1="$(now_ms)"; INST_MS=$((t1 - t0))

    if [ "$INST_RC" -ne 0 ] && [ -e "$marker" ]; then
        INST_STATE="timeout"
    elif false; then
        INST_STATE="failed"
    elif [ ! -x "$stage/node_modules/.bin/prettier" ]; then
        INST_STATE="noprettier"
    elif [ -e "$dir/node_modules" ] || [ -L "$dir/node_modules" ]; then
        # Someone made node_modules while we installed. `mv a b` onto an existing
        # directory moves a INSIDE b, so look again and keep the one that arrived.
        INST_STATE="raced"
    elif mv "$stage/node_modules" "$dir/node_modules" 2>/dev/null; then
        if [ -x "$dir/node_modules/.bin/prettier" ]; then
            INST_STATE="ok"
        else
            # Prettier ran from the stage and does not run from here: the install embeds its own
            # path (an absolute symlink, say). Leaving this node_modules in the package would be
            # the very state staging exists to prevent - "present, no prettier" - so rename it
            # BACK into the stage, which is then removed. Not reproduced for any of the four
            # lockfiles (0 files embed the stage path).
            mv "$dir/node_modules" "$stage/node_modules" 2>/dev/null
            INST_STATE="mvbroken"
        fi
    else
        INST_STATE="mvfail"
    fi
    if [ "$INST_STATE" != "ok" ] && [ "$INST_STATE" != "raced" ] && [ -f "$log" ]; then
        INST_TAIL="$(tail -n 6 "$log" 2>/dev/null)"
    fi
    _rm_stage "$stage"; _FG_STAGE=""
    return 0
}

# first_path_under <pkg>: the first changed path that selected this package (normal mode)
first_path_under() {
    printf '%s\n' "$changed_paths" | awk -v pre="systemTest/$1/" 'index($0, pre) == 1 { print; exit }'
}

# emit_refusal <pkg> <what>: normal mode, Kam's condition ("a tracked file of the
# package is in the push") evaluated and met; the gate could not run on the package.
emit_refusal() {
    local p="$1" what="$2" sel
    sel="$(first_path_under "$p")"
    {
        echo "[format-gate] REFUSED — systemTest/$p: ${what}, and a file of this package is in the push."
        echo "[format-gate]   selected by: ${sel}"
        echo "[format-gate]   This is NOT a formatting failure: the gate could not run on this package."
        if [ -n "${INST_TAIL:-}" ]; then
            echo "[format-gate]   npm output (last lines, shown as printed, not interpreted):"
            printf '%s\n' "$INST_TAIL" | sed 's/^/[format-gate]   | /'
        fi
        echo "[format-gate]   fix: (cd systemTest/$p && npm ci)"
        if [ "${INST_STATE:-}" = "timeout" ]; then
            echo "[format-gate]   a slow link needs longer: FORMAT_GATE_INSTALL_TIMEOUT=<seconds> (now ${INSTALL_CEILING})"
        fi
        if [ "$BASE_MAY_BE_STALE" -eq 1 ]; then
            echo "[format-gate]   If you did not touch systemTest/$p, your origin/develop may be stale: run git fetch origin and push again."
        fi
    } >&2
}

# --- discover the packages ----------------------------------------------------
# bash 3.2 (what macOS ships, and what the pre-push hook runs) has no
# associative arrays and no mapfile. Plain arrays and a newline-delimited string
# only.
packages=()
for pj in "$REPO_ROOT"/systemTest/*/package.json; do
    [ -e "$pj" ] || continue          # an empty glob expands to itself
    dir="$(dirname "$pj")"
    node -e '
        const s = (require(process.argv[1]).scripts) || {};
        process.exit(s["format:check"] ? 0 : 1);
    ' "$pj" >/dev/null 2>&1 || continue
    packages+=("$(basename "$dir")")
done

# `"${arr[@]}"` on an EMPTY array under `set -u` raises "unbound variable" on
# bash 3.2 — and inside a command substitution that error goes to stderr,
# nothing reads it, and the assignment silently yields "". Same trap
# run-shell-suites.sh carries at QA R2-2. Use the +alternate form throughout.
if [ "${#packages[@]}" -eq 0 ]; then
    echo "[format-gate] SKIP (advisory) — no systemTest package declares a format:check script."
    exit 0
fi

if [ "$MODE" = "list" ]; then
    printf '%s\n' "${packages[@]+"${packages[@]}"}"
    exit 0
fi

# --- select the packages this run covers --------------------------------------
changed_paths=""
selected=""
if [ "$MODE" = "all" ]; then
    for p in "${packages[@]+"${packages[@]}"}"; do
        selected="${selected}${p}
"
    done
else
    changed_paths="$(cat)"
    for p in "${packages[@]+"${packages[@]}"}"; do
        if printf '%s\n' "$changed_paths" | grep -q "^systemTest/${p}/"; then
            selected="${selected}${p}
"
        fi
    done
fi

selected="$(printf '%s' "$selected" | grep -v '^$' || true)"
if [ -z "$selected" ]; then
    exit 0                            # nothing under a gated package — say nothing, cost nothing
fi

# --- run it -------------------------------------------------------------------
failed=0
skipped=0
checked=0
refused=0          # KS-998 item 1: could not be checked, and a file of it is in the push
installed=0        # KS-998 item 1: node_modules was absent and was installed this run
BREAKER_PKG=""      # KS-998 item 1: set to the first package whose install TIMED OUT

# A stage whose run was SIGKILLed is garbage; remove it before making new ones.
_sweep_dead_stages

# Read the selection line by line rather than relying on word splitting: this
# file is bash, but the same loop pasted into a zsh shell would not split at all
# and would run zero packages while reporting a clean pass.
while IFS= read -r p; do
    [ -n "$p" ] || continue
    dir="$REPO_ROOT/systemTest/$p"

    # Deps absent. KS-991: an environment condition, never presented as a formatting
    # red. KS-1063: if EVERY selected package is skipped the run examined nothing and
    # is refused below. KS-998 item 1: an ABSENT node_modules is now INSTALLED first;
    # only when that cannot be done does the package fall to the SKIP (--all) or the
    # REFUSAL (normal mode, where a path of the package is in the push by construction).
    if [ ! -x "$dir/node_modules/.bin/prettier" ]; then
        unready=""                       # set to a state name when the package cannot be checked
        INST_STATE=""; INST_RC=0; INST_MS=0; INST_TAIL=""
        if [ -e "$dir/node_modules" ] || [ -L "$dir/node_modules" ]; then
            unready="hollow"             # present: `npm ci` would WIPE it, so never install over it
        elif [ -n "$BREAKER_PKG" ]; then
            unready="notattempted"
        else
            echo "[format-gate] systemTest/$p has no node_modules — installing with npm ci in a staging dir (ceiling ${INSTALL_CEILING}s). This runs the dependency install scripts from the lockfile, exactly as a manual npm ci does."
            run_install "$p" "$dir"
            case "$INST_STATE" in
                ok)
                    installed=$((installed + 1))
                    echo "[format-gate] INSTALLED — systemTest/$p: npm ci succeeded in $(fmt_secs "$INST_MS")s and node_modules was moved into place."
                    ;;
                raced)
                    echo "[format-gate] systemTest/$p: node_modules appeared during the install; keeping the one already there, not replacing it."
                    [ -x "$dir/node_modules/.bin/prettier" ] || unready="hollow"
                    ;;
                timeout)
                    unready="timeout"; BREAKER_PKG="$p"
                    ;;
                *)
                    unready="$INST_STATE"
                    ;;
            esac
        fi

        if [ -n "$unready" ]; then
            secs_txt="$(fmt_secs "$INST_MS")"
            case "$unready" in
                failed)       why_ref="could not install its deps (npm ci exited ${INST_RC} after ${secs_txt}s)"
                              why_skip=" and could not be installed (npm ci exited ${INST_RC} after ${secs_txt}s)" ;;
                noprettier)   why_ref="could not install its deps (npm ci exited 0 after ${secs_txt}s but node_modules/.bin/prettier is still absent)"
                              why_skip=" and could not be installed (npm ci exited 0 after ${secs_txt}s but node_modules/.bin/prettier is still absent)" ;;
                nostage)      why_ref="could not install its deps (a staging directory could not be created under systemTest/ - is it writable?)"
                              why_skip=" and could not be installed (a staging directory could not be created under systemTest/ - is it writable?)" ;;
                mvbroken)     why_ref="could not install its deps (the install embeds its staging path: prettier is not executable after the move, so node_modules was moved back out)"
                              why_skip=" and could not be installed (the install embeds its staging path: prettier is not executable after the move, so node_modules was moved back out)" ;;
                mvfail)       why_ref="could not install its deps (the staged node_modules could not be moved into place)"
                              why_skip=" and could not be installed (the staged node_modules could not be moved into place)" ;;
                timeout)      why_ref="install timed out after ${INSTALL_CEILING}s"
                              why_skip=": install timed out after ${INSTALL_CEILING}s" ;;
                notattempted) why_ref="install not attempted: the install of systemTest/${BREAKER_PKG} timed out after ${INSTALL_CEILING}s, so the registry is treated as unreachable for the rest of this run"
                              why_skip=": install not attempted: the install of systemTest/${BREAKER_PKG} timed out after ${INSTALL_CEILING}s, so the registry is treated as unreachable for the rest of this run" ;;
                hollow)       why_ref="node_modules exists but has no prettier, so it was not reinstalled over"
                              why_skip=" (node_modules exists but has no prettier; not reinstalled over it)" ;;
            esac
            if [ "$MODE" = "all" ]; then
                # --all has no changed set, so Kam's condition cannot be evaluated: named SKIP.
                echo "[format-gate] SKIP — systemTest/$p deps not installed${why_skip} — skipped; --all: there is no changed set, so \"a file of this package is in the push\" cannot be evaluated. Remedy: npm ci in systemTest/$p."
                skipped=$((skipped + 1))
            else
                INST_STATE="$unready"
                emit_refusal "$p" "$why_ref"
                refused=$((refused + 1))
            fi
            continue
        fi
    fi

    # KS-998: `< /dev/null`. This loop reads its package list from the
    # here-string at its `done` on stdin, and npm hands its stdin to the script:
    # a format:check that reads stdin would swallow every package after it.
    out="$(cd "$dir" && npm run --silent format:check < /dev/null 2>&1)"
    rc=$?
    checked=$((checked + 1))
    if [ "$rc" -eq 0 ]; then
        echo "[format-gate] systemTest/$p — format:check OK"
        continue
    fi

    failed=$((failed + 1))
    echo "[format-gate] systemTest/$p — format:check FAILED" >&2

    warns="$(printf '%s\n' "$out" | grep '^\[warn\] ' | grep -v 'Code style issues' || true)"

    # A non-zero exit with NO warn lines is not "no problems found" — it is an
    # unexplained failure, and reporting it as clean is the exact shape of a
    # check that cannot fail. Print what actually came back.
    if [ -z "$warns" ]; then
        echo "[format-gate]   prettier exited $rc but named no files. Raw output:" >&2
        printf '%s\n' "$out" | sed 's/^/[format-gate]   | /' >&2
        continue
    fi

    printf '%s\n' "$warns" | while IFS= read -r w; do
        rel="${w#\[warn\] }"
        full="systemTest/$p/$rel"
        # Whose red is this? The whole point of the ticket is that the bill
        # lands on the wrong person. If the file is not in this push, say so —
        # the reader should not have to work that out.
        # KS-998: -qxF, not -qx — before, "$full" was read as a PATTERN, so a path
        # containing a regex metacharacter could match the wrong line or none at all,
        # and the "(in this push)" label was not a literal statement about this push.
        if [ "$MODE" != "all" ] && printf '%s\n' "$changed_paths" | grep -qxF "$full"; then
            echo "[format-gate]   $full   (in this push)" >&2
        elif [ "$MODE" = "all" ]; then
            echo "[format-gate]   $full" >&2
        else
            echo "[format-gate]   $full   (NOT in this push — inherited red)" >&2
        fi
    done

    echo "[format-gate]   fix: (cd systemTest/$p && npm run format)" >&2
# A here-string, NOT a pipe: `... | while read` puts the loop in a SUBSHELL, so
# every counter below would be incremented in a child and read back as 0 here —
# a gate that always reports "0 failed" no matter what prettier said.
done <<< "$selected"

trailer="${checked} package(s) checked, ${skipped} skipped, ${failed} failed"
[ "$refused" -gt 0 ]   && trailer="${trailer}, ${refused} refused"
[ "$installed" -gt 0 ] && trailer="${trailer}, ${installed} installed"
echo "[format-gate] ${trailer}"

# KS-1063 (Peter, 2026-09-29): a gate that examined NOTHING must not pass. This
# used to fall through to `[ "$failed" -eq 0 ]` and exit 0 on "0 checked, N
# skipped" — the same observable as a clean check, on exactly the systemTest-only
# pushes where this is the only gate that applies (the hook skips the platform
# preflight for them by design). It now refuses, and says in words that nothing
# was checked and that this is NOT a formatting failure, with the command that
# fixes it — the shape preflight leg 1 uses for DEPS MISSING. A run that checked
# at least one package still passes on its own verdict; the skips stay named above.
# A REFUSED package already said, in words, why the gate could not run; do not also claim
# that "every selected package was skipped" when one was refused.
if [ "$checked" -eq 0 ] && [ "$skipped" -gt 0 ] && [ "$refused" -eq 0 ]; then
    {
        echo "[format-gate] NOTHING CHECKED — every selected package was skipped, so no file's formatting was examined."
        echo "[format-gate]   This is NOT a formatting failure: the gate could not run. Install the deps it names above"
        echo "[format-gate]   (npm ci in each skipped systemTest/<package>), then push again."
    } >&2
    exit 1
fi
[ "$failed" -eq 0 ] && [ "$refused" -eq 0 ]
