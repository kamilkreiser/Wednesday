#!/bin/bash
W=/private/tmp/claude-501/gateA-170314/wt
for side in dev green1552; do
  echo "=== side $side ($(git -C $W/$side rev-parse --short HEAD))"
  for t in $W/$side/Blockchain/Dev/scripts/__tests__/preflight_*.test.sh $W/$side/Blockchain/Dev/scripts/__tests__/pre_push_*leg*.test.sh $W/$side/Blockchain/Dev/scripts/__tests__/ks1547_*.test.sh; do
    [ -f "$t" ] || { echo "MISSING $t"; continue; }
    out=$(/bin/bash "$t" 2>&1); rc=$?
    summ=$(printf '%s\n' "$out" | grep -iE 'passed|failed|PASS:|FAIL:|[0-9]+/[0-9]+' | tail -1)
    nf=$(printf '%s\n' "$out" | grep -cE '^(FAIL|not ok)')
    printf '%-60s rc=%s failLines=%s | %s\n' "$(basename $t)" "$rc" "$nf" "$summ"
  done
done
