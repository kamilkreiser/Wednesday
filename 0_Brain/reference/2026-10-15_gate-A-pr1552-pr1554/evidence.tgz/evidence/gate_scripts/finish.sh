#!/bin/bash
E=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-15_gate-A-pr1552-pr1554/evidence
V=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-15_gate-A-pr1552-pr1554/verdict.md
S=/private/tmp/claude-501/gateA-170314
cp $S/runs/shellsuites_dev.txt $E/shellsuites_runner_develop.txt
cp $S/runs/shellsuites_green1552.txt $E/shellsuites_runner_pr1552.txt
cp $S/runs/shellsuites_summary.txt $E/shellsuites_runner_summary.txt
cp -R $S/scripts $E/gate_scripts
cp $S/probe/probe1542.ts $E/gate_scripts/
TXT='develop 86 passed / 2 failed of 88; PR (develop+1552) 87 passed / 2 failed of 89 (the +1 is the new ks1547 suite, green). The same two fail on both sides for environmental reasons in an uninstalled worktree: `ks949_main_seed_idempotence` ("packages/shared is not built ... dist/index.js missing", aborted at cell 1) and `preflight_test_types_ratchet_leg` (no workspace install). The author's in-hook 89/89 and 88/88 are therefore consistent but were not reproduced at full green here (`evidence/shellsuites_runner_*.txt`).'
/usr/bin/perl -0pi -e 's/SHELL_SUITES_PLACEHOLDER/'"$(printf '%s' "$TXT" | sed 's/[\/&]/\\&/g')"'/' $V
grep -c PLACEHOLDER $V
H=$(sed '3d' $V | shasum -a 256 | cut -c1-16)
/usr/bin/perl -pi -e "s/^SHA256_16_PLACEHOLDER\$/sha256\/16 (line 3 deleted, rest hashed): $H/ if \$. == 3" $V
sed -n 1,3p $V
echo "recheck: $(sed '3d' $V | shasum -a 256 | cut -c1-16)"
