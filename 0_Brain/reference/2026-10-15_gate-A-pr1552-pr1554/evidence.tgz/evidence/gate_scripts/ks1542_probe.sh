#!/bin/bash
W=/private/tmp/claude-501/gateA-170314/wt/gw1554
G=$W/Blockchain/Dev/services/api-gateway
V=Blockchain/Dev/services/api-gateway/src/routes/verification.ts
TSX=$W/Blockchain/Dev/node_modules/.bin/tsx
echo "=== PR1554 head product (blob $(git -C $W hash-object $V))"
$TSX /private/tmp/claude-501/gateA-170314/probe/probe1542.ts $G/src/routes/verification $W/Blockchain/Dev/node_modules/express 2>&1
git -C $W checkout origin/develop -- $V
echo "=== develop product (blob $(git -C $W hash-object $V))"
$TSX /private/tmp/claude-501/gateA-170314/probe/probe1542.ts $G/src/routes/verification $W/Blockchain/Dev/node_modules/express 2>&1
git -C $W checkout HEAD -- $V
echo "restored: $(git -C $W status --porcelain -- $V | wc -l | tr -d ' ') dirty"
