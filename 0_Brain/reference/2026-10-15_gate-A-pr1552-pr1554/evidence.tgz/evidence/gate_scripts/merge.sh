#!/bin/bash
R=/private/tmp/claude-501/gateA-170314/repo
D=$(git -C $R rev-parse origin/develop); A=$(git -C $R rev-parse refs/gate/pr1552); B=$(git -C $R rev-parse refs/gate/pr1554)
echo "develop=$D (ls-remote re-read: $(git -C $R ls-remote origin refs/heads/develop | cut -f1))"
mt() { git -C $R merge-tree --write-tree "$@"; }
echo "--- overlap: files changed vs develop"
git -C $R diff --name-only $D...$A | sort > /private/tmp/claude-501/gateA-170314/runs/fa.txt
git -C $R diff --name-only $D...$B | sort > /private/tmp/claude-501/gateA-170314/runs/fb.txt
echo "1552: $(wc -l < /private/tmp/claude-501/gateA-170314/runs/fa.txt) files, 1554: $(wc -l < /private/tmp/claude-501/gateA-170314/runs/fb.txt) files, common: $(comm -12 /private/tmp/claude-501/gateA-170314/runs/fa.txt /private/tmp/claude-501/gateA-170314/runs/fb.txt | wc -l)"
echo "overlap control (a file set against itself): $(comm -12 /private/tmp/claude-501/gateA-170314/runs/fa.txt /private/tmp/claude-501/gateA-170314/runs/fa.txt | wc -l)"
TA=$(mt $D $A); echo "1552 alone: rc=$? tree=$TA"
TB=$(mt $D $B); echo "1554 alone: rc=$? tree=$TB (pr1554 head tree $(git -C $R rev-parse $B^{tree}); develop is ancestor of 1554: $(git -C $R merge-base --is-ancestor $D $B && echo yes || echo no))"
CA=$(git -C $R commit-tree $TA -p $D -p $A -m "gate sim merge 1552"); CB=$(git -C $R commit-tree $TB -p $D -p $B -m "gate sim merge 1554")
T_AB=$(mt $CA $B); echo "1552 then 1554: rc=$? tree=$T_AB"
T_BA=$(mt $CB $A); echo "1554 then 1552: rc=$? tree=$T_BA"
echo "author predicted 0b5143d06f5c85a21dfac9e56edd7d6d21067c4d"
echo "--- combined tree diff vs develop (names):"; git -C $R diff --stat $D $T_AB | tail -5
echo "--- planted conflicting control: a develop-side commit editing the same lines"
WT=/private/tmp/claude-501/gateA-170314/runs/plant-$(date +%H%M%S); mkdir -p $WT
git -C $R show $D:Blockchain/Dev/scripts/preflight/preflight.sh | sed 's/_hdr_total="\${_hdr_total%% \*}"/_hdr_total="${_hdr_total%%[[:space:]]*}"/' > $WT/pf.sh
git -C $R show $D:Blockchain/Dev/services/api-gateway/src/routes/verification.ts | sed "s/: String(value);/: String(value) \/* planted *\/;/" > $WT/v.ts
cmp -s $WT/pf.sh <(git -C $R show $D:Blockchain/Dev/scripts/preflight/preflight.sh) && echo "PLANT pf DID NOT LAND"
cmp -s $WT/v.ts <(git -C $R show $D:Blockchain/Dev/services/api-gateway/src/routes/verification.ts) && echo "PLANT v DID NOT LAND"
BPF=$(git -C $R hash-object -w $WT/pf.sh); BV=$(git -C $R hash-object -w $WT/v.ts)
export GIT_INDEX_FILE=$WT/index
git -C $R read-tree $D
git -C $R update-index --cacheinfo 100644,$BPF,Blockchain/Dev/scripts/preflight/preflight.sh --cacheinfo 100644,$BV,Blockchain/Dev/services/api-gateway/src/routes/verification.ts
PT=$(git -C $R write-tree); unset GIT_INDEX_FILE
PC=$(git -C $R commit-tree $PT -p $D -m "gate planted conflict")
mt --name-only $PC $A >/dev/null; echo "planted vs 1552: rc=$? (1 = conflict expected)"; mt --name-only $PC $A | sed -n '2,6p'
mt --name-only $PC $B >/dev/null; echo "planted vs 1554: rc=$? (1 = conflict expected)"; mt --name-only $PC $B | sed -n '2,6p'
