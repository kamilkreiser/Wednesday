#!/bin/bash
R=/private/tmp/claude-501/gateA-170314/repo
W=/private/tmp/claude-501/gateA-170314/wt/gw1554
git -C $R worktree add --detach $W refs/gate/pr1554 -q
git -C $W log -1 --format=%H
time npm --prefix $W/Blockchain/Dev ci --no-audit --no-fund --ignore-scripts 2>&1 | tail -5
grep -n '"build"' $W/Blockchain/Dev/packages/shared/package.json
npm --prefix $W/Blockchain/Dev run build -w packages/shared 2>&1 | tail -5
ls $W/Blockchain/Dev/packages/shared/dist | head -5
ls -la $W/Blockchain/Dev/node_modules/@secuura/ | head
