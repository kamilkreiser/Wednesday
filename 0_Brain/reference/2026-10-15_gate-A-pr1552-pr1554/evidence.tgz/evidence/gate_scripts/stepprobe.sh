#!/bin/bash
# usage: stepprobe.sh <preflight.sh> <workdir> header...
PF="$1"; WD="$2"; shift 2
mkdir -p "$WD"
awk '/^fail=0$/{on=1} /^step "1\//{on=0} on' "$PF" > "$WD/helpers.sh"
for h in "$@"; do
  { printf 'set -uo pipefail\nGATEWAY=http://127.0.0.1:9\n'; cat "$WD/helpers.sh"; printf 'step %q\necho STEP-RETURNED\n' "$h"; } > "$WD/run.sh"
  out=$(/bin/bash "$WD/run.sh" 2>&1); rc=$?
  ab=$(printf '%s\n' "$out" | grep 'PREFLIGHT ABORTED' | head -1)
  printf '%q\trc=%s\t%s\n' "$h" "$rc" "${ab:-<no abort>}"
done
