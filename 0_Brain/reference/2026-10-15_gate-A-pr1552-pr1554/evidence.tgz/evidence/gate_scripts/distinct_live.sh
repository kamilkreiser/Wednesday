#!/bin/bash
W2=/private/tmp/claude-501/gateA-170314/wt/gw1554; P2=Blockchain/Dev/services/api-gateway/src/routes/verification.ts; G=$W2/Blockchain/Dev/services/api-gateway
VT=$W2/Blockchain/Dev/node_modules/.bin/vitest; T2=src/__tests__/ks1185-f1-workflow-approve-forward-bound-is-validated.test.ts
perl -0pi -e 's/typeof value === .bigint. \? `\$\{value\}n`/typeof value === "bigint" ? `\${value}`/' $W2/$P2
git -C $W2 diff -U0 -- $P2 | grep -E '^[-+][^-+]'
$VT run --root $G $T2 2>&1 | grep -E '^ +×|^ +Tests ' | sed -E 's/ [0-9]+ms$//'
git -C $W2 checkout HEAD -- $P2; echo "restored dirty=$(git -C $W2 status --porcelain | wc -l | tr -d ' ')"
