#!/bin/bash
R=/private/tmp/claude-501/gateA-170314/repo
W=/private/tmp/claude-501/gateA-170314/wt
E=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-15_gate-A-pr1552-pr1554/evidence
T=Blockchain/Dev/scripts/__tests__/ks1547_preflight_step_header_denominator.test.sh
P=Blockchain/Dev/scripts/preflight/preflight.sh
git -C $R worktree add --detach $W/red1552 origin/develop -q
git -C $W/red1552 checkout refs/gate/pr1552 -- $T
git -C $R worktree add --detach $W/green1552 origin/develop -q
git -C $W/green1552 -c user.name=gate -c user.email=gate@local merge --no-edit -q refs/gate/pr1552
echo "red tree preflight blob: $(git -C $W/red1552 hash-object $P) (develop: $(git -C $R rev-parse origin/develop:$P))"
echo "green tree preflight blob: $(git -C $W/green1552 hash-object $P) (pr: $(git -C $R rev-parse refs/gate/pr1552:$P))"
echo "--- RED (develop product + new test), /bin/bash $(/bin/bash -c 'echo $BASH_VERSION')"
/bin/bash $W/red1552/$T; echo "rc=$?"
echo "--- GREEN (develop + PR1552 merged)"
/bin/bash $W/green1552/$T; echo "rc=$?"
