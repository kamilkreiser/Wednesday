#!/bin/bash
for i in $(seq 1 115); do
  [ "$(grep -c '^rc=' /private/tmp/claude-501/gateA-170314/runs/shellsuites_summary.txt)" -ge 2 ] && break
  sleep 5
done
cat /private/tmp/claude-501/gateA-170314/runs/shellsuites_summary.txt
