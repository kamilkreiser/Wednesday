#!/bin/bash
R=/private/tmp/claude-501/gateA-170314/repo
E=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-15_gate-A-pr1552-pr1554/evidence
D=origin/develop
for p in 1552 1554; do
  mb=$(git -C $R merge-base $D refs/gate/pr$p)
  echo "== PR $p merge-base $mb"
  git -C $R log --oneline $D..refs/gate/pr$p
  git -C $R diff --stat $mb refs/gate/pr$p
  git -C $R diff $mb refs/gate/pr$p > $E/pr${p}_diff_vs_mergebase.patch
  git -C $R diff $D...refs/gate/pr$p --name-only
done
git -C $R log -1 --format='%H %P %s' refs/gate/pr1554
git -C $R log --format='%h %P %s' -5 refs/gate/pr1552
