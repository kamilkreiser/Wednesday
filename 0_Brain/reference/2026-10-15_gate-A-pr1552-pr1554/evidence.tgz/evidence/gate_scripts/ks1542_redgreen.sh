#!/bin/bash
W=/private/tmp/claude-501/gateA-170314/wt/gw1554
G=$W/Blockchain/Dev/services/api-gateway
V=Blockchain/Dev/services/api-gateway/src/routes/verification.ts
T=src/__tests__/ks1185-f1-workflow-approve-forward-bound-is-validated.test.ts
VT=$W/Blockchain/Dev/node_modules/.bin/vitest
echo "=== GREEN: PR1554 head (product blob $(git -C $W hash-object $V))"
(  $VT run --root $G $T --reporter=verbose 2>&1 ) | grep -E "✓|✗|×|FAIL|Tests|Test Files|AssertionError|Expected|Received" | head -80
git -C $W checkout origin/develop -- $V
echo "=== RED: develop product + PR test (product blob $(git -C $W hash-object $V))"
(  $VT run --root $G $T --reporter=verbose 2>&1 ) | grep -E "✓|✗|×|FAIL|Tests |Test Files|AssertionError|Expected|Received|expected" | head -120
git -C $W checkout HEAD -- $V
echo "restored dirty=$(git -C $W status --porcelain -- $V | wc -l | tr -d ' ')"
