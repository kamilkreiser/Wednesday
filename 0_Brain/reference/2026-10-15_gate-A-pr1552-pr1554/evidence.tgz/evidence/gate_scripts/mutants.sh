#!/bin/bash
# Mutation runs. Each mutant: perl -0pi substitution on a product file, assert it landed, run the named test, restore.
S=/private/tmp/claude-501/gateA-170314
W1=$S/wt/green1552; P1=Blockchain/Dev/scripts/preflight/preflight.sh; T1=Blockchain/Dev/scripts/__tests__/ks1547_preflight_step_header_denominator.test.sh
W2=$S/wt/gw1554; P2=Blockchain/Dev/services/api-gateway/src/routes/verification.ts; G=$W2/Blockchain/Dev/services/api-gateway
T2=src/__tests__/ks1185-f1-workflow-approve-forward-bound-is-validated.test.ts; VT=$W2/Blockchain/Dev/node_modules/.bin/vitest
run1() { out=$(/bin/bash $W1/$T1 2>&1); echo "rc=$? $(printf '%s\n' "$out" | tail -1) | failing: $(printf '%s\n' "$out" | grep '^FAIL' | sed 's/^FAIL //' | tr '\n' ';')"; }
run2() { out=$($VT run --root $G $T2 2>&1); echo "rc=$? $(printf '%s\n' "$out" | grep -E '^ +Tests ' | tr -s ' ') | failing: $(printf '%s\n' "$out" | grep -E '^ +×' | sed -E 's/^ +× //; s/ [0-9]+ms$//' | cut -c1-70 | tr '\n' ';')"; }
mut() { # side id desc perl-expr
  local side=$1 id=$2 desc=$3 expr=$4 W P
  if [ $side = 1 ]; then W=$W1; P=$P1; else W=$W2; P=$P2; fi
  before=$(git -C $W hash-object $P)
  perl -0pi -e "$expr" $W/$P
  after=$(git -C $W hash-object $P)
  if [ "$before" = "$after" ]; then echo "$id MUTANT-DID-NOT-LAND ($desc)"; return; fi
  echo "$id [$desc]"; git -C $W diff -U0 -- $P | grep -E '^[-+][^-+]' | sed 's/^/      /'
  if [ $side = 1 ]; then echo "      -> $(run1)"; else echo "      -> $(run2)"; fi
  git -C $W checkout HEAD -- $P
  [ "$(git -C $W hash-object $P)" = "$before" ] || echo "      RESTORE FAILED"
}
echo "### baseline (unmutated)"; echo "1552 -> $(run1)"; echo "1554 -> $(run2)"
echo "### PR #1552 preflight.sh step() hunk"
mut 1 N0 'comment-only control' 's/(    _hdr_total="\$\{1#\*\/\}"; _hdr_total="\$\{_hdr_total%%\[!0-9\]\*\}")/    # gate: comment-only control\n$1/'
mut 1 N1 'cut at first whitespace (space+tab) only' 's/_hdr_total%%\[!0-9\]\*/_hdr_total%%[[:space:]]*/'
mut 1 N2 'shortest suffix % instead of longest %%' 's/_hdr_total%%\[!0-9\]\*/_hdr_total%[!0-9]*/'
mut 1 N3 'no star: strip one trailing non-digit' 's/_hdr_total%%\[!0-9\]\*\}/_hdr_total%%[!0-9]}/'
mut 1 N4 'class [!1-9] (0 counted as non-digit)' 's/_hdr_total%%\[!0-9\]\*/_hdr_total%%[!1-9]*/'
mut 1 N5 'cut at first space, tab or colon only (a list, not "non-digit")' 's/_hdr_total%%\[!0-9\]\*/_hdr_total%%[[:space:]:]*/'
mut 1 N6 'equivalence probe: [^0-9] spelling' 's/_hdr_total%%\[!0-9\]\*/_hdr_total%%[^0-9]*/'
mut 1 N7 'compare numerically (-ne) instead of string !=' 's/if \[ "\$_hdr_total" != "\$TOTAL_LEGS" \]/if [ "\$_hdr_total" -ne "\$TOTAL_LEGS" ] 2>\/dev\/null/'
echo "### PR #1554 verification.ts hunk"
mut 2 M0 'comment-only control' 's/an object prints as JSON, or as its/an object prints as JSON (gate control), or as its/'
mut 2 M1 'no try/catch around JSON.stringify' 's/try \{\n\s*shown = JSON.stringify\(value\);\n\s*\} catch \{\n\s*shown = Object.prototype.toString.call\(value\);\n\s*\}/shown = JSON.stringify(value);/'
mut 2 M2 'catch falls back to String(value), not the type tag' 's/shown = Object.prototype.toString.call\(value\);/shown = String(value);/'
mut 2 M3 'only arrays take the JSON branch' "s/if \\(typeof value === 'object' && value !== null\\)/if (Array.isArray(value))/"
mut 2 M4 'equivalence probe: drop value !== null' "s/if \\(typeof value === 'object' && value !== null\\)/if (typeof value === 'object')/"
mut 2 M5 'pretty-printed JSON (multi-line)' 's/shown = JSON.stringify\(value\);/shown = JSON.stringify(value, null, 1);/'
mut 2 M6 'catch prints a constant' "s/shown = Object.prototype.toString.call\\(value\\);/shown = 'object';/"
mut 2 M7 'JSON branch only when String() looks numeric' "s/if \\(typeof value === 'object' && value !== null\\)/if (typeof value === 'object' \\&\\& value !== null \\&\\& \\/^\\\\d*\\\$\\/.test(String(value)))/"
echo "### final state"; git -C $W1 status --porcelain; git -C $W2 status --porcelain; echo "(empty above = clean)"
