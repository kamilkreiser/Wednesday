// Probe: what a refused forward bound prints. argv[2] = abs path to routes/verification(.ts without ext)
/* eslint-disable */
const mod = require(process.argv[2]);
const express = require(process.argv[3]);
function deps(override: unknown) {
  const noop = async () => undefined;
  return {
    authenticateToken: () => (_q: any, _s: any, n: any) => n(),
    mockBodyParser: express.json(), query: async () => ({ rows: [] }), isDbAvailable: () => false,
    redisService: { getWorkflowInstance: noop, setWorkflowInstance: noop, getPendingDocument: noop, deletePendingDocument: noop },
    services: { originate: { url: 'http://127.0.0.1:1' }, anchoring: { url: '' } }, log: () => {},
    memWorkflowToDocumentMap: new Map(), memRejectedDocuments: new Map(), dbSaveRejection: noop, ADMIN_ROLES: ['ADMIN'],
    enforceDocumentTypeRules: async () => ({ ok: true, docType: {} }), createWorkflowInstanceIfRequired: async () => ({ gated: false }),
    meetsVerificationLevel: () => true, originateForwardTimeoutMs: override,
  };
}
const cyc: any = {}; cyc.self = cyc;
const { proxy: revoked, revoke } = Proxy.revocable({}, {}); revoke();
const throwingGetter = { get x() { throw new Error('boom'); } };
class Cfg { ms = 800; }
const cases: Array<[string, () => unknown]> = [
  ['Date(0)', () => new Date(0)], ['Date(NaN) invalid', () => new Date(NaN)],
  ['Map([[ms,800]])', () => new Map([['ms', 800]])], ['Map() empty', () => new Map()],
  ['Set([800])', () => new Set([800])], ['RegExp /800/g', () => /800/g],
  ['nested {a:{b:[1,{c:800}]}}', () => ({ a: { b: [1, { c: 800 }] } })],
  ['new Number(1) boxed', () => new Number(1)], ['new Number(800) boxed', () => new Number(800)],
  ['new String("1") boxed', () => new String('1')], ['new Boolean(true) boxed', () => new Boolean(true)],
  ['{toJSON:()=>1}', () => ({ toJSON: () => 1 })], ['{toJSON:()=>undefined}', () => ({ toJSON: () => undefined })],
  ['Object.create(null)', () => Object.create(null)], ['class instance Cfg{ms:800}', () => new Cfg()],
  ['[1n] BigInt inside', () => [1n]], ['cycle', () => cyc], ['throwing getter', () => throwingGetter],
  ['revoked Proxy', () => revoked], ['[undefined]', () => [undefined]], ['Buffer.from("1")', () => Buffer.from('1')],
  ['Uint8Array([1])', () => new Uint8Array([1])], ['Error("x")', () => new Error('x')], ['array 20000 x 800', () => new Array(20000).fill(800)],
  ['null (control, primitive)', () => null], ['1 (control, ACCEPTED)', () => 1], ['undefined (control, default)', () => undefined],
];
for (const [label, make] of cases) {
  let res: string;
  try { mod.createVerificationRoutes(deps(make())); res = 'ACCEPTED (did not throw)'; }
  catch (e: any) {
    const m = /\(got ([\s\S]*)\); omit it for/.exec(String(e && e.message));
    const named = /originateForwardTimeoutMs/.test(String(e && e.message));
    let g = m ? m[1] : `<no (got) clause; ${e && e.constructor && e.constructor.name}: ${String(e && e.message).slice(0, 80)}>`;
    if (g.length > 80) g = g.slice(0, 60) + `...<${g.length} chars>`;
    res = `REFUSED named=${named} got=${g}`;
  }
  console.log(`${label.padEnd(30)} ${res}`);
}
