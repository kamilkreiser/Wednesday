#!/bin/bash
W=/private/tmp/claude-501/gateA-170314/wt
S=/private/tmp/claude-501/gateA-170314/scripts
RUN=/private/tmp/claude-501/gateA-170314/runs/hdr-$(date +%H%M%S)
P=Blockchain/Dev/scripts/preflight/preflight.sh; mkdir -p $RUN
echo "--- every step call site in preflight.sh (any form):"
grep -nE '(^|[;&|[:space:]])step[[:space:]]' $W/dev/$P | grep -v '^\s*#' 
echo "--- any other definer/caller of a step() with N/TOTAL in Blockchain/Dev (excluding tests):"
grep -rnE '^\s*step\(\)' $W/dev/Blockchain/Dev --include=*.sh | grep -v __tests__
HDRS=()
while IFS= read -r line; do HDRS+=("$line"); done < <(sed -nE 's/^step "(.*)"[[:space:]]*$/\1/p' $W/dev/$P)
echo "real headers extracted: ${#HDRS[@]}"
EDGE=("3/" "3/x" "3/x Title" "3" "3 Title" "3/016  T" "3/16x" "3/16.5  T" "3/ 16  T" "3/1 6" "/16  T" "3/16/17  T" "3/-16  T" "3/+16" "3/16"$'\t'"T" "3/16:T" "3/17  T" "3/1616  T" "3/١٦  T")
for side in dev pr1552; do
  /bin/bash $S/stepprobe.sh $W/$side/$P $RUN/$side "${HDRS[@]}" "${EDGE[@]}" > $RUN/$side.tsv
done
echo "--- dev vs pr1552 (rc + abort line), diff:"
diff $RUN/dev.tsv $RUN/pr1552.tsv
echo "--- full pr1552 table"; cat $RUN/pr1552.tsv
echo "--- full dev table"; cat $RUN/dev.tsv
