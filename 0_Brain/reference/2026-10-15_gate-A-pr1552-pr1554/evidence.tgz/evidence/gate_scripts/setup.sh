#!/bin/bash
set -u
B=/private/tmp/claude-501/gateA-170314
SRC="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files"
SSH='ssh -i "/Volumes/DevMASTER/!CODING/Secuura/Blockchain/3_Access_Keys/github_deploy_rw" -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new'
git -C "$SRC" ls-remote origin refs/heads/develop refs/pull/1552/head refs/pull/1554/head
git clone --shared --no-checkout "$SRC" "$B/repo" || exit 1
git -C "$B/repo" remote set-url origin git@github.com:Secuura/Distributed_Secuura.git
git -C "$B/repo" config core.sshCommand "$SSH"
git -C "$B/repo" fetch origin develop:refs/remotes/origin/develop refs/pull/1552/head:refs/gate/pr1552 refs/pull/1554/head:refs/gate/pr1554 2>&1 | tail -5
git -C "$B/repo" rev-parse refs/remotes/origin/develop refs/gate/pr1552 refs/gate/pr1554
