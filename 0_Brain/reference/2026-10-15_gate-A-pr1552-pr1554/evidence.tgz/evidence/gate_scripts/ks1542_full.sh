#!/bin/bash
W=/private/tmp/claude-501/gateA-170314/wt/gw1554
G=$W/Blockchain/Dev/services/api-gateway
V=Blockchain/Dev/services/api-gateway/src/routes/verification.ts
TF=Blockchain/Dev/services/api-gateway/src/__tests__/ks1185-f1-workflow-approve-forward-bound-is-validated.test.ts
VT=$W/Blockchain/Dev/node_modules/.bin/vitest
TSC=$W/Blockchain/Dev/node_modules/.bin/tsc
ls $G/node_modules/.bin/tsc >/dev/null 2>&1 && TSC=$G/node_modules/.bin/tsc
echo "tsc: $TSC $($TSC --version)"
echo "=== FULL api-gateway suite at PR1554 head"
$VT run --root $G 2>&1 | grep -E "Test Files|Tests |FAIL" | head -20
echo "=== tsc -p tsconfig.test.json at PR head"
$TSC -p $G/tsconfig.test.json --noEmit > /private/tmp/claude-501/gateA-170314/runs/tsc_pr.txt 2>&1; echo "rc=$? errors=$(grep -c 'error TS' /private/tmp/claude-501/gateA-170314/runs/tsc_pr.txt)"
echo "program includes the test file: $($TSC -p $G/tsconfig.test.json --listFilesOnly | grep -c ks1185-f1-workflow-approve-forward-bound-is-validated)"
echo "=== tsc PLANTED control: type error appended to the PR's test file"
printf '\nconst __gatePlanted: number = "not a number"; void __gatePlanted;\n' >> $W/$TF
$TSC -p $G/tsconfig.test.json --noEmit > /private/tmp/claude-501/gateA-170314/runs/tsc_planted.txt 2>&1; echo "rc=$? errors=$(grep -c 'error TS' /private/tmp/claude-501/gateA-170314/runs/tsc_planted.txt)"; grep ks1185-f1 /private/tmp/claude-501/gateA-170314/runs/tsc_planted.txt
git -C $W checkout HEAD -- $TF
echo "=== tsc -p tsconfig.json (build program) at PR head"
$TSC -p $G/tsconfig.json --noEmit > /private/tmp/claude-501/gateA-170314/runs/tsc_build.txt 2>&1; echo "rc=$? errors=$(grep -c 'error TS' /private/tmp/claude-501/gateA-170314/runs/tsc_build.txt)"
echo "=== develop baseline (both files reverted)"
git -C $W checkout origin/develop -- $V $TF
$TSC -p $G/tsconfig.test.json --noEmit > /private/tmp/claude-501/gateA-170314/runs/tsc_dev.txt 2>&1; echo "tsc test-program rc=$? errors=$(grep -c 'error TS' /private/tmp/claude-501/gateA-170314/runs/tsc_dev.txt)"
$VT run --root $G 2>&1 | grep -E "Test Files|Tests |FAIL" | head -20
git -C $W checkout HEAD -- $V $TF
echo "restored dirty=$(git -C $W status --porcelain | wc -l | tr -d ' ')"
