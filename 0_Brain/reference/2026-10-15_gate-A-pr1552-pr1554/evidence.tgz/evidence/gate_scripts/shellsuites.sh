#!/bin/bash
S=/private/tmp/claude-501/gateA-170314
for side in dev green1552; do
  echo "=== $side $(git -C $S/wt/$side rev-parse --short HEAD)"
  ( /bin/bash $S/wt/$side/Blockchain/Dev/scripts/run-shell-suites.sh > $S/runs/shellsuites_$side.txt 2>&1; echo "rc=$?" )
  tail -8 $S/runs/shellsuites_$side.txt
done
