#!/bin/bash
R=/private/tmp/claude-501/gateA-170314/repo
W=/private/tmp/claude-501/gateA-170314/wt
mkdir -p $W
git -C $R worktree add --detach $W/dev origin/develop -q
git -C $R worktree add --detach $W/pr1552 refs/gate/pr1552 -q
git -C $R worktree add --detach $W/pr1554 refs/gate/pr1554 -q
for d in dev pr1552 pr1554; do git -C $W/$d log -1 --format="$d %H"; done
