#!/bin/bash
S=/private/tmp/claude-501/gateA-170314
W1=$S/wt/green1552; P1=Blockchain/Dev/scripts/preflight/preflight.sh
RUN=$S/runs/surv-$(date +%H%M%S); mkdir -p $RUN
declare -a IDS=(N4 N5 N7)
declare -a EX=('s/_hdr_total%%\[!0-9\]\*/_hdr_total%%[!1-9]*/' 's/_hdr_total%%\[!0-9\]\*/_hdr_total%%[[:space:]:]*/' 's/if \[ "\$_hdr_total" != "\$TOTAL_LEGS" \]/if [ "\$_hdr_total" -ne "\$TOTAL_LEGS" ] 2>\/dev\/null/')
for i in 0 1 2; do
  id=${IDS[$i]}; cp $W1/$P1 $RUN/$id.preflight.sh; perl -0pi -e "${EX[$i]}" $RUN/$id.preflight.sh
  cmp -s $W1/$P1 $RUN/$id.preflight.sh && echo "$id DID NOT LAND"
  echo "--- $id: headers where the mutant differs from the PR"
  /bin/bash $S/scripts/stepprobe.sh $W1/$P1 $RUN/pr "3/" "3/x" "3/16x" "3/16)" "3/16,T" "3/16;T" "3/10  T" "3/160  T" "3/1600  T" > $RUN/pr.tsv
  /bin/bash $S/scripts/stepprobe.sh $RUN/$id.preflight.sh $RUN/$id "3/" "3/x" "3/16x" "3/16)" "3/16,T" "3/16;T" "3/10  T" "3/160  T" "3/1600  T" > $RUN/$id.tsv
  diff $RUN/pr.tsv $RUN/$id.tsv | grep '^>' | cut -f1,2
done
echo "--- N7 in place against every preflight sibling suite (does ANY suite kill it?)"
perl -0pi -e "${EX[2]}" $W1/$P1
for t in $W1/Blockchain/Dev/scripts/__tests__/preflight_*.test.sh $W1/Blockchain/Dev/scripts/__tests__/ks1547_*.test.sh; do
  out=$(/bin/bash $t 2>&1); echo "$(basename $t) rc=$? $(printf '%s\n' "$out" | grep -E 'passed' | tail -1)"
done
git -C $W1 checkout HEAD -- $P1; echo "restored dirty=$(git -C $W1 status --porcelain | wc -l | tr -d ' ')"
