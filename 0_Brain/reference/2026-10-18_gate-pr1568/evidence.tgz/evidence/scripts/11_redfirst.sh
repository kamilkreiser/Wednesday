#!/bin/bash
# usage: 11_redfirst.sh -> develop's guard + head's two test files + a FAITHFUL 1-line shim of develop's index.ts quiet condition
set -u
G=/private/tmp/claude-501/gate1568-1792317268
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568/evidence/logs
W=$G/wt/redfirst
A=Blockchain/Dev/services/anchoring/src
echo "develop index.ts quiet condition (the line the shim must express):"
grep -n "payload_is_incoming === false" $W/$A/index.ts
for t in ks1385-anchor-store-keeps-the-latest-events-metadata.integration.test.ts ks1385-guard-reads-under-force-rls.integration.test.ts; do
  git -C $G/repo show 16e71610366b27276469e2215010416991b56ad5:$A/__tests__/$t > $W/$A/__tests__/$t
done
if ! grep -q "export function isQuietKeep" $W/$A/anchorOverwriteGuard.ts; then
  printf '\n// GATE RED-FIRST SHIM: develop index.ts logs unless reason === document-id-not-a-uuid\nexport function isQuietKeep(decision: OverwriteDecision, _documentId: string): boolean { return decision.reason === %s; }\n' "'document-id-not-a-uuid'" >> $W/$A/anchorOverwriteGuard.ts
fi
tail -3 $W/$A/anchorOverwriteGuard.ts
git -C $W diff --stat
/bin/bash /Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568/evidence/scripts/05_itest.sh $W itest_redfirst
