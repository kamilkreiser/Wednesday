#!/bin/bash
# usage: 07_e2e.sh <worktree> <port> <tag> -> boot anchoring (tsx, secuura_app, mock chain), run the #1549 e2e cell + my matrix cell, count kept-payload lines
set -u
G=/private/tmp/claude-501/gate1568-1792317268
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568/evidence/logs
C=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568/evidence/cells
W="$1"; PORT="$2"; TAG="$3"
D=$W/Blockchain/Dev
if lsof -nP -iTCP:$PORT -sTCP:LISTEN >/dev/null 2>&1; then echo "PORT $PORT BUSY"; exit 2; fi
export PORT
export DATABASE_URL="postgresql://secuura_app:app@127.0.0.1:55623/secuura"
export JWT_PUBLIC_KEY="$(base64 < $G/keys/gate.pub | tr -d '\n')"
export NODE_ENV=development
export PII_ENCRYPTION_KEY="$(openssl rand -hex 32)"
unset BLOCKFROST_API_KEY PLATFORM_WALLET_MNEMONIC JWT_JWKS_URL AUTH_SERVICE_URL
echo "tree HEAD=$(git -C $W rev-parse HEAD) dirty=$(git -C $W status --porcelain --untracked-files=no | wc -l | tr -d ' ')"
$D/node_modules/.bin/tsx $D/services/anchoring/src/index.ts > $EV/anchoring_boot_$TAG.log 2>&1 &
SVC=$!
for i in $(seq 1 90); do
  curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$PORT/health 2>/dev/null | grep -q 200 && break
  sleep 1
done
echo "health: $(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$PORT/health)"
$D/node_modules/.bin/tsx $C/e2e_custody.ts http://127.0.0.1:$PORT $G/keys/gate.pem $G/keys/forger.pem "postgresql://secuura:secuura@127.0.0.1:55623/secuura" $W > $EV/e2e_custody_$TAG.log 2>&1
echo "e2e_custody rc=$?"
N1=$(grep -c "kept the stored anchor metadata" $EV/anchoring_boot_$TAG.log)
$D/node_modules/.bin/tsx $C/gate_matrix.ts http://127.0.0.1:$PORT $G/keys/gate.pem $G/keys/forger.pem "postgresql://secuura:secuura@127.0.0.1:55623/secuura" "postgresql://secuura_app:app@127.0.0.1:55623/secuura" $W > $EV/gate_matrix_$TAG.log 2>&1
echo "gate_matrix rc=$?"
sleep 3
kill $SVC
wait $SVC 2>/dev/null
echo "--- e2e_custody:"
python3 -I -c "
import json,sys
for l in open('$EV/e2e_custody_$TAG.log'):
    try: d=json.loads(l)
    except Exception: print('  RAW', l.rstrip()[:200]); continue
    print('  %-70s s1=%s s2=%s replaced=%-5s %s' % (d['cell'][:70], d['firstStatus'], d['secondStatus'], d['replaced'], d['result']))"
echo "kept-payload warnings during e2e_custody: $N1"
echo "--- kept-payload warnings total in the service log: $(grep -c 'kept the stored anchor metadata' $EV/anchoring_boot_$TAG.log)"
grep "kept the stored anchor metadata" $EV/anchoring_boot_$TAG.log | python3 -I -c "
import sys,json
for l in sys.stdin:
    try: d=json.loads(l); print('  ', d.get('reason'), d.get('documentId'))
    except Exception: print('  RAW', l[:200])"
echo "--- guard read-failure lines: $(grep -c 'could not read the owning document' $EV/anchoring_boot_$TAG.log)"
echo "--- 401 count in service log: $(grep -c '"statusCode":401' $EV/anchoring_boot_$TAG.log)"
