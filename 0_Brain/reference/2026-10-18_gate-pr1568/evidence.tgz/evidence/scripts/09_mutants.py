"""usage: python3 -I 09_mutants.py <worktree> <outdir>
One exact-once replacement per mutant in the dedicated mut worktree; run the whole anchoring integration lane
on my Postgres (55623); record failing cell ids; restore and assert sha256 + git status clean."""
import hashlib, json, os, re, subprocess, sys
W, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
A = os.path.join(W, "Blockchain/Dev/services/anchoring")
G = os.path.join(A, "src/anchorOverwriteGuard.ts"); I = os.path.join(A, "src/index.ts")
orig = {G: open(G).read(), I: open(I).read()}
sha = {k: hashlib.sha256(v.encode()).hexdigest() for k, v in orig.items()}
MUT = [
 ("CTRL-none", G, []),
 ("CTRL-comment-only", G, [("  const asPrimaryKey = isUuidShaped(documentId)", "  // gate mutant control: a comment only\n  const asPrimaryKey = isUuidShaped(documentId)")]),
 ("K2 (author) primary-key arm dropped", G, [("AND (d.external_id = $1 OR d.id = $3::uuid)", "AND d.external_id = $1 AND $3::uuid IS NULL OR FALSE")]),
 ("K3 (author) precedence swapped (pkey first)", G, [("ORDER BY (d.external_id = $1) DESC NULLS LAST", "ORDER BY (d.id = $3::uuid) DESC NULLS LAST")]),
 ("K5 (author) uuid parameter guard dropped", G, [("const asPrimaryKey = isUuidShaped(documentId) ? documentId.trim() : null;", "const asPrimaryKey = documentId.trim();")]),
 ("N3 (author) hasIssuer dropped from the issuer allow", G, [("  if (hasIssuer && sameUuid(doc.issuerOrganizationId, caller.organizationId)) {", "  if (sameUuid(doc.issuerOrganizationId, caller.organizationId)) {")]),
 ("G1 (mine) ORDER BY dropped: precedence left to the planner", G, [("        ORDER BY (d.external_id = $1) DESC NULLS LAST\n", "")]),
 ("G2 (mine) Kam's (b) over-widened: any caller in the tenant may update a no-issuer row", G, [("  if (hasIssuer && sameUuid(doc.issuerOrganizationId, caller.organizationId)) {", "  if (!hasIssuer && custodyOption === 'c') return { allow: true, reason: 'caller-shares-custodian-organisation' };\n  if (hasIssuer && sameUuid(doc.issuerOrganizationId, caller.organizationId)) {")]),
 ("G3 (mine) PURE primary-key arm drop (external arm left intact for uuid-shaped ids)", G, [("AND (d.external_id = $1 OR d.id = $3::uuid)", "AND (d.external_id = $1 OR (FALSE AND d.id = $3::uuid))")]),
]
ENV = dict(os.environ, TEST_DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:55623/secuura",
           TEST_APP_DATABASE_URL="postgresql://secuura_app:app@127.0.0.1:55623/secuura",
           DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:55623/secuura")
VT = os.path.join(W, "Blockchain/Dev/node_modules/.bin/vitest")
res = []
for name, f, edits in MUT:
    s = orig[f]; ok = True
    for a, b in edits:
        c = s.count(a)
        if c != 1:
            res.append({"mutant": name, "verdict": f"NOT SCORED (anchor count {c})"}); ok = False; break
        s = s.replace(a, b)
    if ok:
        open(f, "w").write(s)
        tag = re.sub(r"[^A-Za-z0-9]+", "_", name)[:40]
        jf = os.path.join(OUT, tag + ".json")
        p = subprocess.run([VT, "run", "--root", A, "--config", os.path.join(A, "vitest.integration.config.ts"), "--reporter=json", "--outputFile=" + jf],
                           capture_output=True, text=True, env=ENV, timeout=1200)
        open(os.path.join(OUT, tag + ".log"), "w").write(p.stdout + p.stderr)
        try:
            d = json.load(open(jf))
            failed = [a["title"] for t in d["testResults"] for a in t["assertionResults"] if a["status"] == "failed"]
            nonpass = [a["title"] for t in d["testResults"] for a in t["assertionResults"] if a["status"] not in ("passed", "failed")]
            suitefail = [t["name"].split("/")[-1] for t in d["testResults"] if t.get("status") == "failed" and not any(a["status"] == "failed" for a in t["assertionResults"])]
            ids = sorted({(re.match(r"^([A-Z]+-?[0-9]*[a-z]?)\b", t) or re.match(r"(.{0,12})", t)).group(1) for t in failed})
            r = {"mutant": name, "total": d["numTotalTests"], "passed": d["numPassedTests"], "failed": len(failed), "nonpass": len(nonpass), "suiteFail": suitefail, "red": ids,
                 "verdict": "LOADFAIL" if suitefail else ("KILLED" if failed else "SURVIVED")}
        except Exception as e:
            r = {"mutant": name, "verdict": "NO JSON " + str(e)}
        res.append(r)
    for k in orig: open(k, "w").write(orig[k])
    for k in orig: assert hashlib.sha256(open(k).read().encode()).hexdigest() == sha[k], "RESTORE FAILED " + k
    r = res[-1]
    print(f"{r['mutant'][:78]:78s} | {r['verdict']:9s} | {r.get('passed')}/{r.get('total')} nonpass={r.get('nonpass')} suiteFail={r.get('suiteFail')} | red={' '.join(r.get('red', []))}", flush=True)
json.dump(res, open(os.path.join(OUT, "mutants.json"), "w"), indent=1)
st = subprocess.run(["git", "-C", W, "status", "--porcelain", "--untracked-files=no"], capture_output=True, text=True).stdout
print("restored sha256/16:", {os.path.basename(k): v[:16] for k, v in sha.items()}, "| worktree tracked changes after:", len(st.splitlines()))
