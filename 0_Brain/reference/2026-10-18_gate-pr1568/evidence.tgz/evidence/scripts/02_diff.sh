#!/bin/bash
# usage: 02_diff.sh -> diff stats + full patch of the PR, develop drift since base
set -u
G=/private/tmp/claude-501/gate1568-1792317268
R=$G/repo
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568/evidence/logs
B=d2ec786e6130c7ce13384185c84cc1e7566d77cb
H=refs/gate/head
git -C $R diff --stat $B $H > $EV/diff_stat.txt
git -C $R diff $B $H > $EV/pr.patch
git -C $R diff --name-only $B $H > $EV/pr_files.txt
git -C $R diff --name-only $B refs/gate/develop > $EV/dev_files_since_base.txt
for c in 7408f5ec5 16e716103; do git -C $R show --stat --format='%H %an %ad%n%B' $c > $EV/show_$c.txt; git -C $R show $c > $EV/show_$c.patch; done
cat $EV/diff_stat.txt
echo "-- develop files since base:"; cat $EV/dev_files_since_base.txt
echo "-- overlap:"; comm -12 <(sort $EV/pr_files.txt) <(sort $EV/dev_files_since_base.txt)
echo "-- end overlap"
cat $EV/show_7408f5ec5.txt | head -150
echo ----; cat $EV/show_16e716103.txt
