#!/bin/bash
# usage: 05_itest.sh <worktree> <outname> [vitest file filter...]  -> anchoring integration lane on my Postgres 55623
set -u
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568/evidence/logs
W="$1"; O="$2"; shift 2
A=$W/Blockchain/Dev/services/anchoring
export TEST_DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:55623/secuura"
export TEST_APP_DATABASE_URL="postgresql://secuura_app:app@127.0.0.1:55623/secuura"
export DATABASE_URL="$TEST_DATABASE_URL"
VT=$W/Blockchain/Dev/node_modules/.bin/vitest
$VT run --root $A --config $A/vitest.integration.config.ts --reporter=json --outputFile=$EV/$O.json "$@" > $EV/$O.log 2>&1
rc=$?
python3 -I - "$EV/$O.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
print("files",d.get("numTotalTestSuites"),"tests",d["numTotalTests"],"passed",d["numPassedTests"],"failed",d["numFailedTests"],"failedSuites",d.get("numFailedTestSuites"))
for f in d["testResults"]:
    for a in f["assertionResults"]:
        if a["status"]!="passed":
            print("  FAIL", a["fullName"][:160], "|", (a.get("failureMessages") or [""])[0].splitlines()[0][:160])
    if f.get("status")=="failed" and not f["assertionResults"]:
        print("  SUITE-FAIL", f["name"], f.get("message","")[:300])
PY
echo "rc=$rc"
