#!/bin/bash
# usage: 01_clone.sh  -> clone --shared, fetch PR head + develop, receipts
set -u
G=/private/tmp/claude-501/gate1568-1792317268
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568/evidence/logs
SRC="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files"
SSHC="$(git -C "$SRC" config --get core.sshCommand) -o ServerAliveInterval=30"
mkdir -p $G
{ date -u +%FT%TZ; GIT_SSH_COMMAND="$SSHC" git -C "$SRC" ls-remote git@github.com:Secuura/Distributed_Secuura.git refs/pull/1568/head refs/heads/develop refs/pull/1555/head; } > $EV/receipts_lsremote_1.txt 2>&1
cat $EV/receipts_lsremote_1.txt
if [ ! -d $G/repo ]; then
  git clone --shared --no-checkout "$SRC" $G/repo 2>&1 | tail -2
  git -C $G/repo remote set-url origin git@github.com:Secuura/Distributed_Secuura.git
fi
git -C $G/repo config core.sshCommand "$SSHC"
git -C $G/repo fetch origin +refs/pull/1568/head:refs/gate/head +refs/heads/develop:refs/gate/develop 2>&1 | tail -3
for c in 16e71610366b27276469e2215010416991b56ad5 d2ec786e6 1197ab38a5365ce0925b09bdf59a465662d45f2d 8cbadd8d; do
  echo "$c $(git -C $G/repo cat-file -t $c 2>&1)"
done
git -C $G/repo rev-parse refs/gate/head refs/gate/develop
echo "merge-base: $(git -C $G/repo merge-base refs/gate/head refs/gate/develop)"
echo "merge-base(head,d2ec786e6): $(git -C $G/repo merge-base refs/gate/head d2ec786e6)"
git -C $G/repo log --oneline refs/gate/develop -8
echo ----
git -C $G/repo log --oneline d2ec786e6..refs/gate/head
