#!/bin/bash
# usage: 12_static.sh -> tsc --noEmit (anchoring) + eslint on the 4 PR files at head; unit lane at head and develop
set -u
G=/private/tmp/claude-501/gate1568-1792317268
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568/evidence/logs
for t in head dev; do
  W=$G/wt/$t; D=$W/Blockchain/Dev; A=$D/services/anchoring
  $D/node_modules/.bin/tsc -p $A/tsconfig.json --noEmit > $EV/tsc_anchoring_$t.log 2>&1; echo "tsc $t rc=$? errors=$(grep -c 'error TS' $EV/tsc_anchoring_$t.log)"
  $D/node_modules/.bin/vitest run --root $A --reporter=json --outputFile=$EV/unit_$t.json > $EV/unit_$t.log 2>&1; echo "unit $t rc=$?"
  python3 -I -c "
import json; d=json.load(open('$EV/unit_$t.json')); print('  unit $t tests',d['numTotalTests'],'passed',d['numPassedTests'],'failed',d['numFailedTests'])
for f in d['testResults']:
  if f.get('status')=='failed': print('   FAILED FILE', f['name'].split('/')[-1])"
done
W=$G/wt/head; D=$W/Blockchain/Dev; A=$D/services/anchoring
$D/node_modules/.bin/eslint --no-warn-ignored -c $D/eslint.config.mjs --format json $A/src/anchorOverwriteGuard.ts $A/src/index.ts $A/src/__tests__/ks1385-anchor-store-keeps-the-latest-events-metadata.integration.test.ts $A/src/__tests__/ks1385-guard-reads-under-force-rls.integration.test.ts > $EV/eslint_head.json 2> $EV/eslint_head.err
echo "eslint rc=$?"
python3 -I -c "
import json
try:
  d=json.load(open('$EV/eslint_head.json'))
  print('eslint files',len(d),'errors',sum(f['errorCount'] for f in d),'warnings',sum(f['warningCount'] for f in d))
except Exception as e: print('eslint json unreadable', e); print(open('$EV/eslint_head.err').read()[:800])"
