#!/bin/bash
# usage: 10_merge.sh -> re-read live develop + PR head, overlap, merge-tree, planted conflicting control (all in MY clone)
set -u
G=/private/tmp/claude-501/gate1568-1792317268
R=$G/repo
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568/evidence/logs
H=16e71610366b27276469e2215010416991b56ad5
{ date -u +%FT%TZ; git -C $R ls-remote origin refs/pull/1568/head refs/heads/develop refs/pull/1555/head; } > $EV/receipts_lsremote_2.txt 2>&1
cat $EV/receipts_lsremote_2.txt
git -C $R fetch origin +refs/heads/develop:refs/gate/develop2 2>&1 | tail -1
D=$(git -C $R rev-parse refs/gate/develop2)
echo "live develop = $D"
MB=$(git -C $R merge-base $H $D); echo "merge-base = $MB"
git -C $R diff --name-only $MB $H | sort > $G/m_pr.txt
git -C $R diff --name-only $MB $D | sort > $G/m_dev.txt
echo "PR files: $(wc -l < $G/m_pr.txt | tr -d ' ') | develop files since base: $(wc -l < $G/m_dev.txt | tr -d ' ') | overlap: $(comm -12 $G/m_pr.txt $G/m_dev.txt | wc -l | tr -d ' ')"
comm -12 $G/m_pr.txt $G/m_dev.txt
{ cat $G/m_dev.txt; echo "Blockchain/Dev/services/anchoring/src/anchorOverwriteGuard.ts"; } | sort -u > $G/m_dev_planted.txt
echo "planted overlap control (guard added to develop list): $(comm -12 $G/m_pr.txt $G/m_dev_planted.txt | wc -l | tr -d ' ')"
git -C $R merge-tree --write-tree $D $H > $G/mt.txt 2>&1; rc=$?
echo "merge-tree(develop, head) rc=$rc tree=$(head -1 $G/mt.txt)"
T=$(head -1 $G/mt.txt)
echo "files differing merged-tree vs develop:"; git -C $R diff --name-only $D $T
echo "merged-tree vs head-tree on the 4 PR files (expect empty):"; git -C $R diff --stat $H $T -- $(cat $G/m_pr.txt)
# planted conflicting control: a develop-side commit that rewrites the same guard line
git -C $R worktree add --detach $G/wt/planted $D > /dev/null 2>&1 || true
F=$G/wt/planted/Blockchain/Dev/services/anchoring/src/anchorOverwriteGuard.ts
python3 -I - "$F" <<'PY'
import sys
p=sys.argv[1]; s=open(p).read()
a="        WHERE d.id = $1::uuid\n"
assert s.count(a)==1, s.count(a)
open(p,'w').write(s.replace(a,"        WHERE d.id = $1::uuid -- planted conflicting develop edit\n"))
PY
git -C $G/wt/planted -c user.email=gate@invalid -c user.name=gate commit -qam "planted conflicting control" && P=$(git -C $G/wt/planted rev-parse HEAD)
git -C $R merge-tree --write-tree $P $H > $G/mt_planted.txt 2>&1; echo "planted merge-tree rc=$?"; grep -i conflict $G/mt_planted.txt | head -3
