#!/bin/bash
# usage: 06_keys.sh -> RS256 key pair for the service + a foreign "forger" key; copy the #1549 e2e cell and check its sha
set -u
G=/private/tmp/claude-501/gate1568-1792317268
C=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568/evidence/cells
mkdir -p $G/keys
[ -f $G/keys/gate.pem ] || openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out $G/keys/gate.pem 2>/dev/null
openssl pkey -in $G/keys/gate.pem -pubout -out $G/keys/gate.pub
[ -f $G/keys/forger.pem ] || openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out $G/keys/forger.pem 2>/dev/null
ls -l $G/keys
cp "/Volumes/DevMASTER/!CODING/Secuura/Blockchain/scratchpad/j12/e2e/cells/e2e_custody.ts" $C/e2e_custody.ts
shasum -a 256 $C/e2e_custody.ts /Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-15_gate-pr1549-r2/evidence/cells/e2e_custody.ts | cut -c1-16
cmp $C/e2e_custody.ts /Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-15_gate-pr1549-r2/evidence/cells/e2e_custody.ts && echo "byte-identical to the #1549 r2 gate copy"
