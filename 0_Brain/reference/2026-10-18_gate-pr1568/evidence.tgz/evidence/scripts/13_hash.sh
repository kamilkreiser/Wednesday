#!/bin/bash
# usage: 13_hash.sh -> sha256/16 of verdict.md with line 2 deleted; writes it into line 2; re-verifies
set -u
V=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568/verdict.md
H=$(sed '2d' $V | shasum -a 256 | cut -c1-16)
python3 -I - "$V" "$H" <<'PY'
import sys
p, h = sys.argv[1], sys.argv[2]
lines = open(p).read().split('\n')
assert lines[1].startswith('REPORT-SHA256/16:'), lines[1]
lines[1] = 'REPORT-SHA256/16: ' + h
open(p, 'w').write('\n'.join(lines))
PY
echo "line2: $(sed -n 2p $V)"
echo "recheck: $(sed '2d' $V | shasum -a 256 | cut -c1-16)"
