"""usage: python3 -I 08_summ.py <gate_matrix_head.log> <gate_matrix_dev.log> -> side-by-side table"""
import json, sys

def load(p):
    out = {}
    for l in open(p):
        try:
            d = json.loads(l)
        except Exception:
            continue
        if 'cell' in d:
            out[d['cell']] = d
    return out

h, d = load(sys.argv[1]), load(sys.argv[2])
for k, hv in h.items():
    dv = d.get(k, {})
    def fmt(v):
        if 'stored' in v and v['stored']:
            dec = v.get('decision')
            dec = dec if isinstance(dec, str) else (dec or {}).get('reason')
            return f"s={v.get('firstStatus')}/{v.get('secondStatus')} {'REPLACED' if v.get('replaced') else 'kept'} actor={v['stored'].get('actor')} [{dec}]"
        if 'decision' in v:
            dec = v['decision']
            return f"allow={dec.get('allow')} [{dec.get('reason')}]"
        if 'canonical' in v:
            return f"canon={v['canonical']['actor']} upperRow={v['upperRow']['actor']} rows={v['canonical']['rows']}+{v['upperRow']['rows']}"
        return json.dumps(v)[:120]
    print(f"{k[:78]:78s}\n    head: {fmt(hv)}  {hv.get('result','')}\n    dev : {fmt(dv) if dv else '-'}  {dv.get('result','')}")
    for side, v in (('head', hv), ('dev', dv)):
        for vk in ('verifyBefore', 'verifyAfter'):
            if vk in v:
                print(f"    {side} {vk}: {v[vk]['status']} {v[vk]['body'][:900]}")
