#!/bin/bash
# usage: 04_pg.sh <port> <schema-worktree>  -> own Postgres 18, repo schema (docker/init then migrations), secuura_app NOSUPERUSER NOBYPASSRLS
set -u
G=/private/tmp/claude-501/gate1568-1792317268
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568/evidence/logs
PORT="$1"; W="$2"
B=/opt/homebrew/opt/postgresql@18/bin
D=$G/pgdata-$PORT
L=$EV/pg_setup.log
if lsof -nP -iTCP:$PORT -sTCP:LISTEN >/dev/null 2>&1; then echo "PORT $PORT BUSY"; exit 2; fi
echo "port $PORT free at $(date -u +%FT%TZ)" > $L
$B/initdb -D $D -U postgres --auth=trust >>$L 2>&1 || { echo initdb failed; exit 1; }
$B/pg_ctl -D $D -o "-p $PORT -k $G -c listen_addresses=127.0.0.1" -l $EV/pg_server.log start >>$L 2>&1
sleep 3
P="$B/psql -h 127.0.0.1 -p $PORT -v ON_ERROR_STOP=0 -q"
$P -U postgres -d postgres -c "CREATE ROLE secuura SUPERUSER LOGIN PASSWORD 'secuura'" >>$L 2>&1
$P -U postgres -d postgres -c "CREATE DATABASE secuura OWNER secuura" >>$L 2>&1
$P -U postgres -d postgres -c "CREATE ROLE secuura_app LOGIN PASSWORD 'app' NOSUPERUSER NOBYPASSRLS" >>$L 2>&1
DEV=$W/Blockchain/Dev
for f in $DEV/docker/init/0*.sql; do
  case "$(basename $f)" in 00-create-platform-db.sql) continue;; esac
  echo "== $f" >>$L
  $P -U secuura -d secuura -f $f >>$L 2>&1
done
for f in $DEV/migrations/*.sql; do
  echo "== $f" >>$L
  $P -U secuura -d secuura -f $f >>$L 2>&1
done
$P -U secuura -d secuura >>$L 2>&1 <<'EOSQL'
GRANT CONNECT ON DATABASE secuura TO secuura_app;
GRANT USAGE ON SCHEMA public TO secuura_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO secuura_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO secuura_app;
EOSQL
echo "errors in setup log: $(grep -c ERROR $L)"
grep ERROR $L | sort | uniq -c | sort -rn | head -5
$B/psql -h 127.0.0.1 -p $PORT -U secuura -d secuura -tAc "select relname, relrowsecurity, relforcerowsecurity from pg_class where relname in ('documents','users','anchor_store')"
$B/psql -h 127.0.0.1 -p $PORT -U secuura -d secuura -tAc "select polname, polrelid::regclass, polpermissive, pg_get_expr(polqual, polrelid) from pg_policy where polrelid in ('documents'::regclass,'users'::regclass)"
$B/psql -h 127.0.0.1 -p $PORT -U postgres -d postgres -tAc "select rolname, rolsuper, rolbypassrls from pg_roles where rolname like 'secuura%'"
$B/psql -h 127.0.0.1 -p $PORT -U secuura -d secuura -tAc "select conname, pg_get_constraintdef(oid) from pg_constraint where conrelid='documents'::regclass and contype in ('u','p')"
$B/psql -h 127.0.0.1 -p $PORT -U secuura -d secuura -tAc "select conname, pg_get_constraintdef(oid) from pg_constraint where conrelid='anchor_store'::regclass and contype in ('u','p')"
$B/psql -h 127.0.0.1 -p $PORT -U secuura -d secuura -tAc "select indexname, indexdef from pg_indexes where tablename in ('anchor_store','documents') and indexdef ilike '%unique%'"
$B/psql -h 127.0.0.1 -p $PORT -U secuura -d secuura -tAc "select column_name, data_type from information_schema.columns where table_name='anchor_store' and column_name in ('document_id','network')"
