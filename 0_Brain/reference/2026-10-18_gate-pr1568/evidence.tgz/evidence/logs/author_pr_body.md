## BLUF

**Kam's two KS-1385 rulings now reach the anchors originate actually emits, and his (b) reaches certifications.** #1549's guard read the owning document by `documents.id` only. Originate's document anchors send the **external id**, so for real traffic the guard never found the row and kept the stored identity (the #1549 round-2 gate's MAJ-A, KS-1612). And a row with no issuer was refused before the custody rule ran. Kam ruled that the custodian's organisation may update those too. **Runtime change, `services/anchoring` only. Nothing deployed.**

Refs KS-1612
Refs KS-1385

## The two rulings this delivers

* **KS-1612** is the residue of #1549, which merged under the two-round cap. It is no new ruling; it makes these two reach real traffic:
  * card `…anchor-identity-needs-ps895-ruling-1013` = **b**, *"Latest event's identity wins"*;
  * card `…custodian-may-update-anchor-identity-1013` = **c**, *"Issuer, or anyone in the custodian's organisation"*.
* **Card `secuura-ks1385-null-issuer-certifications-1015` = b**, *"Apply (c) to them too"* (2026-10-18 19:00:28, live board). Its detail, verbatim: *"A follow-up ticket and round reorders the guard so the custodian's organisation can update these rows. This gives a certificate holder's organisation a new write."* Kam chose that knowingly.

## What changed

* **`readOwningDocument` resolves the id the way originate's own `getDocument` does: `external_id` first, then the primary key, both bound to the caller's tenant.** That is not a choice made here; it mirrors the resolver originate acts on. It has to be **both**, and this is the part to check:
  * **document** anchors send the external id (`routes/documents.ts`: `documentId: id`, with `id = documentUuid ?? 'doc-…'`, which `documentRepo.ts` writes to `external_id` beside a fresh primary key);
  * **certification** anchors send the **primary key** (`certificationRepo.ts:211` inserts `id = cert.id` and writes **no** `external_id`; `certifications.ts` anchors with `cert.id`).
  * An external-id-only fix would have made Kam's (b) reach **no certification at all**. Cell X7 pins that.
* The primary-key arm takes a uuid **parameter** that is NULL unless the id is uuid-shaped. A `doc-…` id never reaches `::uuid` (22P02), and that doesn't depend on Postgres evaluating an OR's arms in order.
* **`decideMetadataOverwrite`: a NULL issuer is no longer refused before the custody block.** The block runs for every row, and a no-issuer row is refused (`document-has-no-issuer-organisation`) only when no custody rule admits the caller. Under option (a), issuer only, it is still refused (cell C-i), so the widening is the custody rule, not a dropped check.
* **The `document-id-not-a-uuid` refusal is gone**, because a non-uuid id is now looked up instead of refused unread.
* **The kept-payload log line stays as quiet as develop's.** The rule moved into a pure `isQuietKeep()` so a cell can pin it. A non-uuid id that names no document in the caller's tenant stays quiet (Platform S's flat repeats). One that names a document and is refused now logs, because that is a real refusal that has become reachable.
* One pre-existing lint warning fixed in `index.ts` (`prefer-const` in `GET /api/anchors/tx/:txHash`, present on develop).

## Test Evidence (local; head `16e71610366b`; baseline develop `d2ec786e6`; scratch Postgres 15, `secuura_app` NOBYPASSRLS, `documents` FORCE RLS)

**Touched:** `services/anchoring/src/anchorOverwriteGuard.ts`, `services/anchoring/src/index.ts` (the log condition, an import, and one `let`→`const`), `__tests__/ks1385-anchor-store-keeps-the-latest-events-metadata.integration.test.ts`, `__tests__/ks1385-guard-reads-under-force-rls.integration.test.ts`.

**Ran:**

| what | head | develop |
|---|---|---|
| anchoring integration (all of `vitest.integration.config.ts`: 3 files) | **47 / 47** | 30 / 30 |
| anchoring unit (`vitest run`) | 370 / 371 | 370 / 371 |
| failing-cell sets, unit and integration | — | **byte-identical**; the one unit red is `threadTokenMint.test.ts` (`@lucid-evolution`), already in BACKLOG |
| tsc, service program | 0 errors | 0 |
| tsc, **test-inclusive** program (scratch tsconfig, `exclude: []`) | **0 errors, 33 test files** | 0, 33 |
| ESLint, the 4 touched files | **0 errors, 0 warnings** | 0 / 1 (the `prefer-const` fixed here) |

**Red-first:** the new cells were run against **develop's guard**. Develop has no `isQuietKeep`, so importing it there would be a load failure, not a behavioural red. The red-first tree therefore carried a one-line shim that expresses **develop's own** `index.ts:1485` quiet condition through the new seam, and nothing else.

* **13 red / 29 green.** The red set is exactly the 13 predicted before the run: C-f, C-i, X1–X6, Q1, W4, F4, F5 and M4.
* **Every #1549 cell is green on both trees.** So is X7 (the pkey path is unchanged), and so are C-g, C-h and Q2–Q4.

**Mutants on head:**

| mutant | result | red |
|---|---|---|
| C0 comment-only control | survived | 0 |
| K1 external_id arm dropped | **killed** | F4 X1 X2 X3 X4 X6 |
| K2 primary-key arm dropped | **killed** | X7 and every pkey cell (17) |
| K3 precedence swapped (pkey first) | **killed** | **X6** |
| K4 tenant predicate dropped (superuser) | **killed** | X5 M1 C-h |
| K5 uuid parameter guard dropped (`doc-…` → `::uuid`) | **killed** | F4 X1 X3 X4 |
| N1 Kam's (b) reverted | **killed** | C-f C-i |
| N2 no-issuer refusal reason lost | **killed** | C-g C-i M5 W3 |
| N3 `hasIssuer` dropped from the issuer allow | survived — **equivalent** (`sameUuid(null, x)` is already false) | 0 |
| Q-a / Q-b / Q-c `isQuietKeep` always-false / ignores shape / ignores reason | **killed** | Q1 / Q2 / Q3 |
| Q-d `index.ts` stops gating the log on it | **killed** | W4 |

**11 of 11 killable mutants killed.**

**The #1549 round-2 gate's own end-to-end instrument** (`cells/e2e_custody.ts`, run **byte-identical** to the gate's copy) booted the real anchoring service with RS256 tokens, against this head and against develop:

| case | develop | head |
|---|---|---|
| X1 originate-minted `doc-…` external id, issuer org | **kept** (MAJ-A, reproduced) | **replaced** |
| X2 S-supplied `documentUuid`, issuer org | **kept** | **replaced** |
| X3 S-supplied `documentUuid`, a colleague in the custodian's org | **kept** | **replaced** |
| P6 NULL issuer, a colleague in the custodian's org | kept (the old limit) | **replaced** (Kam's (b)) |
| P0–P5b, P7a–P10 (incl. forged tokens → 401) | as before | **identical** |

The kept-payload warnings in the service log fell from 7 to 4: the remaining four are exactly the true refusals, P4, P5, P5b and P7a. That is the quiet-set rule holding on the real service.

**Stuart's cell** (KS-1612, 2026-10-15T06:30:21Z) is X2: *"create under a caller-supplied v4 documentUuid, then a lifecycle event addressed by that same id from the issuer's connector key."* It is green. The id is uuid-shaped and names no primary key, which is exactly why develop missed it.

**Preflight (in-hook):** `PREFLIGHT INCOMPLETE — 13/16 legs ran, 3 SKIPPED. Nothing failed.` Legs 3, 4 and 8 were skipped because the local stack is not up. **This is not a pass.**

* **The first push was REFUSED (legs 14 and 16) and landed nothing.** The cause was this worktree, not the code:
  * its `node_modules` were symlinked for root, originate, anchoring and shared only;
  * so auth, api-gateway and vc-issuer resolved the root's `@types/node` 26.1.0 instead of their own pinned 20.19.43;
  * which gave 4 new test-file type errors in services this PR does not touch (leg 16). The one red shell suite (leg 14) exercises the same ratchet.
* **Fix:** every `node_modules` was mirrored. Before the retry, the ratchet ran standalone with **0 new, 0 stale** and the suite read **38 / 0**. The retry is the push above.

**NOT run:**

* The originate → anchoring hop over HTTP. The cells key rows the way originate writes them, and the e2e posts to anchoring directly with the caller's token, which is what originate forwards (`routes/documents.ts:846`).
* Any Docker or stack leg.
* A real chain: the e2e uses the mock chain, as the gate's did.

**Migrations / config:** none.

## Residual, for the gate to judge

* **Kam's (b) is a new write, by his choice.** A certificate holder's organisation can now replace the anchored identity of a certification issued **to** it. C-f pins it, and C-g / C-h pin who still cannot.
* **Precedence when an external id equals another row's primary key: the external id wins**, as in `getDocument`. Originate refuses to create that collision (`routes/documents.ts`, a `documentUuid` that shadows another document's pkey). X6 constructs it in SQL and pins the precedence.
* **A non-uuid id that names a document in ANOTHER tenant is still a quiet keep**, exactly as on develop. The tenant-bound read cannot tell "absent" from "someone else's", by design.

🤖 Generated with [Claude Code](https://claude.com/claude-code)
