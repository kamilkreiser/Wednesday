// Gate #1568 cell: can tenant B's originate CREATE a document whose external_id equals tenant A's
// certification PRIMARY key? Drives originate's OWN repository functions (getDocument = the route's
// respondForExisting pre-check; saveDocument with conflictMode 'skip' = the documentUuid insert) against
// my Postgres through originate's own createPoolProxy. argv: ownerDbUrl tree
import * as path from 'path';
import * as crypto from 'crypto';
import { createRequire } from 'module';
const [ownerUrl, tree] = process.argv.slice(2);
const req = createRequire(path.join(tree, 'Blockchain/Dev/services/originate/package.json'));
const { Pool } = req('pg');
(async () => {
  process.env.DATABASE_URL = ownerUrl;
  const dbm = await import(path.join(tree, 'Blockchain/Dev/services/originate/src/db.ts'));
  const repo = await import(path.join(tree, 'Blockchain/Dev/services/originate/src/repositories/documentRepo.ts'));
  const pool = new Pool({ connectionString: ownerUrl });
  const db = dbm.createPoolProxy(pool);
  const u = () => crypto.randomUUID();
  const TA = u(), TB = u(), ORG_TB = u(), HOLDER = u(), U_TB = u();
  const hash = crypto.randomBytes(32).toString('hex');
  // organisations / users exist in their tenants (the insert resolves issuer_organization_id tenant-scoped)
  const orgCols = (await pool.query("SELECT column_name, is_nullable, column_default FROM information_schema.columns WHERE table_name='organizations' AND is_nullable='NO' AND column_default IS NULL")).rows.map((r: any) => r.column_name);
  console.log(JSON.stringify({ organizationsRequiredCols: orgCols }));
  const vals: Record<string, unknown> = { id: ORG_TB, tenant_id: TB, name: 'gate org TB', slug: `gate-${ORG_TB.slice(0, 8)}`, type: 'enterprise' };
  const cols = Object.keys(vals).filter((c) => orgCols.includes(c) || ['id', 'tenant_id'].includes(c));
  await pool.query(`INSERT INTO organizations (${cols.join(',')}) VALUES (${cols.map((_, i) => `$${i + 1}`).join(',')})`, cols.map((c) => vals[c]));
  await pool.query('INSERT INTO users (id, email, organization_id, tenant_id) VALUES ($1::uuid, $2, NULL, $3::uuid)', [HOLDER, `${HOLDER}@x.invalid`, TA]);
  await pool.query('INSERT INTO users (id, email, organization_id, tenant_id) VALUES ($1::uuid, $2, $3::uuid, $4::uuid)', [U_TB, `${U_TB}@x.invalid`, ORG_TB, TB]);
  // tenant A's certification, in certificationRepo's shape: id = cert.id (v4), no external_id, no issuer org
  const certId = u();
  await pool.query(`INSERT INTO documents (id, tenant_id, title, document_type, content_hash, status, owner_user_id)
                    VALUES ($1::uuid, $2::uuid, 'cert A', 'certification', $3, 'certified', $4::uuid)`, [certId, TA, hash, HOLDER]);
  const UUID_V4_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i; // routes/documents.ts:352, copied for the report only
  console.log(JSON.stringify({ step: 'cert pkey passes the route documentUuid v4 check', pass: UUID_V4_RE.test(certId) }));
  const preB = await repo.getDocument(certId, TB, db);
  const preA = await repo.getDocument(certId, TA, db);
  console.log(JSON.stringify({ step: 'respondForExisting pre-check getDocument(certPkey, TENANT_B)', result: preB, meaning: preB ? 'would 409/200' : 'null -> no refusal, insert proceeds' }));
  console.log(JSON.stringify({ step: 'control getDocument(certPkey, TENANT_A)', found: !!preA, id: preA?.id }));
  const now = new Date().toISOString();
  const saved = await repo.saveDocument({ id: certId, type: 'invoice', status: 'draft', owner: { id: U_TB, walletAddress: null }, data: { title: 'tenant B doc' }, contentHash: hash, signatures: [], createdAt: now, updatedAt: now } as any,
    TB, db, { conflictMode: 'skip', issuerOrganizationId: ORG_TB });
  console.log(JSON.stringify({ step: 'saveDocument(documentUuid = tenant A cert pkey) in TENANT_B', saved }));
  const rows = (await pool.query('SELECT id::text, external_id, tenant_id::text, issuer_organization_id::text, document_type FROM documents WHERE id = $1::uuid OR external_id = $2 ORDER BY tenant_id', [certId, certId])).rows;
  console.log(JSON.stringify({ step: 'documents rows now named by that id', rows, TA, TB }));
  await pool.end();
  process.exit(0);
})().catch((e) => { console.error('CELL ERROR', e?.stack || e); process.exit(1); });
