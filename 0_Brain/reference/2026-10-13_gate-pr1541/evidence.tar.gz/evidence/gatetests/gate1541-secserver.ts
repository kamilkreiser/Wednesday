// GATE PR1541: boot the REAL security app (this tree) on an ephemeral port, as secuura_app; write the port to argv[2].
import fs from 'fs';
process.env.SECURITY_DISABLE_BOOT = '1';
(async () => {
  const db = await import('./src/db');
  if (!(await db.initDb())) { console.error('no db'); process.exit(2); }
  const app = (await import('./src/index')).default;
  const server = app.listen(0, '127.0.0.1', () => {
    const a = server.address();
    fs.writeFileSync(process.argv[2], String(typeof a === 'object' && a ? a.port : 0));
    console.log('security listening', a);
  });
})();
