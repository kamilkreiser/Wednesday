/**
 * GATE PR1541 — register-connector observed over REAL HTTP through the REAL gateway app (index.ts, no db
 * mock, secuura_app on the gate's Postgres, FORCE RLS), with the REAL security service in a child
 * process (keys minted and validated there for real). The only stand-in is auth's
 * /internal/connector-token HTTP wrapper: it validates the key at the real security service and signs
 * exactly the claims of auth's generateConnectorToken (services/auth/src/services/jwt.ts:281-297).
 * Expected outcomes for HEAD and DEVELOP are written below BEFORE the run; GATE_TREE picks the column.
 */
import { describe, it, expect, beforeAll, afterAll, vi } from 'vitest';
import http from 'http';
import fs from 'fs';
import path from 'path';
import { spawn, type ChildProcess } from 'child_process';
import jwt from 'jsonwebtoken';
import type { AddressInfo } from 'net';
import { Pool } from 'pg';

const TREE = (process.env.GATE_TREE || 'head') as 'head' | 'dev';
const LEDGER = process.env.GATE_LEDGER as string;
const PRIV = process.env.__TEST_JWT_PRIVATE_PEM as string;
const T = 'a0000000-0000-4000-8000-0000001541aa';
const T2 = 'a0000000-0000-4000-8000-0000001541bb';
const RUN = Date.now().toString(36);
const REF = { A1: `g1541-ref-a1-${RUN}`, A2: `g1541-ref-a2-${RUN}`, T2: `g1541-ref-t2-${RUN}`, NEW: `g1541-ref-new-${RUN}`, NEW2: `g1541-ref-new2-${RUN}` };
const ledger: Record<string, unknown> = {};
const pick = (h: unknown, d: unknown) => (TREE === 'head' ? h : d);

let su: Pool; let sec: ChildProcess; let secUrl = ''; let auth: http.Server; let authUrl = ''; let gw: http.Server; let gwUrl = '';
const ORG: Record<string, string> = {};
const KEY: Record<string, string> = {};

async function listen(s: http.Server): Promise<string> {
  await new Promise<void>((r) => s.listen(0, '127.0.0.1', () => r()));
  return `http://127.0.0.1:${(s.address() as AddressInfo).port}`;
}
async function j(url: string, init: RequestInit) {
  const t0 = process.hrtime.bigint();
  const r = await fetch(url, init);
  const text = await r.text();
  const ms = Number(process.hrtime.bigint() - t0) / 1e6;
  let body: any = null; try { body = JSON.parse(text); } catch { /* */ }
  return { status: r.status, text, body, ms };
}
const sysTok = () => jwt.sign({ userId: 'g1541-sys', email: 's@g', role: 'SYSTEM_ADMIN', tenantId: T, verificationLevel: 'full' }, PRIV, { algorithm: 'RS256', expiresIn: 600 });
async function mint(body: Record<string, unknown>): Promise<string> {
  const r = await j(`${secUrl}/api/keys`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${sysTok()}` }, body: JSON.stringify({ name: 'g1541r:key', tenantId: T, ...body }) });
  if (r.status !== 201) throw new Error(`mint ${r.status} ${r.text}`);
  return r.body.data.key;
}
const REG_PATH = '/api/platform/organizations/register-connector';
function reg(key: string, body: Record<string, unknown>, opts: { path?: string; method?: string; headers?: Record<string, string> } = {}) {
  return j(`${gwUrl}${opts.path ?? REG_PATH}`, { method: opts.method ?? 'POST', headers: { 'content-type': 'application/json', 'x-api-key': key, ...(opts.headers ?? {}) }, body: JSON.stringify(body) });
}
async function orgName(id: string): Promise<string> { return (await su.query('SELECT name FROM organizations WHERE id=$1', [id])).rows[0]?.name; }
async function orgByRef(ref: string): Promise<number> { return (await su.query(`SELECT 1 FROM organizations WHERE metadata->>'externalRef'=$1`, [ref])).rowCount ?? 0; }

beforeAll(async () => {
  su = new Pool({ connectionString: process.env.TEST_DATABASE_URL, max: 2 });
  for (const [k, t, ref] of [['A1', T, REF.A1], ['A2', T, REF.A2], ['T2', T2, REF.T2]] as const) {
    const r = await su.query(`INSERT INTO organizations (name, slug, type, status, tenant_id, metadata) VALUES ($1,$2,'business','active',$3::uuid,$4::jsonb) RETURNING id`,
      [`G1541 ${k}`, `g1541-${k.toLowerCase()}-${RUN}`, t, JSON.stringify({ externalRef: ref })]);
    ORG[k] = r.rows[0].id;
  }
  // the real security service, this tree, as secuura_app
  const secDir = path.resolve(__dirname, '..', '..', '..', 'security');
  const portFile = path.join(process.env.GATE_TMP as string, `secport-${RUN}`);
  sec = spawn('npx', ['tsx', 'gate1541-secserver.ts', portFile], { cwd: secDir, env: { ...process.env, DATABASE_URL: process.env.TEST_APP_DATABASE_URL, NODE_ENV: 'test', MULTI_TENANCY_ENABLED: 'false', JWT_JWKS_URL: '', AUTH_SERVICE_URL: '' }, stdio: ['ignore', 'pipe', 'pipe'] });
  let secLog = ''; sec.stdout?.on('data', (d) => { secLog += d; }); sec.stderr?.on('data', (d) => { secLog += d; });
  for (let i = 0; i < 300 && !fs.existsSync(portFile); i++) await new Promise((r) => setTimeout(r, 200));
  if (!fs.existsSync(portFile)) throw new Error(`security did not start: ${secLog.slice(-2000)}`);
  secUrl = `http://127.0.0.1:${fs.readFileSync(portFile, 'utf8')}`;
  // auth's /internal/connector-token, claims exactly as generateConnectorToken signs them
  auth = http.createServer(async (req, res) => {
    const c: Buffer[] = []; for await (const d of req) c.push(d as Buffer);
    const send = (s: number, p: unknown) => { res.writeHead(s, { 'content-type': 'application/json' }); res.end(JSON.stringify(p)); };
    if (req.url === '/internal/connector-token') {
      const apiKey = JSON.parse(Buffer.concat(c).toString() || '{}').apiKey;
      const v = await j(`${secUrl}/api/keys/validate`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ key: apiKey }) });
      const m = v.body?.data; if (!m?.valid) return send(401, { success: false });
      const token = jwt.sign({ userId: `connector:${m.connectorId || 'api-key'}`, email: 'connector@secuura.io', role: 'connector', ...(m.organizationId ? { organizationId: m.organizationId } : {}), verificationLevel: 'api_key', type: 'connector', ...(m.tenantId ? { tenantId: m.tenantId } : {}), scopes: m.scopes }, PRIV, { algorithm: 'RS256', expiresIn: 600 });
      return send(200, { success: true, data: { token, expiresIn: 600 } });
    }
    if (req.url?.startsWith('/.well-known/')) return send(404, {});
    return send(200, { success: true });
  });
  authUrl = await listen(auth);
  for (const n of ['ANALYTICS', 'ANCHORING', 'BILLING', 'GOVERNANCE', 'KYC', 'NFT', 'NOTIFICATION', 'ORIGINATE', 'PRISM', 'REFERRAL', 'STAKING', 'TIMESTAMPING', 'TRANSFER', 'VC_ISSUER', 'WALLET']) vi.stubEnv(`${n}_SERVICE_URL`, authUrl);
  vi.stubEnv('AUTH_SERVICE_URL', authUrl);
  vi.stubEnv('SECURITY_SERVICE_URL', secUrl);
  vi.stubEnv('TENANT_PROVISIONING_URL', authUrl);
  vi.stubEnv('GATEWAY_VOUCH_SECRET', '');
  vi.stubEnv('NODE_ENV', 'test');
  vi.stubEnv('DATABASE_URL', process.env.TEST_APP_DATABASE_URL as string);
  vi.stubEnv('MULTI_TENANCY_ENABLED', 'false');
  delete process.env.JWT_JWKS_URL;
  vi.resetModules();
  const db = await import('../db');
  ledger.gatewayDbInit = await db.initDb();
  const app = (await import('../index')).default;
  gw = http.createServer(app as http.RequestListener);
  gwUrl = await listen(gw);
  KEY.BOUND_A1 = await mint({ organizationId: ORG.A1, scopes: ['organizations:register'] });
  KEY.UNBOUND = await mint({ scopes: ['organizations:register'] });
  KEY.STAR_A1 = await mint({ organizationId: ORG.A1, scopes: ['*'] });
  KEY.PLAIN_A1 = await mint({ organizationId: ORG.A1, scopes: ['documents:read'] });
}, 120000);

afterAll(async () => {
  if (LEDGER) fs.writeFileSync(LEDGER, JSON.stringify(ledger, null, 1));
  gw?.closeAllConnections(); if (gw) await new Promise<void>((r) => gw.close(() => r()));
  if (auth) await new Promise<void>((r) => auth.close(() => r()));
  if (sec) { sec.kill('SIGTERM'); }
  if (su) {
    await su.query(`DELETE FROM svc_api_keys WHERE name LIKE 'g1541r:%' OR name ILIKE 'Platform S connector — %g1541%'`);
    await su.query(`DELETE FROM organizations WHERE metadata->>'externalRef' LIKE $1`, [`g1541-ref-%-${RUN}`]);
    await su.end();
  }
  vi.unstubAllEnvs();
});

const FORBID = 'A provisioning key bound to an organisation may only re-register that organisation';

describe(`GATE-1541 register-connector over HTTP (${TREE})`, () => {
  it('R0 the gateway DB is really up (a control that the route reads the real organizations table)', () => {
    expect(ledger.gatewayDbInit).toBe(true);
  });

  it('R1 bounded A1 key re-registers its OWN organisation', async () => {
    const r = await reg(KEY.BOUND_A1, { externalRef: REF.A1 });
    ledger.R1 = { status: r.status, body: r.body };
    expect([r.status, r.body?.data?.organizationId, r.body?.data?.alreadyRegistered]).toEqual([200, ORG.A1, true]);
  });

  const refusals: Record<string, { status: number; text: string }> = {};
  it('R2 bounded A1 key names A2 (same tenant) — head refuses, develop answered with A2', async () => {
    const r = await reg(KEY.BOUND_A1, { externalRef: REF.A2 });
    refusals.sibling = r; ledger.R2 = { status: r.status, body: r.body };
    expect(r.status).toBe(pick(403, 200));
    if (TREE === 'head') expect(r.body?.error?.message).toBe(FORBID);
    else expect(r.body?.data?.organizationId).toBe(ORG.A2);
  });
  it('R3 bounded A1 key names another TENANT\'s externalRef', async () => {
    const r = await reg(KEY.BOUND_A1, { externalRef: REF.T2 });
    refusals.otherTenant = r; ledger.R3 = { status: r.status, body: r.body };
    expect(r.status).toBe(pick(403, 404));
  });
  it('R4 bounded A1 key names an UNKNOWN externalRef — head refuses and creates nothing', async () => {
    const r = await reg(KEY.BOUND_A1, { externalRef: REF.NEW });
    refusals.unknown = r; ledger.R4 = { status: r.status, body: r.body, orgCreated: await orgByRef(REF.NEW) };
    expect([r.status, await orgByRef(REF.NEW)]).toEqual(pick([403, 0], [201, 1]) as number[]);
  });
  it('R5 head: the three refusals are byte-identical (status + body)', () => {
    ledger.R5 = Object.fromEntries(Object.entries(refusals).map(([k, v]) => [k, `${v.status} ${v.text}`]));
    if (TREE === 'head') {
      expect(new Set(Object.values(refusals).map((v) => `${v.status} ${v.text}`)).size).toBe(1);
    } else {
      expect(new Set(Object.values(refusals).map((v) => `${v.status} ${v.text}`)).size).toBeGreaterThan(1);
    }
  });
  it('R6 bounded A1 key tries to RENAME A2 — head refuses and the name is unchanged', async () => {
    const before = await orgName(ORG.A2);
    const r = await reg(KEY.BOUND_A1, { externalRef: REF.A2, organizationName: 'PWNED by g1541' });
    const after = await orgName(ORG.A2);
    ledger.R6 = { status: r.status, before, after };
    expect([r.status, after === before]).toEqual(pick([403, true], [200, false]) as unknown[]);
  });
  it('R7 the wildcard * key bounded to A1 names A2', async () => {
    const r = await reg(KEY.STAR_A1, { externalRef: REF.A2 });
    ledger.R7 = { status: r.status, body: r.body };
    expect(r.status).toBe(pick(403, 200));
  });
  it('R8 CONTROL: the org-less (Platform S) key creates a NEW organisation and receives its key', async () => {
    const r = await reg(KEY.UNBOUND, { externalRef: REF.NEW2, organizationName: 'G1541 new' });
    ledger.R8 = { status: r.status, hasKey: Boolean(r.body?.data?.key), created: await orgByRef(REF.NEW2), text: r.status >= 400 ? r.text : '' };
    expect([r.status, Boolean(r.body?.data?.key), await orgByRef(REF.NEW2)]).toEqual([201, true, 1]);
  });
  it('R9 CONTROL: the org-less key re-registers A2 (unbounded by the ruling)', async () => {
    const r = await reg(KEY.UNBOUND, { externalRef: REF.A2 });
    ledger.R9 = { status: r.status };
    expect(r.status).toBe(200);
  });
  it('R10 CONTROL: a non-provisioning A1 key is refused by requireOrgProvisioner (both trees)', async () => {
    const r = await reg(KEY.PLAIN_A1, { externalRef: REF.A1 });
    ledger.R10 = { status: r.status, msg: r.body?.error?.message };
    expect(r.status).toBe(403);
    expect(r.body?.error?.message).not.toBe(FORBID);
  });

  // bypass attempts: every spelling must never answer 200/201 with A2 on head
  const BYPASS: Array<[string, Record<string, unknown>, { path?: string; method?: string; headers?: Record<string, string> }]> = [
    ['trailing slash', { externalRef: REF.A2 }, { path: `${REG_PATH}/` }],
    ['upper-case path', { externalRef: REF.A2 }, { path: REG_PATH.toUpperCase() }],
    ['/api/v1 alias', { externalRef: REF.A2 }, { path: REG_PATH.replace('/api/', '/api/v1/') }],
    ['/API/V1 alias', { externalRef: REF.A2 }, { path: REG_PATH.replace('/api/', '/API/V1/') }],
    ['double slash', { externalRef: REF.A2 }, { path: REG_PATH.replace('/organizations', '//organizations') }],
    ['padded externalRef', { externalRef: `  ${REF.A2}  ` }, {}],
    ['x-organization-id header = A2', { externalRef: REF.A2 }, { headers: { 'x-organization-id': ORG.A2 } }],
    ['x-organization-id header empty', { externalRef: REF.A2 }, { headers: { 'x-organization-id': '' } }],
    ['body organizationId = A2', { externalRef: REF.A2, organizationId: ORG.A2 }, {}],
    ['X-HTTP-Method-Override PUT', { externalRef: REF.A2 }, { headers: { 'X-HTTP-Method-Override': 'PUT' } }],
    ['?_method=PUT', { externalRef: REF.A2 }, { path: `${REG_PATH}?_method=PUT` }],
    ['PUT method', { externalRef: REF.A2 }, { method: 'PUT' }],
    ['tenantSlug supplied', { externalRef: REF.A2, tenantSlug: 'g1541' }, {}],
  ];
  for (const [label, body, opts] of BYPASS) {
    it(`R-BYPASS ${label}`, async () => {
      const r = await reg(KEY.BOUND_A1, body, opts);
      ledger[`BYPASS ${label}`] = { status: r.status, text: r.text.slice(0, 160) };
      if (TREE === 'head') {
        expect(r.status === 200 || r.status === 201, `${label} answered ${r.status} ${r.text.slice(0, 120)}`).toBe(false);
        expect(r.text.includes(ORG.A2)).toBe(false);
      }
    });
  }

  it('R-TIMING head: 40 samples each of sibling / other-tenant / unknown refusals, medians within noise', async () => {
    const S: Record<string, number[]> = { sibling: [], otherTenant: [], unknown: [], own: [] };
    for (let i = 0; i < 40; i++) {
      for (const [k, ref] of [['sibling', REF.A2], ['otherTenant', REF.T2], ['unknown', `g1541-ref-nx${i}-${RUN}`], ['own', REF.A1]] as const) {
        S[k].push((await reg(KEY.BOUND_A1, { externalRef: ref })).ms);
      }
    }
    const med = (a: number[]) => { const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
    const q = (a: number[], p: number) => { const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length * p)]; };
    ledger.TIMING = Object.fromEntries(Object.entries(S).map(([k, v]) => [k, { median: med(v), p10: q(v, 0.1), p90: q(v, 0.9) }]));
    if (TREE === 'head') {
      const m = [med(S.sibling), med(S.otherTenant), med(S.unknown)];
      // noise band: the spread of the three refusal medians must be under 2 ms AND under half the own-org IQR-ish band
      ledger.TIMING_spread_ms = Math.max(...m) - Math.min(...m);
      expect(Math.max(...m) - Math.min(...m)).toBeLessThan(2);
    }
  }, 120000);
});
