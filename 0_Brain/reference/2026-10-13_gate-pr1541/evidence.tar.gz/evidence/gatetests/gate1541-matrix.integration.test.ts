/**
 * GATE PR1541 — the escape matrix over the REAL security mint route, every mint principal, every
 * organisation spelling, then the minted key USED at hop 2 as the connector principal the platform
 * builds (validate at this service, auth's generateConnectorToken claims). Expected statuses for
 * HEAD and DEVELOP are written in the tables below BEFORE the run; GATE_TREE picks the column.
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import fs from 'fs';
import type { Server } from 'http';
import type { AddressInfo } from 'net';
import { Pool } from 'pg';

process.env.SECURITY_DISABLE_BOOT = '1';
const TREE = (process.env.GATE_TREE || 'head') as 'head' | 'dev';
const LEDGER = process.env.GATE_LEDGER as string;
const KEYS_IN = process.env.GATE_KEYS_IN;
const T = 'a0000000-0000-4000-8000-0000001541aa';
const T_OTHER = 'a0000000-0000-4000-8000-0000001541bb';
const A1 = 'abcdef00-1541-4541-8541-0000000000a1';
const A2 = 'abcdef00-1541-4541-8541-0000000000a2';
const A3 = 'abcdef00-1541-4541-8541-0000000000a3';
const NAME = 'g1541m:';
const U_A1 = crypto.randomUUID();
const U_A12 = crypto.randomUUID();
const U_NONE = crypto.randomUUID();
const ledger: Record<string, unknown> = {};

const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const PEM = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const b64 = (b: Buffer): string => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function token(claims: Record<string, unknown>): string {
  const h = b64(Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const now = Math.floor(Date.now() / 1000);
  const p = b64(Buffer.from(JSON.stringify({ iat: now, exp: now + 600, ...claims })));
  return `${h}.${p}.${b64(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), PEM))}`;
}
let server: Server; let base: string; let su: Pool;
async function post(path: string, tok: string | null, body: Record<string, unknown>) {
  const r = await fetch(`${base}${path}`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(tok ? { Authorization: `Bearer ${tok}` } : {}) }, body: JSON.stringify(body) });
  const text = await r.text(); let j: any = {}; try { j = JSON.parse(text); } catch { /* */ }
  return { status: r.status, j, text };
}
/** auth's generateConnectorToken (services/auth/src/services/jwt.ts:281-297) from validate metadata. */
function connTok(meta: { connectorId?: string | null; organizationId?: string | null; tenantId?: string | null; scopes?: string[] }): string {
  return token({
    userId: `connector:${meta.connectorId || 'api-key'}`, email: 'connector@secuura.io', role: 'connector',
    ...(meta.organizationId ? { organizationId: meta.organizationId } : {}), verificationLevel: 'api_key', type: 'connector',
    ...(meta.tenantId ? { tenantId: meta.tenantId } : {}), scopes: meta.scopes || [],
  });
}
const P = {
  ADMIN_A1: () => token({ role: 'ADMIN', tenantId: T, userId: U_A1 }),
  ADMIN_A12: () => token({ role: 'ADMIN', tenantId: T, userId: U_A12 }),
  ADMIN_NONE: () => token({ role: 'ADMIN', tenantId: T, userId: U_NONE }),
  admin_A1: () => token({ role: 'admin', tenantId: T, userId: U_A1 }),
  ISSUER_A1: () => token({ role: 'ISSUER_ADMIN', tenantId: T, userId: U_NONE, organizationId: A1 }),
  ORG_A1: () => token({ role: 'ORG_ADMIN', tenantId: T, userId: U_NONE, organizationId: A1 }),
  ORG_NONE: () => token({ role: 'ORG_ADMIN', tenantId: T, userId: U_NONE }),
  SYS: () => token({ role: 'SYSTEM_ADMIN', tenantId: T, userId: crypto.randomUUID() }),
  super_admin: () => token({ role: 'super_admin', tenantId: T, userId: crypto.randomUUID() }),
  CONN_PROV_A1: () => connTok({ connectorId: 'c_prov_a1', organizationId: A1, tenantId: T, scopes: ['organizations:register'] }),
  CONN_PROV_NONE: () => connTok({ connectorId: 'c_prov_none', tenantId: T, scopes: ['organizations:register'] }),
  CONN_STAR_A1: () => connTok({ connectorId: 'c_star', organizationId: A1, tenantId: T, scopes: ['*'] }),
  CONN_ORGSTAR: () => connTok({ connectorId: 'c_orgstar', tenantId: T, scopes: ['organizations:*'] }),
} as const;
type PK = keyof typeof P;
const REG = ['organizations:register'];

// ---- HOP 1: [label, principal, organizationId (undefined = omitted), scopes, expectHEAD, expectDEV]
const H1: Array<[string, PK, string | undefined, string[], number, number]> = [
  ['ADMIN{A1} A1', 'ADMIN_A1', A1, REG, 201, 201],
  ['ADMIN{A1} A2', 'ADMIN_A1', A2, REG, 403, 403],
  ['ADMIN{A1} none', 'ADMIN_A1', undefined, REG, 403, 201],
  ['ADMIN{A1} A1-UPPER', 'ADMIN_A1', A1.toUpperCase(), REG, 201, 201],
  ['ADMIN{A1} A1-padded', 'ADMIN_A1', `  ${A1}  `, REG, 201, 201],
  ['ADMIN{A1} NBSP-A1', 'ADMIN_A1', ` ${A1}`, REG, 201, 201],
  ['ADMIN{A1} {A1}', 'ADMIN_A1', `{${A1}}`, REG, 403, 403],
  ['ADMIN{A1} not-a-uuid', 'ADMIN_A1', 'not-a-uuid', REG, 403, 403],
  ['ADMIN{A1} empty-string', 'ADMIN_A1', '', REG, 403, 201],
  ['ADMIN{A1} whitespace', 'ADMIN_A1', '   ', REG, 403, 201],
  ['ADMIN{A1} none scopes[*]', 'ADMIN_A1', undefined, ['*'], 403, 201],
  ['ADMIN{A1} none scopes[organizations:*]', 'ADMIN_A1', undefined, ['organizations:*'], 403, 201],
  ['ADMIN{A1} A1 scopes[organizations:*]', 'ADMIN_A1', A1, ['organizations:*'], 201, 201],
  ['ADMIN{A1} none scopes[ORGANIZATIONS:REGISTER] (case: not provisioning-capable anywhere)', 'ADMIN_A1', undefined, ['ORGANIZATIONS:REGISTER'], 201, 201],
  ['ADMIN{A1} none scopes[documents:read] CONTROL', 'ADMIN_A1', undefined, ['documents:read'], 201, 201],
  ['ADMIN{A1} none scopes[documents:*] CONTROL', 'ADMIN_A1', undefined, ['documents:*'], 201, 201],
  ['ADMIN{A1,A2} A1', 'ADMIN_A12', A1, REG, 201, 201],
  ['ADMIN{A1,A2} A2', 'ADMIN_A12', A2, REG, 201, 201],
  ['ADMIN{A1,A2} none', 'ADMIN_A12', undefined, REG, 403, 201],
  ['ADMIN{} A1', 'ADMIN_NONE', A1, REG, 403, 403],
  ['ADMIN{} none', 'ADMIN_NONE', undefined, REG, 403, 201],
  ['admin(lower){A1} A1', 'admin_A1', A1, REG, 201, 201],
  ['admin(lower){A1} A2', 'admin_A1', A2, REG, 403, 403],
  ['admin(lower){A1} none', 'admin_A1', undefined, REG, 403, 201],
  ['ISSUER_ADMIN(A1) A1', 'ISSUER_A1', A1, REG, 201, 201],
  ['ISSUER_ADMIN(A1) A2', 'ISSUER_A1', A2, REG, 403, 403],
  ['ISSUER_ADMIN(A1) none', 'ISSUER_A1', undefined, REG, 403, 201],
  ['ISSUER_ADMIN(A1) A1-UPPER', 'ISSUER_A1', A1.toUpperCase(), REG, 201, 201],
  ['ORG_ADMIN(A1) A1', 'ORG_A1', A1, REG, 201, 201],
  ['ORG_ADMIN(A1) A2', 'ORG_A1', A2, REG, 403, 403],
  ['ORG_ADMIN(A1) none', 'ORG_A1', undefined, REG, 403, 201],
  ['ORG_ADMIN(no org) A1', 'ORG_NONE', A1, REG, 403, 403],
  ['ORG_ADMIN(no org) none', 'ORG_NONE', undefined, REG, 403, 201],
  ['SYSTEM_ADMIN none', 'SYS', undefined, REG, 201, 201],
  ['SYSTEM_ADMIN A2', 'SYS', A2, REG, 201, 201],
  ['super_admin none', 'super_admin', undefined, REG, 201, 201],
  ['connector register(A1) mints register A1', 'CONN_PROV_A1', A1, REG, 403, 403],
  ['connector register(org-less) mints register none', 'CONN_PROV_NONE', undefined, REG, 403, 403],
  ['connector *(A1) mints documents:read A1', 'CONN_STAR_A1', A1, ['documents:read'], 403, 403],
  ['connector organizations:*(org-less) mints documents:read A2', 'CONN_ORGSTAR', A2, ['documents:read'], 403, 403],
];

// ---- HOP 2 chains: a hop-1 mint allowed on BOTH trees, then requests with the minted key.
type H2 = [string, Record<string, unknown>, number, number];
const CHAINS: Array<[string, PK, Record<string, unknown>, H2[]]> = [
  ['K_A1 (ADMIN{A1} -> A1 register key)', 'ADMIN_A1', { organizationId: A1, scopes: REG }, [
    ['A1', { organizationId: A1 }, 201, 201],
    ['A2', { organizationId: A2 }, 403, 201],
    ['A3 sibling', { organizationId: A3 }, 403, 201],
    ['none', {}, 201, 201],
    ['A1 + connectorId', { organizationId: A1, connectorId: 'conn_x' }, 403, 201],
    ['none + connectorId', { connectorId: 'conn_of_A2' }, 403, 201],
    ['A1 + connectorId + rotate', { organizationId: A1, connectorId: 'conn_x', rotate: true }, 403, 403],
    ['A1-UPPER', { organizationId: A1.toUpperCase() }, 201, 201],
    ['A1-padded', { organizationId: ` ${A1} ` }, 201, 201],
    ['{A1}', { organizationId: `{${A1}}` }, 403, 201],
    ['not-a-uuid', { organizationId: 'not-a-uuid' }, 403, 201],
    ['A2-UPPER', { organizationId: A2.toUpperCase() }, 403, 201],
    ['other tenant body', { organizationId: A1, tenantId: T_OTHER }, 403, 403],
    ['A1 scopes[organizations:register]', { organizationId: A1, scopes: REG }, 403, 403],
  ]],
  ['K_A2 (ADMIN{A1,A2} -> A2 register key)', 'ADMIN_A12', { organizationId: A2, scopes: REG }, [
    ['A1', { organizationId: A1 }, 403, 201],
    ['A2', { organizationId: A2 }, 201, 201],
  ]],
  ['K_ISS (ISSUER_ADMIN(A1) -> A1 register key)', 'ISSUER_A1', { organizationId: A1, scopes: REG }, [
    ['A2', { organizationId: A2 }, 403, 201],
    ['A2 + connectorId', { organizationId: A2, connectorId: 'conn_of_A2' }, 403, 201],
  ]],
  ['K_ORG (ORG_ADMIN(A1) -> A1 register key)', 'ORG_A1', { organizationId: A1, scopes: REG }, [
    ['A2', { organizationId: A2 }, 403, 201],
  ]],
  ['K_SYS_NONE (SYSTEM_ADMIN -> org-less register key)', 'SYS', { scopes: REG }, [
    ['A2', { organizationId: A2 }, 201, 201],
    ['A2 + connectorId', { organizationId: A2, connectorId: 'conn_of_A2' }, 201, 201],
    ['A2 + connectorId + rotate', { organizationId: A2, connectorId: 'conn_of_A2', rotate: true }, 403, 403],
  ]],
  ['K_SYS_A1 (SYSTEM_ADMIN -> A1 register key, platform-minted BOUNDED)', 'SYS', { organizationId: A1, scopes: REG }, [
    ['A2', { organizationId: A2 }, 403, 201],
    ['A1 + connectorId', { organizationId: A1, connectorId: 'conn_x' }, 403, 201],
  ]],
  ['K_UPPER (ADMIN{A1} -> A1-UPPER register key)', 'ADMIN_A1', { organizationId: A1.toUpperCase(), scopes: REG }, [
    ['A1', { organizationId: A1 }, 201, 201],
    ['A2', { organizationId: A2 }, 403, 201],
  ]],
  ['K_ORGSTAR (ADMIN{A1} -> A1 organizations:* key)', 'ADMIN_A1', { organizationId: A1, scopes: ['organizations:*'] }, [
    ['A1', { organizationId: A1 }, 403, 403],
    ['A2', { organizationId: A2 }, 403, 403],
  ]],
  ['K_MIX (ADMIN{A1} -> A1 [register,*] key)', 'ADMIN_A1', { organizationId: A1, scopes: ['organizations:register', '*'] }, [
    ['A1', { organizationId: A1 }, 201, 201],
    ['A2', { organizationId: A2 }, 403, 201],
  ]],
];

// ---- originate-minted keys (stage 1 output), used at hop 2. Same expectation on both trees: this PR
// does not touch originate, and a whitespace / null organization_id reads as UNBOUNDED by design.
const ORIG: Array<[string, string, Record<string, unknown>, number, number]> = [
  ['o2 ORG_ADMIN(A1) register, organizationId "   "', 'A2 + connectorId', { organizationId: A2, connectorId: 'conn_of_A2' }, 201, 201],
  ['o4 ORG_ADMIN(no org) register, no org', 'A2 + connectorId', { organizationId: A2, connectorId: 'conn_of_A2' }, 201, 201],
  ['o3 ORG_ADMIN(A1) register, organizationId A2', 'A2', { organizationId: A2 }, 201, 201],
  ['o3 ORG_ADMIN(A1) register, organizationId A2', 'A1', { organizationId: A1 }, 403, 201],
];

beforeAll(async () => {
  su = new Pool({ connectionString: process.env.TEST_DATABASE_URL, max: 2 });
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  for (const [u, o] of [[U_A1, A1], [U_A12, A1], [U_A12, A2]]) {
    await su.query('INSERT INTO admin_organisation_scopes (tenant_id,user_id,organization_id,granted_by) VALUES ($1,$2,$3,$4)', [T, u, o, 'g1541']);
  }
  process.env.DATABASE_URL = process.env.TEST_APP_DATABASE_URL;
  process.env.JWT_PUBLIC_KEY = Buffer.from(publicKey.export({ type: 'spki', format: 'pem' }).toString(), 'utf8').toString('base64');
  delete process.env.JWT_JWKS_URL; delete process.env.AUTH_SERVICE_URL;
  const db = await import('../db'); if (!(await db.initDb())) throw new Error('no db');
  const app = (await import('../index')).default;
  await new Promise<void>((r) => { server = app.listen(0, '127.0.0.1', r); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
afterAll(async () => {
  if (LEDGER) fs.writeFileSync(LEDGER, JSON.stringify(ledger, null, 1));
  if (server) await new Promise<void>((r) => server.close(() => r()));
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  await su.query('DELETE FROM admin_organisation_scopes WHERE user_id = ANY($1::uuid[])', [[U_A1, U_A12, U_NONE]]);
  await su.end(); const db = await import('../db'); await db.closeDb();
});

const pick = (h: number, d: number): number => (TREE === 'head' ? h : d);
async function becomeConnector(key: string) {
  const v = await post('/api/keys/validate', null, { key });
  return { v, tok: v.j?.data?.valid ? connTok(v.j.data) : null };
}

describe(`GATE-1541 hop 1 matrix (${TREE})`, () => {
  for (const [label, pk, org, scopes, eh, ed] of H1) {
    it(`H1 ${label}`, async () => {
      const r = await post('/api/keys', P[pk](), { name: `${NAME}h1`, tenantId: T, scopes, ...(org !== undefined ? { organizationId: org } : {}) });
      const row = r.j?.data?.id ? (await su.query('SELECT organization_id FROM svc_api_keys WHERE id=$1', [r.j.data.id])).rows[0] : null;
      ledger[`H1 ${label}`] = { expect: pick(eh, ed), got: r.status, storedOrg: row?.organization_id ?? null, msg: r.status === 201 ? '' : String(r.j?.error?.message ?? r.text).slice(0, 140) };
      expect(r.status).toBe(pick(eh, ed));
    });
  }
});

describe(`GATE-1541 hop 2 chains (${TREE})`, () => {
  for (const [chain, pk, mintBody, reqs] of CHAINS) {
    it(`H2 ${chain}`, async () => {
      const m = await post('/api/keys', P[pk](), { name: `${NAME}c1`, tenantId: T, ...mintBody });
      expect(m.status, `${chain}: the hop-1 mint must succeed on both trees`).toBe(201);
      const { v, tok } = await becomeConnector(m.j.data.key);
      ledger[`H2 ${chain} :: validate`] = { organizationId: v.j?.data?.organizationId ?? null, scopes: v.j?.data?.scopes };
      const fails: string[] = [];
      for (const [rl, body, eh, ed] of reqs) {
        const r = await post('/api/keys', tok, { name: `${NAME}c2`, tenantId: T, scopes: ['documents:read'], ...body });
        const row = r.j?.data?.id ? (await su.query('SELECT organization_id, connector_id FROM svc_api_keys WHERE id=$1', [r.j.data.id])).rows[0] : null;
        ledger[`H2 ${chain} :: ${rl}`] = { expect: pick(eh, ed), got: r.status, stored: row, msg: r.status === 201 ? '' : String(r.j?.error?.message ?? r.text).slice(0, 140) };
        if (r.status !== pick(eh, ed)) fails.push(`${rl}: expected ${pick(eh, ed)} got ${r.status}`);
      }
      expect(fails).toEqual([]);
    });
  }
});

describe(`GATE-1541 hop 2 with originate-minted keys (${TREE})`, () => {
  it('H2 originate keys', async () => {
    if (!KEYS_IN) { ledger['H2 originate'] = 'NOT RUN: no GATE_KEYS_IN'; return; }
    const keys = JSON.parse(fs.readFileSync(KEYS_IN, 'utf8'));
    const fails: string[] = [];
    for (const [ol, rl, body, eh, ed] of ORIG) {
      const k = keys[ol]?.key; if (!k) { fails.push(`${ol}: no key`); continue; }
      const { v, tok } = await becomeConnector(k);
      const r = await post('/api/keys', tok, { name: `${NAME}o2`, tenantId: T, scopes: ['documents:read'], ...body });
      const row = r.j?.data?.id ? (await su.query('SELECT organization_id, connector_id FROM svc_api_keys WHERE id=$1', [r.j.data.id])).rows[0] : null;
      ledger[`H2 ORIG ${ol} :: ${rl}`] = { validateOrg: v.j?.data?.organizationId ?? null, expect: pick(eh, ed), got: r.status, stored: row };
      if (r.status !== pick(eh, ed)) fails.push(`${ol} ${rl}: expected ${pick(eh, ed)} got ${r.status}`);
    }
    expect(fails).toEqual([]);
  });
});
