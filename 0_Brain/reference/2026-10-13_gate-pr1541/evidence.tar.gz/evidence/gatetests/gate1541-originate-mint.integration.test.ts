/**
 * GATE PR1541 (originate stage): a SECOND hop-1. originate's POST /api/admin/api-keys (requireRole
 * SYSTEM_ADMIN, ORG_ADMIN) INSERTs into svc_api_keys with caller-chosen `permissions` and
 * `organizationId: body || claim || null`. The real adminConfigRouter, real authenticate() (RS256),
 * real requireRole, real extractTenantContext over a TenantPoolManager, real prisma, connecting as
 * secuura_app (FORCE RLS). Writes each minted plaintext key to GATE_KEYS for the security stage.
 * Expected statuses are written in EXPECT before the run.
 */
import http from 'http';
import fs from 'fs';
import { Client } from 'pg';
import jwt from 'jsonwebtoken';

const APP_DB = process.env.TEST_APP_DATABASE_URL as string;
const SU_DB = process.env.TEST_DATABASE_URL as string;
const PLATFORM_DB = process.env.PLATFORM_DATABASE_URL as string;
process.env.DATABASE_URL = process.env.GATE_AS_SU === '1' ? SU_DB : APP_DB;
process.env.PLATFORM_DATABASE_URL = PLATFORM_DB;
process.env.JWT_SECRET = 'gate1541-unused';
const { privateKey: _p, publicKey: _u } = require('crypto').generateKeyPairSync('rsa', { modulusLength: 2048 });
const PEM = _p.export({ type: 'pkcs8', format: 'pem' }).toString();
process.env.JWT_PUBLIC_KEY = Buffer.from(_u.export({ type: 'spki', format: 'pem' }).toString()).toString('base64');
process.env.MULTI_TENANCY_ENABLED = process.env.GATE_MT || 'true';
process.env.NODE_ENV = 'test';

const T = 'a0000000-0000-4000-8000-0000001541aa';
const A1 = 'abcdef00-1541-4541-8541-0000000000a1';
const A2 = 'abcdef00-1541-4541-8541-0000000000a2';
const NAME = 'g1541o:';
const OUT = process.env.GATE_KEYS as string;
const keys: Record<string, unknown> = {};

// EXPECTED, written before the run (identical on develop and head: this PR does not touch originate).
const EXPECT: Record<string, number> = {
  'o1 ORG_ADMIN(A1) register, no org': 201,
  'o2 ORG_ADMIN(A1) register, organizationId "   "': 201,
  'o3 ORG_ADMIN(A1) register, organizationId A2': 201,
  'o4 ORG_ADMIN(no org) register, no org': 201,
  'o5 ORG_ADMIN(A1) *, no org': 201,
  'o6 CONTROL ADMIN register': 403,
  'o7 CONTROL ISSUER_ADMIN register': 403,
  'o8 CONTROL no token': 401,
};

let server: http.Server; let base: string; let platform: Client; let su: Client; let disconnect: () => Promise<void>;
const sign = (p: object): string => jwt.sign(p, PEM, { algorithm: 'RS256', expiresIn: 600 });

beforeAll(async () => {
  if (!APP_DB || !SU_DB || !PLATFORM_DB || !OUT) throw new Error('env missing');
  const db = require('../db');
  const { adminConfigRouter } = require('../routes/adminConfig');
  const { extractTenantContext, tenantGucContext } = require('@secuura/shared');
  const express = require('express');
  disconnect = db.disconnectDb;
  platform = new Client({ connectionString: PLATFORM_DB }); await platform.connect();
  su = new Client({ connectionString: SU_DB }); await su.connect();
  const u = new URL(SU_DB);
  await platform.query(`INSERT INTO tenants (id,name,slug,status) VALUES ($1,'G1541','g1541-o','active') ON CONFLICT (id) DO NOTHING`, [T]);
  await platform.query(`INSERT INTO tenant_config (tenant_id,db_name,db_host,db_port) VALUES ($1,$2,$3,$4) ON CONFLICT (tenant_id) DO NOTHING`, [T, u.pathname.slice(1), u.hostname, parseInt(u.port, 10)]);
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  await db.initDb();
  const manager = db.getTenantManager();
  if (!manager && process.env.MULTI_TENANCY_ENABLED === 'true') throw new Error('no tenant manager');
  if (manager) await db.refreshTenantConfigs();
  const app = express();
  app.use(express.json());
  // Mirrors services/originate/src/index.ts:218-258 (the production wiring): the MT block, then the
  // UNCONDITIONAL KS-458 tenant resolver, then tenantGucContext() so the prisma proxy sets the RLS GUC.
  if (manager) app.use((req: any, res: any, next: any) => extractTenantContext(manager)(req, res, next));
  app.use((req: any, _res: any, next: any) => {
    const attached = req.tenantId; const header = req.headers['x-tenant-id'];
    req.tenantId = (typeof attached === 'string' && attached.length > 0 ? attached : undefined)
      || (typeof header === 'string' && header.length > 0 ? header : undefined) || 'a0000000-0000-4000-8000-000000000001';
    next();
  });
  if (process.env.GATE_NO_GUC !== '1') app.use(tenantGucContext());
  app.use('/api/admin', adminConfigRouter);
  server = http.createServer(app);
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  const a = server.address();
  base = `http://127.0.0.1:${typeof a === 'object' && a ? a.port : 0}`;
}, 30000);

afterAll(async () => {
  fs.writeFileSync(OUT, JSON.stringify(keys, null, 1));
  if (server) await new Promise<void>((r) => server.close(() => r()));
  if (platform) {
    await platform.query('DELETE FROM tenant_config WHERE tenant_id=$1', [T]);
    await platform.query('DELETE FROM tenants WHERE id=$1', [T]);
    await platform.end();
  }
  if (su) await su.end();
  if (disconnect) await disconnect();
});

const tok = (role: string, org?: string): string =>
  sign({ userId: `g1541-${role}-${org ?? 'none'}`, email: 'g@g1541.test', role, tenantId: T, ...(org ? { organizationId: org } : {}), verificationLevel: 'full' });

const CASES: Array<[string, string | null, Record<string, unknown>]> = [
  ['o1 ORG_ADMIN(A1) register, no org', tok('ORG_ADMIN', A1), { permissions: ['organizations:register'] }],
  ['o2 ORG_ADMIN(A1) register, organizationId "   "', tok('ORG_ADMIN', A1), { permissions: ['organizations:register'], organizationId: '   ' }],
  ['o3 ORG_ADMIN(A1) register, organizationId A2', tok('ORG_ADMIN', A1), { permissions: ['organizations:register'], organizationId: A2 }],
  ['o4 ORG_ADMIN(no org) register, no org', tok('ORG_ADMIN'), { permissions: ['organizations:register'] }],
  ['o5 ORG_ADMIN(A1) *, no org', tok('ORG_ADMIN', A1), { permissions: ['*'] }],
  ['o6 CONTROL ADMIN register', tok('ADMIN', A1), { permissions: ['organizations:register'] }],
  ['o7 CONTROL ISSUER_ADMIN register', tok('ISSUER_ADMIN', A1), { permissions: ['organizations:register'] }],
  ['o8 CONTROL no token', null, { permissions: ['organizations:register'] }],
];

describe('GATE-1541 originate: a second hop-1 route for provisioning-capable keys', () => {
  for (const [label, t, body] of CASES) {
    it(label, async () => {
      const r = await fetch(`${base}/api/admin/api-keys`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-tenant-id': T, ...(t ? { authorization: `Bearer ${t}` } : {}) },
        body: JSON.stringify({ name: `${NAME}${label.slice(0, 2)}`, ...body }),
      });
      const j: any = await r.json().catch(() => null);
      let row: any = null;
      if (j?.apiKey?.id) {
        row = (await su.query('SELECT organization_id, scopes, tenant_id::text AS t FROM svc_api_keys WHERE id=$1', [j.apiKey.id])).rows[0];
      }
      keys[label] = { status: r.status, key: j?.key ?? null, row, err: r.status >= 400 ? JSON.stringify(j).slice(0, 200) : undefined };
      expect(r.status).toBe(EXPECT[label]);
    });
  }
});
