#!/usr/bin/env python3
"""GATE PR1541 mutant runner. Each mutant is an exact single-occurrence replacement in a HEAD source file of the
gate's scratch worktree. INVALID if the anchor is not found exactly once. After each: rebuild packages/shared when a
shared file moved, run the cell groups, restore the original bytes and assert byte-identity (and rebuild shared)."""
import json, os, re, subprocess, sys, shutil

W = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad/g1541'
D = W + '/head/Blockchain/Dev'
OUT = W + '/ev/mutants'
os.makedirs(OUT, exist_ok=True)
APP_PW = open(W + '/pg/app_pw').read().strip()
ENV = dict(os.environ, TEST_DATABASE_URL='postgresql://secuura@127.0.0.1:55413/secuura',
           TEST_APP_DATABASE_URL=f'postgresql://secuura_app:{APP_PW}@127.0.0.1:55413/secuura',
           NODE_ENV='test', MULTI_TENANCY_ENABLED='false', GATE_TREE='head', GATE_TMP=W + '/tmp',
           GATE_KEYS_IN=W + '/ev/runs/keys_orig_head_su.json')
ENV.pop('PLATFORM_DATABASE_URL', None)

KRP = 'packages/shared/src/security/keyRevokePolicy.ts'
SCO = 'packages/shared/src/security/scopes.ts'
SEC = 'services/security/src/index.ts'
PLA = 'services/api-gateway/src/routes/platform.ts'

M = [
  ('M0', 'comment-only control', SEC, "    // KS-1584 HOP 1 (pull request 1535 gate M1).", "    // KS-1584 HOP 1 (pull request 1535 gate M1). [M0 comment]"),
  ('M1', 'author: the provisioner arm removed', KRP, "if (organisationScope && user.role === 'connector' && isProvisioningCapable(user.scopes)) {", "if (organisationScope && user.role === 'connector__M1' && isProvisioningCapable(user.scopes)) {"),
  ('M2', 'author: the bound compared RAW (caller claim not normalised)', KRP, "    const callerOrg = normaliseOrgId(user.organizationId);\n    if (!callerOrg) {\n      return { allow: true, reason: 'unbounded provisioning key' };", "    const callerOrg = (user.organizationId ?? '').trim() || null;\n    if (!callerOrg) {\n      return { allow: true, reason: 'unbounded provisioning key' };"),
  ('M3', 'author: the HOP-1 default deny removed', SEC, "    if (isProvisioningCapable(requestedScopes as (string | null | undefined)[])\n", "    if (process.env.__M3 === 'on' && isProvisioningCapable(requestedScopes as (string | null | undefined)[])\n"),
  ('M4', 'author: wildcards NOT provisioning-capable (literal includes)', SCO, "  return hasScope(claimed, PROVISIONING_SCOPE_NAME);", "  return claimed.includes(PROVISIONING_SCOPE_NAME);"),
  ('M5', 'author: a BOUNDED provisioner may name a connectorId again', SEC, "      if (boundedProvisioner) {", "      if (boundedProvisioner && process.env.__M5 === 'on') {"),
  ('M6', 'author: the gateway decision lets a bounded key CREATE a new organisation', KRP, "  if (hitOrg === null || hitOrg !== ownOrg) {", "  if (hitOrg !== null && hitOrg !== ownOrg) {"),
  ('M7', 'author: the platform-minted ORG-LESS key becomes BOUNDED', KRP, "      return { allow: true, reason: 'unbounded provisioning key' };", "      return { allow: false, status: 403, reason: 'outside provisioning key organisation' };"),
  ('M8', 'author: decideProvisionerRegistration ignores the org-less exemption', KRP, "  const bounded = args.byConnector && isProvisioningCapable(args.callerScopes) && ownOrg !== null;", "  const bounded = args.byConnector && isProvisioningCapable(args.callerScopes);"),
  ('G1', 'gate: hop-2 bound dropped for WILDCARD-only keys (literal scope at the arm)', KRP, "if (organisationScope && user.role === 'connector' && isProvisioningCapable(user.scopes)) {", "if (organisationScope && user.role === 'connector' && (user.scopes ?? []).includes('organizations:register')) {"),
  ('G2', 'gate: bound compared against the caller TENANT instead of the key row organisation', KRP, "    if (callerOrg !== targetOrg) {\n      return { allow: false, status: 403, reason: 'outside provisioning key organisation' };", "    if (normaliseOrgId(user.tenantId) !== targetOrg) {\n      return { allow: false, status: 403, reason: 'outside provisioning key organisation' };"),
  ('G3', 'gate: connectorId boundedness read RAW (whitespace org claim counts as bounded)', SEC, "        && normaliseOrgId((caller as { organizationId?: string | null } | undefined)?.organizationId ?? null) !== null;", "        && Boolean((caller as { organizationId?: string | null } | undefined)?.organizationId);"),
  ('G4', 'gate: decideProvisionerRegistration refusals made DISTINGUISHABLE (reason)', KRP, "    return { allow: false, status: 403, reason: 'bounded provisioning key may only re-register its own organisation' };", "    return { allow: false, status: 403, reason: hitOrg === null ? 'would create' : 'bounded provisioning key may only re-register its own organisation' };"),
  ('G4b', 'gate: the gateway answers a would-create refusal 404 (distinguishable status)', PLA, "          res.status(registration.status).json({", "          res.status(existing.rows.length === 0 ? 404 : registration.status).json({"),
  ('G5', 'gate: isProvisioningCapable list shortened by one scope (organizations:* dropped)', SCO, "  return hasScope(claimed, PROVISIONING_SCOPE_NAME);", "  return claimed.includes('*') || claimed.includes(PROVISIONING_SCOPE_NAME);"),
  ('G7', 'gate: hop-1 deny exempts ADMIN as well as platform roles', SEC, "      && !isPlatformRole((req as any).user?.role)\n      && normaliseOrgId(data.organizationId ?? null) === null) {", "      && !(isPlatformRole((req as any).user?.role) || String((req as any).user?.role).toUpperCase() === 'ADMIN')\n      && normaliseOrgId(data.organizationId ?? null) === null) {"),
  ('G8', 'gate: hop-1 reads the body organisation RAW (whitespace passes as named)', SEC, "      && normaliseOrgId(data.organizationId ?? null) === null) {", "      && !data.organizationId) {"),
  ('G11', 'gate: decideProvisionerRegistration own organisation compared case-sensitively', KRP, "  const ownOrg = normaliseOrgId(args.callerOrganizationId ?? null);", "  const ownOrg = (args.callerOrganizationId ?? '').trim() || null;"),
  # moved-test pins (item 7): does each retargeted cell still pin the guard it existed for?
  ('T1', 'moved ks1533: the provisioner ROTATE refusal removed', SEC, "      if (isProvisioner && data.rotate === true) {", "      if (isProvisioner && data.rotate === true && process.env.__T1 === 'on') {"),
  ('T2', 'moved ks1533: the unbounded-provisioner connectorId exemption removed', SEC, "      if (!isPlatformRole(caller?.role) && !isProvisioner) {", "      if (!isPlatformRole(caller?.role)) {"),
  ('T3', 'moved ks1215: the connector branch keeps the caller Bearer', 'services/api-gateway/src/middleware/auth.ts', "      delete req.headers.authorization;", "      // delete req.headers.authorization; [T3]"),
  ('T4', 'moved ks780: a ninth normaliseOrgId( call', KRP, "  const hitOrg = normaliseOrgId(args.existingOrganizationId ?? null);", "  const hitOrg = normaliseOrgId(normaliseOrgId(args.existingOrganizationId ?? null));"),
]

GROUPS = [
  ('shared', D + '/packages/shared', ['npx', 'vitest', 'run', '--reporter=verbose', 'src/__tests__/ks1584', 'src/__tests__/ks780', 'src/__tests__/ks764', 'src/__tests__/ks1570']),
  ('sec-unit', D + '/services/security', ['npx', 'vitest', 'run', '--reporter=verbose', 'src/__tests__/ks1533', 'src/__tests__/ks742']),
  ('sec-int', D + '/services/security', ['npx', 'vitest', 'run', '--config', 'vitest.integration.config.ts', '--reporter=verbose', 'src/__tests__/ks1584', 'src/__tests__/gate1541-matrix']),
  ('gw', D + '/services/api-gateway', ['npx', 'vitest', 'run', '--reporter=verbose', '--testTimeout=60000', 'src/__tests__/ks1215', 'src/__tests__/ks480', 'src/__tests__/gate1541-register-live']),
]
CLEAN = re.compile(r'\x1b\[[0-9;]*m')

def build_shared():
    r = subprocess.run(['npm', 'run', 'build'], cwd=D + '/packages/shared', capture_output=True, text=True, env=ENV)
    return r.returncode, (r.stdout + r.stderr)[-1500:]

def run_groups(tag):
    res = {}
    for g, cwd, cmd in GROUPS:
        r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, env=ENV)
        txt = CLEAN.sub('', r.stdout + r.stderr)
        open(f'{OUT}/{tag}_{g}.txt', 'w').write(txt + f'\nrc={r.returncode}\n')
        reds = sorted(set(l.strip()[2:].strip() for l in txt.splitlines() if re.match(r'^\s*[×✗]\s', l)))
        summ = [l.strip() for l in txt.splitlines() if re.match(r'^\s*Tests\s', l)]
        res[g] = {'rc': r.returncode, 'red': reds, 'summary': summ[-1] if summ else 'NO SUMMARY'}
    return res

def main():
    only = sys.argv[1:] or None
    results = {}
    base = run_groups('BASELINE')
    results['BASELINE'] = base
    print('BASELINE', {g: v['summary'] for g, v in base.items()}, flush=True)
    for mid, desc, rel, old, new in M:
        if only and mid not in only: continue
        p = D + '/' + rel
        orig = open(p, 'rb').read()
        txt = orig.decode()
        n = txt.count(old)
        if n != 1:
            results[mid] = {'desc': desc, 'verdict': f'INVALID (anchor count {n})'}
            print(mid, 'INVALID', n, flush=True); continue
        open(p, 'w').write(txt.replace(old, new))
        build = None
        if rel.startswith('packages/shared'):
            build = build_shared()
        try:
            if build and build[0] != 0:
                res = {'build': 'FAILED ' + build[1]}
                verdict = 'INVALID (shared build failed)'
            else:
                res = run_groups(mid)
                reds = [f'{g}: {c}' for g, v in res.items() for c in v['red']]
                broken = [g for g, v in res.items() if v['summary'] == 'NO SUMMARY']
                verdict = ('KILLED' if reds else ('INVALID (no summary: ' + ','.join(broken) + ')' if broken else 'SURVIVED'))
                if mid == 'M0': verdict = 'CONTROL OK (nothing red)' if not reds and not broken else 'CONTROL FAILED'
        finally:
            open(p, 'wb').write(orig)
            if rel.startswith('packages/shared'):
                rb = build_shared()
                assert rb[0] == 0, rb[1]
        same = open(p, 'rb').read() == orig
        results[mid] = {'desc': desc, 'file': rel, 'verdict': verdict, 'restored_identical': same,
                        'red': {g: v.get('red') for g, v in res.items()} if isinstance(res, dict) and 'build' not in res else res}
        print(mid, verdict, 'restored', same, flush=True)
        json.dump(results, open(OUT + '/mutants.json', 'w'), indent=1)
    json.dump(results, open(OUT + '/mutants.json', 'w'), indent=1)

main()
