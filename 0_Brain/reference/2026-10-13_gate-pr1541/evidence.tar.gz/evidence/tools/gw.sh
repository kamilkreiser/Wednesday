#!/bin/bash
# gw.sh <tree> <outfile> [vitest args]
W=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad/g1541
T=$1; OUT=$2; shift 2
export TEST_DATABASE_URL="postgresql://secuura@127.0.0.1:55413/secuura"
export TEST_APP_DATABASE_URL="postgresql://secuura_app:$(cat $W/pg/app_pw)@127.0.0.1:55413/secuura"
export GATE_TMP=$W/tmp
exec python3 -I $W/bin/runin.py $W/$T/Blockchain/Dev/services/api-gateway $OUT npx vitest run --reporter=verbose "$@"
