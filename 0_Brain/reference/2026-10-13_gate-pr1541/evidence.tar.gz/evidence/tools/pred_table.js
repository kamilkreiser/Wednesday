const [,, headDist, devDist] = process.argv;
const H = require(headDist + '/security/scopes.js');
const Dv = require(devDist + '/security/scopes.js');
const KRP = require(headDist + '/security/keyRevokePolicy.js');
// decideMint admission (services/security/src/provisioningPolicy.ts) re-stated literally: connector + includes(literal)
const admitted = (s) => Array.isArray(s) && s.includes('organizations:register');
const cases = [
  ['organizations:register'], ['*'], ['organizations:*'], ['ORGANIZATIONS:REGISTER'], ['organizations:register '], [' organizations:register'],
  ['organizations:read'], ['organizations:write'], ['organization:register'], ['organizations:Register'], ['*:*'], ['*:register'],
  ['organizations'], ['organizations:'], ['documents:*'], ['documents:read'], [], [null], [null, 'organizations:register'], [undefined, '*'],
  ['organizations:register', 'documents:read'], ['read', 'write'], ['metering:read'], ['subjects:erase'],
];
const rows = [];
for (const c of cases) {
  let head, gwDev, err = '';
  try { head = H.isProvisioningCapable(c); } catch (e) { head = 'THROW ' + e.message; }
  try { gwDev = Dv.hasScope(c ?? [], 'organizations:register'); } catch (e) { gwDev = 'THROW ' + e.message; }
  rows.push({ scopes: JSON.stringify(c), isProvisioningCapable_head: head, gatewayGate_develop_hasScope: gwDev, decideMint_admission_literal: admitted(c), registration_bound_applies_if_org: KRP.decideProvisionerRegistration({ byConnector: true, callerScopes: c, callerOrganizationId: 'a', existingOrganizationId: 'b' }).allow === false });
}
for (const x of [undefined, null, 'organizations:register', 'x']) {
  let head, gwDev;
  try { head = H.isProvisioningCapable(x); } catch (e) { head = 'THROW ' + e.message; }
  try { gwDev = Dv.hasScope(x ?? [], 'organizations:register'); } catch (e) { gwDev = 'THROW ' + e.message; }
  rows.push({ scopes: 'NON-ARRAY ' + JSON.stringify(x), isProvisioningCapable_head: head, gatewayGate_develop_hasScope: gwDev, decideMint_admission_literal: admitted(x) });
}
console.table(rows);
