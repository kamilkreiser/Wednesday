#!/bin/bash
# orig.sh <tree> <outfile> <keysfile> [jest args]
W=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad/g1541
T=$1; OUT=$2; export GATE_KEYS=$3; shift 3
export TEST_DATABASE_URL="postgresql://secuura@127.0.0.1:55413/secuura"
export TEST_APP_DATABASE_URL="postgresql://secuura_app:$(cat $W/pg/app_pw)@127.0.0.1:55413/secuura"
export PLATFORM_DATABASE_URL="postgresql://secuura@127.0.0.1:55413/secuura_platform"
exec python3 -I $W/bin/runin.py $W/$T/Blockchain/Dev/services/originate $OUT npx jest --config jest.integration.config.js --verbose "$@"
