import io, re, subprocess, os, json, sys
G = '/private/tmp/claude-501/gate1555r2-1792314908'
DEV = G + '/wt/m/Blockchain/Dev'
O = DEV + '/services/originate'
V = O + '/src/routes/verification.ts'; RT = O + '/src/utils/requestTenant.ts'
SUPER = 'postgresql://secuura:secuura@127.0.0.1:55841/secuura'; APP = 'postgresql://secuura_app:app@127.0.0.1:55841/secuura'
PS = 'postgresql://secuura:secuura@127.0.0.1:55841/secuura_platform'; PA = 'postgresql://secuura_app:app@127.0.0.1:55841/secuura_platform'
EXP = 17
def run(mode, mt='false'):
    env = dict(os.environ, TEST_DATABASE_URL=SUPER, DATABASE_URL=SUPER, TEST_SUPER_PLATFORM_DATABASE_URL=PS,
               TEST_PLATFORM_DATABASE_URL=PA if mode == 'app' else PS, MULTI_TENANCY_ENABLED=mt)
    if mode == 'app': env['TEST_APP_DATABASE_URL'] = APP
    else: env.pop('TEST_APP_DATABASE_URL', None)
    p = subprocess.run([DEV + '/node_modules/.bin/jest', '--rootDir', O, '--config', O + '/jest.integration.config.js', 'ks1114', '--runInBand', '--forceExit'],
                       capture_output=True, text=True, env=env, timeout=900)
    out = p.stdout + p.stderr
    m = re.search(r'^Tests:\s+(?:(\d+) failed, )?(?:(\d+) passed, )?(\d+) total', out, re.M)
    red = sorted(set(re.findall(r'●[^\n]*›\s*(T\d+[a-z]?)\b', out)))
    return ((int(m.group(1) or 0), int(m.group(3))) if m else None), red, out
TEN = "              AND d.tenant_id::text = ${tenantForTitle}\n"
ST = "              AND d.status NOT IN ('draft', 'revoked')\n"
GUARD = "if (!tenantForTitle || titleToFind === ERASED_MARKER) return titleNotFound();"
SQLSENT = "              AND d.title <> ${ERASED_MARKER}\n"
HITRET = "return res.json({ verified: false, checks: { documentExists: true } });"
MISSBODY = "            verified: false,\n            error: 'Document not found in the registry',\n            checks: { documentExists: false, hashValid: false, integrityVerified: false },\n          });\n          const tenantForTitle"
M = [
 ('A1 tenant predicate removed (superuser, RLS bypassed)', V, [(TEN, "")], 'super', 'false', 'T2'),
 ('A2 [M9b] tenant predicate removed (secuura_app, FORCE RLS)', V, [(TEN, "")], 'app', 'false', 'SURVIVES by design (RLS)'),
 ('A2b [M9b] tenant predicate removed (secuura_app, MT=true)', V, [(TEN, "")], 'app', 'true', 'SURVIVES by design (RLS)'),
 ('A3 caller tenant hard-coded DEFAULT', V, [("const tenantForTitle = callerTenantOf(req);", "const tenantForTitle = 'a0000000-0000-4000-8000-000000000001'; void callerTenantOf;")], 'app', 'false', 'T2b'),
 ('A4 [M3] status checked on the NEWEST row only (filter moved out of WHERE)', V, [("            SELECT 1 AS found\n", "            SELECT d.status\n"), (ST + "            LIMIT 1\n", "            ORDER BY d.created_at DESC NULLS LAST, d.id DESC\n            LIMIT 1\n"), ("          if (titleRows.length === 0) return titleNotFound();\n          " + HITRET, "          if (titleRows.length === 0 || ['draft', 'revoked'].includes(titleRows[0].status)) return titleNotFound();\n          " + HITRET)], 'app', 'false', 'T4b/T4c ONLY'),
 ('A5 status filter removed', V, [(ST, "")], 'app', 'false', 'T10/T11'),
 ('A6 only draft excluded', V, [(ST, "              AND d.status NOT IN ('draft')\n")], 'app', 'false', 'T4c/T10/T11'),
 ('A7 only revoked excluded', V, [(ST, "              AND d.status NOT IN ('revoked')\n")], 'app', 'false', 'T4b/T10/T11'),
 ('A8 case-insensitive title match', V, [("            WHERE d.title = ${titleToFind}\n", "            WHERE lower(d.title) = lower(${titleToFind})\n")], 'app', 'false', 'T5'),
 ('A9 both sentinel lines removed (as written: compile break expected)', V, [(GUARD, "if (!tenantForTitle) return titleNotFound();"), (SQLSENT, "")], 'app', 'false', 'LOAD FAILURE (TS6133)'),
 ("A9' both sentinel lines removed, compile-valid (void ERASED_MARKER)", V, [(GUARD, "void ERASED_MARKER; if (!tenantForTitle) return titleNotFound();"), (SQLSENT, "")], 'app', 'false', 'T6'),
 ('A9a sentinel early-return removed ONLY', V, [(GUARD, "if (!tenantForTitle) return titleNotFound();")], 'app', 'false', 'SURVIVES (defence in depth)'),
 ('A9b sentinel SQL exclusion removed ONLY', V, [(SQLSENT, "")], 'app', 'false', 'SURVIVES (defence in depth)'),
 ('A10 miss echoes the title', V, [(MISSBODY, "            verified: false,\n            title: titleToFind,\n            error: 'Document not found in the registry',\n            checks: { documentExists: false, hashValid: false, integrityVerified: false },\n          });\n          const tenantForTitle")], 'app', 'false', 'T2/T6/T10'),
 ('A11 whitespace-only title treated as present', V, [("typeof title === 'string' && title.trim().length > 0 ? title : undefined;", "typeof title === 'string' && title.length > 0 ? title : undefined;")], 'app', 'false', 'T7'),
 ('A12 hit answers round-1 full by-id body', V, [(HITRET, "return respondExistenceOnly({ id: 'x', external_id: 'x', title: titleToFind, status: 'certified', content_hash: 'h', metadata: {}, certification_metadata: {} }, 'found by title');")], 'app', 'false', 'T1/T1b'),
 ('A13 hit adds strategy:"title"', V, [(HITRET, "return res.json({ verified: false, strategy: 'title', checks: { documentExists: true } });")], 'app', 'false', 'T1'),
 ('A14 KS-1032 gate removed: x-tenant-id read unvouched', RT, [("  const header = isGatewayVouched(req) ? nonEmpty(req.headers['x-tenant-id']) : undefined;", "  void isGatewayVouched; const header = nonEmpty(req.headers['x-tenant-id']);")], 'app', 'false', 'T3'),
 # gate's own (round 2)
 ('G1 `deleted` also hidden (NOT IN draft, revoked, deleted)', V, [(ST, "              AND d.status NOT IN ('draft', 'revoked', 'deleted')\n")], 'app', 'false', 'T11 (pins deleted as a hit)'),
 ('G2 allow-list: only certified can hit', V, [(ST, "              AND d.status IN ('certified')\n")], 'app', 'false', 'T11'),
 ('G3 status compared case-insensitively (lower(d.status) NOT IN)', V, [(ST, "              AND lower(btrim(d.status)) NOT IN ('draft', 'revoked')\n")], 'app', 'false', 'SURVIVES predicted: no cell holds a case-variant status'),
 ('G4 hit carries checks.hashValid:false', V, [(HITRET, "return res.json({ verified: false, checks: { documentExists: true, hashValid: false } });")], 'app', 'false', 'T1/T1b'),
 ('G5 hit status 200 -> 404 same body', V, [(HITRET, "return res.status(404).json({ verified: false, checks: { documentExists: true } });")], 'app', 'false', 'T1? (T1 asserts status)'),
 ('CONTROL comment-only line', V, [("        if (titleToFind && !documentId && !computedHash) {\n", "        // gate1555 r2 comment-only control\n        if (titleToFind && !documentId && !computedHash) {\n")], 'app', 'false', 'SURVIVES (control)'),
]
res = []
for name, path, edits, mode, mt, pred in M:
    src = io.open(path, encoding='utf-8').read(); mut = src; ok = True
    for o, n in edits:
        if mut.count(o) != 1: print(f'{name}: ANCHOR FAULT ({mut.count(o)})', flush=True); ok = False; break
        mut = mut.replace(o, n)
    if not ok: res.append((name, 'ANCHOR', pred, [])); continue
    io.open(path, 'w', encoding='utf-8').write(mut)
    try:
        tally, red, out = run(mode, mt)
    finally: io.open(path, 'w', encoding='utf-8').write(src)
    if tally is None or tally[1] != EXP:
        print(f'{name}: LOAD FAILURE ({tally}) - NOT scored', flush=True); open(G + '/ev/mut_loadfail_' + name.split()[0] + '.log', 'w').write(out); res.append((name, 'LOADFAIL', pred, red)); continue
    st = 'KILLED' if tally[0] > 0 else 'SURVIVED'
    print(f'{name} [{mode} MT={mt}]: {st} ({tally[0]} red) red={red} | predicted: {pred}', flush=True); res.append((name, st, pred, red))
for mode in ('app', 'super'):
    t, r, _ = run(mode); print(f'CLEAN ({mode}):', t, r, flush=True)
print('worktree clean after mutants:', subprocess.run(['git', '-C', G + '/wt/m', 'diff', '--stat'], capture_output=True, text=True).stdout.strip() == '')
json.dump(res, open(G + '/ev/mutants.json', 'w'), indent=1)
