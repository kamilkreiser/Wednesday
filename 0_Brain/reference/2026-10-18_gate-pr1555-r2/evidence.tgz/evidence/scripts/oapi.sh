#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555r2-1792314908
W=$G/wt/$1/Blockchain/Dev
$W/node_modules/.bin/tsx $W/scripts/generate-openapi.ts --check > $G/ev/oapi_check_$1.log 2>&1
echo "generate-openapi --check ($1) rc=$?"; tail -3 $G/ev/oapi_check_$1.log
node $W/scripts/spec-examples/check-spec-examples.mjs > $G/ev/spec_examples_$1.log 2>&1
echo "check-spec-examples ($1) rc=$?"; tail -2 $G/ev/spec_examples_$1.log
