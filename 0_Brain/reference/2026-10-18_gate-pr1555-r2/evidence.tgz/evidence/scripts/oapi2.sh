#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555r2-1792314908; S=$G/scripts
W=$G/wt/h/Blockchain/Dev; Y=Blockchain/Dev/docs/openapi/secuura-api.yaml; O=Blockchain/Dev/services/originate/src/originate.openapi.ts
/bin/bash $S/oapi.sh h
echo "== regenerate in place (no --check)"
$W/node_modules/.bin/tsx $W/scripts/generate-openapi.ts > $G/ev/oapi_regen_h.log 2>&1; echo "regen rc=$?"; tail -2 $G/ev/oapi_regen_h.log
echo "yaml diff after regeneration (lines): $(git -C $G/wt/h diff -- $Y | wc -l)"; sha256sum $W/docs/openapi/secuura-api.yaml 2>/dev/null || shasum -a 256 $W/docs/openapi/secuura-api.yaml
git -C $G/wt/h rev-parse HEAD:$Y; git -C $G/wt/h hash-object $W/docs/openapi/secuura-api.yaml
echo "== control: plant a word in KS1114_TITLE_SEMANTICS"
cp $G/wt/h/$O $G/ev/originate.openapi.ts.bak
python3 -I - $G/wt/h/$O <<'PY'
import sys; p=sys.argv[1]; s=open(p).read(); a='"A `title` match is an EXISTENCE answer'; assert s.count(a)==1; open(p,'w').write(s.replace(a,'"A `title` match is an PLANTED EXISTENCE answer'))
PY
$W/node_modules/.bin/tsx $W/scripts/generate-openapi.ts --check > $G/ev/oapi_ctl.log 2>&1; echo "control --check rc=$? (expect 1)"; tail -2 $G/ev/oapi_ctl.log
git -C $G/wt/h checkout -- $O
echo "worktree h status after restore: [$(git -C $G/wt/h status --porcelain --untracked-files=no)]"
