#!/bin/bash
V=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1555-r2/verdict.md
H=$(sed '2d' $V | shasum -a 256 | cut -c1-16)
python3 -I - "$V" "$H" <<'PY'
import sys
p, h = sys.argv[1], sys.argv[2]
L = open(p).read().split('\n')
assert L[1] == 'SHA256/16: PLACEHOLDER'
L[1] = 'SHA256/16: ' + h
open(p, 'w').write('\n'.join(L))
PY
echo "computed $H; recheck $(sed '2d' $V | shasum -a 256 | cut -c1-16)"; head -2 $V
