#!/bin/bash
# head's ks1114 cells on round-1's source (wt r1); restore afterwards
set -u
G=/private/tmp/claude-501/gate1555r2-1792314908; S=$G/scripts
F=Blockchain/Dev/services/originate/src/__tests__/ks1114-anonymous-title-lookup-one-tenant.integration.test.ts
cp $G/wt/h/$F $G/wt/r1/$F
for mt in false true; do for role in app super; do
  echo "== redfirst r1-source head-cells mt=$mt $role"; /bin/bash $S/itest2.sh r1 rf_${mt}_${role} $mt $role ks1114 --runInBand --forceExit | sed -E 's/^(  FAIL ).*› (T[0-9]+[a-z]?)[^|]*\|.*/\1\2/' 
done; done
git -C $G/wt/r1 checkout -- $F
echo "r1 worktree diff after restore: [$(git -C $G/wt/r1 diff --stat)]"
