#!/bin/bash
G=/private/tmp/claude-501/gate1555r2-1792314908; S=$G/scripts
nohup /bin/bash $S/app3.sh h 46101 false app h_st_app >/dev/null 2>&1 &
nohup /bin/bash $S/app3.sh h 46102 false super h_st_super >/dev/null 2>&1 &
nohup /bin/bash $S/app3.sh h 46103 true app h_mt_app >/dev/null 2>&1 &
nohup /bin/bash $S/app3.sh h 46104 true super h_mt_super >/dev/null 2>&1 &
nohup /bin/bash $S/app3.sh d 46105 false app d_st_app >/dev/null 2>&1 &
nohup /bin/bash $S/app3.sh h 46106 true app h_mtprod_app production >/dev/null 2>&1 &
nohup /bin/bash $S/app3.sh r1 46107 false app r1_st_app >/dev/null 2>&1 &
sleep 2
for p in 46101 46102 46103 46104 46105 46106 46107; do echo -n "$p "; /bin/bash $S/waithealth.sh $p; done
