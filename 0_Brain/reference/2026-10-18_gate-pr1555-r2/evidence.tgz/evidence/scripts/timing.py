import http.client, json, random, statistics, sys, time
port, n, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
classes = {
 'absent': {'title': 'G1555 no such title'},
 'otherTenant': {'title': 'G1555 Bravo only'},
 'sentinel': {'title': '[erased]'},
 'hit': {'title': 'G1555 Alpha'},
 'draft': {'title': 'G1555 Draft'},
 'revoked': {'title': 'G1555 Revoked'},
 'shadowHitOverDraft': {'title': 'G1555 Shadow D'},
 'absent2': {'title': 'G1555 another missing'},
}
conn = http.client.HTTPConnection('127.0.0.1', port, timeout=30)
def one(body):
    b = json.dumps(body)
    t0 = time.perf_counter_ns()
    conn.request('POST', '/api/verification/verify', body=b, headers={'content-type': 'application/json'})
    r = conn.getresponse(); txt = r.read()
    return (time.perf_counter_ns() - t0) / 1e6, txt
for k, b in classes.items():
    for _ in range(20): one(b)  # warm-up
order = [k for k in classes for _ in range(n)]; random.seed(1555); random.shuffle(order)
samples = {k: [] for k in classes}; bodies = {k: set() for k in classes}
for k in order:
    ms, txt = one(classes[k]); samples[k].append(ms)
    bodies[k].add(txt)
def mw(a, b):
    # Mann-Whitney U, normal approximation, two-sided p
    import math
    allv = sorted([(v, 0) for v in a] + [(v, 1) for v in b])
    ranks = {}; i = 0
    while i < len(allv):
        j = i
        while j + 1 < len(allv) and allv[j + 1][0] == allv[i][0]: j += 1
        for k in range(i, j + 1): ranks.setdefault(k, (i + j) / 2 + 1)
        i = j + 1
    r1 = sum(ranks[idx] for idx, (v, g) in enumerate(allv) if g == 0)
    n1, n2 = len(a), len(b); u = r1 - n1 * (n1 + 1) / 2
    mu = n1 * n2 / 2; sd = math.sqrt(n1 * n2 * (n1 + n2 + 1) / 12)
    z = (u - mu) / sd; p = math.erfc(abs(z) / math.sqrt(2))
    return round(z, 2), p
res = {}
for k, v in samples.items():
    v2 = sorted(v)
    res[k] = {'n': len(v), 'median_ms': round(statistics.median(v), 3), 'p10': round(v2[len(v)//10], 3), 'p90': round(v2[9*len(v)//10], 3), 'mean': round(statistics.mean(v), 3), 'distinct_bodies': len(bodies[k])}
pairs = [('absent', 'otherTenant'), ('absent', 'absent2'), ('absent', 'draft'), ('absent', 'revoked'), ('draft', 'revoked'), ('absent', 'sentinel'), ('absent', 'hit'), ('hit', 'shadowHitOverDraft')]
res['mannwhitney'] = {f'{a}~{b}': mw(samples[a], samples[b]) for a, b in pairs}
same = len({next(iter(bodies[k])) for k in ('absent', 'otherTenant', 'sentinel', 'absent2', 'draft', 'revoked')}) == 1
res['not_found_bodies_identical_across_absent_otherTenant_sentinel_absent2_draft_revoked'] = same
json.dump({'summary': res, 'samples': samples}, open(out, 'w'))
print(json.dumps(res, indent=1))
