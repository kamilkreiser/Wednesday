#!/bin/bash
G=/private/tmp/claude-501/gate1555r2-1792314908; S=$G/scripts
python3 -I $S/timing.py 46101 400 $G/ev/timing_h_st_app.json > $G/ev/timing_h_st_app_summary.json
python3 -I $S/timing.py 46103 400 $G/ev/timing_h_mt_app.json > $G/ev/timing_h_mt_app_summary.json
cat $G/ev/timing_h_st_app_summary.json; echo ===MT; cat $G/ev/timing_h_mt_app_summary.json
