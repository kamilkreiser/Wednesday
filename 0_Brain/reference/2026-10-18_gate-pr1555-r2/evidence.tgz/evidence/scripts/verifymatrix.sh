#!/bin/bash
S=/private/tmp/claude-501/gate1555r2-1792314908/scripts
for wt in h d r1; do for mt in false true; do for role in app super; do
  echo "== $wt verify-int mt=$mt $role"; /bin/bash $S/itest2.sh $wt v_${wt}_${mt}_${role} $mt $role 'ks1114|ks1119|ks1557' --runInBand --forceExit
done; done; done
