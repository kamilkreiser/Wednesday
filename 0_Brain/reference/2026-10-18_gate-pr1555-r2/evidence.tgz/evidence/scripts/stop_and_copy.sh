#!/bin/bash
G=/private/tmp/claude-501/gate1555r2-1792314908; E=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1555-r2/evidence
for p in 46101 46102 46103 46104 46105 46106 46107; do pid=$(lsof -nP -t -iTCP:$p -sTCP:LISTEN); [ -n "$pid" ] && kill $pid; done
sleep 2
echo "apps still listening: $(for p in 46101 46102 46103 46104 46105 46106 46107; do lsof -nP -t -iTCP:$p -sTCP:LISTEN; done | wc -l)"
/opt/homebrew/opt/postgresql@18/bin/pg_ctl -D $G/pgdata-55841 stop -m fast
echo "pg 55841 listening: $(lsof -nP -t -iTCP:55841 -sTCP:LISTEN | wc -l)"
cp $G/scripts/* $E/scripts/
for f in $G/ev/*; do case "$(basename $f)" in originate.openapi.ts.bak|verification_head.ts|pr1555.json|pg_server.log|unit_h.json) continue;; esac; cp "$f" $E/runs/; done
ls $E/runs | wc -l; du -sh $E
