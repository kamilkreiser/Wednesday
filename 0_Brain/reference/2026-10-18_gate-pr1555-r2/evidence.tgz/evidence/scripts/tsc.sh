#!/bin/bash
G=/private/tmp/claude-501/gate1555r2-1792314908; T=$G/wt/h/Blockchain/Dev/node_modules/.bin/tsc
$T -p $G/wt/h/Blockchain/Dev/services/originate/tsconfig.json --noEmit > $G/ev/tsc_prod.log 2>&1; echo "tsc (product config) rc=$? errors=$(grep -c 'error TS' $G/ev/tsc_prod.log)"
$T -p $G/wt/tsconfig.gate-tests.json > $G/ev/tsc_tests.log 2>&1; echo "tsc (test-inclusive scratch config) rc=$? errors=$(grep -c 'error TS' $G/ev/tsc_tests.log)"
grep 'error TS' $G/ev/tsc_tests.log | head -5
