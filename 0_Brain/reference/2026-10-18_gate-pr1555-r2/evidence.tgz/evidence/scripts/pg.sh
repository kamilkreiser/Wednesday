#!/bin/bash
# usage: pg.sh <port> <schema-worktree>
set -u
G=/private/tmp/claude-501/gate1555r2-1792314908
PORT="$1"; W="$2"
B=/opt/homebrew/opt/postgresql@18/bin
D=$G/pgdata-$PORT
L=$G/ev/pg_setup.log
if lsof -nP -iTCP:$PORT -sTCP:LISTEN >/dev/null 2>&1; then echo "PORT $PORT BUSY"; exit 2; fi
$B/initdb -D $D -U postgres --auth=trust >$L 2>&1 || { echo initdb failed; exit 1; }
$B/pg_ctl -D $D -o "-p $PORT -k $G -c listen_addresses=127.0.0.1" -l $G/ev/pg_server.log start >>$L 2>&1
sleep 3
P="$B/psql -h 127.0.0.1 -p $PORT -v ON_ERROR_STOP=0 -q"
$P -U postgres -d postgres -c "CREATE ROLE secuura SUPERUSER LOGIN PASSWORD 'secuura'" >>$L 2>&1
$P -U postgres -d postgres -c "CREATE DATABASE secuura OWNER secuura" >>$L 2>&1
$P -U postgres -d postgres -c "CREATE ROLE secuura_app LOGIN PASSWORD 'app' NOSUPERUSER NOBYPASSRLS" >>$L 2>&1
DEV=$W/Blockchain/Dev
for f in $DEV/docker/init/0*.sql; do
  case "$(basename $f)" in 00-create-platform-db.sql) continue;; esac
  echo "== $f" >>$L
  $P -U secuura -d secuura -f $f >>$L 2>&1
done
for f in $DEV/migrations/*.sql; do
  echo "== $f" >>$L
  $P -U secuura -d secuura -f $f >>$L 2>&1
done
$P -U secuura -d secuura >>$L 2>&1 <<'EOSQL'
GRANT CONNECT ON DATABASE secuura TO secuura_app;
GRANT USAGE ON SCHEMA public TO secuura_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO secuura_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO secuura_app;
EOSQL
echo "errors in setup log: $(grep -c ERROR $L)"
$B/psql -h 127.0.0.1 -p $PORT -U secuura -d secuura -tAc "select relname, relrowsecurity, relforcerowsecurity from pg_class where relname in ('documents','tenants')"
$B/psql -h 127.0.0.1 -p $PORT -U secuura -d secuura -tAc "select polname, polrelid::regclass, pg_get_expr(polqual, polrelid) from pg_policy where polrelid in ('documents'::regclass)"
