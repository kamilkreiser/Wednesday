const fs = require('fs'); const yaml = require('js-yaml'); const Ajv = require('ajv');
const spec = yaml.load(fs.readFileSync(process.argv[2], 'utf8'));
const op = spec.paths['/api/verification/verify'].post;
const r200 = op.responses['200'].content['application/json'].schema;
console.log('200 schema ref:', JSON.stringify(r200));
const conv = (o) => JSON.parse(JSON.stringify(o).replace(/"#\/components\/schemas\//g, '"#/definitions/'));
const defs = conv(spec.components.schemas);
// openapi nullable -> ignore; strict false
const ajv = new Ajv({ strict: false, allErrors: true });
const root = Object.assign({}, conv(r200), { definitions: defs });
const v = ajv.compile(root);
const vr = defs.VerifyResponse; console.log('VerifyResponse.required:', JSON.stringify(vr.required), 'additionalProperties:', JSON.stringify(vr.additionalProperties));
console.log('VerifyChecks.required:', JSON.stringify(defs.VerifyChecks.required));
for (const [n, b] of [['HIT', '{"verified":false,"checks":{"documentExists":true}}'], ['MISS', '{"verified":false,"error":"Document not found in the registry","checks":{"documentExists":false,"hashValid":false,"integrityVerified":false}}'], ['CONTROL no verified', '{"checks":{"documentExists":true}}'], ['CONTROL checks wrong type', '{"verified":false,"checks":{"documentExists":"yes"}}']]) {
  const ok = v(JSON.parse(b)); console.log(n, ok ? 'VALID' : 'INVALID ' + JSON.stringify(v.errors.map(e => e.instancePath + ' ' + e.message)));
}
