#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555r2-1792314908; R=$G/repo
for m in 7c32b44f1 986732cf5; do p1=$(git -C $R rev-parse $m^1); p2=$(git -C $R rev-parse $m^2); t=$(git -C $R merge-tree --write-tree $p1 $p2 | head -1); echo "$m auto=$t actual=$(git -C $R rev-parse $m^{tree}) $([ $t = $(git -C $R rev-parse $m^{tree}) ] && echo CLEAN-MERGE || echo EVIL)"; done
echo "== PR-own diff r1 head -> r2 head, excluding develop's changes: diff (c85cc28d merged with develop d2ec) vs head"
T=$(git -C $R merge-tree --write-tree c85cc28d d2ec786e6 | head -1)
git -C $R diff --stat $T pr/1555
echo "== commits fd576f06c, a83499eb3 stats"
git -C $R show --stat --format='%H %s' fd576f06c | tail -12
git -C $R show --stat --format='%H %s' a83499eb3 | tail -4
git -C $R diff $T pr/1555 > $G/ev/r1_to_r2_owndiff.patch
wc -l $G/ev/r1_to_r2_owndiff.patch
