import json, sys, re, hashlib
G = '/private/tmp/claude-501/gate1555r2-1792314908/ev/'
L = {t: {r['case']: r for r in json.load(open(G + f'probe_{t}.json'))} for t in ['h_st_app','h_st_super','h_mt_app','h_mt_super','d_st_app','h_mtprod_app','r1_st_app']}
norm = lambda b: re.sub(r'"verifiedAt":"[^"]*"', '"verifiedAt":"<ts>"', b)
HIT = '{"verified":false,"checks":{"documentExists":true}}'
h = L['h_st_app']
MISS = h['P03 anon missing title']['body']
miss_cases = [c for c, r in h.items() if r['body'] == MISS]
hit_cases = [c for c, r in h.items() if r['body'] == HIT]
other = [c for c in h if c not in miss_cases and c not in hit_cases]
print('MISS body:', MISS, 'sha256/16', hashlib.sha256(MISS.encode()).hexdigest()[:16])
print('HIT body :', HIT)
print('miss cases (%d):' % len(miss_cases), [c.split()[0] for c in miss_cases])
print('hit cases (%d):' % len(hit_cases), [c.split()[0] for c in hit_cases])
print('other (%d):' % len(other), [c.split()[0] for c in other])
title_miss_expected = ['P02','P03','P04','P04b','P04c','P07','P07b','P07d','P08b','P08c','P09b','P09c','P09e','P13','P13b','P15','P15b','P15c','P15d','P15e','P15f','P15g','P16b','P16c','P16d','R13','R15','R16','R17']
got = [c.split()[0] for c in miss_cases]
print('expected title-miss set == measured:', sorted(got) == sorted(title_miss_expected), set(got) ^ set(title_miss_expected))
print('develop absent-title body == head MISS byte for byte:', L['d_st_app']['P03 anon missing title']['body'] == MISS)
print('develop: distinct bodies over the head miss-cases:', len({L['d_st_app'][c]['body'] for c in miss_cases if c.split()[0] not in ('P13','P13b','R13','R15','R16','R17','P16b','P16c','P16d','P15','P15b','P15c','P15d','P15e','P15f','P15g','P02')}))
for t in ['h_st_super','h_mt_app','h_mt_super','h_mtprod_app','d_st_app','r1_st_app']:
    diff = [c.split()[0] for c in h if norm(h[c]['body']) != norm(L[t][c]['body']) or h[c]['status'] != L[t][c]['status']]
    print(f'h_st_app vs {t}: {len(h)-len(diff)}/{len(h)} identical; differ: {diff}')
print('mtprod sample:', L['h_mtprod_app']['P01 anon hit default tenant']['status'], L['h_mtprod_app']['P01 anon hit default tenant']['body'])
# headers hit vs miss
hh = h['P01 anon hit default tenant']['headers']; mh = h['P03 anon missing title']['headers']
keys = sorted(set(hh) | set(mh))
print('header diffs hit vs miss:', {k: (hh.get(k), mh.get(k)) for k in keys if hh.get(k) != mh.get(k)})
# miss header sets identical across miss cases (except content-length/etag must also be same)
hs = {json.dumps({k: v for k, v in h[c]['headers'].items()}, sort_keys=True) for c in miss_cases}
print('distinct header sets across all miss cases:', len(hs))
hs2 = {json.dumps(h[c]['headers'], sort_keys=True) for c in hit_cases}
print('distinct header sets across all hit cases:', len(hs2))
print('one hit header set:', json.dumps(hh))
