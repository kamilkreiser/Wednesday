#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555r2-1792314908; R=$G/repo
SRC="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files"
SSHC='ssh -i "/Volumes/DevMASTER/!CODING/Secuura/Blockchain/3_Access_Keys/github_deploy_rw" -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new -o ServerAliveInterval=30'
echo "== live refs at $(date -u +%FT%TZ)"
GIT_SSH_COMMAND="$SSHC" git -C "$SRC" ls-remote origin refs/heads/develop refs/pull/1555/head refs/pull/1565/head refs/pull/1566/head
git -C $R fetch -q origin '+refs/heads/develop:refs/remotes/origin/develop' '+refs/pull/1555/head:refs/remotes/pr/1555' '+refs/pull/1565/head:refs/remotes/pr/1565' '+refs/pull/1566/head:refs/remotes/pr/1566'
DEV=$(git -C $R rev-parse origin/develop); HEADP=$(git -C $R rev-parse pr/1555)
echo "develop=$DEV pr1555=$HEADP mergebase=$(git -C $R merge-base $DEV $HEADP)"
echo "develop..pr commits: $(git -C $R rev-list --count $DEV..$HEADP)  pr..develop commits: $(git -C $R rev-list --count $HEADP..$DEV)"
echo "== merge-tree pr1555 onto live develop"
git -C $R merge-tree --write-tree --name-only $DEV $HEADP; echo "rc=$?"
T=$(git -C $R merge-tree --write-tree $DEV $HEADP | head -1)
echo "merged tree=$T  pr head tree=$(git -C $R rev-parse $HEADP^{tree})  equal=$([ "$T" = "$(git -C $R rev-parse $HEADP^{tree})" ] && echo yes || echo no)"
echo "== PR files vs develop-side files since merge-base (overlap)"
MB=$(git -C $R merge-base $DEV $HEADP)
git -C $R diff --name-only $MB $HEADP | sort > $G/ev/pr_files.txt
git -C $R diff --name-only $MB $DEV | sort > $G/ev/dev_files.txt
echo "PR files: $(wc -l < $G/ev/pr_files.txt)  develop-side files: $(wc -l < $G/ev/dev_files.txt)  overlap: $(comm -12 $G/ev/pr_files.txt $G/ev/dev_files.txt | wc -l)"
echo "== cross-lane PRs 1565 / 1566"
for p in 1565 1566; do
  H=$(git -C $R rev-parse pr/$p); M=$(git -C $R merge-base $DEV $H)
  echo "PR $p head=$H base=$M subject: $(git -C $R log -1 --format=%s $H)"
  git -C $R diff --name-only $M $H | sort > $G/ev/pr${p}_files.txt
  echo "   files: $(wc -l < $G/ev/pr${p}_files.txt); overlap with #1555: [$(comm -12 $G/ev/pr_files.txt $G/ev/pr${p}_files.txt | tr '\n' ' ')]"
  git -C $R diff --name-only $M $H | grep -E 'secuura-api.yaml|openapi|routes/verification.ts' | sed 's/^/   touches: /'
  T2=$(git -C $R merge-tree --write-tree $DEV $H | head -1); echo "   $p onto develop: tree=$T2"
  git -C $R merge-tree --write-tree --name-only $T2 $HEADP >/dev/null 2>&1; true
  # build a synthetic commit for develop+p, then merge 1555 on it
  C=$(git -C $R commit-tree $T2 -p $DEV -p $H -m "gate synth develop+$p")
  git -C $R merge-tree --write-tree --name-only $C $HEADP > $G/ev/merge_after_$p.txt; echo "   #1555 onto develop+$p: rc=$? $(head -1 $G/ev/merge_after_$p.txt)"
done
echo "== planted conflicting control: a develop-side edit of the title SQL line"
WTC=$G/wt/ctl-$(date +%s)
git -C $R worktree add -q --detach $WTC $DEV
F=Blockchain/Dev/services/originate/src/routes/verification.ts
python3 -I - "$WTC/$F" <<'PY'
import sys
p=sys.argv[1]; s=open(p).read()
old="          const titleRows: any[] = await db.$queryRaw`"
if s.count(old)!=1:
    old="      const { documentId, providedHash, documentData, contentHash, documentHash, hash } = req.body;"
    if s.count(old)!=1:
        import re; m=re.search(r"\n(\s*const \{ documentId[^\n]*req\.body;)", s); old=m.group(1)
print('anchor:', old.strip()[:90])
open(p,'w').write(s.replace(old, old + " // planted control", 1))
PY
git -C $WTC -c user.email=gate@x -c user.name=gate commit -q -am "planted control"
C=$(git -C $R -C $WTC rev-parse HEAD)
git -C $R merge-tree --write-tree --name-only $C $HEADP; echo "control rc=$? (expect 1 = conflict)"
