import json, sys, urllib.request, urllib.error
port = sys.argv[1]
def post(path, raw):
    req = urllib.request.Request(f'http://127.0.0.1:{port}{path}', data=raw, headers={'content-type': 'application/json'}, method='POST')
    try: r = urllib.request.urlopen(req, timeout=60); return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
cases = [
 ('X1 v2 verify with a hit title', '/api/v2/verification/verify', json.dumps({'title': 'G1555 Alpha'}).encode()),
 ('X2 v2 verify with a missing title', '/api/v2/verification/verify', json.dumps({'title': 'G1555 no such title'}).encode()),
 ('X3 v1 lone surrogate in a title', '/api/verification/verify', b'{"title":"G1555 \\ud800"}'),
 ('X4 v1 lone surrogate, hit prefix', '/api/verification/verify', b'{"title":"G1555 Alpha\\udfff"}'),
 ('X5 v1 malformed JSON', '/api/verification/verify', b'{"title":'),
 ('X6 v1 hit title, trailing slash path', '/api/verification/verify/', json.dumps({'title': 'G1555 Alpha'}).encode()),
 ('X7 v1 hit with duplicate key (last wins?)', '/api/verification/verify', b'{"title":"nope","title":"G1555 Alpha"}'),
 ('X8 v1 1MB title', '/api/verification/verify', json.dumps({'title': 'z' * 1_000_000}).encode()),
]
for n, p, raw in cases:
    st, b = post(p, raw); print(n, '|', st, '|', b[:400])
