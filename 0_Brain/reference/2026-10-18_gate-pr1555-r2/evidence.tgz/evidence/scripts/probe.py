import json, sys, urllib.request, urllib.error
port, out = sys.argv[1], sys.argv[2]
URL = f'http://127.0.0.1:{port}/api/verification/verify'
V = 'gate1555r2-vouch-secret-0123456789abcdef'
B = 'b1555000-0000-4000-8000-000000001555'
def post(body, headers=None, raw=None, path=None):
    h = {'content-type': 'application/json'}; h.update(headers or {})
    data = raw if raw is not None else json.dumps(body).encode()
    req = urllib.request.Request((f'http://127.0.0.1:{port}' + path) if path else URL, data=data, headers=h, method='POST')
    try:
        r = urllib.request.urlopen(req, timeout=60); st = r.status; txt = r.read().decode(); hd = dict(r.headers)
    except urllib.error.HTTPError as e:
        st = e.code; txt = e.read().decode(); hd = dict(e.headers)
    return st, hd, txt
cases = [
 ('P01 anon hit default tenant', {'title': 'G1555 Alpha'}, {}),
 ('P02 anon title only in tenant B', {'title': 'G1555 Bravo only'}, {}),
 ('P03 anon missing title', {'title': 'G1555 no such title'}, {}),
 ('P04 anon erasure sentinel', {'title': '[erased]'}, {}),
 ('P04b sentinel with trailing space', {'title': '[erased] '}, {}),
 ('P04c sentinel upper', {'title': '[ERASED]'}, {}),
 ('P05 empty title', {'title': ''}, {}),
 ('P06 whitespace title', {'title': '   '}, {}),
 ('P06b tab-newline title', {'title': '\t\n'}, {}),
 ('P06c NBSP-only title', {'title': ' '}, {}),
 ('P07 percent wildcard', {'title': 'G1555 100%'}, {}),
 ('P07b underscore wildcard', {'title': 'G1555 100% off__'}, {}),
 ('P07c exact pct title', {'title': 'G1555 100% off_x'}, {}),
 ('P07d LIKE-all', {'title': '%'}, {}),
 ('P08 quotes exact', {'title': 'G1555 O\'Brien "q" \\x'}, {}),
 ('P08b SQL injection', {'title': "' OR '1'='1"}, {}),
 ('P08c SQL injection 2', {'title': "G1555 Alpha' OR title <> '"}, {}),
 ('P09 long exact 500', {'title': 'G1555 L' + 'x'*493}, {}),
 ('P09b long 501', {'title': 'G1555 L' + 'x'*494}, {}),
 ('P09c 100k title', {'title': 'y'*100000}, {}),
 ('P09d unicode', {'title': 'G1555 Café'}, {}),
 ('P09e unicode NFD', {'title': 'G1555 Café'}, {}),
 ('P09f NUL in title', None, {}),
 ('P10 documentId + title(other doc)', {'documentId': 'g1555-child', 'title': 'G1555 Alpha'}, {}),
 ('P10b unknown documentId + title(hit)', {'documentId': 'g1555-nope', 'title': 'G1555 Alpha'}, {}),
 ('P11 hash + title(hit)', {'hash': 'c1'*32, 'title': 'G1555 Alpha'}, {}),
 ('P11b unknown hash + title(hit)', {'hash': '99'*32, 'title': 'G1555 Alpha'}, {}),
 ('P11c documentData + title', {'documentData': {'x': 1}, 'title': 'G1555 Alpha'}, {}),
 ('P11d contentHash empty string + title', {'contentHash': '', 'title': 'G1555 Alpha'}, {}),
 ('P11e documentId empty string + title', {'documentId': '', 'title': 'G1555 Alpha'}, {}),
 ('P12 title non-string', {'title': 123}, {}),
 ('P12b title array', {'title': ['G1555 Alpha']}, {}),
 ('P13 draft doc by title', {'title': 'G1555 Draft'}, {}),
 ('P13b revoked doc by title', {'title': 'G1555 Revoked'}, {}),
 ('P14 shared title (default older, B newer)', {'title': 'G1555 In both'}, {}),
 ('P15 forged x-tenant-id unvouched', {'title': 'G1555 Bravo only'}, {'x-tenant-id': B}),
 ('P15b x-tenant-override unvouched', {'title': 'G1555 Bravo only'}, {'x-tenant-override': B}),
 ('P15c x-tenant-slug unvouched', {'title': 'G1555 Bravo only'}, {'x-tenant-slug': 'g1555-b'}),
 ('P15d wrong vouch secret', {'title': 'G1555 Bravo only'}, {'x-gateway-vouch': 'wrong', 'x-tenant-id': B}),
 ('P15e x-user-* forged', {'title': 'G1555 Bravo only'}, {'x-user-id': 'u', 'x-user-role': 'connector', 'x-user-tenant-id': B}),
 ('P15f query ?tenant=', {'title': 'G1555 Bravo only'}, {}, '/api/verification/verify?tenant=' + B + '&tenantId=' + B),
 ('P15g body tenantId', {'title': 'G1555 Bravo only', 'tenantId': B, 'tenant_id': B}, {}),
 ('P16 VOUCHED tenant B', {'title': 'G1555 Bravo only'}, {'x-gateway-vouch': V, 'x-tenant-id': B}),
 ('P16b VOUCHED tenant B upper-case id', {'title': 'G1555 Bravo only'}, {'x-gateway-vouch': V, 'x-tenant-id': B.upper()}),
 ('P16c VOUCHED tenant B, default-only title', {'title': 'G1555 Alpha'}, {'x-gateway-vouch': V, 'x-tenant-id': B}),
 ('P16d VOUCHED malformed tenant', {'title': 'G1555 Alpha'}, {'x-gateway-vouch': V, 'x-tenant-id': "x' OR 1=1--"}),
 ('P16e VOUCHED shared title as B', {'title': 'G1555 In both'}, {'x-gateway-vouch': V, 'x-tenant-id': B}),
 ('R01 status pending_signature', {'title': 'G1555 St pending_signature'}, {}),
 ('R02 status signed', {'title': 'G1555 St signed'}, {}),
 ('R03 status anchored', {'title': 'G1555 St anchored'}, {}),
 ('R04 status anchor_failed', {'title': 'G1555 St anchor_failed'}, {}),
 ('R05 status certified', {'title': 'G1555 St certified'}, {}),
 ('R06 status deleted (residual)', {'title': 'G1555 St deleted'}, {}),
 ('R07 status expired (not in census)', {'title': 'G1555 St expired'}, {}),
 ('R08 status REVOKED upper (no writer)', {'title': 'G1555 St REVOKED'}, {}),
 ('R09 status Draft mixed (no writer)', {'title': 'G1555 St Draft'}, {}),
 ('R10 status "revoked " trailing space (no writer)', {'title': 'G1555 St revoked-space'}, {}),
 ('R11 newer draft over older certified', {'title': 'G1555 Shadow D'}, {}),
 ('R12 newer revoked over older certified', {'title': 'G1555 Shadow R'}, {}),
 ('R13 title held only by a draft and a revoked', {'title': 'G1555 Draft and revoked only'}, {}),
 ('R14 created_at NULL certified', {'title': 'G1555 Null created'}, {}),
 ('R15 VOUCHED B draft', {'title': 'G1555 B draft'}, {'x-gateway-vouch': V, 'x-tenant-id': B}),
 ('R16 VOUCHED B, title in default only (draft)', {'title': 'G1555 Draft'}, {'x-gateway-vouch': V, 'x-tenant-id': B}),
 ('R17 anon B-draft title', {'title': 'G1555 B draft'}, {}),
 ('R18 hit with Accept text/html', {'title': 'G1555 Alpha'}, {'accept': 'text/html'}),
 ('R19 title + requestedFields', {'title': 'G1555 Alpha', 'requestedFields': ['contentHash', 'issuer', 'lineage']}, {}),
 ('R20 title + purpose + includeLineage', {'title': 'G1555 Alpha', 'purpose': 'x', 'includeLineage': True, 'verbose': True}, {}),
 ('R21 GET-style query title', None, {}, '/api/verification/verify?title=G1555%20Alpha'),
 ('R22 title object {toString}', {'title': {'toString': 'G1555 Alpha'}}, {}),
 ('R23 providedHash empty + title', {'providedHash': '', 'title': 'G1555 Alpha'}, {}),
 ('R24 documentHash null + title', {'documentHash': None, 'title': 'G1555 Alpha'}, {}),
 ('R25 hash sha256: prefix only + title', {'hash': 'sha256:', 'title': 'G1555 Alpha'}, {}),
]
res = []
for c in cases:
    name, body, hdr = c[0], c[1], c[2]
    path = c[3] if len(c) > 3 else None
    raw = b'{"title":"G1555 Al\\u0000pha"}' if name.startswith('P09f') else (b'{}' if name.startswith('R21') else None)
    st, hd, txt = post(body, hdr, raw=raw, path=path)
    keep = {k: v for k, v in hd.items() if k.lower() not in ('date', 'keep-alive', 'connection')}
    res.append({'case': name, 'status': st, 'headers': keep, 'body': txt if len(txt) < 3000 else txt[:3000] + '...[trunc]'})
json.dump(res, open(out, 'w'), indent=1, ensure_ascii=False)
for r in res:
    b = r['body']
    print(r['case'], '|', r['status'], '|', (b[:600] + ('...' if len(b) > 600 else '')).replace('\n', ' '))
