#!/bin/bash
# usage: app3.sh <wt> <port> <mt true|false> <role app|super> <tag> [nodeenv]  (foreground; run in background)
set -u
G=/private/tmp/claude-501/gate1555r2-1792314908
W=$G/wt/$1/Blockchain/Dev/services/originate
export PORT=$2 MULTI_TENANCY_ENABLED=$3
export NODE_ENV=${6:-development}
if [ "$4" = super ]; then U="secuura:secuura"; else U="secuura_app:app"; fi
export DATABASE_URL="postgresql://$U@127.0.0.1:55841/secuura"
export PLATFORM_DATABASE_URL="postgresql://$U@127.0.0.1:55841/secuura_platform"
export GATEWAY_VOUCH_SECRET="gate1555r2-vouch-secret-0123456789abcdef"
export JWT_SECRET="gate1555r2-jwt-0123456789abcdef0123456789abcdef"
export SIMULATE_ANCHORING=true ANCHORING_SERVICE_URL=http://127.0.0.1:2 AUTH_SERVICE_URL=http://127.0.0.1:3
export PII_ENCRYPTION_KEY=$(python3 -I -c "print('ab'*32)") PII_LOOKUP_HMAC_KEY=$(python3 -I -c "print('cd'*32)")
export REDIS_URL=redis://127.0.0.1:1 LOG_LEVEL=info
exec $G/wt/$1/Blockchain/Dev/node_modules/.bin/tsx $W/src/index.ts > $G/ev/app_$5.log 2>&1
