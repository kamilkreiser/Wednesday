#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555r2-1792314908; S=$G/scripts
/bin/bash $S/wt2.sh h 986732cf5f70de4417a76b3d2100a57bc8fe0d04
/bin/bash $S/wt2.sh d d2ec786e6130c7ce13384185c84cc1e7566d77cb
/bin/bash $S/wt2.sh r1 c85cc28d0232e5641901bfd12ca6960a9711e783
/bin/bash $S/wt2.sh m 986732cf5f70de4417a76b3d2100a57bc8fe0d04
/bin/bash $S/pg.sh 55841 $G/wt/h
/bin/bash $S/platdb.sh
