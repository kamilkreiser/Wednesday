#!/bin/bash
G=/private/tmp/claude-501/gate1555r2-1792314908; S=$G/scripts
for pt in 46101:h_st_app 46102:h_st_super 46103:h_mt_app 46104:h_mt_super 46105:d_st_app 46106:h_mtprod_app 46107:r1_st_app; do
  p=${pt%%:*}; t=${pt##*:}
  python3 -I $S/probe.py $p $G/ev/probe_$t.json > $G/ev/probe_$t.txt 2>&1; echo "$t rc=$? lines=$(wc -l < $G/ev/probe_$t.txt)"
done
