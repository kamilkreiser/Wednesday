#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555r2-1792314908; S=$G/scripts; P="/opt/homebrew/opt/postgresql@18/bin/psql -h 127.0.0.1 -p 55841 -U secuura"
$P -d secuura -c "INSERT INTO tenants (id, name, slug, status, created_at, updated_at) VALUES ('b1555000-0000-4000-8000-000000001555','g1555-b','g1555-b','active',NOW(),NOW()) ON CONFLICT (id) DO NOTHING"
$P -d secuura_platform -c "\d tenants" | head -30
$P -d secuura -f $S/seed_docs.sql
$P -d secuura -tAc "select column_name,is_nullable,data_type,character_maximum_length,column_default from information_schema.columns where table_name='documents' and column_name in ('status','title','tenant_id')"
$P -d secuura -tAc "select conname, pg_get_constraintdef(oid) from pg_constraint where conrelid='documents'::regclass and contype='c'"
$P -d secuura -tAc "select indexname, indexdef from pg_indexes where tablename='documents' and indexdef ilike '%title%'"
