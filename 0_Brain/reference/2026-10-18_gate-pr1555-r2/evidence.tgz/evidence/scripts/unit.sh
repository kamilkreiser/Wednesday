#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555r2-1792314908
for wt in h; do
O_DIR=$G/wt/$wt/Blockchain/Dev/services/originate
J=$G/wt/$wt/Blockchain/Dev/node_modules/.bin/jest
env -u DATABASE_URL -u TEST_DATABASE_URL $J --rootDir $O_DIR --config $O_DIR/jest.config.js --json --outputFile=$G/ev/unit_$wt.json --forceExit > $G/ev/unit_$wt.log 2>&1
echo "$wt rc=$?"
python3 -I - "$G/ev/unit_$wt.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
print("suites",d["numTotalTestSuites"],"passedSuites",d["numPassedTestSuites"],"tests",d["numTotalTests"],"passed",d["numPassedTests"],"failed",d["numFailedTests"])
for f in d["testResults"]:
    for a in f["assertionResults"]:
        if a["status"]=="failed": print("  FAIL", f["name"].split("/")[-1], "|", a["fullName"][:140])
    if f.get("status")=="failed" and not f["assertionResults"]: print("  SUITE-FAIL", f["name"].split("/")[-1], f.get("message","")[:300].replace("\n"," "))
PY
done
