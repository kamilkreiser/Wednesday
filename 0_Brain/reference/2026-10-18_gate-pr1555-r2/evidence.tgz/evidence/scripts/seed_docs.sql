\set D '''a0000000-0000-4000-8000-000000000001'''
\set B '''b1555000-0000-4000-8000-000000001555'''
INSERT INTO documents (id, tenant_id, external_id, title, document_type, content_hash, status, created_at, certified_at, metadata, certification_metadata, parent_document_id) VALUES
 ('15550000-0000-4000-8000-0000000000f0', :D, 'g1555-parent', 'G1555 Parent', 'DIPLOMA', repeat('f0',32), 'certified', '2026-01-01Z', '2026-01-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-0000000000a1', :D, 'g1555-alpha', 'G1555 Alpha', 'DIPLOMA', repeat('a1',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{"issuerName":"Acme Private Issuer Pty"}', '{"certificationType":"academic","blockchain":{"txHash":"0xsim","simulated":true}}', '15550000-0000-4000-8000-0000000000f0'),
 ('15550000-0000-4000-8000-0000000000c1', :D, 'g1555-child', 'G1555 Child', 'DIPLOMA', repeat('c1',32), 'certified', '2026-03-01Z', '2026-03-01Z', '{}', '{}', '15550000-0000-4000-8000-0000000000a1'),
 ('15550000-0000-4000-8000-0000000000b1', :B, 'g1555-bravo', 'G1555 Bravo only', 'DIPLOMA', repeat('b1',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{"issuerName":"Tenant B Issuer"}', '{}', NULL),
 ('15550000-0000-4000-8000-0000000000b2', :B, 'g1555-both-b', 'G1555 In both', 'DIPLOMA', repeat('b2',32), 'certified', '2026-09-01Z', '2026-09-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-0000000000d2', :D, 'g1555-both-d', 'G1555 In both', 'DIPLOMA', repeat('d2',32), 'certified', '2026-01-01Z', '2026-01-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-0000000000e1', :D, 'g1555-erased', '[erased]', 'DIPLOMA', repeat('e1',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-0000000000e2', :D, 'g1555-draft', 'G1555 Draft', 'DIPLOMA', repeat('e2',32), 'draft', '2026-02-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-0000000000e3', :D, 'g1555-revoked', 'G1555 Revoked', 'DIPLOMA', repeat('e3',32), 'revoked', '2026-02-01Z', '2026-02-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000101', :D, 'g1555-pct', 'G1555 100% off_x', 'DIPLOMA', repeat('11',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000102', :D, 'g1555-quote', 'G1555 O''Brien "q" \x', 'DIPLOMA', repeat('12',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000103', :D, 'g1555-long', 'G1555 L' || repeat('x', 493), 'DIPLOMA', repeat('13',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000104', :D, 'g1555-unicode', 'G1555 Café', 'DIPLOMA', repeat('14',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{}', '{}', NULL)
ON CONFLICT (id) DO NOTHING;
SELECT external_id, tenant_id, length(title), status FROM documents WHERE external_id LIKE 'g1555-%' ORDER BY external_id;
-- round 2 additions
INSERT INTO documents (id, tenant_id, external_id, title, document_type, content_hash, status, created_at, certified_at, metadata, certification_metadata, parent_document_id) VALUES
 ('15550000-0000-4000-8000-000000000201', :D, 'g1555-st-pending_signature', 'G1555 St pending_signature', 'DIPLOMA', repeat('21',32), 'pending_signature', '2026-02-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000202', :D, 'g1555-st-signed', 'G1555 St signed', 'DIPLOMA', repeat('22',32), 'signed', '2026-02-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000203', :D, 'g1555-st-anchored', 'G1555 St anchored', 'DIPLOMA', repeat('23',32), 'anchored', '2026-02-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000204', :D, 'g1555-st-anchor_failed', 'G1555 St anchor_failed', 'DIPLOMA', repeat('24',32), 'anchor_failed', '2026-02-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000205', :D, 'g1555-st-deleted', 'G1555 St deleted', 'DIPLOMA', repeat('25',32), 'deleted', '2026-02-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000206', :D, 'g1555-st-expired', 'G1555 St expired', 'DIPLOMA', repeat('26',32), 'expired', '2026-02-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000207', :D, 'g1555-st-REVOKED', 'G1555 St REVOKED', 'DIPLOMA', repeat('27',32), 'REVOKED', '2026-02-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000208', :D, 'g1555-st-Draft', 'G1555 St Draft', 'DIPLOMA', repeat('28',32), 'Draft', '2026-02-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000209', :D, 'g1555-st-revokedsp', 'G1555 St revoked-space', 'DIPLOMA', repeat('29',32), 'revoked ', '2026-02-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000210', :D, 'g1555-st-certified', 'G1555 St certified', 'DIPLOMA', repeat('2a',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000211', :D, 'g1555-shadow-old', 'G1555 Shadow D', 'DIPLOMA', repeat('31',32), 'certified', '2026-01-01Z', '2026-01-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000212', :D, 'g1555-shadow-newdraft', 'G1555 Shadow D', 'DIPLOMA', repeat('32',32), 'draft', '2026-09-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000213', :D, 'g1555-shadowr-old', 'G1555 Shadow R', 'DIPLOMA', repeat('33',32), 'certified', '2026-01-01Z', '2026-01-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000214', :D, 'g1555-shadowr-newrev', 'G1555 Shadow R', 'DIPLOMA', repeat('34',32), 'revoked', '2026-09-01Z', '2026-02-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000215', :D, 'g1555-dr-1', 'G1555 Draft and revoked only', 'DIPLOMA', repeat('35',32), 'draft', '2026-01-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000216', :D, 'g1555-dr-2', 'G1555 Draft and revoked only', 'DIPLOMA', repeat('36',32), 'revoked', '2026-02-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000217', :D, 'g1555-nullcreated', 'G1555 Null created', 'DIPLOMA', repeat('37',32), 'certified', NULL, NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000218', :B, 'g1555-b-draft', 'G1555 B draft', 'DIPLOMA', repeat('38',32), 'draft', '2026-02-01Z', NULL, '{}', '{}', NULL)
ON CONFLICT (id) DO NOTHING;
SELECT status, count(*) FROM documents WHERE external_id LIKE 'g1555-%' GROUP BY status ORDER BY status;
