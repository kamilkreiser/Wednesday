#!/bin/bash
set -euo pipefail
G=/private/tmp/claude-501/gate1555r2-1792314908
SRC="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files"
SSHC='ssh -i "/Volumes/DevMASTER/!CODING/Secuura/Blockchain/3_Access_Keys/github_deploy_rw" -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new -o ServerAliveInterval=30'
GIT_SSH_COMMAND="$SSHC" git -C "$SRC" ls-remote origin refs/pull/1555/head refs/heads/develop refs/pull/1565/head refs/pull/1566/head 2>&1 | tee $G/ev/lsremote.txt || true
git clone -q --shared --no-checkout "$SRC" $G/repo
git -C $G/repo config core.sshCommand "$SSHC"
git -C $G/repo remote set-url origin git@github.com:Secuura/Distributed_Secuura.git
git -C $G/repo fetch -q origin '+refs/pull/1555/head:refs/remotes/pr/1555' '+refs/heads/develop:refs/remotes/origin/develop' '+refs/pull/1565/head:refs/remotes/pr/1565' '+refs/pull/1566/head:refs/remotes/pr/1566'
git -C $G/repo rev-parse pr/1555 origin/develop pr/1565 pr/1566
