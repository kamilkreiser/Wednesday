#!/usr/bin/env python3
"""Gate PR1548 r2 mutant runner (scratch HEAD worktree only). Each mutant alone; anchor must occur exactly once; JSON reporter;
red cells recorded BY NAME WITH message; a 'kill' whose red cells all carry an empty message = EMPTY-MSG, not counted; a suite
that loads fewer cells than expected = LOADFAIL. Both files restored from byte snapshots, sha256 asserted after each mutant.
For each mutant, also runs tsc on a program that INCLUDES the changed test file (tsconfig.changed.json)."""
import hashlib, json, os, subprocess, sys, re
W = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1548r2'
SEC = W + '/wt_head/Blockchain/Dev/services/security'
IDX = SEC + '/src/index.ts'; TST = SEC + '/src/__tests__/ks1570b-admin-scope-route.integration.test.ts'
TSC = W + '/wt_head/Blockchain/Dev/node_modules/.bin/tsc'
APP_PW = open(W + '/pg/app_pw').read().strip()
ENV = dict(os.environ, TEST_DATABASE_URL='postgresql://secuura@127.0.0.1:55583/secuura',
           TEST_APP_DATABASE_URL=f'postgresql://secuura_app:{APP_PW}@127.0.0.1:55583/secuura', NODE_ENV='test',
           MULTI_TENANCY_ENABLED=os.environ.get('MT', 'false'))
ENV.pop('PLATFORM_DATABASE_URL', None)
I = 'vitest.integration.config.ts'
SUITES = [('authorRoute', 'src/__tests__/ks1570b-admin-scope-route.integration.test.ts', 45),
          ('gateG', 'src/__tests__/gate1548-g-status.integration.test.ts', 22),
          ('gateH2', 'src/__tests__/gate1548r2-h2-enum.integration.test.ts', 103)]
G = "lower(status COLLATE \\\"C\\\") = 'active'"
VOC = "expect(inConstraint, 'every status this file exercises, and no other').toEqual([...VOCAB].sort());"
MUT = {
 "C0 comment-only control (index.ts)": [(IDX, "    // Purging existing rows on demotion or deletion is NOT in this change", "    // gate1548r2 C0 comment-only control\n    // Purging existing rows on demotion or deletion is NOT in this change")],
 "C0t comment-only control (test file)": [(TST, "  // --- m1: the Unicode fold ---", "  // gate1548r2 C0t\n  // --- m1: the Unicode fold ---")],
 "M1R COLLATE removed (author)": [(IDX, G, "lower(status) = 'active'")],
 "X4 <> 'deleted' with COLLATE (author's X4)": [(IDX, G, "lower(status COLLATE \\\"C\\\") <> 'deleted'")],
 "X4g gate round-1 X4 literally: lower(status) <> 'deleted'": [(IDX, G, "lower(status) <> 'deleted'")],
 "X5a IN ('active','pending') (author's X5)": [(IDX, G, "lower(status COLLATE \\\"C\\\") IN ('active','pending')")],
 "L1 LIKE '%active%' (author)": [(IDX, G, "lower(status COLLATE \\\"C\\\") LIKE '%active%'")],
 "V1 inverted want on vocab cell (author, test file)": [(TST, VOC, "expect(inConstraint, 'every status this file exercises, and no other').toEqual([...VOCAB].filter((v) => v !== 'inactive').sort());")],
 "X0 deliberate type error in test file (author; must NOT count)": [(TST, "  const DOTTED_UPPER = 'ACT\\u0130VE';", "  const gateX0: number = 'x0' as unknown as string;\n  const DOTTED_UPPER = 'ACT\\u0130VE';")],
 "G2 (mine) COLLATE misplaced: lower(status) COLLATE \"C\"": [(IDX, G, "lower(status) COLLATE \\\"C\\\" = 'active'")],
 "G3 (mine) upper(status COLLATE \"C\") = 'ACTIVE' (predicted equivalent)": [(IDX, G, "upper(status COLLATE \\\"C\\\") = 'ACTIVE'")],
 "G4 (mine) IN ('active','invited')": [(IDX, G, "lower(status COLLATE \\\"C\\\") IN ('active','invited')")],
 "ALLTRUE (reach) status clause removed": [(IDX, " AND " + G, "")],
 "ALLFALSE (reach) = 'nothing'": [(IDX, G, "lower(status COLLATE \\\"C\\\") = 'nothing'")],
}
sha = lambda b: hashlib.sha256(b).hexdigest()
strip = lambda s: re.sub(r'\x1b\[[0-9;]*m', '', s)
def tsc():
    r = subprocess.run([TSC, '-p', W + '/tsc/tsconfig.changed.json'], cwd=SEC, capture_output=True, text=True)
    errs = [l for l in (r.stdout + r.stderr).splitlines() if 'error TS' in l]
    return r.returncode, [re.sub(r'.*/src/', 'src/', l)[:140] for l in errs]
def run_suites(tag):
    res = {}
    for name, f, n in SUITES:
        jf = f'{W}/ev/mut/{re.sub(r"[^A-Za-z0-9]", "", tag)[:8]}_{name}.json'
        if os.path.exists(jf): os.rename(jf, jf + '.stale')
        subprocess.run(['npx', 'vitest', 'run', '--config', I, f, '--reporter=json', f'--outputFile={jf}'], cwd=SEC, env=ENV, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=900)
        if not os.path.exists(jf): res[name] = {'loadfail': True, 'red': []}; continue
        j = json.load(open(jf))
        a = [x for t in j['testResults'] for x in t['assertionResults']]
        red = [{'title': x['title'], 'msg': strip((x.get('failureMessages') or [''])[0]).split('\n')[0][:240]} for x in a if x['status'] != 'passed']
        res[name] = {'total': len(a), 'expected': n, 'red': red, 'loadfail': len(a) != n}
    return res
os.makedirs(W + '/ev/mut', exist_ok=True)
snap = {p: open(p, 'rb').read() for p in (IDX, TST)}; h0 = {p: sha(b) for p, b in snap.items()}
out = {}; lines = []
def say(s): print(s, flush=True); lines.append(s)
say('MT=' + ENV['MULTI_TENANCY_ENABLED'] + ' snapshot ' + json.dumps({os.path.basename(p): h[:16] for p, h in h0.items()}))
trc, terr = tsc(); say(f'BASELINE tsc(changed-program) rc={trc} errs={len(terr)}')
base = run_suites('BASELINE'); out['BASELINE'] = base
say('BASELINE ' + json.dumps({k: (v.get('total'), len(v.get('red', []))) for k, v in base.items()}))
if any(v.get('loadfail') or v.get('red') for v in base.values()): say('BASELINE NOT GREEN: STOP'); sys.exit(2)
only = os.environ.get('ONLY')
for name, reps in MUT.items():
    if only and name.split()[0] not in only.split(','): continue
    cur = {p: snap[p].decode() for p in snap}
    for p, a, b in reps:
        assert cur[p].count(a) == 1, f'{name}: anchor count {cur[p].count(a)}: {a[:80]!r}'
        cur[p] = cur[p].replace(a, b)
    try:
        for p in cur: open(p, 'w').write(cur[p])
        trc, terr = tsc()
        r = run_suites(name)
    finally:
        for p in snap: open(p, 'wb').write(snap[p])
    assert all(sha(open(p, 'rb').read()) == h0[p] for p in snap), 'RESTORE FAILED'
    out[name] = {'tsc_rc': trc, 'tsc_errs': terr, 'suites': r}
    red = {k: v['red'] for k, v in r.items() if v.get('red')}
    lf = [k for k, v in r.items() if v.get('loadfail')]
    msgs = [c['msg'] for v in red.values() for c in v]
    verdict = 'LOADFAIL' if lf and not red else ('SURVIVED' if not red else ('EMPTY-MSG (not counted)' if all(not m.strip() for m in msgs) else 'KILLED'))
    nempty = sum(1 for m in msgs if not m.strip())
    say(f'{name}: {verdict} | tsc rc={trc} errs={len(terr)} | red ' + json.dumps({k: len(v) for k, v in red.items()}) + f' empty-msg {nempty}/{len(msgs)}' + (f' loadfail={lf}' if lf else ''))
    for e in terr[:3]: say(f'    tsc: {e}')
    for k, v in red.items():
        for c in v[:40]: say(f'    {k}: {c["title"][:110]}  ::  {c["msg"][:150]}')
    json.dump(out, open(W + '/ev/mutants_r2' + os.environ.get('RUNTAG', '') + '.json', 'w'), indent=1)
say('restored identical: ' + str(all(sha(open(p, 'rb').read()) == h0[p] for p in snap)))
open(W + '/ev/mutants_r2_run' + os.environ.get('RUNTAG', '') + '.txt', 'w').write('\n'.join(lines) + '\n')
