\pset pager off
\echo '== instrument: every codepoint 1..0x10FFFF except surrogates D800-DFFF, PG 15.14, db collation en_US.UTF-8'
CREATE TEMP TABLE cps AS SELECT cp, chr(cp) AS c FROM generate_series(1, 1114111) cp WHERE cp NOT BETWEEN 55296 AND 57343;
SELECT count(*) AS codepoints_enumerated FROM cps;
\echo '== C collation: non-ASCII codepoints whose lower() differs from input (expect 0)'
SELECT count(*) AS c_changed FROM cps WHERE cp > 127 AND lower(c COLLATE "C") <> c COLLATE "C";
\echo '== C collation: non-ASCII codepoints whose lower() contains ANY ASCII byte (expect 0)'
SELECT count(*) AS c_to_ascii FROM cps WHERE cp > 127 AND lower(c COLLATE "C") ~ '[\x01-\x7f]';
\echo '== C collation, positive control in the same instrument: ASCII A-Z changed by lower() (expect 26)'
SELECT count(*) AS c_ascii_changed FROM cps WHERE cp <= 127 AND lower(c COLLATE "C") <> c COLLATE "C";
\echo '== CONTROL, default (libc en_US.UTF-8) collation: non-ASCII codepoints whose lower() differs (expect >0)'
SELECT count(*) AS default_changed FROM cps WHERE cp > 127 AND lower(c) <> c;
\echo '== default collation: non-ASCII codepoints whose lower() lands in the ASCII range (the m1 class, enumerated)'
SELECT to_hex(cp) AS cp, c, lower(c) AS lowered, ascii(lower(c)) AS lowered_cp FROM cps WHERE cp > 127 AND lower(c) ~ '^[\x01-\x7f]+$' ORDER BY cp;
\echo '== default collation: of those, which land on a letter of active|pending|suspended|deactivated|invited|inactive|deleted'
SELECT to_hex(cp) AS cp, lower(c) AS lowered FROM cps WHERE cp > 127 AND lower(c) ~ '^[acdeilnpstuv]$' ORDER BY cp;
\echo '== ICU und-x-icu: non-ASCII codepoints whose lower() lands in ASCII'
SELECT to_hex(cp) AS cp, lower(c COLLATE "und-x-icu") AS lowered FROM cps WHERE cp > 127 AND lower(c COLLATE "und-x-icu") ~ '^[\x01-\x7f]+$' ORDER BY cp;
\echo '== upper() side, default collation: non-ASCII codepoints whose upper() lands in ASCII (the i6 role class)'
SELECT to_hex(cp) AS cp, upper(c) AS uppered FROM cps WHERE cp > 127 AND upper(c) ~ '^[\x01-\x7f]+$' ORDER BY cp;
SELECT count(*) AS c_upper_to_ascii FROM cps WHERE cp > 127 AND upper(c COLLATE "C") ~ '[\x01-\x7f]';
\echo '== whole-string: all 64 ASCII case spellings of active under C (expect 64 true)'
WITH RECURSIVE s(i, v) AS (SELECT 0, ''::text UNION ALL SELECT i+1, v || x FROM s, LATERAL (VALUES (substr('active', i+1, 1)), (upper(substr('active', i+1, 1)))) t(x) WHERE i < 6)
SELECT count(*) AS spellings, count(*) FILTER (WHERE lower(v COLLATE "C") = 'active') AS guard_true FROM s WHERE i = 6;
\echo '== whole-string: CHECK-admitted non-ASCII spellings of each vocabulary word (U+0130 substituted for every subset of i positions), guard under default vs C'
WITH RECURSIVE w(word) AS (VALUES ('active'),('pending'),('suspended'),('deactivated'),('invited'),('inactive'),('deleted')),
s(word, i, v) AS (SELECT word, 0, ''::text FROM w UNION ALL SELECT s.word, i+1, v || x FROM s, LATERAL (SELECT substr(s.word, i+1, 1) UNION SELECT upper(substr(s.word, i+1, 1)) UNION SELECT CASE WHEN substr(s.word,i+1,1)='i' THEN chr(304) END) t(x) WHERE i < length(s.word) AND x IS NOT NULL)
SELECT word, count(*) AS spellings, count(*) FILTER (WHERE v ~ '[^\x01-\x7f]') AS non_ascii,
  count(*) FILTER (WHERE v ~ '[^\x01-\x7f]' AND lower(v) IN ('active','pending','suspended','deactivated','invited','inactive','deleted')) AS non_ascii_check_admits,
  count(*) FILTER (WHERE v ~ '[^\x01-\x7f]' AND lower(v) = 'active') AS non_ascii_guard_default_true,
  count(*) FILTER (WHERE v ~ '[^\x01-\x7f]' AND lower(v COLLATE "C") = 'active') AS non_ascii_guard_C_true,
  count(*) FILTER (WHERE v !~ '[^\x01-\x7f]' AND lower(v COLLATE "C") = 'active') AS ascii_guard_C_true
FROM s WHERE i = length(word) GROUP BY word ORDER BY word;
