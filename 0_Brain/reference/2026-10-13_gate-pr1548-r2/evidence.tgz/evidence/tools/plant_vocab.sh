#!/bin/bash
# plant_vocab.sh: plant vocabulary changes in MY scratch DB (55583), run ONLY the author's vocabulary-read cell, restore, assert def identical.
W=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1548r2
PSQL="/opt/homebrew/opt/postgresql@15/bin/psql -h 127.0.0.1 -p 55583 -U secuura -d secuura -At -v ON_ERROR_STOP=1"
F=src/__tests__/ks1570b-admin-scope-route.integration.test.ts
ORIG=$($PSQL -c "SELECT pg_get_constraintdef(oid) FROM pg_constraint WHERE conrelid='users'::regclass AND conname='users_status_vocabulary'")
echo "ORIG: $ORIG"
plant() { # name, sql
  echo "=== PLANT $1"
  $PSQL -c "ALTER TABLE users DROP CONSTRAINT IF EXISTS users_status_vocabulary; ALTER TABLE users DROP CONSTRAINT IF EXISTS users_status_vocabulary_x; $2" || { echo PLANT-FAILED; return; }
  $PSQL -c "SELECT conname, pg_get_constraintdef(oid) FROM pg_constraint WHERE conrelid='users'::regclass AND conname LIKE 'users_status_vocab%'"
  bash $W/bin/sec.sh wt_head $W/ev/plant_$1.txt i $F -t "g1548-i2: the spectrum below IS" | grep -E "Tests|rc"
  sed 's/\x1b\[[0-9;]*m//g' $W/ev/plant_$1.txt | grep -E "AssertionError|^\s+(\+|-) " | head -8
  $PSQL -c "ALTER TABLE users DROP CONSTRAINT IF EXISTS users_status_vocabulary; ALTER TABLE users DROP CONSTRAINT IF EXISTS users_status_vocabulary_x; ALTER TABLE users ADD CONSTRAINT users_status_vocabulary CHECK (lower(status) IN ('active','pending','suspended','deactivated','invited','inactive','deleted'))"
  NOW=$($PSQL -c "SELECT pg_get_constraintdef(oid) FROM pg_constraint WHERE conrelid='users'::regclass AND conname='users_status_vocabulary'")
  [ "$NOW" = "$ORIG" ] && echo "restored identical" || { echo "RESTORE MISMATCH: $NOW"; exit 3; }
}
plant P0_none_control "ALTER TABLE users ADD CONSTRAINT users_status_vocabulary CHECK (lower(status) IN ('active','pending','suspended','deactivated','invited','inactive','deleted'))"
plant P1_add_archived "ALTER TABLE users ADD CONSTRAINT users_status_vocabulary CHECK (lower(status) IN ('active','pending','suspended','deactivated','invited','inactive','deleted','archived'))"
plant P2_remove_invited "ALTER TABLE users ADD CONSTRAINT users_status_vocabulary CHECK (lower(status) IN ('active','pending','suspended','deactivated','inactive','deleted'))"
plant P3_add_on_hold "ALTER TABLE users ADD CONSTRAINT users_status_vocabulary CHECK (lower(status) IN ('active','pending','suspended','deactivated','invited','inactive','deleted','on_hold'))"
plant P4_add_pending2 "ALTER TABLE users ADD CONSTRAINT users_status_vocabulary CHECK (lower(status) IN ('active','pending','suspended','deactivated','invited','inactive','deleted','tier2'))"
plant P5_add_dashed "ALTER TABLE users ADD CONSTRAINT users_status_vocabulary CHECK (lower(status) IN ('active','pending','suspended','deactivated','invited','inactive','deleted','re-invited'))"
plant P6_renamed "ALTER TABLE users ADD CONSTRAINT users_status_vocabulary_x CHECK (lower(status) IN ('active','pending','suspended','deactivated','invited','inactive','deleted'))"
plant P7_swap_active_for_enabled "ALTER TABLE users ADD CONSTRAINT users_status_vocabulary CHECK (lower(status) IN ('enabled','pending','suspended','deactivated','invited','inactive','deleted'))"
