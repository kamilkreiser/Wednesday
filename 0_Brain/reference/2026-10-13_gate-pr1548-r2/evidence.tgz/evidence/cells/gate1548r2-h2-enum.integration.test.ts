/** Gate PR1548 r2 H2: EVERY spelling of 'active' the CHECK can admit, at the real route.
 * Set = per position {lower, UPPER, and U+0130 where the letter is i} = 96 strings (64 ASCII, 32 carrying U+0130).
 * The SQL enumeration (enum_fold.txt) shows U+0130 is the ONLY non-ASCII codepoint libc lower() maps onto a vocabulary letter,
 * so this set is the whole CHECK-admitted spelling space of 'active'. Plus fold-class strings the CHECK must refuse. */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import fs from 'fs';
import { H, boot, shutdown, put } from './gate1548-common';
const T = 'a0000000-0000-4000-8000-0000000154e2';
const A1 = 'abcdef00-1548-4548-8548-0000000000e2';
const made: string[] = []; const LEDGER: Record<string, unknown> = {};
const spellings: string[] = (() => { let acc = ['']; for (const ch of 'active') { const opts = [ch, ch.toUpperCase(), ...(ch === 'i' ? ['İ'] : [])]; acc = acc.flatMap((p) => opts.map((o) => p + o)); } return acc; })();
const REFUSE = ['ａctive', 'ACTＩVE', 'actıve', 'acti̇ve', 'Ktive', 'ACTIVE​'];
beforeAll(async () => {
  await boot();
  await H.su.query(`INSERT INTO organizations (id, name, slug, type, tenant_id) VALUES ($1::uuid,'gate1548r2 e2','gate1548r2-e2','issuer',$2::uuid) ON CONFLICT (id) DO NOTHING`, [A1, T]);
});
afterAll(async () => {
  if (process.env.GATE_LEDGER) fs.writeFileSync(process.env.GATE_LEDGER, JSON.stringify(LEDGER, null, 1));
  await H.su.query('DELETE FROM admin_organisation_scopes WHERE user_id = ANY($1::uuid[])', [made]);
  await H.su.query("DELETE FROM audit_logs WHERE action='admin_scope.set' AND resource_id = ANY($1::uuid[])", [made]);
  await H.su.query('DELETE FROM users WHERE id = ANY($1::uuid[])', [made]);
  await H.su.query('DELETE FROM organizations WHERE id=$1::uuid', [A1]);
  await shutdown();
});
async function probe(s: string): Promise<{ insert: string; put: number; rows: number; audits: number }> {
  const id = crypto.randomUUID(); made.push(id);
  let insert = 'ok';
  try { await H.su.query("INSERT INTO users (id, tenant_id, email, role, status) VALUES ($1::uuid,$2::uuid,$3,'ADMIN',$4)", [id, T, `g1548r2-${id}@example.invalid`, s]); } catch (e: any) { insert = `refused ${e.code}`; }
  const r = insert === 'ok' ? await put(id, T, [A1]) : { status: 0 };
  const rows = Number((await H.su.query('SELECT count(*) n FROM admin_organisation_scopes WHERE user_id=$1::uuid', [id])).rows[0].n);
  const audits = Number((await H.su.query("SELECT count(*) n FROM audit_logs WHERE action='admin_scope.set' AND resource_id=$1::uuid", [id])).rows[0].n);
  return { insert, put: r.status, rows, audits };
}
describe('gate1548r2 H2: the whole admitted spelling space of active', () => {
  it('the set has 96 members, 32 non-ASCII', () => {
    expect(spellings.length).toBe(96);
    expect(spellings.filter((s) => /[^\x00-\x7f]/.test(s)).length).toBe(32);
  });
  for (const s of spellings) {
    const ascii = !/[^\x00-\x7f]/.test(s);
    const authActive = s === 'active' || s.toLowerCase() === 'active';
    it(`H2 ${JSON.stringify(s)} ascii=${ascii} authActive=${authActive}`, async () => {
      const r = await probe(s);
      LEDGER[s] = { ...r, ascii, authActive };
      expect(r.insert, 'the CHECK admits every member').toBe('ok');
      expect(authActive).toBe(ascii);
      expect(r).toEqual(ascii ? { insert: 'ok', put: 200, rows: 1, audits: 1 } : { insert: 'ok', put: 404, rows: 0, audits: 0 });
    });
  }
  for (const s of REFUSE) {
    it(`H2 refused-by-CHECK or not-live ${JSON.stringify(s)}`, async () => {
      const r = await probe(s);
      LEDGER['REFUSE ' + s] = r;
      expect(r.rows).toBe(0);
      expect(r.put === 0 || r.put === 404).toBe(true);
    });
  }
});
