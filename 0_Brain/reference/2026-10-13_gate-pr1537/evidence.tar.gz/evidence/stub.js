const http=require('http'),fs=require('fs'),path=require('path');
const DIST=process.argv[2], PORT=+process.argv[3]||7551;
let cfg={orgs:'ok3',orgsDelay:0,keys:'ok',keysDelay:0,mint:'ok',mintDelay:0,revoke:'ok',orgsByTenant:{},keysDelayByOrg:{}};
let log=[]; let minted=0;
const ORGS3=[{id:'AAAAAAAA-1111-4111-8111-AAAAAAAAAAAA',name:'Org <b>Alpha</b>',type:'x',status:'active',userCount:1,documentCount:1,createdAt:'2026'},
 {id:'bbbbbbbb-2222-4222-8222-bbbbbbbbbbbb',name:'Beta',type:'x',status:'active',userCount:1,documentCount:1,createdAt:'2026'},
 {id:'cccccccc-3333-4333-8333-cccccccccccc',name:'',type:'x',status:'active',userCount:1,documentCount:1,createdAt:'2026'}];
const mime={'.js':'text/javascript','.css':'text/css','.html':'text/html','.svg':'image/svg+xml','.json':'application/json','.png':'image/png'};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function json(res,code,obj){res.writeHead(code,{'content-type':'application/json'});res.end(JSON.stringify(obj));}
http.createServer(async (req,res)=>{
 let body='';for await(const c of req)body+=c;
 const u=new URL(req.url,'http://x');
 if(u.pathname==='/__cfg'){ if(req.method==='POST'){cfg={...cfg,...JSON.parse(body||'{}')};} return json(res,200,cfg);}
 if(u.pathname==='/__log'){ const l=log; if(u.searchParams.get('clear'))log=[]; return json(res,200,l);}
 if(u.pathname.startsWith('/api/')){
  const t=req.headers['x-tenant-override']||null;
  log.push({t:Date.now(),m:req.method,u:req.url,tenant:t,body:body||undefined});
  const p=u.pathname;
  if(p==='/api/auth/refresh') return json(res,200,{success:true,data:{accessToken:'tok',expiresIn:900,tokenType:'Bearer',user:{id:'u1',email:'a@b.co',role:'ADMIN'}}});
  if(p==='/api/users/me') return json(res,200,{success:true,data:{id:'u1',email:'a@b.co',role:'ADMIN'}});
  if(p.startsWith('/api/platform/tenants/')){await sleep(cfg.tenantDelay||0);return json(res,200,{success:true,data:{tenant:{id:p.split('/').pop(),name:'T',slug:'t',status:'active'},contacts:[]}});}
  if(p==='/api/platform/tenants') return json(res,200,{success:true,data:{tenants:[{id:'T1',name:'T1',slug:'t1',status:'active'},{id:'T2',name:'T2',slug:'t2',status:'active'}]}});
  if(p==='/api/users/admin/organizations'){
    await sleep(cfg.orgsDelay);
    let m=(cfg.orgsByTenant&&cfg.orgsByTenant[t])||cfg.orgs;
    let d=(cfg.orgsDelayByTenant&&cfg.orgsDelayByTenant[t]); if(d)await sleep(d);
    if(m==='net') return req.socket.destroy();
    if(m==='403') return json(res,403,{success:false,error:{code:'FORBIDDEN',message:'Admin role required'}});
    if(m==='500') return json(res,500,{success:false,error:{code:'INTERNAL',message:'boom'}});
    if(m==='html'){res.writeHead(502,{'content-type':'text/html'});return res.end('<html><h1>502 Bad Gateway</h1></html>');}
    if(m==='ok0') return json(res,200,{success:true,data:{organizations:[],total:0}});
    if(m==='ok1') return json(res,200,{success:true,data:{organizations:[ORGS3[0]],total:1}});
    if(m==='T1only') return json(res,200,{success:true,data:{organizations:[{...ORGS3[1],id:'t1-org-1',name:'T1 Org'}],total:1}});
    if(m==='T2only') return json(res,200,{success:true,data:{organizations:[{...ORGS3[1],id:'t2-org-1',name:'T2 Org'}],total:1}});
    return json(res,200,{success:true,data:{organizations:ORGS3,total:3}});
  }
  if(p==='/api/security/keys' && req.method==='GET'){
    await sleep(cfg.keysDelay); const o=u.searchParams.get('organizationId'); const dd=cfg.keysDelayByOrg[o]; if(dd)await sleep(dd);
    const m=cfg.keys;
    if(m==='net') return req.socket.destroy();
    if(m==='400') return json(res,400,{success:false,error:{code:'BAD_REQUEST',message:'organizationId required'}});
    if(m==='403') return json(res,403,{success:false,error:{code:'FORBIDDEN',message:'Not your organisation'}});
    if(m==='401') return json(res,401,{success:false,error:{code:'UNAUTH',message:'expired'}});
    if(m==='500') return json(res,500,{success:false,error:{code:'INTERNAL',message:'boom'}});
    if(m==='html'){res.writeHead(500,{'content-type':'text/html'});return res.end('<html><script>alert(1)</script></html>');}
    if(m==='empty') return json(res,200,{success:true,data:[]});
    return json(res,200,{success:true,data:[{id:'key-'+o+'-1',name:'K for '+o,prefix:'sk_'+o.slice(0,4),scopes:['read'],usageCount:0,isActive:true,createdAt:'2026-01-01T00:00:00Z'}]});
  }
  if(p==='/api/security/keys' && req.method==='POST'){
    await sleep(cfg.mintDelay); const m=cfg.mint; minted++;
    if(m==='net') return req.socket.destroy();
    if(m==='400') return json(res,400,{success:false,error:{code:'BAD_REQUEST',message:'name too short'}});
    if(m==='403') return json(res,403,{success:false,error:{code:'FORBIDDEN',message:'API keys may only be minted for your own organisation'}});
    if(m==='404') return json(res,404,{success:false,error:{code:'NF',message:'organisation not found'}});
    if(m==='500') return json(res,500,{success:false,error:{code:'INTERNAL',message:'boom'}});
    if(m==='html'){res.writeHead(500,{'content-type':'text/html'});return res.end('<html>oops</html>');}
    if(m==='strerr') return json(res,400,{error:'plain string error <img src=x onerror=window.__xss=1>'});
    if(m==='objnomsg') return json(res,400,{error:{code:'X'}});
    if(m==='xss') return json(res,400,{error:{code:'X',message:'<img src=x onerror=window.__xss=1>'}});
    if(m==='empty200') return json(res,200,{success:true,data:{}});
    if(m==='emptybody'){res.writeHead(500);return res.end();}
    return json(res,201,{success:true,data:{id:'new'+minted,key:'sk_live_REALKEY_'+minted}});
  }
  if(p.startsWith('/api/security/keys/') && req.method==='DELETE'){
    if(cfg.revoke==='500') return json(res,500,{success:false,error:{code:'INTERNAL',message:'cannot revoke'}});
    if(cfg.revoke==='403') return json(res,403,{success:false,error:{code:'FORBIDDEN',message:'not allowed'}});
    return json(res,200,{success:true});
  }
  return json(res,200,{success:true,data:{}});
 }
 // static
 let rel=u.pathname.replace(/^\/admin\/?/,'');
 let f=path.join(DIST,rel);
 if(!rel||!fs.existsSync(f)||fs.statSync(f).isDirectory()) f=path.join(DIST,'index.html');
 res.writeHead(200,{'content-type':mime[path.extname(f)]||'application/octet-stream'});res.end(fs.readFileSync(f));
}).listen(PORT,()=>console.log('stub on',PORT));
