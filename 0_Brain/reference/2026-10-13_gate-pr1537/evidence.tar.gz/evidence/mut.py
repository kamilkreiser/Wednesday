import sys,re,subprocess,shutil
G,D,E=sys.argv[1:4]
A=D+'/frontend/admin/src'
P=A+'/pages/ApiKeys.tsx'; API=A+'/services/api.ts'
headP=open(G+'/ApiKeys.head').read(); headA=open(G+'/api.head').read()
LIT="default"+"-org"
muts={
 'M1 literal in mint':      (lambda p,a:(p.replace('organizationId: dialogOrgId',"organizationId: '%s'"%LIT),a)),
 'M2 default value on dialogOrgId state':(lambda p,a:(p.replace("useState('')\n  const [listError","useState('')\n  const [listError"),a)),
 'M3 || fallback in api.ts fetchApiKeys':(lambda p,a:(p,a.replace("encodeURIComponent(organizationId)","encodeURIComponent(organizationId || '%s')"%LIT))),
 'M4 literal in other file':(lambda p,a:(p,a+"\nexport const X='%s';\n"%LIT)),
 'M5 concatenated literal in mint':(lambda p,a:(p.replace('organizationId: dialogOrgId',"organizationId: 'default'+'-org'"),a)),
 'M6 const built from pieces, ident in mint':(lambda p,a:(p.replace('organizationId: dialogOrgId',"organizationId: FALLBACK_ORG").replace("export default function ApiKeys","const FALLBACK_ORG = ['default','org'].join('-');\nexport default function ApiKeys"),a)),
 'M7 ?? fallback in api.ts (template)':(lambda p,a:(p,a.replace("encodeURIComponent(organizationId)","encodeURIComponent(organizationId ?? `default-${'org'}`)"))),
 'M8 list call site sends fallback':(lambda p,a:(p.replace("fetchApiKeys(orgId)","fetchApiKeys(orgId || FB)").replace("export default function ApiKeys","const FB = ['default','org'].join('-');\nexport default function ApiKeys"),a)),
 'M9 mint ident ternary':(lambda p,a:(p.replace('organizationId: dialogOrgId',"organizationId: dialogOrgId ? dialogOrgId : 'x'"),a)),
 'C comment-only':(lambda p,a:(p+"\n// "+LIT+" was removed\n",a)),
 'M10 literal in .js/.json/.tsx-less file (e.g. config.js)':None,
}
for name,f in muts.items():
    if f is None: continue
    p,a=f(headP,headA)
    changed = (p!=headP) or (a!=headA)
    open(P,'w').write(p); open(API,'w').write(a)
    r=subprocess.run(['npm','run','test','--prefix',D+'/packages/shared','--','ks1564','--reporter=verbose'],capture_output=True,text=True)
    out=r.stdout+r.stderr
    fails=[l.split('>')[-1].strip()[:40] for l in out.splitlines() if l.strip().startswith('×')]
    print(f"{name}: applied={changed} rc={r.returncode} red={len(fails)} {fails}")
open(P,'w').write(headP); open(API,'w').write(headA)
