// Gate #1568 r2: the error saveDocument throws on migration 050's refusal when originate runs with MULTI_TENANCY_ENABLED unset
// (db.ts: the real PrismaClient over PrismaPg — compose's default), and what isIdNamespaceCollision() says about it.
// argv: ownerDbUrl originateTree
import * as path from 'path';
import * as crypto from 'crypto';
import { createRequire } from 'module';
const [ownerUrl, tree] = process.argv.slice(2);
process.env.DATABASE_URL = ownerUrl;
delete process.env.MULTI_TENANCY_ENABLED;
const O = path.join(tree, 'Blockchain/Dev/services/originate/src');
const req = createRequire(path.join(tree, 'Blockchain/Dev/services/originate/package.json'));
const { Client } = req('pg');
(async () => {
  const owner = new Client({ connectionString: ownerUrl }); await owner.connect();
  const TA = crypto.randomUUID(), TB = crypto.randomUUID(), P = crypto.randomUUID();
  await owner.query(`INSERT INTO documents (id, tenant_id, title, document_type, content_hash, status) VALUES ($1::uuid, $2::uuid, 'probe cert', 'certification', $3, 'certified')`, [P, TA, 'c'.repeat(64)]);
  const repo = await import(path.join(O, 'repositories/documentRepo.ts'));
  const { isIdNamespaceCollision } = await import(path.join(O, 'utils/idNamespaceCollision.ts'));
  const doc = { id: P, type: 'invoice', status: 'draft', owner: { id: crypto.randomUUID(), walletAddress: null }, data: { title: 'probe' }, contentHash: 'd'.repeat(64), signatures: [], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
  for (const mode of ['skip', 'upsert'] as const) {
    try { await repo.saveDocument(doc as any, TB, undefined, mode === 'skip' ? { conflictMode: 'skip' } : {}); console.log(JSON.stringify({ mode, threw: false })); }
    catch (e: any) {
      console.log(JSON.stringify({ mode, threw: true, name: e?.constructor?.name, code: e?.code, constraint: e?.constraint ?? null, meta: e?.meta ?? null,
        message: String(e?.message).trim().slice(0, 200), isIdNamespaceCollision: isIdNamespaceCollision(e) }));
    }
  }
  const landed = await owner.query('SELECT count(*)::int AS n FROM documents WHERE external_id = $1', [P]);
  console.log(JSON.stringify({ rowsWithExternalIdP: landed.rows[0].n }));
  await owner.end(); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
