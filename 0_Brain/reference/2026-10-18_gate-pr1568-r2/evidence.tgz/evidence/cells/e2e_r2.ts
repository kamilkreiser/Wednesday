// Gate #1568 round 2 cell. BOOTED anchoring + BOOTED originate (real routes, real repos, secuura_app, FORCE RLS,
// mock chain, RS256). Round 1's MAJ-1 cells XT1/XT2 re-run with the colliding row attempted through originate's
// REAL create route in ANOTHER tenant; the byte-compare of the 409; and the orphan-anchor cells XT3/XT4 (an
// anchor_store row keyed by a v4 that names NO documents row, as originate's own /api/anchoring/submit mints).
// argv: anchoringBase originateBase privKeyPath ownerDbUrl appDbUrl anchoringTree originateTree
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import { createRequire } from 'module';
const [abase, obase, keyPath, ownerUrl, appUrl, treeA] = process.argv.slice(2);
const req = createRequire(path.join(treeA, 'Blockchain/Dev/services/anchoring/package.json'));
const jwt = req('jsonwebtoken');
const { Client } = req('pg');
const key = fs.readFileSync(keyPath, 'utf8');
const u = () => crypto.randomUUID();
const RUN = crypto.randomBytes(3).toString('hex');
// TENANT_A / TENANT_B from the boot script: two tenants registered in the platform DB (MT=true), or both the DEFAULT tenant (MT unset: one tenant, two organisations)
const TA = process.env.TENANT_A || u(), TB = process.env.TENANT_B || u();
const ORG_I = u(), ORG_C = u(), ORG_CI = u(), ORG_TB = u();
const U_ISS = u(), U_HOLDER = u(), U_COLL = u(), U_CERTISS = u(), U_TB = u();
type Claims = { userId: string; tenantId: string; organizationId?: string; role: string };
const C_ISS: Claims = { userId: U_ISS, tenantId: TA, organizationId: ORG_I, role: 'ISSUER_ADMIN' };
const C_COLL: Claims = { userId: U_COLL, tenantId: TA, organizationId: ORG_C, role: 'ISSUER_ADMIN' };
const C_TB: Claims = { userId: U_TB, tenantId: TB, organizationId: ORG_TB, role: 'ISSUER_ADMIN' };
const tok = (c: Claims) => jwt.sign({ email: `${c.userId}@x.invalid`, verificationLevel: 'BASIC', ...c }, key, { algorithm: 'RS256', expiresIn: '10m' });
const owner = new Client({ connectionString: ownerUrl });
const hashOf = (s: string) => crypto.createHash('sha256').update(s).digest('hex');
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const out: any[] = [];
const emit = (rec: any) => { out.push(rec); console.log(JSON.stringify(rec)); };
async function anchorPost(c: Claims, documentId: string, contentHash: string, actor?: string) {
  const r = await fetch(`${abase}/api/anchors`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${tok(c)}` },
    body: JSON.stringify({ documentId, contentHash, ...(actor ? { identity: { actorDid: actor, actorLevel: 2, actorSource: 'platform' } } : {}) }) });
  return r.status;
}
async function create(c: Claims, body: Record<string, unknown>) {
  const r = await fetch(`${obase}/api/documents`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${tok(c)}`, 'x-tenant-id': c.tenantId, 'x-gateway-vouch': process.env.GATE_VOUCH ?? '' }, body: JSON.stringify(body) });
  const text = await r.text();
  return { status: r.status, contentType: r.headers.get('content-type'), length: r.headers.get('content-length'), body: text };
}
async function row(documentId: string) {
  const r = await owner.query(`SELECT metadata_payload->'secuura'->>'actorDid' AS actor, metadata_payload->'secuura'->>'issuerOrgId' AS issuer_org,
      status, transaction_hash, updated_at, created_at FROM anchor_store WHERE document_id = $1 AND network = 'preprod'`, [documentId]);  // anchoring's own row (CARDANO_NETWORK preprod); originate's /submit also writes a 'preview' row
  const x = r.rows[0];
  return { rows: r.rowCount, actor: x?.actor ?? null, issuerOrgId: x?.issuer_org ?? null, status: x?.status ?? null, tx: (x?.transaction_hash ?? '').slice(0, 16) || null, updatedAt: x?.updated_at ? new Date(x.updated_at).toISOString() : null, createdAt: x?.created_at ? new Date(x.created_at).toISOString() : null };
}
async function docsNaming(id: string) {
  const r = await owner.query(`SELECT tenant_id::text AS tenant, (id::text = $1) AS by_pkey, (external_id = $1) AS by_ext, issuer_organization_id::text AS issuer
                               FROM documents WHERE id::text = $1 OR external_id = $1`, [id]);
  return r.rows.map((x: any) => ({ tenant: x.tenant === TA ? 'A' : x.tenant === TB ? 'B' : x.tenant, byPkey: x.by_pkey, byExt: x.by_ext, issuer: x.issuer === ORG_TB ? 'ORG_TB' : x.issuer }));
}
async function verify(h: string) {
  const r = await fetch(`${abase}/api/anchors/verify/${h}`);
  const t = await r.text();
  let actor: unknown = null, documentId: unknown = null, verified: unknown = null;
  try { const j = JSON.parse(t); const d = j.data ?? j; verified = d.verified; const m = d.metadata ?? d.anchor?.metadata ?? {}; documentId = m.documentId ?? m.secuura?.documentId ?? null;
    const s = JSON.stringify(j); const mm = s.match(/did:key:z[A-Za-z0-9_]+/g); actor = mm ? Array.from(new Set(mm)) : null; } catch { /* raw */ }
  return { status: r.status, verified, actorDidsInBody: actor, documentIdInBody: documentId };
}
async function insDoc(o: { tenant: string; issuerOrg: string | null; owner: string | null; externalId?: string | null; id?: string; issuerUser?: string | null; hash: string; type?: string }) {
  const id = o.id ?? u();
  await owner.query(`INSERT INTO documents (id, external_id, title, document_type, content_hash, tenant_id, issuer_organization_id, owner_user_id, issuer_user_id, status)
                     VALUES ($1::uuid, $2, 'gate 1568 r2', $3, $4, $5::uuid, $6::uuid, $7::uuid, $8::uuid, 'certified')`,
    [id, o.externalId ?? null, o.type ?? 'invoice', o.hash, o.tenant, o.issuerOrg, o.owner, o.issuerUser ?? null]);
  return id;
}
const attackerBody = (documentUuid: string, contentHash: string) => ({ title: `gate r2 attacker ${RUN}`, documentType: 'invoice', contentHash, documentUuid,
  organizationUuid: ORG_TB, identity: { actorDid: 'did:key:zTENANT_B_ATTACKER', actorLevel: 3, actorSource: 'platform' } });
(async () => {
  await owner.connect();
  for (const [id, t, name] of [[ORG_I, TA, 'issuer'], [ORG_C, TA, 'holder'], [ORG_CI, TA, 'certiss'], [ORG_TB, TB, 'attacker']] as const) {
    await owner.query(`INSERT INTO organizations (id, name, slug, type, tenant_id) VALUES ($1::uuid, $2, $3, 'company', $4::uuid)`, [id, `g-${name}-${RUN}`, `g-${name}-${RUN}`, t]);
  }
  for (const [id, org, t] of [[U_ISS, ORG_I, TA], [U_HOLDER, ORG_C, TA], [U_COLL, ORG_C, TA], [U_CERTISS, ORG_CI, TA], [U_TB, ORG_TB, TB]] as const) {
    await owner.query('INSERT INTO users (id, email, organization_id, tenant_id) VALUES ($1::uuid, $2, $3::uuid, $4::uuid)', [id, `${id}@x.invalid`, org, t]);
  }
  emit({ run: RUN, TA, TB, ORG_TB });
  // ---- CONTROL: an ordinary tenant-B create lands, in tenant B, and its auto-anchor lands (proves the harness reaches both services)
  { const du = u(); const h = hashOf(`ctl-${RUN}`);
    const r = await create(C_TB, attackerBody(du, h)); await sleep(5000);
    emit({ cell: 'CTL tenant-B create with a fresh documentUuid', create: { status: r.status, body: r.body.slice(0, 200) }, docs: await docsNaming(du), anchor: await row(du) }); }
  // ---- XT1 (round 1's MAJ-1): tenant-A certification P (certificationRepo shape), anchored by a holder-org colleague
  for (const kind of ['XT1 cert (pkey, NULL issuer, holder org C)', 'XT2 tenant-A document anchored under its pkey (issuer ORG_I)']) {
    const h = hashOf(`${kind}-${RUN}`);
    const P = kind.startsWith('XT1')
      ? await insDoc({ tenant: TA, issuerOrg: null, owner: U_HOLDER, issuerUser: U_CERTISS, hash: h, type: 'certification' })
      : await insDoc({ tenant: TA, issuerOrg: ORG_I, owner: U_HOLDER, hash: h });
    const sA = await anchorPost(kind.startsWith('XT1') ? C_COLL : C_ISS, P, h, 'did:key:zVICTIM');
    await sleep(4000);
    const before = { anchor: await row(P), verify: await verify(h) };
    const c = await create(C_TB, attackerBody(P, h));
    await sleep(5000);
    const afterCreate = { anchor: await row(P), verify: await verify(h), docs: await docsNaming(P) };
    // and the KS-1603 direct route, tenant B naming P with its own identity (the guard must keep the identity)
    const sDirect = await anchorPost(C_TB, P, h, 'did:key:zTENANT_B_DIRECT');
    await sleep(3000);
    const afterDirect = { anchor: await row(P), verify: await verify(h) };
    emit({ cell: kind, firstAnchor: sA, before, attackerCreate: c, afterCreate, directPost: sDirect, afterDirect,
      result: (c.status === 409 && afterCreate.anchor.actor === 'did:key:zVICTIM' && afterDirect.anchor.actor === 'did:key:zVICTIM' && afterCreate.docs.length === 1) ? 'CLOSED' : 'OPEN' });
  }
  // ---- byte-compare: the SAME-TENANT refusals (tenant A posting documentUuid = its own cert pkey; and = its own ext id, other bytes)
  { const h = hashOf(`same-${RUN}`);
    const P = await insDoc({ tenant: TA, issuerOrg: null, owner: U_HOLDER, issuerUser: U_CERTISS, hash: h, type: 'certification' });
    const sameTenantPkey = await create(C_ISS, { ...attackerBody(P, hashOf('different bytes than the cert')), organizationUuid: ORG_I });
    const sameTenantPkeySameBytes = await create(C_ISS, { ...attackerBody(P, h), organizationUuid: ORG_I });
    const E = u(); await insDoc({ tenant: TA, issuerOrg: ORG_I, owner: U_ISS, externalId: E, hash: h });
    const sameTenantExt = await create(C_ISS, { ...attackerBody(E, hashOf('other bytes')), organizationUuid: ORG_I });
    const P2 = await insDoc({ tenant: TA, issuerOrg: null, owner: U_HOLDER, hash: hashOf(`p2-${RUN}`), type: 'certification' });
    const crossTenantPkey = await create(C_TB, attackerBody(P2, hashOf(`p2-${RUN}`)));
    const E2 = u(); await insDoc({ tenant: TA, issuerOrg: ORG_I, owner: U_ISS, externalId: E2, hash: h });
    const crossTenantExt = await create(C_TB, attackerBody(E2, h));
    const strip = (x: any) => ({ status: x.status, contentType: x.contentType, length: x.length, body: x.body });
    emit({ cell: 'BYTES 409 comparison', sameTenantPkey: strip(sameTenantPkey), sameTenantPkeySameBytes_preexisting: { status: sameTenantPkeySameBytes.status, body: sameTenantPkeySameBytes.body.slice(0, 160) }, sameTenantExt: strip(sameTenantExt), crossTenantPkey_050: strip(crossTenantPkey), crossTenantExt_preexisting: strip(crossTenantExt),
      equal_050_vs_sameTenant: JSON.stringify(strip(crossTenantPkey)) === JSON.stringify(strip(sameTenantPkey)) });
  }
  // ---- XT3 ORPHAN via originate's REAL /api/anchoring/submit (mints documentId = uuidv4, no documents row anywhere)
  { const h = hashOf(`xt3-${RUN}`);
    const s = await fetch(`${obase}/api/anchoring/submit`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${tok(C_ISS)}`, 'x-tenant-id': C_ISS.tenantId, 'x-gateway-vouch': process.env.GATE_VOUCH ?? '' }, body: JSON.stringify({ documentHash: h }) });
    const sBody = await s.text();
    await sleep(4000);
    const found = await owner.query('SELECT document_id FROM anchor_store WHERE content_hash = $1', [h]);
    const U = found.rows[0]?.document_id as string | undefined;
    const before = U ? { anchor: await row(U), verify: await verify(h), docs: await docsNaming(U) } : null;
    let c: any = null, after: any = null;
    if (U) { c = await create(C_TB, attackerBody(U, h)); await sleep(5000); after = { anchor: await row(U), verify: await verify(h), docs: await docsNaming(U) }; }
    emit({ cell: 'XT3 orphan anchor minted by tenant A through originate /api/anchoring/submit; tenant B registers documentUuid = that id', submit: { status: s.status, body: sBody.slice(0, 300) }, orphanId: U ?? null, before, attackerCreate: c ? { status: c.status, body: c.body.slice(0, 200) } : null, after,
      result: after && after.anchor.actor === 'did:key:zTENANT_B_ATTACKER' ? 'REWRITTEN' : 'KEPT' }); }
  // ---- XT4 ORPHAN via a tenant-A anchor of a v4 that names no documents row, WITH tenant A's identity (originate POST /api/anchors forwards any documentId)
  { const h = hashOf(`xt4-${RUN}`); const U = u();
    const s = await fetch(`${obase}/api/anchors`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${tok(C_ISS)}`, 'x-tenant-id': C_ISS.tenantId, 'x-gateway-vouch': process.env.GATE_VOUCH ?? '' },
      body: JSON.stringify({ documentId: U, contentHash: h, identity: { actorDid: 'did:key:zVICTIM4', actorLevel: 2, actorSource: 'platform' } }) });
    const sBody = await s.text();
    await sleep(4000);
    const before = { anchor: await row(U), verify: await verify(h), docs: await docsNaming(U) };
    const c = await create(C_TB, attackerBody(U, h)); await sleep(5000);
    const after = { anchor: await row(U), verify: await verify(h), docs: await docsNaming(U) };
    emit({ cell: 'XT4 orphan anchor by tenant A via originate POST /api/anchors (v4 naming no document), tenant B registers documentUuid = it', anchorPost: { status: s.status, body: sBody.slice(0, 200) }, before,
      attackerCreate: { status: c.status, body: c.body.slice(0, 200) }, after, result: after.anchor.actor === 'did:key:zTENANT_B_ATTACKER' ? 'REWRITTEN' : 'KEPT' }); }
  await owner.end();
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
