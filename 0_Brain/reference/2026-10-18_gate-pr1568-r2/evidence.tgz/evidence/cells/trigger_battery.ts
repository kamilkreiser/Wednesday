// Gate #1568 r2: migration 050's trigger, probed directly. Every write is inside a transaction that is ROLLED BACK,
// except the race cell (two committed rows in my own scratch DB, reported, never deleted).
// argv: ownerDbUrl appDbUrl tree
import * as path from 'path';
import * as crypto from 'crypto';
import { createRequire } from 'module';
const [ownerUrl, appUrl, tree] = process.argv.slice(2);
const req = createRequire(path.join(tree, 'Blockchain/Dev/services/anchoring/package.json'));
const { Client } = req('pg');
const u = () => crypto.randomUUID();
const h = () => crypto.randomBytes(32).toString('hex');
const out: any[] = [];
const emit = (r: any) => { out.push(r); console.log(JSON.stringify(r)); };
const errOf = (e: any) => e ? { code: e.code, constraint: e.constraint ?? null, message: e.message, detail: e.detail ?? null, hint: e.hint ?? null, schema: e.schema ?? null, table: e.table ?? null } : null;
async function attempt(c: any, sql: string, params: unknown[] = []) {
  await c.query('SAVEPOINT s');
  try { const r = await c.query(sql, params); await c.query('RELEASE SAVEPOINT s'); return { ok: true, rowCount: r.rowCount, err: null }; }
  catch (e: any) { await c.query('ROLLBACK TO SAVEPOINT s'); return { ok: false, rowCount: 0, err: errOf(e) }; }
}
const INS = `INSERT INTO documents (id, external_id, title, document_type, content_hash, tenant_id) VALUES ($1::uuid, $2, 'gate r2 trig', 'DOC', $3, $4::uuid)`;
const CENSUS = `SELECT count(*)::int AS n FROM documents a JOIN documents b
  ON b.id = CASE WHEN a.external_id ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' THEN a.external_id::uuid END AND b.id <> a.id`;
(async () => {
  const owner = new Client({ connectionString: ownerUrl }); await owner.connect();
  const app = new Client({ connectionString: appUrl }); await app.connect();
  const TA = u(), TB = u();
  // ---- privilege
  for (const [who, c] of [['secuura_app', app], ['owner (secuura, superuser)', owner]] as const) {
    let e: any = null; try { await c.query('SELECT documents_id_namespaces_disjoint()'); } catch (x: any) { e = x; }
    emit({ cell: `PRIV call the function as ${who}`, err: errOf(e) });
  }
  emit({ cell: 'PRIV catalogue', rows: (await owner.query(`SELECT p.prosecdef, pg_get_userbyid(p.proowner) AS owner, p.proacl::text, p.proconfig, p.provolatile,
      has_function_privilege('secuura_app', p.oid, 'EXECUTE') AS app_execute, (SELECT rolsuper FROM pg_roles WHERE oid = p.proowner) AS owner_super,
      (SELECT relowner::regrole::text FROM pg_class WHERE oid = 'documents'::regclass) AS table_owner,
      has_table_privilege('secuura_app', 'documents', 'TRIGGER') AS app_trigger_priv, has_schema_privilege('secuura_app', 'public', 'CREATE') AS app_create_in_public
    FROM pg_proc p WHERE p.proname = 'documents_id_namespaces_disjoint'`)).rows });
  { // can the app role switch the trigger off?
    await app.query('BEGIN');
    const a = await attempt(app, `SET LOCAL session_replication_role = replica`);
    const b = await attempt(app, `ALTER TABLE documents DISABLE TRIGGER documents_id_namespaces_disjoint`);
    const c = await attempt(app, `CREATE OR REPLACE FUNCTION documents_id_namespaces_disjoint() RETURNS trigger LANGUAGE plpgsql AS $$BEGIN RETURN NEW; END$$`);
    await app.query('ROLLBACK');
    emit({ cell: 'PRIV app role tries to bypass: replica mode / DISABLE TRIGGER / replace function', replica: a.err, disable: b.err, replace: c.err });
  }
  // ---- forward / reverse / variants, as secuura_app in tenant B (the victim row is in tenant A and INVISIBLE to it)
  const victim = u();
  await owner.query('BEGIN');
  await owner.query(`INSERT INTO documents (id, title, document_type, content_hash, tenant_id) VALUES ($1::uuid, 'victim cert', 'certification', $2, $3::uuid)`, [victim, h(), TA]);
  const extA = u();
  await owner.query(INS, [u(), extA, h(), TA]);
  const extUpper = u();
  await owner.query(INS, [u(), extUpper.toUpperCase(), h(), TA]);
  const extPadded = u();
  await owner.query(INS, [u(), ` ${extPadded}`, h(), TA]);
  await owner.query('COMMIT');
  await app.query('BEGIN');
  await app.query("SELECT set_config('app.current_tenant_id', $1, true)", [TB]);
  emit({ cell: 'VIS secuura_app in tenant B sees the tenant-A victim row?', rows: (await app.query('SELECT 1 FROM documents WHERE id = $1::uuid', [victim])).rowCount });
  const fwd: Array<[string, string]> = [
    ['F1 external_id = victim pkey (canonical lower)', victim],
    ['F2 external_id = UPPER(victim pkey)', victim.toUpperCase()],
    ['F3 external_id = mixed case', victim.slice(0, 18).toUpperCase() + victim.slice(18)],
    ['F4 external_id = leading space + pkey', ` ${victim}`],
    ['F5 external_id = pkey + trailing space', `${victim} `],
    ['F6 external_id = pkey + trailing newline', `${victim}\n`],
    ['F7 external_id = {pkey}', `{${victim}}`],
    ['F8 external_id = pkey without hyphens', victim.replace(/-/g, '')],
    ['F9 external_id = urn:uuid:pkey', `urn:uuid:${victim}`],
    ['F10 CONTROL external_id = a fresh v4 naming nothing', u()],
    ['F11 CONTROL external_id = doc-… form', `doc-${Date.now()}-gate`],
  ];
  for (const [name, ext] of fwd) {
    const r = await attempt(app, INS, [u(), ext, h(), TB]);
    let pgCastsIt: unknown = null; try { pgCastsIt = (await owner.query('SELECT ($1::text)::uuid::text AS v', [ext])).rows[0].v === victim; } catch { pgCastsIt = 'cast raises'; }
    emit({ cell: name, sent: JSON.stringify(ext), inserted: r.ok, err: r.err ? { code: r.err.code, constraint: r.err.constraint, message: r.err.message } : null, postgresUuidCastEqualsVictim: pgCastsIt });
  }
  const rev: Array<[string, string]> = [
    ['R1 new pkey = an existing uuid external_id (lower), other tenant', extA],
    ['R2 new pkey = lower(an existing UPPER-case external_id)', extUpper],
    ['R3 new pkey = an existing external_id that has a leading space', extPadded],
  ];
  for (const [name, pk] of rev) {
    const r = await attempt(app, INS, [pk, `doc-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, h(), TB]);
    emit({ cell: name, inserted: r.ok, err: r.err ? { code: r.err.code, constraint: r.err.constraint } : null });
  }
  // the trigger let R2/R3 through? then the census sees them? (inside this still-open app transaction the rows are uncommitted; read with the app's own view is RLS-blind, so measure on the owner after a separate committed replay below)
  await app.query('ROLLBACK');
  // ---- UPDATE paths, bulk paths, same statement
  await owner.query('BEGIN');
  const mine = u();
  await owner.query(INS, [mine, `doc-${Date.now()}-mine`, h(), TB]);
  emit({ cell: 'U1 UPDATE SET external_id = victim pkey', ...(await attempt(owner, 'UPDATE documents SET external_id = $1 WHERE id = $2::uuid', [victim, mine])) });
  emit({ cell: 'U2 UPDATE SET id = an existing external_id', ...(await attempt(owner, 'UPDATE documents SET id = $1::uuid WHERE id = $2::uuid', [extA, mine])) });
  emit({ cell: 'U3 UPDATE SET external_id = UPPER(victim pkey)', ...(await attempt(owner, 'UPDATE documents SET external_id = $1 WHERE id = $2::uuid', [victim.toUpperCase(), mine])) });
  emit({ cell: 'U4 CONTROL UPDATE of another column only (trigger is OF id, external_id)', ...(await attempt(owner, `UPDATE documents SET title = 'x' WHERE id = $1::uuid`, [mine])) });
  const x1 = u();
  emit({ cell: 'B1 one multi-row INSERT: row1 pkey X, row2 external_id X', ...(await attempt(owner, `INSERT INTO documents (id, external_id, title, document_type, content_hash, tenant_id) VALUES ($1::uuid, NULL, 'b1a', 'DOC', $3, $4::uuid), ($5::uuid, $2, 'b1b', 'DOC', $3, $6::uuid)`, [x1, x1, h(), TA, u(), TB])) });
  const x2 = u();
  emit({ cell: 'B2 one multi-row INSERT: row1 external_id X, row2 pkey X', ...(await attempt(owner, `INSERT INTO documents (id, external_id, title, document_type, content_hash, tenant_id) VALUES ($1::uuid, $2, 'b2a', 'DOC', $3, $4::uuid), ($2::uuid, NULL, 'b2b', 'DOC', $3, $5::uuid)`, [u(), x2, h(), TB, TA])) });
  emit({ cell: 'B3 INSERT … SELECT carrying the victim pkey as external_id', ...(await attempt(owner, `INSERT INTO documents (id, external_id, title, document_type, content_hash, tenant_id) SELECT gen_random_uuid(), id::text, 'b3', 'DOC', content_hash, $2::uuid FROM documents WHERE id = $1::uuid`, [victim, TB])) });
  emit({ cell: 'B4 the ON CONFLICT (external_id) DO UPDATE path (saveDocument upsert mode) with external_id = victim pkey', ...(await attempt(owner, `${INS} ON CONFLICT (external_id) DO UPDATE SET title = 'u'`, [u(), victim, h(), TB])) });
  emit({ cell: 'B5 a row whose external_id is its OWN pkey (no other row)', ...(await attempt(owner, INS, [x2, x2, h(), TB])) });
  await owner.query('ROLLBACK');
  // ---- COPY (owner; secuura_app cannot COPY into an RLS table at all)
  {
    await owner.query('BEGIN');
    const { from } = (() => { try { return req('pg-copy-streams'); } catch { return { from: null }; } })();
    let res: any = { note: 'pg-copy-streams not installed; COPY measured in 10_copy.sql via psql instead' };
    if (from) {
      res = await new Promise((resolve) => {
        const s = owner.query(from(`COPY documents (id, external_id, title, document_type, content_hash, tenant_id) FROM STDIN`));
        s.on('error', (e: any) => resolve({ ok: false, err: errOf(e) })); s.on('finish', () => resolve({ ok: true }));
        s.write(`${u()}\t${victim}\tcopy\tDOC\t${h()}\t${TB}\n`); s.end();
      });
    }
    await owner.query('ROLLBACK').catch(() => undefined);
    emit({ cell: 'C1 COPY FROM STDIN with external_id = victim pkey', ...res });
  }
  // ---- the asymmetry, COMMITTED in my own scratch DB so the census can read it: an UPPER-case uuid external_id, then a row whose pkey is its lower form
  {
    const before = (await owner.query(CENSUS)).rows[0].n;
    const e = u();
    await owner.query(INS, [u(), e.toUpperCase(), h(), TA]);
    const r = await owner.query(INS, [e, `doc-${Date.now()}-asym`, h(), TB]).then(() => ({ inserted: true }), (x: any) => ({ inserted: false, err: errOf(x) }));
    const after = (await owner.query(CENSUS)).rows[0].n;
    emit({ cell: 'A1 trigger vs census: ext UPPER(e) exists, then INSERT pkey e (other tenant) — trigger allows? census counts?', ...r, censusBefore: before, censusAfter: after, value: e });
  }
  // ---- the race, COMMITTED (accepted residual): T1 inserts pkey X and holds; T2 inserts external_id X; both commit
  {
    const c1 = new Client({ connectionString: ownerUrl }); await c1.connect();
    const c2 = new Client({ connectionString: ownerUrl }); await c2.connect();
    const X = u();
    const before = (await owner.query(CENSUS)).rows[0].n;
    await c1.query('BEGIN'); await c1.query(`INSERT INTO documents (id, title, document_type, content_hash, tenant_id) VALUES ($1::uuid, 'race pk', 'certification', $2, $3::uuid)`, [X, h(), TA]);
    await c2.query('BEGIN'); const r2 = await attempt(c2, INS, [u(), X, h(), TB]);
    await c1.query('COMMIT'); await c2.query('COMMIT');
    const after = (await owner.query(CENSUS)).rows[0].n;
    emit({ cell: 'RACE T1 pkey X uncommitted, T2 external_id X: both commit?', t2: r2.ok, censusBefore: before, censusAfter: after, value: X });
    await c1.end(); await c2.end();
  }
  await owner.end(); await app.end();
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
