// Gate #1568 cell: against a BOOTED anchoring service (real index.ts + real guard, Postgres as secuura_app,
// FORCE RLS, mock chain, RS256 tokens). For each cell: a FIRST anchor, then a SECOND from the caller under
// test; report the HTTP statuses, the guard's own decision for that caller (the product function, imported
// from the same tree, same DB, app role) and the stored row afterwards.
// argv: baseUrl privKeyPath forgerKeyPath ownerDbUrl appDbUrl tree
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import { createRequire } from 'module';
const [base, keyPath, forgerPath, ownerUrl, appUrl, tree] = process.argv.slice(2);
const req = createRequire(path.join(tree, 'Blockchain/Dev/services/anchoring/package.json'));
const jwt = req('jsonwebtoken');
const { Client } = req('pg');
const key = fs.readFileSync(keyPath, 'utf8');
const forger = fs.readFileSync(forgerPath, 'utf8');
const u = () => crypto.randomUUID();
const RUN = crypto.randomBytes(3).toString('hex');
const TA = u(), TB = u();
const ORG_I = u(), ORG_C = u(), ORG_T = u(), ORG_TB = u(), ORG_CI = u();
const U_ISS = u(), U_CUST = u(), U_COLL = u(), U_THIRD = u(), U_TB = u(), U_CERTISS = u();
type Claims = { userId?: string; tenantId?: string; organizationId?: string; role?: string };
const C_ISS: Claims = { userId: U_ISS, tenantId: TA, organizationId: ORG_I, role: 'ISSUER_ADMIN' };
const C_CUST: Claims = { userId: U_CUST, tenantId: TA, organizationId: ORG_C, role: 'ISSUER_ADMIN' };
const C_COLL: Claims = { userId: U_COLL, tenantId: TA, organizationId: ORG_C, role: 'ISSUER_ADMIN' };
const C_THIRD: Claims = { userId: U_THIRD, tenantId: TA, organizationId: ORG_T, role: 'ISSUER_ADMIN' };
const C_TB: Claims = { userId: U_TB, tenantId: TB, organizationId: ORG_TB, role: 'ISSUER_ADMIN' };
const C_CERTISS: Claims = { userId: U_CERTISS, tenantId: TA, organizationId: ORG_CI, role: 'ISSUER_ADMIN' };
const C_NOORG: Claims = { userId: U_THIRD, tenantId: TA, role: 'ISSUER_ADMIN' };
const C_BADORG: Claims = { userId: U_THIRD, tenantId: TA, organizationId: 'org-not-a-uuid', role: 'ISSUER_ADMIN' };
const C_CONN_NOORG: Claims = { userId: 'connector:api-key', tenantId: TA, role: 'connector' };
const C_CONN_ORG: Claims = { userId: 'connector:k1', tenantId: TA, organizationId: ORG_I, role: 'connector' };
const tok = (c: Claims, signer = key, extra: object = {}) =>
  jwt.sign({ email: 'x@x.invalid', verificationLevel: 'BASIC', ...c, ...extra }, signer, { algorithm: 'RS256', ...(Object.prototype.hasOwnProperty.call(extra, 'exp') ? {} : { expiresIn: '10m' }) });
const expired = (c: Claims) => tok(c, key, { exp: Math.floor(Date.now() / 1000) - 120 });
const owner = new Client({ connectionString: ownerUrl });
let guard: any;
const hashOf = (s: string) => crypto.createHash('sha256').update(s).digest('hex');
async function post(token: string, documentId: string, actor: string, contentHash: string) {
  const r = await fetch(`${base}/api/anchors`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
    body: JSON.stringify({ documentId, contentHash, identity: { actorDid: actor, actorLevel: 2, actorSource: 'platform' } }) });
  return r.status;
}
async function row(documentId: string) {
  const r = await owner.query(`SELECT document_id, metadata_payload->'secuura'->>'actorDid' AS actor, content_hash, status, anchor_type, transaction_hash, updated_at
                               FROM anchor_store WHERE document_id = $1`, [documentId]);
  return { rows: r.rowCount, actor: r.rows[0]?.actor ?? null, status: r.rows[0]?.status ?? null, tx: (r.rows[0]?.transaction_hash ?? '').slice(0, 16) || null };
}
async function insDoc(o: { tenant: string; issuerOrg: string | null; owner: string | null; externalId?: string | null; id?: string; issuerUser?: string | null; hash: string; type?: string }) {
  const id = o.id ?? u();
  await owner.query(`INSERT INTO documents (id, external_id, title, document_type, content_hash, tenant_id, issuer_organization_id, owner_user_id, issuer_user_id)
                     VALUES ($1::uuid, $2, 'gate 1568', $3, $4, $5::uuid, $6::uuid, $7::uuid, $8::uuid)`,
    [id, o.externalId ?? null, o.type ?? 'invoice', o.hash, o.tenant, o.issuerOrg, o.owner, o.issuerUser ?? null]);
  return id;
}
async function decide(documentId: string, c: Claims) {
  try { return await guard.mayOverwriteStoredMetadata(documentId, c); } catch (e: any) { return { error: String(e?.message ?? e) }; }
}
const out: any[] = [];
let n = 0;
async function cell(name: string, documentId: string, first: Claims, second: { claims?: Claims; token?: string }, expect: 'REPLACE' | 'KEEP', hash: string) {
  n += 1;
  const a1 = `did:key:zFIRST${n}`, a2 = `did:key:zSECOND${n}`;
  const s1 = await post(tok(first), documentId, a1, hash);
  const s2 = await post(second.token ?? tok(second.claims!), documentId, a2, hash);
  const st = await row(documentId);
  const replaced = st.actor === a2;
  const decision = second.claims ? await decide(documentId, second.claims) : 'n/a (token refused)';
  const rec = { cell: name, documentId, firstStatus: s1, secondStatus: s2, decision, stored: st, replaced, expected: expect, result: (replaced === (expect === 'REPLACE')) ? 'AS-EXPECTED' : 'UNEXPECTED' };
  out.push(rec);
  console.log(JSON.stringify(rec));
}
(async () => {
  process.env.DATABASE_URL = appUrl;
  guard = await import(path.join(tree, 'Blockchain/Dev/services/anchoring/src/anchorOverwriteGuard.ts'));
  await owner.connect();
  for (const [id, org, t] of [[U_ISS, ORG_I, TA], [U_CUST, ORG_C, TA], [U_COLL, ORG_C, TA], [U_THIRD, ORG_T, TA], [U_TB, ORG_TB, TB], [U_CERTISS, ORG_CI, TA]] as const) {
    await owner.query('INSERT INTO users (id, email, organization_id, tenant_id) VALUES ($1::uuid, $2, $3::uuid, $4::uuid)', [id, `${id}@x.invalid`, org, t]);
  }
  console.log(JSON.stringify({ run: RUN, TA, TB, ORG_I, ORG_C, ORG_T, ORG_TB, ORG_CI }));
  // ===== item 2: DOCUMENT anchor, keyed by the EXTERNAL id originate sends (doc-…), issuer ORG_I, custodian U_CUST (org C)
  const docCell = async (name: string, second: { claims?: Claims; token?: string }, expect: 'REPLACE' | 'KEEP', issuerOrg: string | null = ORG_I) => {
    const ext = `doc-${Date.now()}-${RUN}${n}`; const h = hashOf(ext);
    await insDoc({ tenant: TA, issuerOrg, owner: U_CUST, externalId: ext, hash: h });
    await cell(name, ext, issuerOrg ? C_ISS : C_COLL, second, expect, h);
  };
  await docCell('D1 doc(ext): the issuer org', { claims: C_ISS }, 'REPLACE');
  await docCell('D2 doc(ext): a colleague in the custodian org C', { claims: C_COLL }, 'REPLACE');
  await docCell('D3 doc(ext): the custodian user himself', { claims: C_CUST }, 'REPLACE');
  await docCell('D4 doc(ext): NULL issuer, colleague in custodian org (Kam b)', { claims: C_COLL }, 'REPLACE', null);
  await docCell('D5 doc(ext): another org in the same tenant', { claims: C_THIRD }, 'KEEP');
  await docCell('D6 doc(ext): another tenant', { claims: C_TB }, 'KEEP');
  await docCell('D7 doc(ext): another tenant claiming custodian org C', { claims: { ...C_TB, organizationId: ORG_C } }, 'KEEP');
  await docCell('D8 doc(ext): forged token (foreign key) claiming issuer org', { token: tok(C_ISS, forger) }, 'KEEP');
  await docCell('D9 doc(ext): expired token of the issuer', { token: expired(C_ISS) }, 'KEEP');
  // ===== item 2/4: CERTIFICATION anchor, keyed by the PRIMARY key, no external_id, NULL issuer_organization_id,
  // owner_user_id = the HOLDER (U_CUST, org C), issuer_user_id = the issuing user (org CI) — certificationRepo's shape
  const certCell = async (name: string, firstC: Claims, second: { claims?: Claims; token?: string }, expect: 'REPLACE' | 'KEEP') => {
    const h = hashOf(`cert-${RUN}-${n}`);
    const id = await insDoc({ tenant: TA, issuerOrg: null, owner: U_CUST, issuerUser: U_CERTISS, hash: h, type: 'certification' });
    await cell(name, id, firstC, second, expect, h);
  };
  await certCell('C1 cert(pkey): a colleague in the HOLDER org C (Kam b, the new write)', C_CERTISS, { claims: C_COLL }, 'REPLACE');
  await certCell('C2 cert(pkey): the holder himself', C_CERTISS, { claims: C_CUST }, 'REPLACE');
  await certCell('C3 cert(pkey): the cert ISSUING user org CI (issuer_organization_id is NULL)', C_COLL, { claims: C_CERTISS }, 'KEEP');
  await certCell('C4 cert(pkey): another org in the same tenant', C_CERTISS, { claims: C_THIRD }, 'KEEP');
  await certCell('C5 cert(pkey): another tenant', C_CERTISS, { claims: C_TB }, 'KEEP');
  await certCell('C6 cert(pkey): another tenant claiming holder org C', C_CERTISS, { claims: { ...C_TB, organizationId: ORG_C } }, 'KEEP');
  await certCell('C7 cert(pkey): forged token claiming holder org C', C_CERTISS, { token: tok(C_COLL, forger) }, 'KEEP');
  await certCell('C8 cert(pkey): expired token of a holder-org colleague', C_CERTISS, { token: expired(C_COLL) }, 'KEEP');
  // ===== non-uuid id naming NOTHING
  { const id = `doc-${Date.now()}-nothing${RUN}a`; await cell('N1 non-uuid id naming nothing: same caller twice', id, C_ISS, { claims: C_ISS }, 'KEEP', hashOf(id)); }
  { const id = `doc-${Date.now()}-nothing${RUN}b`; await cell('N2 non-uuid id naming nothing: another tenant second', id, C_ISS, { claims: C_TB }, 'KEEP', hashOf(id)); }
  // ===== item 3: resolution
  { // R1 same-tenant collision: row P has pkey S (issuer ORG_I); row E has external_id S (issuer ORG_T)
    const S = u(); const h = hashOf(`r1-${S}`);
    await insDoc({ tenant: TA, issuerOrg: ORG_I, owner: null, id: S, hash: h });
    let r1err: any = null; try { await insDoc({ tenant: TA, issuerOrg: ORG_T, owner: null, externalId: S, hash: h }); } catch (e: any) { r1err = { code: e.code, constraint: e.constraint }; }
    console.log(JSON.stringify({ cell: 'R1 setup: same-tenant ext=pkey collision row', refused: r1err }));
    await cell('R1a collision ext=pkey, same tenant: ext row issuer (ORG_T) wins', S, C_ISS, { claims: C_THIRD }, 'REPLACE', h);
    await cell('R1b collision ext=pkey, same tenant: pkey row issuer (ORG_I) refused', S, C_THIRD, { claims: C_ISS }, 'KEEP', h);
  }
  { // R2 an id that exists ONLY in another tenant (external id, then primary key)
    const ext = `doc-${Date.now()}-${RUN}tb`; const h = hashOf(ext);
    await insDoc({ tenant: TB, issuerOrg: ORG_TB, owner: null, externalId: ext, hash: h });
    await cell('R2a ext id exists only in tenant B; tenant-A caller', ext, C_TB, { claims: C_ISS }, 'KEEP', h);
    const h2 = hashOf(`r2b-${RUN}`);
    const pk = await insDoc({ tenant: TB, issuerOrg: ORG_TB, owner: null, hash: h2 });
    await cell('R2b pkey exists only in tenant B; tenant-A caller (claims ORG_TB)', pk, C_TB, { claims: { ...C_ISS, organizationId: ORG_TB } }, 'KEEP', h2);
  }
  { // R3 case / format variants — direct guard decisions (the product function), no write
    const sExt = u(); const h = hashOf(`r3-${sExt}`);
    await insDoc({ tenant: TA, issuerOrg: ORG_I, owner: null, externalId: sExt, hash: h });
    const pk = await insDoc({ tenant: TA, issuerOrg: ORG_I, owner: null, hash: h });
    const variants: Array<[string, string]> = [
      ['ext lower (canonical)', sExt], ['ext UPPER', sExt.toUpperCase()], ['ext padded', ` ${sExt} `], ['ext braces', `{${sExt}}`], ['ext no-hyphens', sExt.replace(/-/g, '')],
      ['pkey lower (canonical)', pk], ['pkey UPPER', pk.toUpperCase()], ['pkey padded', ` ${pk} `], ['pkey tab+newline', `\t${pk}\n`], ['pkey braces', `{${pk}}`], ['pkey no-hyphens', pk.replace(/-/g, '')], ['pkey urn', `urn:uuid:${pk}`],
    ];
    for (const [label, v] of variants) {
      const d = await decide(v, C_ISS);
      const rec = { cell: `R3 variant: ${label}`, sent: JSON.stringify(v), decision: d };
      out.push(rec); console.log(JSON.stringify(rec));
    }
    // and through the route: an UPPER variant of a pkey-keyed anchor is a SEPARATE anchor_store row (text key)
    const s1 = await post(tok(C_ISS), pk, 'did:key:zCANON', h);
    const s2 = await post(tok(C_ISS), pk.toUpperCase(), 'did:key:zUPPER', h);
    const canon = await row(pk); const upper = await row(pk.toUpperCase());
    const rec = { cell: 'R3r route: pkey then UPPER(pkey), issuer', s1, s2, canonical: canon, upperRow: upper };
    out.push(rec); console.log(JSON.stringify(rec));
  }
  // ===== the cross-tenant namespace collision (anchor_store.document_id is one global text namespace;
  // documents.external_id is globally UNIQUE, but nothing stops tenant B's external_id equalling tenant A's PRIMARY key)
  { const h = hashOf(`xt0-${RUN}`);
    const cert = await insDoc({ tenant: TA, issuerOrg: null, owner: U_CUST, issuerUser: U_CERTISS, hash: h, type: 'certification' });
    await cell('XT0 control: tenant-B issuer, NO colliding row in B, on tenant-A cert pkey', cert, C_COLL, { claims: C_TB }, 'KEEP', h); }
  { const h = hashOf(`xt1-${RUN}`);
    const cert = await insDoc({ tenant: TA, issuerOrg: null, owner: U_CUST, issuerUser: U_CERTISS, hash: h, type: 'certification' });
    // the row originate's create writes for tenant B with documentUuid = <tenant A's cert pkey> (documentRepo: fresh pkey, external_id = documentUuid)
    // ROUND 2: the colliding row is now refused by migration 050 (here as the RLS-bypassing owner, the strongest writer)
    let collideErr: any = null; try { await insDoc({ tenant: TB, issuerOrg: ORG_TB, owner: U_TB, externalId: cert, hash: h }); } catch (e: any) { collideErr = { code: e.code, constraint: e.constraint }; }
    console.log(JSON.stringify({ cell: 'XT1 setup: the colliding tenant-B row', refused: collideErr }));
    // step by step, so the public verify is read BEFORE and AFTER tenant B's event
    n += 1;
    const sA = await post(tok(C_COLL), cert, 'did:key:zVICTIM_HOLDER_ORG', h);
    await new Promise((r) => setTimeout(r, 4000));
    const vb = await fetch(`${base}/api/anchors/verify/${h}`); const before = await vb.text();
    const sB = await post(tok(C_TB), cert, 'did:key:zTENANT_B_ATTACKER', h);
    await new Promise((r) => setTimeout(r, 4000));
    const va = await fetch(`${base}/api/anchors/verify/${h}`); const after = await va.text();
    const st = await row(cert);
    const rec = { cell: 'XT1 tenant-B issuer whose OWN document has external_id = tenant-A cert pkey', documentId: cert, firstStatus: sA, secondStatus: sB,
      decision: await decide(cert, C_TB), stored: st, replaced: st.actor === 'did:key:zTENANT_B_ATTACKER', expected: 'KEEP',
      result: st.actor === 'did:key:zTENANT_B_ATTACKER' ? 'UNEXPECTED' : 'AS-EXPECTED',
      verifyBefore: { status: vb.status, body: before.slice(0, 1200) }, verifyAfter: { status: va.status, body: after.slice(0, 1200) } };
    out.push(rec); console.log(JSON.stringify(rec)); }
  { const h = hashOf(`xt2-${RUN}`);
    const d = await insDoc({ tenant: TA, issuerOrg: ORG_I, owner: U_CUST, hash: h });
    let collideErr2: any = null; try { await insDoc({ tenant: TB, issuerOrg: ORG_TB, owner: U_TB, externalId: d, hash: h }); } catch (e: any) { collideErr2 = { code: e.code, constraint: e.constraint }; }
    console.log(JSON.stringify({ cell: 'XT2 setup: the colliding tenant-B row', refused: collideErr2 }));
    await cell('XT2 same, on a tenant-A DOCUMENT anchored under its pkey (issuer ORG_I)', d, C_ISS, { claims: C_TB }, 'KEEP', h); }
  // ===== item 6: the quiet set on the real service — a non-uuid id naming nothing, callers develop kept quiet
  { const id = `doc-${Date.now()}-quiet${RUN}noorg`; await cell('L1 quiet? caller with tenant, NO organizationId, non-uuid id naming nothing', id, C_NOORG, { claims: C_NOORG }, 'KEEP', hashOf(id)); }
  { const id = `doc-${Date.now()}-quiet${RUN}badorg`; await cell('L2 quiet? caller org not a uuid, non-uuid id naming nothing', id, C_BADORG, { claims: C_BADORG }, 'KEEP', hashOf(id)); }
  { const id = `doc-${Date.now()}-quiet${RUN}connnoorg`; await cell('L3 quiet? connector token without organizationId, non-uuid id naming nothing', id, C_CONN_NOORG, { claims: C_CONN_NOORG }, 'KEEP', hashOf(id)); }
  { const id = `doc-${Date.now()}-quiet${RUN}connorg`; await cell('L4 control: connector WITH organizationId, non-uuid id naming nothing', id, C_CONN_ORG, { claims: C_CONN_ORG }, 'KEEP', hashOf(id)); }
  { const ext = `doc-${Date.now()}-quiet${RUN}allowedhash`; const h = hashOf(ext);
    await insDoc({ tenant: TA, issuerOrg: ORG_I, owner: null, externalId: ext, hash: h });
    const s1 = await post(tok(C_ISS), ext, 'did:key:zL5a', h);
    const s2 = await post(tok(C_ISS), ext, 'did:key:zL5b', hashOf('different-bytes'));
    const rec = { cell: 'L5 issuer, non-uuid id naming a doc, ALLOWED but different contentHash (payload kept by MAJ-2)', s1, s2, stored: await row(ext), decision: await decide(ext, C_ISS) };
    out.push(rec); console.log(JSON.stringify(rec)); }
  await owner.end();
  const unexpected = out.filter((r) => r.result === 'UNEXPECTED').map((r) => r.cell);
  console.log(JSON.stringify({ summary: { cells: out.filter((r) => r.result).length, unexpected } }));
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
