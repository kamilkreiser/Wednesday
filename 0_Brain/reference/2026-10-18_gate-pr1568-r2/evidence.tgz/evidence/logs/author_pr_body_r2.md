## BLUF — round 2 (of 2, the cap)

**Round 1's MAJ-1 is closed at the database:** tenant B can no longer register a document whose `external_id` equals tenant A's primary key, in any tenant, by any writer. Migration **050** adds a SECURITY DEFINER trigger that **no role can call**, so no callable privilege is added. Kam's two KS-1385 rulings still reach originate's anchors and certifications, and the guard's logic is unchanged. **Runtime + migration. Nothing deployed.**

Refs KS-1612
Refs KS-1385

## ⚠ DEPLOY-TIME STEP — run the census FIRST

Migration **050 fails closed**. It refuses to apply while any existing row already collides, and it refuses to run as a role that cannot see every tenant.

**Before deploying to any box (kintsugi, demo), run this read-only census as the migrations role.** It is also in 050's header:

```sql
SELECT a.id AS row_with_external_id, a.tenant_id AS its_tenant, a.external_id,
       b.id AS row_with_that_pkey,   b.tenant_id AS pkey_tenant
  FROM documents a
  JOIN documents b
    ON b.id = CASE WHEN a.external_id ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' THEN a.external_id::uuid END
   AND b.id <> a.id;
```

* **Zero rows** means 050 applies.
* **Any row** means 050 refuses, with the count, and changes nothing. A human resolves those rows; 050 never edits data.
* The migrations image **bakes** the `.sql` files, so rebuild `migrations` with the service images. Then confirm the runner prints `Applying 050_documents_id_namespaces_disjoint.sql`.

## What MAJ-1 was, and what closes it

* **The attack.** `anchor_store` is one global text namespace (`UNIQUE (document_id, network)`, no tenant column).
  * Document anchors send the external id; certification anchors send the primary key.
  * Originate's shadow check is tenant-scoped (`routes/documents.ts`, `respondForExisting`).
  * So tenant B could create a row whose `external_id` was tenant A's certification pkey. B's anchors then addressed A's row, and the guard, resolving B's own row, let B rewrite A's anchored identity.
* **Option (b), ruled by Wednesday 2026-10-18T10:19:24Z, implemented in migration 050.** A `BEFORE INSERT OR UPDATE OF id, external_id` trigger refuses a row when:
  * its uuid-shaped `external_id` is another row's pkey (index-backed), or
  * its pkey is another row's `external_id` (index-backed).
  * It raises SQLSTATE `23505` with `CONSTRAINT = documents_id_namespaces_disjoint` and a fixed message that names no id and no tenant.
* **The function and its privilege:**
  * It is `SECURITY DEFINER`, owned by the migrations role, which bypasses RLS; 050 asserts that before doing anything.
  * It `RETURNS trigger`, so nobody can call it: not `secuura_app` ("permission denied"), and not even its owner ("trigger functions can only be called as triggers").
  * `EXECUTE` is revoked from `PUBLIC`.
* **Originate maps ONLY that SQLSTATE + constraint** to the create route's **existing** 409 body, byte for byte, via one shared constant used by both refusals. The reply doesn't reveal which tenant holds the id. Every other error, including any other unique violation, keeps today's 500.
* **MIN-1:** `isQuietKeep` is quiet, as develop was, on a non-uuid id from a caller with a tenant whose organisation is unusable. That covers the org-less connector token (auth `jwt.ts`) and an organisation that is not a uuid.
* **MIN-2:** the stale authority comments are rewritten to say what the code does and that it rests on 050: `index.ts` upsert SQL, `routes/documents.ts`, and the guard header's "never add one".
* Two pre-existing `no-useless-assignment` warnings in touched files are fixed (`routes/documents.ts`).

## Residual / out of scope (named, as ruled)

* **Race:** two concurrent inserts of one value in the two namespaces both pass. Pkeys are server-random v4, so an attacker would need a key before it exists.
* **KS-1603's direct route is unchanged:** a bare `POST /api/anchors` naming another tenant's id still overwrites that row's unconditional columns, as on develop. The guard keeps the identity. Its structural answer is a tenant column on `anchor_store` (KS-1384).
* **Legacy collided rows are the census's job.** Cell XT-L shows that such a row *would* still let another tenant in, which is why 050 refuses to apply while one exists.
* Kam's (b) and the round-1 gate's INF-2 behaviour are untouched. INF-2 goes to Kam as a card.

## Test Evidence (local; head `767ab5758`; develop `833984fc9`; scratch Postgres 15, `secuura_app` NOBYPASSRLS, `documents` FORCE RLS, 050 applied)

**Touched:**

* `migrations/050_documents_id_namespaces_disjoint.sql` (new)
* `services/originate/src/utils/idNamespaceCollision.ts` (new)
* `services/originate/src/routes/documents.ts`
* `services/anchoring/src/anchorOverwriteGuard.ts`
* `services/anchoring/src/index.ts`
* new cells: `originate/__tests__/ks1612-create-maps-only-the-namespace-collision-to-409.test.ts` (6) and `ks1612-documents-id-namespaces-disjoint.integration.test.ts` (13); `anchoring/__tests__/ks1385-anchor-store-keeps-the-latest-events-metadata.integration.test.ts` (+10)

**Ran:**

| what | head | develop |
|---|---|---|
| **fresh DB:** `docker/init` + every migration via `scripts/run-migrations.sh` | **applied=52 failed=0**, `Applying 050_…` printed after 048/049; trigger present, SECURITY DEFINER, owner superuser | — |
| anchoring integration (all of it) | **56 / 56** | 30 / 30 |
| anchoring unit | 370 / 371 | 370 / 371 (the one red is BACKLOG's `threadTokenMint`, on both) |
| originate unit | **111 suites / 1382** | 110 / 1376 |
| verify matrix (ks1114 + ks1119 + ks1557) × MT false/true × superuser/app | red sets **byte-identical** in all 4 | develop's own 6 |
| ks1612 integration, MT=false and MT=true | **13 / 13** each | — |
| tsc: service + test-inclusive (scratch tsconfig, `exclude: []`) | 0 / 0 for both services | 0 / 0 |
| ESLint, the 8 touched files | **0 / 0** | — |

**Red-first, two dimensions** (each predicted before the run):

* **Database:** the new cells against a DB **without** 050 (dropped, then re-applied and verified).
  * anchoring red **P050 X6 XT1 XT2**, exactly as predicted.
  * originate red **P0 N1 N2 N3 N5 N6 U1 U2**, plus M1 and M2. Those two are the census working: with no trigger, N1/N3/N5/N6 really created 4 collisions, which M1 then counted (4) and M2 counted with its own planted row (5).
* **Code:** the new cells against round 1's code (`16e716103`), with 050 present.
  * route **R1 R5** red.
  * anchoring **Q5 Q6** red.

**Mutants: 15 of 15 killed. The control is 0 red. The DB was restored to the original 050 after each (function-definition hash checked).**

| mutant | killed by |
|---|---|
| MM1 forward check removed | N1 N2 N5 N6 X6 XT1 XT2 (+ M1 M2 via the collisions it lets through) |
| MM2 reverse check removed | N3 (+ M1 M2) |
| MM3 SECURITY INVOKER (blind under FORCE RLS) | **P0 N2** |
| MM4 legacy census removed | **M2** |
| MM5 RLS-bypass assert removed | **M3** |
| MM6 message carries an FK-retry word | N1 N6 |
| MM7 constraint name changed | N1 N2 N3 N5 N6 X6 XT1 XT2 |
| MM8 `REVOKE … FROM PUBLIC` removed | **U1** |
| RM1 route maps EVERY 23505 | **R2 R3** |
| RM2 route mapping removed | R1 R5 |
| RM3 route answers a different 409 body | R1 |
| QM1 / QM2 / QM3 / QM4 quiet-set mutants | Q5 / Q6 / Q8 / Q2+Q7 |

**Preflight (in-hook):** @@PREFLIGHT@@

**NOT run:**

* No Docker and no stack legs.
* No real chain.
* The census on kintsugi or demo: that is the deploy round's step, above. No box was touched.

**Migrations / config:** **050 (new) — a deploy-time step, census first.**

<details><summary>Round 1 body, as raised on 2026-10-18 — superseded wherever round 2 above says otherwise (its "never add one" framing, and its evidence counts)</summary>

