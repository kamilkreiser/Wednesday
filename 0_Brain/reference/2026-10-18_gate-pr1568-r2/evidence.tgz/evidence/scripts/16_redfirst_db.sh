#!/bin/bash
# usage: 16_redfirst_db.sh -> red-first, database dimension: database `no050` (docker/init + migrations 001-049, no 050), head's lanes against it
set -u
G=/private/tmp/claude-501/gate1568r2
DEV=$G/wt/head/Blockchain/Dev
B=/opt/homebrew/opt/postgresql@18/bin; PORT=55731
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/logs
S="$B/psql -h 127.0.0.1 -p $PORT -U secuura -d no050"
$B/psql -h 127.0.0.1 -p $PORT -U secuura -d postgres -qc "CREATE DATABASE no050 OWNER secuura"
for f in $DEV/docker/init/0*.sql; do case "$(basename $f)" in 00-create-platform-db.sql) continue;; esac; $S -q -f $f >/dev/null 2>&1; done
PATH=$B:$PATH DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:$PORT/no050" /bin/sh $G/run-migrations.mig049.sh > $EV/run_migrations_no050.log 2>&1; echo "built: $(grep Summary $EV/run_migrations_no050.log)"
$S -qc "GRANT CONNECT ON DATABASE no050 TO secuura_app; GRANT USAGE ON SCHEMA public TO secuura_app; GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO secuura_app;"
echo "trigger present: $($S -tAc "select count(*) from pg_trigger where tgname='documents_id_namespaces_disjoint'")"
/bin/bash /Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/scripts/13_lanes.sh $G/wt/head redfirst_no050 no050
