#!/bin/bash
# usage: 15_merge.sh -> re-read live develop + PR head (ls-remote), overlap, merge-tree, planted overlap + planted conflicting control (MY clone only)
set -u
G=/private/tmp/claude-501/gate1568r2
R=$G/repo
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/logs
H=767ab575818f75b68664ddad1a511478db63c09d
{ date -u +%FT%TZ; git -C $R ls-remote origin refs/pull/1568/head refs/heads/develop; } > $EV/receipts_lsremote_2.txt 2>&1
cat $EV/receipts_lsremote_2.txt
git -C $R fetch origin +refs/heads/develop:refs/gate/develop2 2>&1 | tail -1
D=$(git -C $R rev-parse refs/gate/develop2); echo "live develop = $D"
MB=$(git -C $R merge-base $H $D); echo "merge-base = $MB"
git -C $R log --oneline $MB..$D
git -C $R diff --name-only $MB $H | sort > $G/m_pr.txt
git -C $R diff --name-only $MB $D | sort > $G/m_dev.txt
echo "PR files: $(wc -l < $G/m_pr.txt | tr -d ' ') | develop files since base: $(wc -l < $G/m_dev.txt | tr -d ' ') | overlap: $(comm -12 $G/m_pr.txt $G/m_dev.txt | wc -l | tr -d ' ')"
comm -12 $G/m_pr.txt $G/m_dev.txt
echo "develop files since base:"; sed 's/^/   /' $G/m_dev.txt
{ cat $G/m_dev.txt; echo "Blockchain/Dev/services/anchoring/src/anchorOverwriteGuard.ts"; } | sort -u > $G/m_dev_planted.txt
echo "planted overlap control (guard added to develop's list): $(comm -12 $G/m_pr.txt $G/m_dev_planted.txt | wc -l | tr -d ' ')"
git -C $R merge-tree --write-tree $D $H > $G/mt.txt 2>&1; rc=$?
T=$(head -1 $G/mt.txt); echo "merge-tree(develop, head) rc=$rc tree=$T"
echo "files differing merged-tree vs develop:"; git -C $R diff --name-only $D $T | sed 's/^/   /'
echo "merged-tree vs head on the PR's files (expect empty):"; git -C $R diff --stat $H $T -- $(cat $G/m_pr.txt)
echo "develop's own files in the merged tree equal develop (expect empty):"; git -C $R diff --stat $D $T -- $(cat $G/m_dev.txt)
echo "migration numbering on develop (a second 050 would collide):"; git -C $R ls-tree --name-only $D Blockchain/Dev/migrations/ | grep -E '/05[0-9]_' || echo "   none >= 050 on develop"
[ -d $G/wt/planted ] || git -C $R worktree add --detach $G/wt/planted $D > /dev/null 2>&1
F=$G/wt/planted/Blockchain/Dev/services/anchoring/src/anchorOverwriteGuard.ts
python3 -I - "$F" <<'PY'
import sys
p=sys.argv[1]; s=open(p).read()
a="          AND (d.external_id = $1 OR d.id = $3::uuid)\n"
if s.count(a)==0:
    a="        WHERE d.id = $1::uuid\n"
assert s.count(a)==1, s.count(a)
open(p,'w').write(s.replace(a, a.rstrip('\n')+" -- planted conflicting develop edit\n"))
print("planted on:", a.strip())
PY
git -C $G/wt/planted -c user.email=gate@invalid -c user.name=gate commit -qam "planted conflicting control" && P=$(git -C $G/wt/planted rev-parse HEAD)
git -C $R merge-tree --write-tree $P $H > $G/mt_planted.txt 2>&1; echo "planted merge-tree rc=$?"; grep -i conflict $G/mt_planted.txt | head -3
