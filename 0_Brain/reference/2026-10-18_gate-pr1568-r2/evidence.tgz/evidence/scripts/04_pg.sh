#!/bin/bash
# usage: 04_pg.sh <port> <schema-worktree> <tag> -> own Postgres 18; docker/init (as compose's initdb would) then the
# PROJECT'S OWN scripts/run-migrations.sh (copied, its relative `migrations/*.sql` glob made absolute, nothing else changed)
set -u
G=/private/tmp/claude-501/gate1568r2
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/logs
PORT="$1"; W="$2"; TAG="$3"
B=/opt/homebrew/opt/postgresql@18/bin
D=$G/pgdata-$PORT
L=$EV/pg_setup_$TAG.log
if lsof -nP -iTCP:$PORT -sTCP:LISTEN >/dev/null 2>&1; then echo "PORT $PORT BUSY"; exit 2; fi
echo "port $PORT free (lsof) at $(date -u +%FT%TZ)" > $L
$B/initdb -D $D -U postgres --auth=trust >>$L 2>&1 || { echo initdb failed; exit 1; }
$B/pg_ctl -D $D -o "-p $PORT -k $G -c listen_addresses=127.0.0.1" -l $EV/pg_server_$TAG.log start >>$L 2>&1
sleep 3
P="$B/psql -h 127.0.0.1 -p $PORT -v ON_ERROR_STOP=0 -q"
$P -U postgres -d postgres -c "CREATE ROLE secuura SUPERUSER LOGIN PASSWORD 'secuura'" >>$L 2>&1
$P -U postgres -d postgres -c "CREATE DATABASE secuura OWNER secuura" >>$L 2>&1
$P -U postgres -d postgres -c "CREATE ROLE secuura_app LOGIN PASSWORD 'app' NOSUPERUSER NOBYPASSRLS" >>$L 2>&1
DEV=$W/Blockchain/Dev
for f in $DEV/docker/init/0*.sql; do
  case "$(basename $f)" in 00-create-platform-db.sql) continue;; esac
  echo "== $f" >>$L
  $P -U secuura -d secuura -f $f >>$L 2>&1
done
sed "s#for f in migrations/\*.sql; do#for f in $DEV/migrations/*.sql; do#" $DEV/scripts/run-migrations.sh > $G/run-migrations.$TAG.sh
echo "runner diff vs the project's:"; diff $DEV/scripts/run-migrations.sh $G/run-migrations.$TAG.sh
PATH=$B:$PATH DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:$PORT/secuura" /bin/sh $G/run-migrations.$TAG.sh > $EV/run_migrations_$TAG.log 2>&1
echo "run-migrations rc=$?"; grep -E "Summary|FAILED|050|Migration runner" $EV/run_migrations_$TAG.log
$P -U secuura -d secuura >>$L 2>&1 <<'EOSQL'
GRANT CONNECT ON DATABASE secuura TO secuura_app;
GRANT USAGE ON SCHEMA public TO secuura_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO secuura_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO secuura_app;
EOSQL
Q="$B/psql -h 127.0.0.1 -p $PORT -U secuura -d secuura -tA"
$Q -c "select relname, relrowsecurity, relforcerowsecurity from pg_class where relname in ('documents','users','anchor_store')"
$B/psql -h 127.0.0.1 -p $PORT -U postgres -d postgres -tAc "select rolname, rolsuper, rolbypassrls from pg_roles where rolname like 'secuura%'"
$Q -c "select tgname, tgenabled, pg_get_triggerdef(t.oid) from pg_trigger t where tgrelid='documents'::regclass and not tgisinternal"
$Q -c "select proname, prosecdef, pg_get_userbyid(proowner), proacl, proconfig from pg_proc where proname='documents_id_namespaces_disjoint'"
$Q -c "select count(*) from _secuura_migrations"
