#!/bin/bash
# usage: 09_anchoring_matrix.sh <worktree> <tag> -> boot anchoring alone (secuura_app, mock chain, RS256) and run round 1's matrix (gate_matrix_r2.ts)
set -u
G=/private/tmp/claude-501/gate1568r2
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/logs
C=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/cells
W="$1"; TAG="$2"; PORT=55733
if lsof -nP -iTCP:$PORT -sTCP:LISTEN >/dev/null 2>&1; then echo "PORT $PORT BUSY"; exit 2; fi
export PORT DATABASE_URL="postgresql://secuura_app:app@127.0.0.1:55731/secuura" JWT_PUBLIC_KEY="$(base64 < $G/keys/gate.pub | tr -d '\n')" NODE_ENV=development PII_ENCRYPTION_KEY="$(openssl rand -hex 32)"
unset BLOCKFROST_API_KEY PLATFORM_WALLET_MNEMONIC JWT_JWKS_URL AUTH_SERVICE_URL
D=$W/Blockchain/Dev
echo "tree $(git -C $W rev-parse --short HEAD) dirty=$(git -C $W status --porcelain --untracked-files=no | wc -l | tr -d ' ')"
$D/node_modules/.bin/tsx $D/services/anchoring/src/index.ts > $EV/anchoring_matrix_boot_$TAG.log 2>&1 &
SVC=$!
for i in $(seq 1 90); do curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$PORT/health 2>/dev/null | grep -q 200 && break; sleep 1; done
$D/node_modules/.bin/tsx $C/gate_matrix_r2.ts http://127.0.0.1:$PORT $G/keys/gate.pem $G/keys/forger.pem "postgresql://secuura:secuura@127.0.0.1:55731/secuura" "postgresql://secuura_app:app@127.0.0.1:55731/secuura" $W > $EV/gate_matrix_r2_$TAG.log 2>&1
echo "matrix rc=$?"
sleep 3; kill $SVC; wait $SVC 2>/dev/null
echo "kept-payload lines by reason:"; grep "kept the stored anchor metadata" $EV/anchoring_matrix_boot_$TAG.log | python3 -I -c "
import sys,json,collections
c=collections.Counter()
for l in sys.stdin:
    try: d=json.loads(l); c[(d.get('reason'), str(d.get('documentId'))[:24])]+=1
    except Exception: c[('RAW',l[:60])]+=1
for k,v in sorted(c.items()): print('   ',v,k)"
