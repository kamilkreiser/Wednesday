#!/bin/bash
# usage: 05b_prisma_rig_links.sh -> symlink every OTHER installed package into the rig (read-only use), keep @prisma/* + prisma as
# real copies so `prisma generate` writes .prisma/client inside the rig and never into the project
set -u
RIG=/private/tmp/claude-501/gate1568r2/prisma_rig
PD="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files/Blockchain/Dev"
for base in "$PD/services/originate/node_modules" "$PD/node_modules"; do
  for e in "$base/"* "$base/".bin; do
    n=$(basename "$e"); case "$n" in @prisma|prisma|.prisma) continue;; esac
    [ -e "$RIG/node_modules/$n" ] || ln -s "$e" "$RIG/node_modules/$n"
  done
done
PRISMA_HIDE_UPDATE_MESSAGE=1 CHECKPOINT_DISABLE=1 node $RIG/node_modules/prisma/build/index.js generate --schema $RIG/prisma/schema.prisma 2>&1 | tail -8
ls -la $RIG/node_modules/.prisma/client 2>&1 | head -5
echo "project untouched? $(ls -d "$PD/node_modules/.prisma" "$PD/services/originate/node_modules/.prisma" 2>&1 | tr '\n' ' ')"
