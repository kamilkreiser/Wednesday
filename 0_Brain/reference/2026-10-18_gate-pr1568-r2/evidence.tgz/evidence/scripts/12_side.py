# usage: python3 -I 12_side.py headlog devlog -> side-by-side of round 1's matrix cells
import json, sys
def load(p):
    d = {}
    for l in open(p):
        try: r = json.loads(l)
        except Exception: continue
        c = r.get('cell')
        if c: d[c] = r
    return d
h, v = load(sys.argv[1]), load(sys.argv[2])
def fmt(r):
    if r is None: return '-'
    if 'replaced' in r:
        dec = r.get('decision'); dec = dec.get('reason') if isinstance(dec, dict) else dec
        return f"{'REPLACED' if r['replaced'] else 'kept'} s2={r.get('secondStatus')} ({dec}) {r.get('result','')}"
    if 'refused' in r: return f"refused={r['refused']}"
    if 'decision' in r: d = r['decision']; return f"allow={d.get('allow')} {d.get('reason')}"
    if 'stored' in r: return f"stored actor={r['stored'].get('actor')} decision={r.get('decision',{}).get('reason')}"
    return json.dumps({k: r[k] for k in r if k != 'cell'})[:160]
for c in list(dict.fromkeys(list(h) + list(v))):
    print(f"{c[:78]:<78} | HEAD {fmt(h.get(c)):<70} | DEV {fmt(v.get(c))}")
