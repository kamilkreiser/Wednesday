#!/bin/bash
# usage: 07_boot.sh <anchoring-worktree> <originate-worktree> <tag> <cell.ts> [MT]
#   boots redis (own port), anchoring (tsx, secuura_app, mock chain) and originate (tsx, secuura_app, MULTI_TENANCY_ENABLED
#   unset = compose's default = the real PrismaClient path, unless MT=true), runs the cell, stops all three.
set -u
G=/private/tmp/claude-501/gate1568r2
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/logs
C=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/cells
WA="$1"; WO="$2"; TAG="$3"; CELL="$4"; MT="${5:-}"
PGPORT=55731; RPORT=55732; APORT=55733; OPORT=55734
for p in $RPORT $APORT $OPORT; do if lsof -nP -iTCP:$p -sTCP:LISTEN >/dev/null 2>&1; then echo "PORT $p BUSY"; exit 2; fi; done
redis-server --port $RPORT --bind 127.0.0.1 --save '' --appendonly no --dir $G > $EV/redis_$TAG.log 2>&1 &
RS=$!
export JWT_PUBLIC_KEY="$(base64 < $G/keys/gate.pub | tr -d '\n')"
export NODE_ENV=development
export PII_ENCRYPTION_KEY="$(openssl rand -hex 32)"
export PII_LOOKUP_HMAC_KEY="$(openssl rand -hex 32)"
unset BLOCKFROST_API_KEY PLATFORM_WALLET_MNEMONIC JWT_JWKS_URL AUTH_SERVICE_URL
# the gateway's vouch (originate gatewayProvenance.ts): without it x-tenant-id is stripped and every create lands in the DEFAULT tenant
export GATEWAY_VOUCH_SECRET="gate-vouch-$(openssl rand -hex 12)"
export GATE_VOUCH="$GATEWAY_VOUCH_SECRET"
if [ "$MT" = "true" ]; then
  export MULTI_TENANCY_ENABLED=true
  export TENANT_A=$(uuidgen | tr A-Z a-z) TENANT_B=$(uuidgen | tr A-Z a-z)
  BIN=/opt/homebrew/opt/postgresql@18/bin
  $BIN/psql -h 127.0.0.1 -p $PGPORT -U secuura -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='secuura_platform'" | grep -q 1 || $BIN/psql -h 127.0.0.1 -p $PGPORT -U secuura -d postgres -qc "CREATE DATABASE secuura_platform OWNER secuura"
  # the two columns sets refreshConfigs() reads (tenant-pool-manager.ts:300-305); no tenant_config row = the tenant shares the default DB
  $BIN/psql -h 127.0.0.1 -p $PGPORT -U secuura -d secuura_platform -q -c "CREATE TABLE IF NOT EXISTS tenants (id uuid PRIMARY KEY, slug text, status text); CREATE TABLE IF NOT EXISTS tenant_config (tenant_id uuid, db_name text, db_host text, db_port int); INSERT INTO tenants VALUES ('$TENANT_A','gate-a','active'),('$TENANT_B','gate-b','active')"
  export PLATFORM_DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:$PGPORT/secuura_platform"
else
  unset MULTI_TENANCY_ENABLED PLATFORM_DATABASE_URL
  export TENANT_A=a0000000-0000-4000-8000-000000000001 TENANT_B=a0000000-0000-4000-8000-000000000001
fi
echo "TENANT_A=$TENANT_A TENANT_B=$TENANT_B"
export DATABASE_URL="postgresql://secuura_app:app@127.0.0.1:$PGPORT/secuura"
export REDIS_URL="redis://127.0.0.1:$RPORT"
echo "anchoring tree $(git -C $WA rev-parse --short HEAD) dirty=$(git -C $WA status --porcelain --untracked-files=no | wc -l | tr -d ' ') | originate tree $(git -C $WO rev-parse --short HEAD) dirty=$(git -C $WO status --porcelain --untracked-files=no | wc -l | tr -d ' ') | MT=${MULTI_TENANCY_ENABLED:-unset}"
PORT=$APORT $WA/Blockchain/Dev/node_modules/.bin/tsx $WA/Blockchain/Dev/services/anchoring/src/index.ts > $EV/anchoring_boot_$TAG.log 2>&1 &
AS=$!
PORT=$OPORT ANCHORING_SERVICE_URL=http://127.0.0.1:$APORT $WO/Blockchain/Dev/node_modules/.bin/tsx $WO/Blockchain/Dev/services/originate/src/index.ts > $EV/originate_boot_$TAG.log 2>&1 &
OS=$!
for i in $(seq 1 120); do
  a=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$APORT/health 2>/dev/null); o=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$OPORT/health 2>/dev/null)
  [ "$a" = 200 ] && [ "$o" = 200 ] && break
  sleep 1
done
echo "health anchoring=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$APORT/health) originate=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$OPORT/health)"
$WA/Blockchain/Dev/node_modules/.bin/tsx $C/$CELL http://127.0.0.1:$APORT http://127.0.0.1:$OPORT $G/keys/gate.pem \
  "postgresql://secuura:secuura@127.0.0.1:$PGPORT/secuura" "postgresql://secuura_app:app@127.0.0.1:$PGPORT/secuura" $WA $WO > $EV/cell_${CELL%.ts}_$TAG.log 2>&1
echo "cell rc=$?"
sleep 2
kill $OS $AS $RS 2>/dev/null; wait $OS $AS $RS 2>/dev/null
echo "kept-payload warnings: $(grep -c 'kept the stored anchor metadata' $EV/anchoring_boot_$TAG.log)"
