#!/bin/bash
# usage: 01_clone.sh  -> clone --shared, fetch PR head + develop, receipts
set -u
G=/private/tmp/claude-501/gate1568r2
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/logs
SRC="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files"
SSHC="$(git -C "$SRC" config --get core.sshCommand) -o ServerAliveInterval=30"
mkdir -p $G
if [ ! -d $G/repo ]; then
  git clone --shared --no-checkout "$SRC" $G/repo 2>&1 | tail -2
  git -C $G/repo remote set-url origin git@github.com:Secuura/Distributed_Secuura.git
fi
git -C $G/repo config core.sshCommand "$SSHC"
{ date -u +%FT%TZ; git -C $G/repo ls-remote origin refs/pull/1568/head refs/heads/develop; } > $EV/receipts_lsremote_1.txt 2>&1
cat $EV/receipts_lsremote_1.txt
git -C $G/repo fetch origin +refs/pull/1568/head:refs/gate/head +refs/heads/develop:refs/gate/develop 2>&1 | tail -3
git -C $G/repo rev-parse refs/gate/head refs/gate/develop
for c in 767ab575818f75b68664ddad1a511478db63c09d 833984fc9 26378a40378dc53787f69a96609a90cad499d50b 16e71610366b27276469e2215010416991b56ad5 d2ec786e6; do echo "$c $(git -C $G/repo cat-file -t $c 2>&1)"; done
echo "merge-base(head,develop): $(git -C $G/repo merge-base refs/gate/head refs/gate/develop)"
echo "is 833984fc9 ancestor of head: $(git -C $G/repo merge-base --is-ancestor 833984fc9 refs/gate/head && echo yes || echo no)"
git -C $G/repo log --oneline --graph d2ec786e6..refs/gate/head | head -30
echo ---- develop since 833984fc9
git -C $G/repo log --oneline 833984fc9..refs/gate/develop | head -30
