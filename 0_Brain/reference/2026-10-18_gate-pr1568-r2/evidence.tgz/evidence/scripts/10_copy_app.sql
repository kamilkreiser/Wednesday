\set ON_ERROR_STOP 0
\set VERBOSITY verbose
BEGIN;
SELECT set_config('app.current_tenant_id', '44444444-4444-4444-8444-444444444444', true);
COPY documents (id, external_id, title, document_type, content_hash, tenant_id) FROM STDIN;
55555555-5555-4555-8555-555555555555	doc-1-copyapp	copy app	DOC	ffff	44444444-4444-4444-8444-444444444444
\.
ROLLBACK;
