"""Gate #1568 r2 mutants: the AUTHOR's 16 (C0, MM1-8, RM1-3, QM1-4; anchors copied verbatim from
j12/tools/mut1612r2.py) plus MINE (G-T1, G-T2 on the trigger; G-R1, G-R2 on the 409 mapping; G-C0 comment-only control in the route).
Each: exact-count replace in worktree `mut`, migration mutants also re-installed in database `mig` (DROP trigger+function, apply
the mutated file), the named suites run, RED cell ids recorded, then the file restored (sha asserted) and the original 050 re-installed
(function-definition + trigger count + ACL hash asserted equal to the pre-run hash).
usage: python3 -I 14_mutants.py <Dev dir of worktree mut> <outdir>"""
import hashlib, json, os, re, subprocess, sys
DEV = sys.argv[1]; OUT = sys.argv[2]; os.makedirs(OUT, exist_ok=True)
PSQL = "/opt/homebrew/opt/postgresql@18/bin/psql"; SU = "postgresql://secuura:secuura@127.0.0.1:55731/mig"
APP = "postgresql://secuura_app:app@127.0.0.1:55731/mig"
MIG = os.path.join(DEV, "migrations/050_documents_id_namespaces_disjoint.sql")
HELP = os.path.join(DEV, "services/originate/src/utils/idNamespaceCollision.ts")
ROUTE = os.path.join(DEV, "services/originate/src/routes/documents.ts")
GUARD = os.path.join(DEV, "services/anchoring/src/anchorOverwriteGuard.ts")
ENV = dict(os.environ, TEST_DATABASE_URL=SU, TEST_APP_DATABASE_URL=APP, DATABASE_URL=SU)
def sh(args): return subprocess.run(args, capture_output=True, text=True, env=ENV, timeout=900)
def fndef(): return hashlib.sha256(sh([PSQL, SU, "-Atc", "SELECT coalesce(pg_get_functiondef('documents_id_namespaces_disjoint'::regproc),'') || (SELECT count(*)::text FROM pg_trigger WHERE tgname='documents_id_namespaces_disjoint') || coalesce((SELECT string_agg(pg_get_triggerdef(oid),'') FROM pg_trigger WHERE tgname='documents_id_namespaces_disjoint'),'') || coalesce((SELECT proacl::text FROM pg_proc WHERE proname='documents_id_namespaces_disjoint'),'')"]).stdout.encode()).hexdigest()[:16]
def install(path):
    sh([PSQL, SU, "-q", "-c", "DROP TRIGGER IF EXISTS documents_id_namespaces_disjoint ON documents; DROP FUNCTION IF EXISTS documents_id_namespaces_disjoint();"])
    return sh([PSQL, SU, "-v", "ON_ERROR_STOP=1", "-q", "-f", path]).returncode
ORIG = {p: open(p).read() for p in (MIG, HELP, ROUTE, GUARD)}; SHA = {p: hashlib.sha256(v.encode()).hexdigest() for p, v in ORIG.items()}
DB0 = fndef()
BIN = os.path.join(DEV, "node_modules/.bin"); O = os.path.join(DEV, "services/originate"); A = os.path.join(DEV, "services/anchoring")
S_OI = ("originate-int", [f"{BIN}/jest", "--rootDir", O, "--config", f"{O}/jest.integration.config.js", "--runTestsByPath", f"{O}/src/__tests__/ks1612-documents-id-namespaces-disjoint.integration.test.ts"])
S_OU = ("originate-unit", [f"{BIN}/jest", "--rootDir", O, "--config", f"{O}/jest.config.js", "--runTestsByPath", f"{O}/src/__tests__/ks1612-create-maps-only-the-namespace-collision-to-409.test.ts"])
S_AI = ("anchoring-int", [f"{BIN}/vitest", "run", "--root", A, "--reporter=verbose", "--config", f"{A}/vitest.integration.config.ts", f"{A}/src/__tests__/ks1385-anchor-store-keeps-the-latest-events-metadata.integration.test.ts"])
F_MSG = "RAISE EXCEPTION 'document id namespace collision' USING ERRCODE = '23505', CONSTRAINT = 'documents_id_namespaces_disjoint';"
MUT = [
 ("C0 author: comment-only control (migration, re-installed)", MIG, [("REVOKE ALL ON FUNCTION", "-- mutant control\nREVOKE ALL ON FUNCTION")], True, [S_OI, S_AI], "0 red"),
 ("MM1 author: forward check removed", MIG, [("    IF EXISTS (SELECT 1 FROM public.documents d WHERE d.id = NEW.external_id::uuid AND d.id <> NEW.id) THEN", "    IF FALSE AND EXISTS (SELECT 1 FROM public.documents d WHERE d.id = NEW.external_id::uuid AND d.id <> NEW.id) THEN")], True, [S_OI, S_AI], "N1 N2 N5 N6 + XT1 XT2 X6"),
 ("MM2 author: reverse check removed", MIG, [("  IF EXISTS (SELECT 1 FROM public.documents d WHERE d.external_id = NEW.id::text AND d.id <> NEW.id) THEN", "  IF FALSE AND EXISTS (SELECT 1 FROM public.documents d WHERE d.external_id = NEW.id::text AND d.id <> NEW.id) THEN")], True, [S_OI], "N3"),
 ("MM3 author: SECURITY INVOKER", MIG, [("LANGUAGE plpgsql SECURITY DEFINER SET search_path", "LANGUAGE plpgsql SECURITY INVOKER SET search_path")], True, [S_OI], "P0 N2"),
 ("MM4 author: legacy census removed", MIG, [("  IF collisions > 0 THEN", "  IF collisions > 0 AND FALSE THEN")], True, [S_OI], "M2"),
 ("MM5 author: RLS-bypass assert removed", MIG, [("  IF NOT coalesce(can_see_every_tenant, false) THEN", "  IF FALSE AND NOT coalesce(can_see_every_tenant, false) THEN")], True, [S_OI], "M3"),
 ("MM6 author: message carries an FK-retry word", MIG, [(F_MSG, F_MSG.replace("'document id namespace collision'", "'document id namespace collision violates the namespace rule'"), 2)], True, [S_OI], "N1 N6"),
 ("MM7 author: constraint name changed", MIG, [(F_MSG, F_MSG.replace("CONSTRAINT = 'documents_id_namespaces_disjoint'", "CONSTRAINT = 'documents_ids_disjoint'"), 2)], True, [S_OI, S_AI], "N1 N2 N5 N6 + X6 XT1 XT2"),
 ("MM8 author: REVOKE FROM PUBLIC removed", MIG, [("REVOKE ALL ON FUNCTION documents_id_namespaces_disjoint() FROM PUBLIC;", "-- (revoke removed)")], True, [S_OI], "U1"),
 ("RM1 author: route maps EVERY 23505", HELP, [("  return e.code === '23505' && e.constraint === ID_NAMESPACE_CONSTRAINT;", "  return e.code === '23505' || e.constraint === ID_NAMESPACE_CONSTRAINT;")], False, [S_OU], "R2 R3"),
 ("RM2 author: route mapping removed", ROUTE, [("        if (isIdNamespaceCollision(saveErr)) return res.status(409).json(DOCUMENT_UUID_CONFLICT_BODY);", "        if (isIdNamespaceCollision(saveErr) && false) return res.status(409).json(DOCUMENT_UUID_CONFLICT_BODY);")], False, [S_OU], "R1 R5"),
 ("RM3 author: a DIFFERENT 409 body", ROUTE, [("        if (isIdNamespaceCollision(saveErr)) return res.status(409).json(DOCUMENT_UUID_CONFLICT_BODY);", "        if (isIdNamespaceCollision(saveErr)) return res.status(409).json({ success: false, error: { code: 'CONFLICT', message: 'documentUuid belongs to another document' } });")], False, [S_OU], "R1"),
 ("QM1 author: quiet set drops caller-has-no-organisation", GUARD, [("  'caller-has-no-organisation',\n", "")], False, [S_AI], "Q5"),
 ("QM2 author: quiet set drops caller-organisation-not-a-uuid", GUARD, [("  'caller-organisation-not-a-uuid',\n", "")], False, [S_AI], "Q6"),
 ("QM3 author: quiet set admits caller-has-no-tenant", GUARD, [("  'document-not-in-callers-tenant',\n", "  'document-not-in-callers-tenant',\n  'caller-has-no-tenant' as OverwriteRefusal,\n")], False, [S_AI], "Q8"),
 ("QM4 author: quiet set ignores the id's shape", GUARD, [("DEVELOP_QUIET_REASONS.has(decision.reason) && !isUuidShaped(documentId);", "DEVELOP_QUIET_REASONS.has(decision.reason) && documentId.length > 0;")], False, [S_AI], "Q7 Q2"),
 # ---- mine
 ("G-T1 mine: trigger's shape test case-SENSITIVE (~ not ~*): an UPPER-case pkey external_id passes", MIG, [("  IF NEW.external_id ~* '^[0-9a-f]{8}", "  IF NEW.external_id ~ '^[0-9a-f]{8}")], True, [S_OI, S_AI], "predicted SURVIVES (no cell sends an upper-case id)"),
 ("G-T2 mine: trigger fires on INSERT only (UPDATE OF id, external_id dropped)", MIG, [("  BEFORE INSERT OR UPDATE OF id, external_id ON documents", "  BEFORE INSERT ON documents")], True, [S_OI, S_AI], "N5"),
 ("G-R1 mine: any NAMED 23505 maps to the 409", HELP, [("  return e.code === '23505' && e.constraint === ID_NAMESPACE_CONSTRAINT;", "  return e.code === '23505' && typeof e.constraint === 'string';")], False, [S_OU], "R2"),
 ("G-R2 mine: any save error on a documentUuid create maps to the 409", ROUTE, [("        if (isIdNamespaceCollision(saveErr)) return res.status(409).json(DOCUMENT_UUID_CONFLICT_BODY);", "        if (isIdNamespaceCollision(saveErr) || documentUuid) return res.status(409).json(DOCUMENT_UUID_CONFLICT_BODY);")], False, [S_OU], "R2 R3 R4"),
 ("G-C0 mine: comment-only control in the route", ROUTE, [("      } catch (saveErr) {\n", "      } catch (saveErr) { // gate comment-only control\n")], False, [S_OU], "0 red"),
]
res = []
for name, f, edits, dbmut, suites, want in MUT:
    s = ORIG[f]; ok = True
    for e in edits:
        a, b, n = (e + (1,))[:3]
        c = s.count(a)
        if c != n: res.append({"mutant": name, "verdict": f"NOT SCORED (anchor count {c}, want {n})", "want": want}); ok = False; break
        s = s.replace(a, b)
    if ok:
        open(f, "w").write(s); inst = install(MIG) if dbmut else None
        reds, tallies = set(), []
        for svc, cmd in suites:
            p = sh(cmd); log = p.stdout + p.stderr
            open(os.path.join(OUT, re.sub(r"[^A-Za-z0-9]+", "_", name)[:40] + "_" + svc + ".log"), "w").write(log)
            t = (re.findall(r"^Tests:.*$", log, re.M) or re.findall(r"Tests\s+.*\(\d+\)", log) or ["NO TALLY"])[-1]; tallies.append(t.strip())
            ID = r"((?:[A-Z]{1,2}-?[0-9]+[a-zL]?)|C-[a-z]|XT-L|P050)\b"
            reds |= set(re.findall(r"^\s+× .*> " + ID, log, re.M)) | set(re.findall(r"^\s+✕ " + ID, log, re.M)) | set(re.findall(r"^\s+× " + ID, log, re.M))
        res.append({"mutant": name, "installed_rc": inst, "tallies": tallies, "red": sorted(reds), "want": want,
                    "verdict": "LOADFAIL" if any(("NO TALLY" in t) or re.search(r"\b0 total\b", t) for t in tallies) else ("KILLED" if reds or any('failed' in t for t in tallies) else "SURVIVED")})
    for p, v in ORIG.items(): open(p, "w").write(v)
    if dbmut: install(MIG)
    for p in ORIG: assert hashlib.sha256(open(p).read().encode()).hexdigest() == SHA[p], "FILE RESTORE FAILED " + p
    assert fndef() == DB0, "DB RESTORE FAILED"
    r = res[-1]; print(f"{r['mutant'][:70]:70s} | {r['verdict']:9s} | {' / '.join(r.get('tallies', []))[:80]} | red={' '.join(r.get('red', []))[:70]} | want: {r['want']}", flush=True)
json.dump(res, open(os.path.join(OUT, "mutants.json"), "w"), indent=1)
print("files restored by sha; installed 050 restored, function-def hash", DB0)
