#!/bin/bash
# usage: 03_worktree.sh <name> <commit>  -> worktree G/wt/<name>, node_modules symlinked to the project's install (read-only use), shared dist built
set -u
G=/private/tmp/claude-501/gate1568r2
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/logs
R=$G/repo
N="$1"; C="$2"
W=$G/wt/$N
mkdir -p $G/wt
[ -d $W ] || git -C $R worktree add --detach $W $C 2>&1 | tail -1
PD="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files/Blockchain/Dev"
WD="$W/Blockchain/Dev"
mkdir -p "$WD/node_modules/@secuura"
for e in "$PD/node_modules/"* "$PD/node_modules/".bin; do
  n=$(basename "$e"); [ "$n" = "@secuura" ] && continue
  [ -e "$WD/node_modules/$n" ] || ln -s "$e" "$WD/node_modules/$n"
done
for e in "$PD/node_modules/@secuura/"*; do
  n=$(basename "$e"); t=$(readlink "$e")
  [ -e "$WD/node_modules/@secuura/$n" ] || ln -s "$t" "$WD/node_modules/@secuura/$n"
done
for s in services/originate services/anchoring packages/shared; do
  [ -e "$WD/$s/node_modules" ] || { [ -e "$PD/$s/node_modules" ] && ln -s "$PD/$s/node_modules" "$WD/$s/node_modules"; }
done
"$WD/node_modules/.bin/tsc" -p "$WD/packages/shared/tsconfig.json" > $EV/build_shared_$N.log 2>&1
echo "shared build rc=$? ($EV/build_shared_$N.log)"
ls $WD/packages/shared/dist | head -3
echo "status (tracked): $(git -C $W status --porcelain --untracked-files=no | wc -l | tr -d ' ')"
echo "HEAD=$(git -C $W rev-parse HEAD)"
