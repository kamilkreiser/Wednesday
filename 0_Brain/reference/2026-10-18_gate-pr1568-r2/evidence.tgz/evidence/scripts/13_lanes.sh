#!/bin/bash
# usage: 13_lanes.sh <worktree> <tag> [db] -> originate: the two ks1612 files (jest, integration + unit config); anchoring: the whole
# integration lane (vitest). Postgres 55731, database <db> (default mig: built by 11_migration.sh, census 0).
set -u
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/logs
W="$1"; TAG="$2"; DB="${3:-mig}"
D=$W/Blockchain/Dev
export TEST_DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:55731/$DB" TEST_APP_DATABASE_URL="postgresql://secuura_app:app@127.0.0.1:55731/$DB"
export DATABASE_URL="$TEST_DATABASE_URL"
J=$D/node_modules/.bin/jest
$J --rootDir $D/services/originate --config $D/services/originate/jest.integration.config.js --runTestsByPath $D/services/originate/src/__tests__/ks1612-documents-id-namespaces-disjoint.integration.test.ts --json --outputFile=$EV/lane_o_int_$TAG.json > $EV/lane_o_int_$TAG.log 2>&1; echo "originate ks1612 integration rc=$?"
$J --rootDir $D/services/originate --config $D/services/originate/jest.config.js --runTestsByPath $D/services/originate/src/__tests__/ks1612-create-maps-only-the-namespace-collision-to-409.test.ts --json --outputFile=$EV/lane_o_unit_$TAG.json > $EV/lane_o_unit_$TAG.log 2>&1; echo "originate ks1612 409 unit rc=$?"
VT=$D/node_modules/.bin/vitest; A=$D/services/anchoring
$VT run --root $A --config $A/vitest.integration.config.ts --reporter=json --outputFile=$EV/lane_a_int_$TAG.json > $EV/lane_a_int_$TAG.log 2>&1; echo "anchoring integration rc=$?"
python3 -I - $EV/lane_o_int_$TAG.json $EV/lane_o_unit_$TAG.json $EV/lane_a_int_$TAG.json <<'PY'
import json,sys,re
for p in sys.argv[1:]:
    try: d=json.load(open(p))
    except Exception as e: print(p.split('/')[-1], 'NO JSON', e); continue
    red=[]
    for f in d['testResults']:
        for a in f['assertionResults']:
            if a['status']!='passed': red.append((a.get('title') or a['fullName'])[:12])
        if not f['assertionResults'] and f.get('status')=='failed': red.append('SUITE:'+f.get('message','')[:200])
    print(p.split('/')[-1], 'tests', d['numTotalTests'], 'passed', d['numPassedTests'], 'failed', d['numFailedTests'], 'red', red)
PY
