#!/bin/bash
# usage: 06_headp.sh <name> <commit> -> a worktree whose services/originate/node_modules is a REAL dir: every entry symlinked to the
# project's install, except @prisma and .prisma, which point at the isolated rig (generated client). Then the usual 03 setup.
set -u
G=/private/tmp/claude-501/gate1568r2
N="$1"; C="$2"
W=$G/wt/$N
PD="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files/Blockchain/Dev"
[ -d $W ] || git -C $G/repo worktree add --detach $W $C 2>&1 | tail -1
O=$W/Blockchain/Dev/services/originate/node_modules
mkdir -p $O
for e in "$PD/services/originate/node_modules/"* "$PD/services/originate/node_modules/".bin; do
  n=$(basename "$e"); case "$n" in @prisma|.prisma) continue;; esac
  [ -e "$O/$n" ] || ln -s "$e" "$O/$n"
done
[ -e "$O/@prisma" ] || ln -s $G/prisma_rig/node_modules/@prisma "$O/@prisma"
[ -e "$O/.prisma" ] || ln -s $G/prisma_rig/node_modules/.prisma "$O/.prisma"
/bin/bash /Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/scripts/03_worktree.sh $N $C
ls -la $O/@prisma $O/.prisma | head -3
