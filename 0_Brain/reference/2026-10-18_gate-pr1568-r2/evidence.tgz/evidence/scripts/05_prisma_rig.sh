#!/bin/bash
# usage: 05_prisma_rig.sh -> an ISOLATED copy of originate's installed Prisma 7.8 (client + CLI + adapter) under my scratch,
# generate the client there from head's schema, so the MULTI_TENANCY_ENABLED=false path (db.ts: real PrismaClient + PrismaPg) can run.
set -u
G=/private/tmp/claude-501/gate1568r2
RIG=$G/prisma_rig
PD="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files/Blockchain/Dev"
mkdir -p $RIG/node_modules/@prisma $RIG/prisma
for p in "$PD/services/originate/node_modules/@prisma/"* "$PD/node_modules/@prisma/"*; do
  n=$(basename "$p"); [ -e "$RIG/node_modules/@prisma/$n" ] || cp -RL "$p" "$RIG/node_modules/@prisma/$n"
done
for p in prisma pg pg-pool pg-protocol pg-types pg-connection-string pgpass pg-int8 postgres-array postgres-bytea postgres-date postgres-interval split2 xtend obuf; do
  for base in "$PD/services/originate/node_modules" "$PD/node_modules"; do
    if [ -e "$base/$p" ] && [ ! -e "$RIG/node_modules/$p" ]; then cp -RL "$base/$p" "$RIG/node_modules/$p"; fi
  done
done
ls $RIG/node_modules $RIG/node_modules/@prisma
cp /private/tmp/claude-501/gate1568r2/wt/head/Blockchain/Dev/prisma/schema.prisma $RIG/prisma/schema.prisma
echo '{"name":"rig","version":"0.0.0","private":true}' > $RIG/package.json
CLI=$(node -e "const p=require('$RIG/node_modules/prisma/package.json');const b=typeof p.bin==='string'?p.bin:p.bin.prisma;console.log(require('path').join('$RIG/node_modules/prisma',b))")
echo "cli=$CLI"
PRISMA_HIDE_UPDATE_MESSAGE=1 CHECKPOINT_DISABLE=1 node "$CLI" generate --schema $RIG/prisma/schema.prisma 2>&1 | tail -8
ls -d $RIG/node_modules/.prisma/client 2>&1
