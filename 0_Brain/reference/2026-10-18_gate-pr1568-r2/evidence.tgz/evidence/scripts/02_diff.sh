#!/bin/bash
set -u
R=/private/tmp/claude-501/gate1568r2/repo
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/logs
H=767ab575818f75b68664ddad1a511478db63c09d
git -C $R diff --stat 833984fc9 $H > $EV/diff_stat_vs_833984.txt
git -C $R diff 833984fc9 $H > $EV/pr.patch
git -C $R diff 16e716103 938500c80 > $EV/r2_commit.patch
git -C $R show 767ab5758 > $EV/show_767ab5758.patch
git -C $R show --stat 938500c80 > $EV/show_938500c80_stat.txt
git -C $R diff 16e716103 6c30a6df4 --stat -- . ':!Blockchain/Dev/services/originate/src/routes/verify*' | tail -3
cat $EV/diff_stat_vs_833984.txt
cat $EV/show_938500c80_stat.txt
git -C $R diff --stat 6c30a6df4 $H
