# usage: python3 -I 08_summ.py <cell log> -> compact per-cell view
import json, sys
for l in open(sys.argv[1]):
    try: d = json.loads(l)
    except Exception: print("RAW", l[:300].rstrip()); continue
    c = d.get('cell')
    if not c: print(d); continue
    print("==", c)
    for k, v in d.items():
        if k != 'cell': print("   ", k, ":", json.dumps(v)[:600])
