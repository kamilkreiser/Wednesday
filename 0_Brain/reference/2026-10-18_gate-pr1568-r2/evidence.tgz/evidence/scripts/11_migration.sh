#!/bin/bash
# usage: 11_migration.sh -> migration 050 on its own database `mig` (same server, port 55731): built WITHOUT 050, planted legacy
# collisions, refusal + census, non-bypass role refusal, resolve by UPDATE (nothing deleted), apply, re-apply, runner re-run, gateway-style run
set -u
G=/private/tmp/claude-501/gate1568r2
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-pr1568-r2/evidence/logs
W=$G/wt/head; DEV=$W/Blockchain/Dev
B=/opt/homebrew/opt/postgresql@18/bin
PORT=55731
S="$B/psql -h 127.0.0.1 -p $PORT -U secuura -d mig"
A="env PGPASSWORD=app $B/psql -h 127.0.0.1 -p $PORT -U secuura_app -d mig"
M050=$DEV/migrations/050_documents_id_namespaces_disjoint.sql
$B/psql -h 127.0.0.1 -p $PORT -U secuura -d postgres -qc "CREATE DATABASE mig OWNER secuura"
for f in $DEV/docker/init/0*.sql; do case "$(basename $f)" in 00-create-platform-db.sql) continue;; esac; $S -q -f $f >/dev/null 2>&1; done
mkdir -p $G/mig049
for f in $DEV/migrations/*.sql; do case "$(basename $f)" in 050_*) continue;; esac; [ -e $G/mig049/$(basename $f) ] || ln -s $f $G/mig049/$(basename $f); done
sed "s#for f in migrations/\*.sql; do#for f in $G/mig049/*.sql; do#" $DEV/scripts/run-migrations.sh > $G/run-migrations.mig049.sh
PATH=$B:$PATH DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:$PORT/mig" /bin/sh $G/run-migrations.mig049.sh > $EV/run_migrations_mig049.log 2>&1
echo "build without 050: rc=$? $(grep Summary $EV/run_migrations_mig049.log)"
$S -qc "GRANT CONNECT ON DATABASE mig TO secuura_app; GRANT USAGE ON SCHEMA public TO secuura_app; GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO secuura_app;"
echo "trigger present before 050: $($S -tAc "select count(*) from pg_trigger where tgname='documents_id_namespaces_disjoint'")"
# planted legacy rows: two real collisions (lower, UPPER) and one look-alike the rule does not cover (padded)
$S -q <<'SQL'
INSERT INTO documents (id, title, document_type, content_hash, tenant_id) VALUES
 ('aaaaaaaa-0000-4000-8000-000000000001','legacy cert 1','certification',repeat('1',64),'aaaaaaaa-1111-4111-8111-111111111111'),
 ('aaaaaaaa-0000-4000-8000-000000000002','legacy cert 2','certification',repeat('2',64),'aaaaaaaa-1111-4111-8111-111111111111'),
 ('aaaaaaaa-0000-4000-8000-000000000003','legacy cert 3','certification',repeat('3',64),'aaaaaaaa-1111-4111-8111-111111111111');
INSERT INTO documents (id, external_id, title, document_type, content_hash, tenant_id) VALUES
 ('bbbbbbbb-0000-4000-8000-000000000001','aaaaaaaa-0000-4000-8000-000000000001','collides lower','DOC',repeat('1',64),'bbbbbbbb-1111-4111-8111-111111111111'),
 ('bbbbbbbb-0000-4000-8000-000000000002','AAAAAAAA-0000-4000-8000-000000000002','collides UPPER','DOC',repeat('2',64),'bbbbbbbb-1111-4111-8111-111111111111'),
 ('bbbbbbbb-0000-4000-8000-000000000003',' aaaaaaaa-0000-4000-8000-000000000003','padded look-alike','DOC',repeat('3',64),'bbbbbbbb-1111-4111-8111-111111111111');
SQL
echo "--- M1 050 as the superuser with 2 planted collisions:"
$S -v ON_ERROR_STOP=1 -q -f $M050 2>&1 | sed 's/^/    /'; echo "    psql rc=${PIPESTATUS[0]}"
echo "    after refusal: function=$($S -tAc "select count(*) from pg_proc where proname='documents_id_namespaces_disjoint'") trigger=$($S -tAc "select count(*) from pg_trigger where tgname='documents_id_namespaces_disjoint'")"
echo "--- M2 the header's census, verbatim from the file:"
sed -n '/^--   SELECT a.id/,/^--      AND b.id <> a.id;/p' $M050 | sed 's/^--  //' > $G/census.sql
cat $G/census.sql | sed 's/^/    | /'
$S -f $G/census.sql 2>&1 | sed 's/^/    /'
echo "--- M3 the same census as secuura_app (FORCE RLS, no tenant GUC): what a non-bypass run would have counted"
$A -tAc "SELECT count(*) FROM documents a JOIN documents b ON b.id = CASE WHEN a.external_id ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\$' THEN a.external_id::uuid END AND b.id <> a.id" 2>&1 | sed 's/^/    count=/'
echo "--- M4 050 as secuura_app:"
$A -v ON_ERROR_STOP=1 -q -f $M050 2>&1 | sed 's/^/    /'; echo "    psql rc=${PIPESTATUS[0]}"
echo "--- M5 the runner over all 52 files (050 included) with the collisions present:"
sed "s#for f in migrations/\*.sql; do#for f in $DEV/migrations/*.sql; do#" $DEV/scripts/run-migrations.sh > $G/run-migrations.migall.sh
PATH=$B:$PATH DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:$PORT/mig" /bin/sh $G/run-migrations.migall.sh > $EV/run_migrations_mig_refuse.log 2>&1; echo "    runner rc=$?"
grep -E "050|Summary|ERROR" $EV/run_migrations_mig_refuse.log | head -6 | sed 's/^/    /'
echo "--- M6 resolve by UPDATE (nothing deleted), then the runner again:"
$S -qc "UPDATE documents SET external_id = 'doc-1-legacy-resolved-' || right(id::text, 1) WHERE id IN ('bbbbbbbb-0000-4000-8000-000000000001','bbbbbbbb-0000-4000-8000-000000000002')"
PATH=$B:$PATH DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:$PORT/mig" /bin/sh $G/run-migrations.migall.sh > $EV/run_migrations_mig_apply.log 2>&1; echo "    runner rc=$?"
grep -E "050|Summary" $EV/run_migrations_mig_apply.log | sed 's/^/    /'
H1=$($S -tAc "select md5(pg_get_functiondef('documents_id_namespaces_disjoint'::regproc)) || ' ' || (select count(*) from pg_trigger where tgname='documents_id_namespaces_disjoint')")
echo "--- M7 re-apply the FILE directly, twice (idempotent?):"
$S -v ON_ERROR_STOP=1 -q -f $M050 2>&1 | sed 's/^/    /'; echo "    rc=${PIPESTATUS[0]}"
$S -v ON_ERROR_STOP=1 -q -f $M050 2>&1 | sed 's/^/    /'; echo "    rc=${PIPESTATUS[0]}"
H2=$($S -tAc "select md5(pg_get_functiondef('documents_id_namespaces_disjoint'::regproc)) || ' ' || (select count(*) from pg_trigger where tgname='documents_id_namespaces_disjoint')")
echo "    function md5 + trigger count before/after: $H1 | $H2"
echo "--- M8 the runner a third time:"
PATH=$B:$PATH DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:$PORT/mig" /bin/sh $G/run-migrations.migall.sh 2>&1 | grep -E "050|Summary" | sed 's/^/    /'
echo "--- M9 the padded look-alike row still there and still allowed; a NEW lower collision now refused by the trigger:"
$S -tAc "select count(*) from documents where external_id = ' aaaaaaaa-0000-4000-8000-000000000003'" | sed 's/^/    padded rows=/'
$S -c "INSERT INTO documents (id, external_id, title, document_type, content_hash, tenant_id) VALUES (gen_random_uuid(),'aaaaaaaa-0000-4000-8000-000000000003','new','DOC',repeat('4',64),'bbbbbbbb-1111-4111-8111-111111111111')" 2>&1 | sed 's/^/    /'
