-- COPY FROM STDIN fires BEFORE ROW triggers; the victim is created in the same rolled-back transaction
\set ON_ERROR_STOP 0
\set VERBOSITY verbose
BEGIN;
INSERT INTO documents (id, title, document_type, content_hash, tenant_id) VALUES ('11111111-1111-4111-8111-111111111111', 'copy victim', 'certification', repeat('e',64), '22222222-2222-4222-8222-222222222222');
COPY documents (id, external_id, title, document_type, content_hash, tenant_id) FROM STDIN;
33333333-3333-4333-8333-333333333333	11111111-1111-4111-8111-111111111111	copy attacker	DOC	ffff	44444444-4444-4444-8444-444444444444
\.
SELECT count(*) AS rows_with_that_external_id FROM documents WHERE external_id = '11111111-1111-4111-8111-111111111111';
ROLLBACK;
