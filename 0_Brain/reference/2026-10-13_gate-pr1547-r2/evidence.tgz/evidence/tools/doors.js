// doors.js <shared-dist> <originate-matrix.json> <security-matrix.json> : cell-by-cell verdict comparison of the two doors
const [, , SHARED, OF, SF] = process.argv;
const { normaliseOrgId } = require(SHARED);
const o = require(OF), s = require(SF);
const MALFORMED_P = new Set(['P-string-register', 'P-nested', 'P-null+register', 'P-object']);
const NONSTR_O = new Set(['O-number', 'O-array-own', 'O-array-foreign', 'O-object', 'O-true']);
const om = new Map(o.results.filter((r) => r.hdrTenant === o.T).map((r) => [`${r.role}|${r.perm}|${r.org}`, r]));
const cls = (st) => (st >= 200 && st < 300 ? 'ALLOW' : st === 400 ? '400' : st === 403 ? '403' : String(st));
const buckets = {}; const diffs = {};
let n = 0, missing = 0;
for (const r of s.results) {
  const k = `${r.role}|${r.perm}|${r.org}`; const x = om.get(k); if (!x) { missing++; continue; } n++;
  const b = MALFORMED_P.has(r.perm) ? 'malformed-permissions' : NONSTR_O.has(r.org) ? 'non-string-org' : r.org === 'O-null' ? 'null-org' : 'well-formed';
  buckets[b] = buckets[b] || { cells: 0, sameVerdict: 0, allowRefuseDiffer: 0, refusalCodeDiffer: 0, storedOrgDiffer: 0 };
  const B = buckets[b]; B.cells++;
  const cs = cls(r.status), co = cls(x.status);
  if (cs === co) B.sameVerdict++;
  else if ((cs === 'ALLOW') !== (co === 'ALLOW')) { B.allowRefuseDiffer++; (diffs[b] = diffs[b] || []).push(`${k}: security ${r.status} (${r.err}) vs originate ${x.status} (${x.err})`); }
  else { B.refusalCodeDiffer++; (diffs[b + ':code'] = diffs[b + ':code'] || []).push(`${k}: security ${r.status} vs originate ${x.status}`); }
  if (cs === 'ALLOW' && co === 'ALLOW') {
    const so = normaliseOrgId(r.row?.organization_id ?? null), oo = normaliseOrgId(x.row?.organization_id ?? null);
    if (so !== oo) { B.storedOrgDiffer++; (diffs[b + ':storedOrg'] = diffs[b + ':storedOrg'] || []).push(`${k}: security stored ${JSON.stringify(r.row?.organization_id)} vs originate ${JSON.stringify(x.row?.organization_id)}`); }
  }
}
const hist = {}; for (const r of s.results) hist[r.status] = (hist[r.status] || 0) + 1;
console.log(JSON.stringify({ securityRows: s.results.length, compared: n, missing, securityStatusHist: hist, buckets }, null, 1));
for (const [k, v] of Object.entries(diffs)) { console.log(`--- ${k} (${v.length})`); for (const l of v.slice(0, 25)) console.log('  ' + l); }
