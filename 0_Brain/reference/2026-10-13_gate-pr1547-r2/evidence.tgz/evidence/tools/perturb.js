// perturb.js <shared> <matrix.json> <outdir>: one synthetic defect per classifier category, proving each zero can be non-zero
const [, , SHARED, F, OD] = process.argv;
const fs = require('fs'); const { execFileSync } = require('child_process');
const base = JSON.parse(fs.readFileSync(F, 'utf8'));
const find = (p) => base.results.findIndex(p);
const P = {
  s500: (d) => { d.results[0].status = 500; },
  rowOnRefusal: (d) => { const i = d.results.findIndex((r) => r.status === 403 && r.role === 'ORG_ADMIN(A1)'); d.results[i].nrows = 1; },
  fpUnboundedProv: (d) => { const i = d.results.findIndex((r) => r.role === 'ORG_ADMIN(A1)' && r.perm === 'P-register' && r.org === 'O-own'); d.results[i].row.organization_id = null; },
  fpForeignOrg: (d) => { const i = d.results.findIndex((r) => r.role === 'ORG_ADMIN(A1)' && r.perm === 'P-read' && r.org === 'O-own'); d.results[i].row.organization_id = d.A2; },
  fpProvNoBodyOrg: (d) => { const i = d.results.findIndex((r) => r.role === 'ORG_ADMIN(A1)' && r.perm === 'P-register' && r.org === 'O-absent' && r.hdrTenant === d.T); Object.assign(d.results[i], { status: 201, nrows: 1, row: { organization_id: d.A1, scopes: ['organizations:register'], tenant: d.T } }); },
  falseRefusalOwnProv: (d) => { const i = d.results.findIndex((r) => r.role === 'ORG_ADMIN(A1)' && r.perm === 'P-register' && r.org === 'O-own'); Object.assign(d.results[i], { status: 403, nrows: 0, row: null }); },
  nonString_not400: (d) => { const i = d.results.findIndex((r) => r.role === 'ORG_ADMIN(A1)' && r.org === 'O-array-own'); d.results[i].status = 201; d.results[i].nrows = 1; d.results[i].row = { organization_id: d.A1, scopes: ['read'], tenant: d.T }; },
  nullVsAbsentDiffer: (d) => { const i = d.results.findIndex((r) => r.role === 'SYSTEM_ADMIN(none)' && r.perm === 'P-read' && r.org === 'O-null'); d.results[i].status = 400; d.results[i].nrows = 0; d.results[i].row = null; },
  unnormStored: (d) => { const i = d.results.findIndex((r) => r.role === 'SYSTEM_ADMIN(none)' && r.org === 'O-own-UPPER' && r.status === 201); d.results[i].row.organization_id = d.A1.toUpperCase(); },
};
for (const [cat, fn] of Object.entries(P)) {
  const d = JSON.parse(JSON.stringify(base)); fn(d);
  const f = `${OD}/perturb_${cat}.json`; fs.writeFileSync(f, JSON.stringify(d));
  const out = execFileSync('node', [__dirname + '/classify2.js', SHARED, f]).toString();
  const s = JSON.parse(out.split('\n---')[0]).summary;
  console.log(`${cat}: base 0 -> perturbed ${s[cat]}  (oracleMismatch ${s.oracleMismatch})`);
}
