// classify2.js <shared-dist-index.js> <matrix.json> — gate 1547 ROUND 2.
// Judges every row against Kam's ruling b as Wednesday stated it to the author (09:59Z):
//   isProvisioningCapable(requested) && !callerIsPlatform && requestedOrg === null -> 403,
//   requestedOrg = normaliseOrgId(BODY organizationId), NO fall-back to the claim;
//   non-platform naming an org that is not its own -> 403 (c);
//   non-string organizationId (present, not null) -> 400, no row; null behaves as absent.
// Uses the head's OWN shared isProvisioningCapable / normaliseOrgId / isPlatformRole.
const [, , SHARED, FILE] = process.argv;
const { isProvisioningCapable, normaliseOrgId, isPlatformRole } = require(SHARED);
const d = require(FILE);
const ADMITTED = new Set(['SYSTEM_ADMIN', 'SUPER_ADMIN', 'super_admin', 'ORG_ADMIN']); // requireRole, exact (round 1)
const parseJsonArray = (v) => (!v ? [] : Array.isArray(v) ? v : typeof v === 'string' ? (() => { try { return JSON.parse(v); } catch { return []; } })() : []);
const cats = ['s500', 'rowOnRefusal', 'fpUnboundedProv', 'fpForeignOrg', 'fpProvNoBodyOrg', 'unboundedWithClaim', 'unnormStored',
  'falseRefusal', 'falseRefusalOwnProv', 'nonString_not400', 'nonString_rowWritten', 'nullVsAbsentDiffer', 'oracleMismatch'];
const out = { total: 0, statusHist: {}, ownProvAdmitted: 0, nonStringCases: 0, nullAbsentPairs: 0 };
for (const c of cats) out[c] = [];
const byKey = new Map();
for (const r of d.results) {
  out.total++;
  out.statusHist[r.status] = (out.statusHist[r.status] || 0) + 1;
  const roleV = r.roleV;
  const admitted = typeof roleV === 'string' && ADMITTED.has(roleV);
  const platform = admitted && isPlatformRole(roleV);
  const key = `${r.role} | ${r.perm} | ${r.org}${r.hdrTenant !== d.T ? ' | hdr=T2' : ''}`;
  const permV = r.permV === '<absent>' ? undefined : r.permV;
  const orgPresent = r.orgV !== '<absent>';
  const orgV = orgPresent ? r.orgV : undefined;
  const nonString = orgPresent && orgV !== null && typeof orgV !== 'string';
  const requested = Array.isArray(permV) && permV.length > 0 ? permV : ['read'];
  const provReq = isProvisioningCapable(requested);
  const reqOrg = typeof orgV === 'string' ? normaliseOrgId(orgV) : null;
  const claimN = normaliseOrgId(typeof r.claim === 'string' && r.claim !== '<absent>' ? r.claim : null);
  // ORACLE (the ruled rule, written independently of the handler's text)
  let exp, expOrg = null;
  if (!admitted) exp = 403;
  else if (nonString) exp = 400;
  else if (provReq && !platform && reqOrg === null) exp = 403;
  else if (!platform && reqOrg !== null && reqOrg !== claimN) exp = 403;
  else { exp = 201; expOrg = reqOrg ?? claimN; }
  if (r.hdrTenant === d.T) byKey.set(`${r.role}|${r.perm}|${r.org}`, r);
  const storedOrg = r.row ? r.row.organization_id : undefined;
  if (r.status >= 500) out.s500.push(`${key} -> ${r.status} ${r.err}`);
  if (r.status !== 201 && r.nrows > 0) out.rowOnRefusal.push(key);
  if (r.status === 201 && r.row) {
    const scopes = parseJsonArray(r.row.scopes);
    const storedN = normaliseOrgId(storedOrg);
    if (storedOrg !== null && storedOrg !== storedN) out.unnormStored.push(`${key} stored=${JSON.stringify(storedOrg)}`);
    if (!platform) {
      if (isProvisioningCapable(scopes) && storedN === null) out.fpUnboundedProv.push(`${key} scopes=${JSON.stringify(r.row.scopes)}`);
      if (isProvisioningCapable(scopes) && reqOrg === null) out.fpProvNoBodyOrg.push(`${key} stored=${JSON.stringify(storedOrg)}`);
      if (storedN !== null && storedN !== claimN) out.fpForeignOrg.push(`${key} stored=${JSON.stringify(storedOrg)} claim=${JSON.stringify(r.claim)}`);
      if (storedN === null && claimN !== null) out.unboundedWithClaim.push(`${key} claim=${JSON.stringify(r.claim)}`);
    }
  }
  if (admitted && r.hdrTenant === d.T) {
    if (exp === 201 && r.status !== 201) out.falseRefusal.push(`${key} -> ${r.status} ${r.err}`);
    if (!platform && provReq && reqOrg !== null && reqOrg === claimN) {
      if (r.status === 201 && normaliseOrgId(storedOrg) === claimN) out.ownProvAdmitted++;
      else out.falseRefusalOwnProv.push(`${key} -> ${r.status} stored=${JSON.stringify(storedOrg)} ${r.err}`);
    }
    if (nonString) {
      out.nonStringCases++;
      if (r.status !== 400) out.nonString_not400.push(`${key} -> ${r.status}`);
      if (r.nrows > 0) out.nonString_rowWritten.push(key);
    }
  }
  const okOrg = exp !== 201 || (r.row && normaliseOrgId(storedOrg) === expOrg && storedOrg === expOrg);
  if (r.hdrTenant === d.T && (r.status !== exp || !okOrg)) out.oracleMismatch.push(`${key} -> got ${r.status} stored=${JSON.stringify(storedOrg)} | expected ${exp} org=${JSON.stringify(expOrg)}`);
}
for (const [k, r] of byKey) {
  if (!k.endsWith('|O-null')) continue;
  const a = byKey.get(k.replace(/\|O-null$/, '|O-absent'));
  out.nullAbsentPairs++;
  const sa = a.row ? a.row.organization_id : '<no row>', sn = r.row ? r.row.organization_id : '<no row>';
  if (a.status !== r.status || sa !== sn) out.nullVsAbsentDiffer.push(`${k}: null -> ${r.status} ${JSON.stringify(sn)} vs absent -> ${a.status} ${JSON.stringify(sa)}`);
}
const summ = {};
for (const [k, v] of Object.entries(out)) summ[k] = Array.isArray(v) ? v.length : v;
console.log(JSON.stringify({ mt: d.mt, summary: summ }, null, 1));
for (const k of cats) {
  console.log(`--- ${k} (${out[k].length})`);
  for (const l of out[k].slice(0, 60)) console.log('  ' + l);
}
