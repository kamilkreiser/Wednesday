#!/usr/bin/env python3
"""Gate 1547 ROUND 2 mutation pass, head 0f97a015. Each mutant edits the SCRATCH wt_head adminConfig.ts (never the
project), runs tsc, then the 23 KS-1594 cells (MT=false; MT=true where listed), and optionally the 6158-row matrix.
A kill counts only if: the suite LOADED all 23 cells, tsc rc 0, and every red cell's failure block carries a
non-empty assertion message (an 'Expected'/'Received' pair or a thrown message). Restore asserted by sha256.
usage: mutants2.py [--matrix] [names...]"""
import hashlib, re, subprocess, sys, json, os
W = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1547r2'
ORIG = W + '/wt_head/Blockchain/Dev/services/originate'
F = ORIG + '/src/routes/adminConfig.ts'
PRISTINE = open(F).read()
SHA = hashlib.sha256(PRISTINE.encode()).hexdigest()
R1HEAD = subprocess.run(['git', '-C', W + '/repo', 'show', 'a897f57eba3d39afd8fd19e2895cb0e83188ab58:Blockchain/Dev/services/originate/src/routes/adminConfig.ts'], capture_output=True, text=True, check=True).stdout

A_IF = "if (isProvisioningCapable(requestedScopes) && !callerIsPlatform && requestedOrg === null) {"
C_IF = "if (!callerIsPlatform && requestedOrg !== null && requestedOrg !== callerOrg) {"
G_IF = "if (d.organizationId !== undefined && d.organizationId !== null && typeof d.organizationId !== 'string') {"
WRITE = "const orgId = requestedOrg ?? callerOrg;"
PLAT = "const callerIsPlatform = isPlatformRole((req as any).user?.role as string | undefined);"
GUARD_BLOCK = """    if (d.organizationId !== undefined && d.organizationId !== null && typeof d.organizationId !== 'string') {
      return res.status(400).json({
        success: false,
        error: { code: 'BAD_REQUEST', message: 'organizationId must be a string' },
      });
    }
"""
AUDIT = "    // Audit A-12: API key value MUST be cryptographic"

M = {
  # ---- the author's ten (re-spelled by the gate from the author's names) ----
  'T1 (a) disabled': [(A_IF, A_IF.replace('if (', 'if (false && ', 1))],
  'T2 (a) platform test inverted': [(A_IF, A_IF.replace('!callerIsPlatform', 'callerIsPlatform'))],
  'T3 write not normalised': [(WRITE, "const orgId = (d.organizationId as string) || ((req as any).user?.organizationId as string | undefined) || null;")],
  'T4 (c) requested side raw': [(C_IF, "if (!callerIsPlatform && requestedOrg !== null && (d.organizationId as string) !== callerOrg) {")],
  'T5 (c) disabled': [(C_IF, C_IF.replace('if (', 'if (false && ', 1))],
  'T6 (c) caller side raw': [(C_IF, "if (!callerIsPlatform && requestedOrg !== null && requestedOrg !== (((req as any).user?.organizationId as string | undefined) ?? null)) {")],
  'G7a (a) requestedOrg clause deleted (= round-1 rule a)': [(A_IF, "if (isProvisioningCapable(requestedScopes) && !callerIsPlatform) {")],
  'G7b (a) requestedOrg clause inverted': [(A_IF, A_IF.replace('requestedOrg === null', 'requestedOrg !== null'))],
  'G8 platform = literal SYSTEM_ADMIN only': [(PLAT, "void isPlatformRole;\n    const callerIsPlatform = (req as any).user?.role === 'SYSTEM_ADMIN';")],
  'M2m m2 400 guard removed': [(G_IF, "if (false && d.organizationId !== undefined && d.organizationId !== null && typeof d.organizationId !== 'string') {")],
  # ---- the gate's own ----
  'R1 400 guard moved AFTER (a) and (c) (post-normalisation, post-decision)': [(GUARD_BLOCK, ""), (AUDIT, GUARD_BLOCK + AUDIT)],
  'R2 400 guard tests the NORMALISED value (dead guard)': [(G_IF, "if (requestedOrgPre !== null && typeof requestedOrgPre !== 'string') {"),
      ("const callerIsPlatform = isPlatformRole", "const requestedOrgPre = normaliseOrgId(d.organizationId as string | null | undefined);\n    const callerIsPlatform = isPlatformRole")],
  'R3 (a) tests the RAW body value (truthiness), not normalised': [(A_IF, "if (isProvisioningCapable(requestedScopes) && !callerIsPlatform && !d.organizationId) {")],
  'R4 (a) tests the post-FALL-BACK value (requestedOrg ?? callerOrg)': [(A_IF, "if (isProvisioningCapable(requestedScopes) && !callerIsPlatform && (requestedOrg ?? callerOrg) === null) {")],
  'R5 platform check reads the BODY role (wrong field)': [(PLAT, "const callerIsPlatform = isPlatformRole(d.role as string | undefined);")],
  'R6 platform check reads user.organizationId (wrong field)': [(PLAT, "const callerIsPlatform = isPlatformRole((req as any).user?.organizationId as string | undefined);")],
  'R7 guard drops the null exemption (null -> 400)': [(G_IF, "if (d.organizationId !== undefined && typeof d.organizationId !== 'string') {")],
  'R8 guard catches objects only (number/boolean pass as absent)': [(G_IF, "if (d.organizationId !== undefined && d.organizationId !== null && typeof d.organizationId === 'object') {")],
  'R9 guard only for platform callers': [(G_IF, "if (callerIsPlatform && d.organizationId !== undefined && d.organizationId !== null && typeof d.organizationId !== 'string') {")],
  'R10 guard only for non-platform callers': [(G_IF, "if (!callerIsPlatform && d.organizationId !== undefined && d.organizationId !== null && typeof d.organizationId !== 'string') {")],
  'R11 (a) only when MULTI_TENANCY_ENABLED=true': [(A_IF, A_IF.replace('if (', "if (process.env.MULTI_TENANCY_ENABLED === 'true' && ", 1))],
  # ---- controls ----
  'R0 whole file = round-1 head a897f57e (red-first control)': 'R1HEAD',
  'X0 tsc control (deliberate type error)': [(WRITE, WRITE + "\n    const _gateTypeErr: number = 'not a number';")],
  'C0 comment-only control': [(A_IF, "// gate1547r2 comment-only control\n    " + A_IF)],
}
MODES = {'R11 (a) only when MULTI_TENANCY_ENABLED=true': ['false', 'true']}
args = sys.argv[1:]
matrix = '--matrix' in args
args = [a for a in args if a != '--matrix']
names = [n for n in M if not args or n.split(' ')[0] in args]
os.makedirs(W + '/ev/mutants', exist_ok=True)
clean = lambda s: re.sub(r'\x1b\[[0-9;]*m', '', s)

def blocks(txt):
    """failure blocks keyed by cell id -> has a non-empty assertion message"""
    out = {}
    parts = re.split(r'^  ● ', txt, flags=re.M)[1:]
    for p in parts:
        head = p.splitlines()[0]
        m = re.search(r'› (c\d+b?)\b', head)
        if not m: continue
        body = '\n'.join(p.splitlines()[1:12])
        msg = bool(re.search(r'Expected[^\n]*\S', body) and re.search(r'Received[^\n]*\S', body)) or bool(re.search(r'^\s{4}\S.+', body, re.M))
        out.setdefault(m.group(1), []).append(msg)
    return out

res = {}
try:
    for name in names:
        spec = M[name]
        if spec == 'R1HEAD':
            src = R1HEAD
        else:
            src = PRISTINE
            for old, new in spec:
                n = src.count(old)
                assert n == 1, f'{name}: anchor count {n} for {old[:60]!r}'
                src = src.replace(old, new, 1)
        assert src != PRISTINE
        open(F, 'w').write(src)
        t = subprocess.run(['npx', 'tsc', '--noEmit', '-p', 'tsconfig.json'], cwd=ORIG, capture_output=True, text=True)
        tsc_err = [l for l in (t.stdout + t.stderr).splitlines() if 'error TS' in l]
        tag = re.sub(r'[^A-Za-z0-9]+', '_', name.split(' ')[0])
        for mt in MODES.get(name, ['false']):
            out = f'{W}/ev/mutants/{tag}_mt{mt}.txt'
            subprocess.run([W + '/bin/orig.sh', 'wt_head', out, mt, 'ks1594-admin-mint'], capture_output=True, text=True)
            txt = clean(open(out).read())
            cells = re.findall(r'^\s+([✓✕])\s+(c\d+b?)\s', txt, re.M)
            red = [c for s, c in cells if s == '✕']
            bl = blocks(txt)
            empty = sorted({c for c in red if not all(bl.get(c, [False]))})
            tot = re.search(r'^Tests:.*$', txt, re.M)
            verdict = ('CONTROL' if name[0] in 'XC' or name.startswith('R0') else
                       'LOAD-FAIL (not a kill)' if len(cells) != 23 else
                       'TSC-FAIL (not a kill)' if t.returncode != 0 else
                       'KILLED' if red and not empty else
                       'KILL REJECTED (empty message)' if red else 'SURVIVES')
            r = {'tsc_rc': t.returncode, 'tsc_err': tsc_err[:2], 'loaded': len(cells), 'red': red, 'empty_msg': empty,
                 'tests': tot.group(0) if tot else 'NO TESTS LINE', 'verdict': verdict}
            if matrix:
                mo = f'{W}/ev/mutants/{tag}_matrix_mt{mt}.json'
                env = dict(os.environ, GATE_OUT=mo)
                subprocess.run([W + '/bin/orig.sh', 'wt_head', f'{W}/ev/mutants/{tag}_matrixrun_mt{mt}.txt', mt, 'gate1547r2-matrix'], capture_output=True, text=True, env=env)
                c = subprocess.run(['node', W + '/bin/classify2.js', W + '/wt_head/Blockchain/Dev/packages/shared/dist/index.js', mo], capture_output=True, text=True)
                open(f'{W}/ev/mutants/{tag}_classify_mt{mt}.txt', 'w').write(c.stdout + c.stderr)
                try:
                    s = json.loads(c.stdout.split('\n---')[0])['summary']
                    r['matrix'] = {k: v for k, v in s.items() if isinstance(v, int) and v and k not in ('total', 'ownProvAdmitted', 'nonStringCases', 'nullAbsentPairs')}
                except Exception as e:
                    r['matrix'] = f'classify failed: {e}'
            res[f'{name} [MT={mt}]'] = r
            print(f"{name} [MT={mt}] tsc={t.returncode} loaded={len(cells)} red={red} empty={empty} | {r['tests']} => {verdict}" + (f" | matrix {r.get('matrix')}" if matrix else ''), flush=True)
finally:
    open(F, 'w').write(PRISTINE)
    assert hashlib.sha256(open(F).read().encode()).hexdigest() == SHA
    print('restored, sha256 matches pristine', SHA[:16])
fn = W + '/ev/mutants/summary' + ('_matrix' if matrix else '') + '.json'
prev = json.load(open(fn)) if os.path.exists(fn) else {}
prev.update(res)
json.dump(prev, open(fn, 'w'), indent=1)
