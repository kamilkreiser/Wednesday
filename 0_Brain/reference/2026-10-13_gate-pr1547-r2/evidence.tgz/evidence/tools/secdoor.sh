#!/bin/bash
# secdoor.sh <outjson> <outlog>: run the security-door matrix in wt_dev (develop) against PG 55471
W=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1547r2
export TEST_DATABASE_URL="postgresql://secuura@127.0.0.1:55471/secuura"
export TEST_APP_DATABASE_URL="postgresql://secuura_app:$(cat $W/pg/app_pw)@127.0.0.1:55471/secuura"
export GATE_OUT=$1
exec python3 -I $W/bin/runin.py $W/wt_dev/Blockchain/Dev/services/security $2 npx vitest run --config vitest.integration.config.ts gate1547r2-securitydoor
