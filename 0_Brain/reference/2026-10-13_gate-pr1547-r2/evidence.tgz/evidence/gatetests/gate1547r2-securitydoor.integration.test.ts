/**
 * Gate PR 1547 r2: the SECURITY door (POST /api/keys, develop 026c2d16) driven with the same
 * role x permissions x organizationId shapes as the originate matrix, so the two doors' verdicts
 * can be compared cell by cell. NOT part of the PR. Real app (SECURITY_DISABLE_BOOT=1, as the
 * KS-1584 cells do), real RS256 tokens, app role secuura_app under FORCE RLS. Output -> GATE_OUT.
 */
import { it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import fs from 'fs';
import type { Server } from 'http';
import type { AddressInfo } from 'net';
import { Pool } from 'pg';

process.env.SECURITY_DISABLE_BOOT = '1';
const OUT = process.env.GATE_OUT;
const T = 'a0000000-0000-4000-8000-0000001547aa';
const A1 = 'abcdef00-1547-4547-8547-0000000000a1';
const A2 = 'abcdef00-1547-4547-8547-0000000000a2';
const NAME = 'g1547r2s:';
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const PEM = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const b64url = (b: Buffer): string => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function token(claims: Record<string, unknown>): string {
  const h = b64url(Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const now = Math.floor(Date.now() / 1000);
  const p = b64url(Buffer.from(JSON.stringify({ iat: now, exp: now + 600, ...claims })));
  return `${h}.${p}.${b64url(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), PEM))}`;
}
const ROLES: Array<[string, string, unknown]> = [
  ['ORG_ADMIN(A1)', 'ORG_ADMIN', A1],
  ['ORG_ADMIN(none)', 'ORG_ADMIN', undefined],
  ['ORG_ADMIN(A1-UPPER)', 'ORG_ADMIN', A1.toUpperCase()],
  ['ORG_ADMIN(ws-A1)', 'ORG_ADMIN', `  ${A1}\t`],
  ['ORG_ADMIN(blank)', 'ORG_ADMIN', '   '],
  ['SYSTEM_ADMIN(none)', 'SYSTEM_ADMIN', undefined],
  ['SYSTEM_ADMIN(A1)', 'SYSTEM_ADMIN', A1],
  ['SUPER_ADMIN(none)', 'SUPER_ADMIN', undefined],
  ['super_admin(none)', 'super_admin', undefined],
  ['super_admin(A1)', 'super_admin', A1],
];
const PERMS: Array<[string, unknown]> = [
  ['P-absent', undefined],
  ['P-read', ['read']],
  ['P-docs', ['documents:read', 'documents:write']],
  ['P-register', ['organizations:register']],
  ['P-star', ['*']],
  ['P-org*', ['organizations:*']],
  ['P-REGISTER-upper', ['ORGANIZATIONS:REGISTER']],
  ['P-ws-register', [' organizations:register ']],
  ['P-Org*-mixed', ['Organizations:*']],
  ['P-star-ws', ['* ']],
  ['P-read+register', ['read', 'organizations:register']],
  ['P-string-register', 'organizations:register'],
  ['P-nested', [['organizations:register']]],
  ['P-null+register', [null, 'organizations:register']],
  ['P-empty', []],
  ['P-object', { 0: 'organizations:register', length: 1 }],
  ['P-space-joined', ['read organizations:register']],
  ['P-comma-joined', ['read,organizations:register']],
];
const ORGS: Array<[string, unknown, boolean]> = [
  ['O-absent', undefined, false],
  ['O-own', A1, true],
  ['O-own-UPPER', A1.toUpperCase(), true],
  ['O-own-ws', `  ${A1}  `, true],
  ['O-own-tabnl', `\t${A1}\n`, true],
  ['O-foreign', A2, true],
  ['O-foreign-UPPER', A2.toUpperCase(), true],
  ['O-empty', '', true],
  ['O-blank', '   ', true],
  ['O-nbsp', ' ', true],
  ['O-nbsp-own', ` ${A1} `, true],
  ['O-zwsp-own', `​${A1}`, true],
  ['O-null', null, true],
  ['O-number', 12345, true],
  ['O-array-own', [A1], true],
  ['O-array-foreign', [A2], true],
  ['O-object', { id: A2 }, true],
  ['O-true', true, true],
];
let server: Server; let base: string; let su: Pool;
beforeAll(async () => {
  if (!process.env.TEST_DATABASE_URL || !process.env.TEST_APP_DATABASE_URL || !OUT) throw new Error('needs DB urls and GATE_OUT');
  su = new Pool({ connectionString: process.env.TEST_DATABASE_URL, max: 3 });
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  process.env.DATABASE_URL = process.env.TEST_APP_DATABASE_URL;
  process.env.JWT_PUBLIC_KEY = Buffer.from(publicKey.export({ type: 'spki', format: 'pem' }).toString(), 'utf8').toString('base64');
  delete process.env.JWT_JWKS_URL; delete process.env.AUTH_SERVICE_URL;
  const db = await import('../db');
  if (!(await db.initDb())) throw new Error('no db');
  const app = (await import('../index')).default;
  await new Promise<void>((r) => { server = app.listen(0, '127.0.0.1', r); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
afterAll(async () => {
  if (server) await new Promise<void>((r) => server.close(() => r()));
  if (su) { await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]); await su.end(); }
  const db = await import('../db'); await db.closeDb();
});
it('security door matrix', async () => {
  const results: any[] = []; let i = 0;
  for (const [role, roleV, claim] of ROLES) for (const [perm, permV] of PERMS) for (const [org, orgV, present] of ORGS) {
    const label = `${NAME}${i++}`;
    const body: Record<string, unknown> = { name: label, tenantId: T };
    if (permV !== undefined) body.scopes = permV;
    if (present) body.organizationId = orgV;
    const tok = token({ role: roleV, tenantId: T, userId: crypto.randomUUID(), ...(claim !== undefined ? { organizationId: claim } : {}) });
    const r = await fetch(`${base}/api/keys`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${tok}` }, body: JSON.stringify(body) });
    const j: any = await r.json().catch(() => null);
    const rows = (await su.query('SELECT organization_id, scopes FROM svc_api_keys WHERE name = $1', [label])).rows;
    results.push({ role, roleV, claim: claim === undefined ? '<absent>' : claim, perm, org, status: r.status, err: j?.error?.message ?? j?.error ?? null, nrows: rows.length, row: rows[0] ?? null });
  }
  fs.writeFileSync(OUT as string, JSON.stringify({ door: 'security', A1, A2, T, results }, null, 1));
  expect(results.length).toBe(ROLES.length * PERMS.length * ORGS.length);
}, 900000);
