#!/bin/bash
# Gate 1545 (A) the cache fallback: npm_config_cache unset -> the gate hands the install the developer's ~/.npm.
# Wednesday's case 2 / the author's (b): a poisoned entry served to the NEXT install. Real gate, real npm, local listener.
# Two tarballs with the SAME name@version: BENIGN (postinstall writes "benign") and EVIL (writes "EVIL").
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1545
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1545/evidence
GATE=${GATE_UNDER_TEST:-$S/gates/gate_50f0552ce.sh}
W=$S/cache_$(date +%H%M%S)_$$; mkdir -p $W/hits $W/cases $W/src; export TMPDIR=$S/tmp
SENT=$W/hits/hits.log; SRVLOG=$W/srv.log; : > $SRVLOG; PN=gate1545-probe-dep
CACACHE=$(dirname $(dirname $(readlink -f $(command -v npm))))/node_modules/cacache
[ -d "$CACACHE" ] || CACACHE=/opt/homebrew/lib/node_modules/npm/node_modules/cacache
for kind in benign EVIL; do mkdir -p $W/src/$kind
  printf '{ "name": "%s", "version": "1.0.0", "scripts": { "postinstall": "node pi.js" } }\n' $PN > $W/src/$kind/package.json
  printf "require('fs').appendFileSync('%s', '%s '+process.cwd()+'\\\\n')\n" "$SENT" "$kind" > $W/src/$kind/pi.js
  mkdir -p $W/src/out_$kind; npm pack $W/src/$kind --pack-destination $W/src/out_$kind --cache $W/packcache --silent >/dev/null 2>&1
done
TB=$W/src/out_benign/$PN-1.0.0.tgz; TE=$W/src/out_EVIL/$PN-1.0.0.tgz
IB="sha512-$(openssl dgst -sha512 -binary $TB | base64 | tr -d '\n')"; IE="sha512-$(openssl dgst -sha512 -binary $TE | base64 | tr -d '\n')"
cp $TB $W/served.tgz
python3 -I $EV/tools/srv.py $W/port $W/served.tgz $SRVLOG & SRVPID=$!
for i in 1 2 3 4 5 6 7 8 9 10; do [ -s $W/port ] && break; sleep 0.3; done; PORT=$(cat $W/port); LOC="http://127.0.0.1:$PORT"
echo "gate md5=$(md5 -q $GATE) npm=$(npm -v) cacache=$CACACHE integrity benign=${IB:7:12}.. EVIL=${IE:7:12}.."
FH=$W/fakehome; DC=$FH/.npm; mkdir -p $DC
mkcase() { local r=$W/cases/$1; mkdir -p $r/systemTest/scripts $r/systemTest/p; cp $GATE $r/systemTest/scripts/check-package-format.sh
  printf '{ "name": "p", "version": "1.0.0", "scripts": { "format:check": "exit 0" }, "dependencies": { "%s": "1.0.0" } }\n' $PN > $r/systemTest/p/package.json
  printf '{"name":"p","version":"1.0.0","lockfileVersion":3,"requires":true,"packages":{"":{"name":"p","version":"1.0.0","dependencies":{"%s":"1.0.0"}},"node_modules/%s":{"version":"1.0.0","resolved":"%s","integrity":"%s","hasInstallScript":true}}}\n' $PN $PN "$2" "$3" > $r/systemTest/p/package-lock.json; echo $r; }
row() { local name=$1 r=$2; shift 2; local before=$(wc -l < $SRVLOG); local hb=$(wc -l < $SENT 2>/dev/null || echo 0)
  out=$(printf 'systemTest/p/x.ts\n' | env -i PATH="$PATH" HOME=$FH TMPDIR=$TMPDIR FORMAT_GATE_LOCK_ALLOW="$LOC/" "$@" bash $r/systemTest/scripts/check-package-format.sh 2>&1); rc=$?
  local ran=$(tail -n +$((hb+1)) $SENT 2>/dev/null | awk '{print $1}' | sort | uniq -c | tr -s ' ' | tr '\n' ',')
  printf '%-58s rc=%-2s GETs=%-2s scripts_ran=[%s] %s\n' "$name" "$rc" "$(( $(wc -l < $SRVLOG) - before ))" "$ran" "$(printf '%s' "$out" | grep -o -E 'EINTEGRITY|EACCES|EPERM|npm ci exited [0-9]+' | sort -u | tr '\n' ' ')"
  printf '%s\n' "$out" > "$W/cases/${name%% *}.out"; }
: > $SENT
row "K1 cold developer cache (~/.npm passed): BENIGN served" $(mkcase K1 $LOC/a/$PN-1.0.0.tgz $IB)
echo "   cache now holds: $(node -e 'const c=require(process.argv[1]);c.ls(process.argv[2]).then(o=>{console.log(Object.keys(o).length+" index keys: "+Object.keys(o).map(k=>k.replace(/^make-fetch-happen:request-cache:/,"mfh:")).join(" | "))})' $CACACHE $DC/_cacache)"
echo "   packument (metadata) requests in K1: $(grep -v '\.tgz' $SRVLOG | wc -l | tr -d ' ')   tarball requests: $(grep -c '\.tgz' $SRVLOG)"
# K2: the cached CONTENT for the benign integrity overwritten in place with the EVIL bytes (what a malicious install script could do)
CP=$(node -e 'const c=require(process.argv[1]);c.get.info(process.argv[2],process.argv[3]).then(i=>console.log(i.path))' $CACACHE $DC/_cacache "make-fetch-happen:request-cache:$LOC/a/$PN-1.0.0.tgz")
chmod u+w "$CP" 2>/dev/null; cp $TE "$CP"; echo "   K2 setup: overwrote $(basename $(dirname $CP))/$(basename $CP) with the EVIL tarball"
row "K2 same lock, cached content poisoned in place" $(mkcase K2 $LOC/a/$PN-1.0.0.tgz $IB)
# K3: an index (metadata) entry for the tarball URL pointing at EVIL content, in a fresh cache that has no benign content
FH3=$W/fakehome3; mkdir -p $FH3/.npm
node -e 'const c=require(process.argv[1]),fs=require("fs");c.put(process.argv[2],process.argv[3],fs.readFileSync(process.argv[4]),{metadata:{url:process.argv[5]}}).then(i=>console.log("   K3 setup: index key -> "+String(i).slice(0,20)+"..."))' $CACACHE $FH3/.npm/_cacache "make-fetch-happen:request-cache:$LOC/k3/$PN-1.0.0.tgz" $TE "$LOC/k3/$PN-1.0.0.tgz"
FH_SAVE=$FH; FH=$FH3
row "K3 index entry for the URL -> EVIL content; lock says BENIGN" $(mkcase K3 $LOC/k3/$PN-1.0.0.tgz $IB)
FH=$FH_SAVE
# K4: a cache populated by a DIFFERENT lock (EVIL integrity, other URL) - does a lock asking for BENIGN ever get EVIL?
FH4=$W/fakehome4; mkdir -p $FH4/.npm; FH_SAVE=$FH; FH=$FH4
cp $TE $W/served.tgz; row "K4a other lock (EVIL integrity) fills the cache" $(mkcase K4a $LOC/other/$PN-1.0.0.tgz $IE)
cp $TB $W/served.tgz; row "K4b this lock (BENIGN integrity, other URL), same cache" $(mkcase K4b $LOC/this/$PN-1.0.0.tgz $IB)
row "K4c CONTROL a lock with the EVIL integrity again: served from cache" $(mkcase K4c $LOC/third/$PN-1.0.0.tgz $IE)
FH=$FH_SAVE
# K5: a developer cache the install cannot write (closest I can build to "owned by another user": no sudo here)
FH5=$W/fakehome5; mkdir -p $FH5/.npm; chmod 555 $FH5/.npm; FH_SAVE=$FH; FH=$FH5
row "K5 ~/.npm exists but is not writable (mode 555)" $(mkcase K5 $LOC/k5/$PN-1.0.0.tgz $IB)
echo "   K5 message: $(grep -o -i -E 'npm error code [A-Z]+|EACCES[^,]*|cache folder[^.]*' $W/cases/K5.out | head -2 | tr '\n' ' ')"
chmod 755 $FH5/.npm; FH=$FH_SAVE
echo "== listener log"; cat $SRVLOG; echo "== script runs"; cat $SENT
kill $SRVPID; echo workdir=$W
