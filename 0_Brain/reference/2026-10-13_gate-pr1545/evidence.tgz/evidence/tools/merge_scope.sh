#!/bin/bash
# Gate 1545 re-launch: scope, overlap, merge-tree, evil-merge, blob claims. Read-only on the project; writes objects only in the scratch clone.
R=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1545/repo
g(){ git -C "$R" "$@"; }
H=50f0552ce011ac9d8c4caddf67bc747a7fed2d5b; D0=405e33a1061310662b10245c5154c3d75c49f0f4; H1540=c6d103ffc4692cb075287eb8143715989abeafab
D=$(g rev-parse origin/develop)
echo "head=$(g rev-parse refs/gate/head) develop_live=$D develop_at_commission=$D0 h1540=$(g rev-parse refs/gate/h1540)"
echo "is D0 ancestor of head: $(g merge-base --is-ancestor $D0 $H && echo yes || echo no)"
echo "merge-base(head, live develop)=$(g merge-base $H $D)"
echo "== develop moved since D0 =="; g log --format='%h %s' $D0..$D
echo "== paths changed on develop since D0 =="; g diff --name-only $D0 $D | tee /tmp/.x 2>/dev/null >/dev/null; g diff --name-only $D0 $D
echo "== PR paths (D0..head) =="; g diff --name-only $D0 $H
echo "== diff --stat D0..head =="; g diff --stat $D0 $H
echo "== diff --stat h1540..head (count) =="; g diff --name-only $H1540 $H | wc -l
echo "== diff --stat live develop...head (three-dot, from merge-base) =="; g diff --stat $D...$H
dev_paths=$(g diff --name-only $D0 $D); pr_paths=$(g diff --name-only $D0 $H)
ov=$(comm -12 <(printf '%s\n' "$dev_paths"|sort) <(printf '%s\n' "$pr_paths"|sort) | grep -c .)
echo "OVERLAP(develop since D0, PR paths) = $ov  [instrument: comm -12 of sorted git diff --name-only lists]"
# planted control: a commit on top of live develop touching .gitignore (a PR path)
T=$(g rev-parse $D^{tree}); GI=$( { g show $D:.gitignore; echo '# gate-control'; } | g hash-object -w --stdin )
T2=$(g ls-tree $D | awk -v b=$GI '{ if ($4==".gitignore") { print $1" "$2" "b"\t"$4 } else { sub(/^/, ""); print } }' | g mktree)
C=$(echo "gate control: touch .gitignore" | GIT_AUTHOR_NAME=gate GIT_AUTHOR_EMAIL=g@x GIT_COMMITTER_NAME=gate GIT_COMMITTER_EMAIL=g@x g commit-tree $T2 -p $D)
ctl_paths=$(g diff --name-only $D0 $C)
ovc=$(comm -12 <(printf '%s\n' "$ctl_paths"|sort) <(printf '%s\n' "$pr_paths"|sort) | grep -c .)
echo "CONTROL overlap(develop+planted .gitignore edit, PR paths) = $ovc (must be >=1)  control commit=$C"
echo "== merge-tree --write-tree live develop + head =="
out=$(g merge-tree --write-tree --name-only $D $H 2>&1); rc=$?; echo "$out"; echo "merge-tree rc=$rc"
MT=$(echo "$out"|head -1)
# predicted: head's tree with develop's moved paths taken from develop
echo "head tree=$(g rev-parse $H^{tree})  develop tree=$(g rev-parse $D^{tree})"
echo "-- merged tree vs head, paths that differ:"; g diff --name-only $H $MT
echo "-- merged tree vs live develop, paths that differ:"; g diff --name-only $D $MT
echo "-- every merged-tree path equals head or develop at that path (blob check over the union of differing paths):"
for p in $( (g diff --name-only $H $MT; g diff --name-only $D $MT) | sort -u); do m=$(g rev-parse -q --verify $MT:$p); h=$(g rev-parse -q --verify $H:$p); d=$(g rev-parse -q --verify $D:$p); s=NEITHER; [ "$m" = "$h" ] && s=head; [ "$m" = "$d" ] && s="$s+develop"; echo "  $s $p"; done
# conflicting negative control: develop-side edit of a line in the hook that the PR rewrites
L=$(g diff -U0 $D0 $H -- .githooks/pre-push | grep -m1 '^@@' | sed -E 's/^@@ -([0-9]+).*/\1/')
HB=$( g show $D:.githooks/pre-push | awk -v L=$L 'NR==L{print $0" # gate-conflict-control"; next}{print}' | g hash-object -w --stdin )
HT=$(g ls-tree $D .githooks | awk '{print $3}')
HT2=$(g ls-tree $HT | awk -v b=$HB '$4=="pre-push"{print $1" "$2" "b"\t"$4; next}{print}' | g mktree)
T3=$(g ls-tree $D | awk -v b=$HT2 '$4==".githooks"{print $1" "$2" "b"\t"$4; next}{print}' | g mktree)
C2=$(echo "gate control: conflict on hook line $L" | GIT_AUTHOR_NAME=gate GIT_AUTHOR_EMAIL=g@x GIT_COMMITTER_NAME=gate GIT_COMMITTER_EMAIL=g@x g commit-tree $T3 -p $D)
echo "== NEGATIVE CONTROL merge-tree (develop + edit of hook line $L, a line the PR's first hunk rewrites) vs head =="
g merge-tree --write-tree --name-only $C2 $H 2>&1; echo "control merge-tree rc=$? (1 = conflict detected)"
echo
echo "== EVIL-MERGE CHECK of the head's merge commit =="
M=$(g rev-list --merges $D0..$H); echo "merge commits in D0..head: $M"
for m in $M; do P1=$(g rev-parse $m^1); P2=$(g rev-parse $m^2); echo "merge=$m p1=$P1 ($(g log -1 --format=%s $P1)) p2=$P2"
 echo "-- auto-merge of parents:"; am=$(g merge-tree --write-tree --name-only $P1 $P2 2>&1); amrc=$?; echo "$am" | sed -n '1,12p'; echo "auto-merge rc=$amrc"; AT=$(echo "$am"|head -1)
 echo "-- paths where merge commit differs from the auto-merge tree (incl. conflict-marker blobs):"; g diff --name-only $AT $m
 echo "-- per path changed by the merge vs either parent: merge blob equals p1 / p2 / NEITHER"
 for p in $( (g diff --name-only $P1 $m; g diff --name-only $P2 $m) | sort -u); do b=$(g rev-parse -q --verify $m:$p); b1=$(g rev-parse -q --verify $P1:$p); b2=$(g rev-parse -q --verify $P2:$p); s=""; [ "$b" = "$b1" ] && s=p1; [ "$b" = "$b2" ] && s="$s+p2"; [ -z "$s" ] && s=NEITHER; echo "  $s $p"; done | sort | uniq -c -w8 | head -3
 echo "   (full list:)"; for p in $( (g diff --name-only $P1 $m; g diff --name-only $P2 $m) | sort -u); do b=$(g rev-parse -q --verify $m:$p); b1=$(g rev-parse -q --verify $P1:$p); b2=$(g rev-parse -q --verify $P2:$p); s=""; [ "$b" = "$b1" ] && s=p1; [ "$b" = "$b2" ] && s="${s}+p2"; [ -z "$s" ] && s=NEITHER; echo "  $s $p"; done
 echo "-- blob claim: on each conflicted path, develop(D0) blob == 1540 head blob (so --ours lost nothing of develop's), and p1 has 1540 head as ancestor"
 echo "   h1540 ancestor of p1: $(g merge-base --is-ancestor $H1540 $P1 && echo yes || echo no)"
 for p in $(echo "$am" | sed -n '2,$p' | grep -v '^$' | grep -v '^Auto-merging' | grep -v '^CONFLICT'); do echo "   $p D0=$(g rev-parse --short -q --verify $D0:$p) h1540=$(g rev-parse --short -q --verify $H1540:$p) p1=$(g rev-parse --short -q --verify $P1:$p) merge=$(g rev-parse --short -q --verify $m:$p) mergebase(p1,p2)=$(g rev-parse --short -q --verify $(g merge-base $P1 $P2):$p)"; done
 echo "   develop changes on conflicted paths between h1540 and D0 (must be empty for --ours to be lossless):"; g diff --stat $H1540 $D0 -- $(echo "$am" | sed -n '2,$p' | grep -v '^$' | grep -v '^Auto-merging' | grep -v '^CONFLICT')
done
