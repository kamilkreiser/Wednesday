# Tiny HTTP listener for the gate-1545 lock/env attack harness. Serves TGZ (argv[2]) for any path ending .tgz,
# a packument for any other path, and appends one line per request to LOG (argv[3]). Writes its port to argv[1].
import http.server, json, sys, os, hashlib, base64
portfile, tgz, log = sys.argv[1], sys.argv[2], sys.argv[3]
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        auth = 'auth=yes' if self.headers.get('Authorization') else 'auth=no'
        with open(log, 'a') as f: f.write(f"GET {self.path} {auth}\n")
        if self.path.endswith('.tgz'):
            b = open(os.environ.get('SRV_TGZ_OVERRIDE') or tgz, 'rb').read() if not os.path.exists(tgz + '.swap') else open(tgz + '.swap', 'rb').read()
            self.send_response(200); self.send_header('Content-Type', 'application/octet-stream'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
        else:
            self.send_response(404); self.end_headers()
s = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H)
open(portfile, 'w').write(str(s.server_address[1]))
s.serve_forever()
