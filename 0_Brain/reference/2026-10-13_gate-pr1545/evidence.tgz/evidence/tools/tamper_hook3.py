#!/usr/bin/env python3
"""Mutation proof for the item 2 hook. Copies of the hook run through the three hook-level suites via HOOK_SH.
A mutant is KILLED BY NAME only if every cell named in advance is among the FAIL lines of ANY of the suites."""
import datetime, os, re, subprocess, sys
HOOK, OUT = sys.argv[1], sys.argv[2]
D = os.path.dirname(HOOK) + "/../Blockchain/Dev/scripts/__tests__/"
SUITES = [D + "ks998_pre_push_judges_the_push.test.sh", D + "ks998_pre_push_stale_base_hint.test.sh", D + "pre_push_hook_base.test.sh"]
os.makedirs(OUT, exist_ok=True)
src = open(HOOK, encoding="utf-8").read()
now = lambda: datetime.datetime.now(datetime.timezone.utc).strftime("%H:%M:%SZ")
M = []
def mut(name, edits, kills, survive=None): M.append((name, edits, kills, survive))
TIPLINE = '''    _tip=$(git rev-parse --verify --quiet "${_jr_lsha}^{commit}" 2>/dev/null) || _tip=''\n'''
DELLINE = '''    [ "$_jr_lsha" = "$ZERO" ] && { _jr_skip=delete; return 0; }     # deleting a ref rewrites nothing and archives nothing\n'''
FC = '''    if [ -n "$changed" ] && [ "$_tip" != "$_head_c" ]; then\n'''
mut("h01_gate_judges_head_not_the_pushed_tip", [('FORMAT_GATE_TREE="$_tip" FORMAT_GATE_BASE_MAY_BE_STALE=', 'FORMAT_GATE_TREE="$_head_c" FORMAT_GATE_BASE_MAY_BE_STALE=')],
    ["SC2 pushing a branch that is NOT checked out: its red systemTest file is caught"])
mut("h02_no_fail_closed_refusal", [(FC, '    if false; then\n')],
    ["SC3 a pushed sha that is not HEAD and changes Blockchain/Dev is REFUSED", "SC11 HEAD plus a not-checked-out Blockchain/Dev ref: the whole push is refused"])
mut("h03_refuses_every_non_head_ref", [(FC, '    if [ "$_tip" != "$_head_c" ]; then\n')],
    ["...naming the pushed file"])
mut("h04_deleted_ref_archived", [(DELLINE, ''), (TIPLINE, '    _tip="$_jr_lsha"\n')],
    ["SC5 deleting a remote branch goes through"])
mut("h04b_delete_guard_dropped_ALONE", [(DELLINE, '')],
    ["...and no misleading 'not a commit' note for the all-zero sha"])
mut("h05_remote_sha_ignored_for_existing_branches", [('    if [ -n "$_jr_rsha" ] && [ "$_jr_rsha" != "$ZERO" ] && git cat-file -e "${_jr_rsha}^{commit}" 2>/dev/null; then', '    if false; then')],
    ["SC8 a docs-only push to an existing branch is NOT refused for the untouched pkgA"])
mut("h06_upstream_step_dropped", [('    if [ -n "$_jr_up" ]; then\n        all_changed=$(git -c core.quotePath=false diff --name-only "$_jr_up" "$_tip"', '    if false; then\n        all_changed=$(git diff --name-only "$_jr_up" "$_tip"')],
    ["trunk as upstream, pkgA not installable: REFUSED"])
mut("h07_tags_get_the_unconditional_rule", [('    case "$_jr_lref" in refs/tags/*)\n', '    case "$_jr_lref" in refs/tags-off/*)\n')],
    ["SC21 a tag whose commit every base contains (and the remote lacks) lands with a note: no preflight, no refusal"])
mut("h08_non_commit_objects_gated", [('    [ -n "$_tip" ] || { _jr_skip=notcommit; return 0; }              # a tag of a blob or a tree is not code\n', '')],
    ["SC9c a tag that points at a BLOB is not a commit: not gated, said so, and lands"])
mut("h09_blockchain_dev_change_not_accumulated", [('    _changed_all="${_changed_all}${changed}"\n', '')],
    ["SC4 HEAD:other-name with a Blockchain/Dev change runs the preflight and lands"])
mut("h10_stale_flag_inverted_for_upstreams", [('        if [ "${_jr_up#*/}" != "$_jr_brname" ]; then st_base_stale=1; fi', '        if [ "${_jr_up#*/}" = "$_jr_brname" ]; then st_base_stale=1; fi')],
    ["...WITH the stale-base hint (that upstream is not this branch's own counterpart)"])
mut("h11_stale_flag_not_set_for_new_branches", [('    st_base_stale=1   # KS-998 item 1: a merge-base with origin/develop is only as fresh as the last fetch\n', '')],
    ["...and the hint: your origin/develop may be stale"])
mut("h12_gate_failure_does_not_refuse", [('    echo "           (bypass, sparingly: git push --no-verify)" >&2\n    exit 1\n}', '    echo "           (bypass, sparingly: git push --no-verify)" >&2\n}')],
    ["SC1 red at the pushed sha, fix uncommitted: the push is REFUSED"])
mut("h13_failing_ref_not_named", [('    echo "           ref: ${_lr} -> ${_rr} (commit $(_short "$_tip"))" >&2\n', '')],
    ["...the failing ref is named"])
mut("h14_force_push_judged_from_the_remote_tip", [('''        if git merge-base --is-ancestor "$_jr_rsha" "$_tip" 2>/dev/null; then
            _jr_b="$_jr_rsha"
        else
            _jr_b=$(git merge-base "$_jr_rsha" "$_tip" 2>/dev/null) || _jr_b=''      # a deliberate force push
        fi''', '        _jr_b="$_jr_rsha"')],
    ["SC12 ALLOW_FORCE=1: the rewrite goes through (docs only; pkgA's removal is not 'in this push')"])
mut("h15_tip_is_always_head", [(TIPLINE, '    _tip=$(git rev-parse HEAD 2>/dev/null)\n')],
    ["SC2 pushing a branch that is NOT checked out: its red systemTest file is caught", "SC3 a pushed sha that is not HEAD and changes Blockchain/Dev is REFUSED"])
mut("h16_all_mode_gate_runs_in_the_working_tree", [('FORMAT_GATE_TREE="$_tip" bash "$_fmt_gate" --all </dev/null', 'bash "$_fmt_gate" --all </dev/null')],
    ["SC13 --all (no base): the PUSHED red commit is refused though the working tree is fixed"])
mut("h17_tag_skip_applies_to_branches_too", [('    case "$_jr_lref" in refs/tags/*)\n', '    case "$_jr_lref" in refs/*)\n')],
    ["SC13 --all (no base): the PUSHED red commit is refused though the working tree is fixed"])
mut("h18_ref_lines_not_kept_for_judging", [('done <<EOF\n$_ref_lines\nEOF\nchanged="$_changed_all"', 'done </dev/null\nchanged="$_changed_all"')],
    ["SC1 red at the pushed sha, fix uncommitted: the push is REFUSED"])

# ================= gate verdict on #1540: Minor 1, Minor 2 (hook half), Minor 4 (X02, X04), Info 4 =================
ONR = '    if [ -n "$(git for-each-ref --contains "$_tip" "refs/remotes/${_remote}/" 2>/dev/null)" ]; then _jr_skip=onremote; return 0; fi\n'
mut("h20_already_on_the_remote_not_checked", [(ONR, '')],
    ["SC14a a tag on a commit the remote already has lands (rc 0), runs nothing, is not refused", "SC15 a new branch at a commit the remote already has lands, with HEAD elsewhere"])
mut("h21_onremote_looks_at_origin_only", [(ONR, ONR.replace('refs/remotes/${_remote}/', 'refs/remotes/origin/'))],
    ["SC20a the tag goes to the remote that already has the commit: lands, not refused"])
mut("h22_onremote_looks_at_every_remote", [(ONR, ONR.replace('refs/remotes/${_remote}/', 'refs/remotes/'))],
    ["SC20b the same tag to the remote that does NOT have it is still refused (HEAD is elsewhere)"])
mut("h23_remote_name_fixed_to_origin", [('_remote="${1:-origin}"', '_remote="origin"')],
    ["SC20a the tag goes to the remote that already has the commit: lands, not refused"])
BANNER = "    [ -z \"$_jr_banner\" ] || printf '%s\\n' \"$_jr_banner\" >&2      # only now: the run it announces really follows\n"
REFUSE = '    if [ -n "$changed" ] && [ "$_tip" != "$_head_c" ]; then\n'
mut("h24_banner_printed_before_the_refusal", [(BANNER, ''), (REFUSE, BANNER.replace("      # only now: the run it announces really follows", "") + REFUSE)],
    ["...and the 'Running the preflight UNCONDITIONALLY' banner is NOT printed before the refusal"])
mut("h25_banner_never_printed", [(BANNER, '')],
    ["SC16b the same push with the tip CHECKED OUT: the banner is printed and the preflight runs (KS-882 still holds)"])
mut("h26_refusal_skipped_for_tags", [(REFUSE, '    if [ -n "$changed" ] && [ "$_tip" != "$_head_c" ] && [ "${_lr#refs/tags/}" = "$_lr" ]; then\n')],
    ["SC14b a tag on a NOT-pushed commit that changes Blockchain/Dev and is not checked out is still REFUSED"])
mut("h27_head_taken_from_the_upstream", [("_head_c=$(git rev-parse --verify --quiet 'HEAD^{commit}' 2>/dev/null || true)", "_head_c=$(git rev-parse --verify --quiet '@{upstream}^{commit}' 2>/dev/null || true)")],
    ["SC17 a HEAD push from a tracking branch that changes Blockchain/Dev is not refused: the preflight runs and it lands"])
mut("h28_quotepath_on_for_new_branches", [('        _files=$(git -c core.quotePath=false diff --name-only "$_b" "$_tip" || true)', '        _files=$(git diff --name-only "$_b" "$_tip" || true)')],
    ["SC18 a red file in a non-ASCII package is caught in the push"])
mut("h29_quotepath_on_for_existing_branches", [('            all_changed=$(git -c core.quotePath=false diff --name-only "$_jr_b" "$_tip" 2>/dev/null || true)', '            all_changed=$(git diff --name-only "$_jr_b" "$_tip" 2>/dev/null || true)')],
    ["SC18b a red non-ASCII file pushed to a branch that EXISTS at the remote is caught"])
mut("h30_quotepath_on_for_upstreams", [('        all_changed=$(git -c core.quotePath=false diff --name-only "$_jr_up" "$_tip" 2>/dev/null || true)', '        all_changed=$(git diff --name-only "$_jr_up" "$_tip" 2>/dev/null || true)')],
    ["SC18c a red non-ASCII file pushed from a branch with an UPSTREAM is caught"])
mut("h31_unborn_head_captured_as_the_word_HEAD", [("_head_c=$(git rev-parse --verify --quiet 'HEAD^{commit}' 2>/dev/null || true)", "_head_c=$(git rev-parse HEAD 2>/dev/null || true)")],
    ["SC19 the refusal on an unborn HEAD says so, not 'HEAD is HEAD'"])
mut("h32_unborn_wording_dropped", [("        _hd=$(_short \"$_head_c\"); [ -n \"$_hd\" ] || _hd='not a commit yet (an unborn branch)'\n", "        _hd=$(_short \"$_head_c\")\n")],
    ["SC19 the refusal on an unborn HEAD says so, not 'HEAD is HEAD'"])
mut("h33_onremote_note_silent", [('            echo "[pre-push] note: ${_lr} ($(_short "$_tip")) is already on the remote (${_remote}) — it sends no commit the remote lacks; not gated." >&2\n', '')],
    ["...and says why it was not gated (already on the remote)"])
def run(path, tag):
    fails = []; tallies = []
    for su in SUITES:
        p = subprocess.run(["/bin/bash", su], capture_output=True, text=True, env=dict(os.environ, HOOK_SH=path), timeout=400)
        open(f"{OUT}/{tag}.{os.path.basename(su)}.out", "w").write(p.stdout)
        m = re.findall(r"(\d+) passed, (\d+) failed", p.stdout); tallies.append((int(m[-1][0]), int(m[-1][1])) if m else (0, 0))
        fails += [l.strip()[5:] for l in p.stdout.splitlines() if l.strip().startswith("FAIL ")]
    return tallies, fails
if os.environ.get("CHECK_ANCHORS"):
    bad = 0
    for name, edits, kills, survive in M:
        s2 = src
        for old, new in edits:
            if s2.count(old) != 1: print(f"ANCHOR-ERROR {name}: found {s2.count(old)}x: {old[:80]!r}"); bad += 1; break
            s2 = s2.replace(old, new, 1)
        else:
            open(f"{OUT}/_anchor_check.sh", "w").write(s2)
            if subprocess.run(["/bin/sh", "-n", f"{OUT}/_anchor_check.sh"], capture_output=True).returncode: print(f"DOES-NOT-PARSE {name}"); bad += 1
    print(f"anchor check: {len(M)} hook mutants, {bad} problems"); sys.exit(1 if bad else 0)
t, f = run(HOOK, "00_control")
ok = all(b == 0 and a > 0 for a, b in t)
print(f"[{now()}] CONTROL unmutated hook: {t} -> {'GREEN' if ok else 'NOT GREEN - ABORT'}", flush=True)
if not ok: sys.exit(3)
res = {}
for name, edits, kills, survive in M:
    s = src; bad = None
    for old, new in edits:
        if s.count(old) != 1: bad = f"anchor found {s.count(old)}x: {old[:70]!r}"; break
        s = s.replace(old, new, 1)
    if bad: print(f"[{now()}] {name}: ANCHOR-ERROR {bad}", flush=True); res[name] = "ANCHOR-ERROR"; continue
    path = f"{OUT}/{name}.sh"; open(path, "w", encoding="utf-8").write(s)
    if subprocess.run(["/bin/sh", "-n", path], capture_output=True).returncode: print(f"[{now()}] {name}: DOES-NOT-PARSE", flush=True); res[name] = "LOADFAIL"; continue
    t, fails = run(path, name)
    if all(a == 0 and b == 0 for a, b in t): v = "LOADFAIL"
    elif sum(b for _, b in t) == 0: v = "SURVIVED-BY-DESIGN" if survive else "SURVIVED"
    else:
        miss = [k for k in kills if not any(k in x for x in fails)]
        v = "KILLED-BY-NAME" if kills and not miss else ("KILLED-BUT-NOT-BY-THE-NAMED-CELL" if kills else "KILLED (no name)")
    res[name] = v
    print(f"[{now()}] {name}: {v}  {t}" + (f"  MISSING {miss}" if v.startswith("KILLED-BUT") else "") + ("" if v.startswith("KILLED") else f"  first fails: {fails[:2]}"), flush=True)
import collections, json
print(f"[{now()}] DONE", dict(collections.Counter(res.values())), flush=True)
json.dump(res, open(f"{OUT}/results.json", "w"), indent=1)
