#!/bin/bash
# push_matrix.sh <hook> <gate> <workdir(new)> : real `git push` to bare remotes, one scenario per row (gate 1545).
# Columns: rc | landed (refs at the remote) | preflight ran | not-HEAD refusal | gate FAILED | onremote note | UNCONDITIONALLY banner
# (the script changes directory inside its OWN process only; it never deletes anything)
set -u
HOOK=$1; GATE=$2; W=$3
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
export npm_config_cache="$W/npm-cache" npm_config_registry="http://127.0.0.1:9/"
mkdir -p "$W/npm-cache"
build() {
  local r=$W/$1
  (
  set -e
  mkdir -p $r; git init -q --bare -b main $r/origin.git; git init -q --bare -b main $r/fork.git
  git init -q -b main $r/seed; cd $r/seed
  git config user.email t@t.t; git config user.name t
  mkdir -p Blockchain/Dev/scripts/preflight systemTest/scripts "systemTest/pkgB/src" docs
  echo base > Blockchain/Dev/file.txt; echo docs > docs/readme.md
  printf '#!/usr/bin/env bash\necho "[preflight] ran in $(git rev-parse --short HEAD)"\nexit 0\n' > Blockchain/Dev/scripts/preflight/preflight.sh
  : > systemTest/slot-target.sh
  cp "$GATE" systemTest/scripts/check-package-format.sh
  printf 'node_modules/\nsystemTest/.format-gate-stage.*/\nsystemTest/.format-gate-tree.*/\nsystemTest/.format-gate-aside.*/\n' > .gitignore
  printf '{ "name": "fixture-pkgB", "version": "0.0.0", "scripts": { "format:check": "sh check.sh" } }\n' > systemTest/pkgB/package.json
  cat > systemTest/pkgB/check.sh <<'SH'
bad=$(find src \( -type f -o -type l \) -exec sh -c 'for f; do [ "$(cat "$f" 2>/dev/null)" = good ] || echo "[warn] $f"; done' sh {} +)
[ -z "$bad" ] || { echo "$bad"; exit 1; }
exit 0
SH
  echo good > systemTest/pkgB/src/b.ts
  git add -A; git commit -qm init; git branch develop
  git remote add origin $r/origin.git; git push -q origin main develop
  git remote add fork $r/fork.git; git push -q fork main develop
  cd $r; git clone -q $r/origin.git fresh; cd fresh
  git config user.email t@t.t; git config user.name t
  git remote add fork $r/fork.git; git fetch -q fork
  mkdir -p .githooks; cp "$HOOK" .githooks/pre-push; chmod +x .githooks/pre-push
  git config core.hooksPath .githooks; echo '.githooks/' >> .git/info/exclude
  mkdir -p systemTest/pkgB/node_modules/.bin
  printf '#!/bin/sh\nexit 0\n' > systemTest/pkgB/node_modules/.bin/prettier; chmod +x systemTest/pkgB/node_modules/.bin/prettier
  ) >/dev/null 2>&1 || { echo "BUILD FAIL $1"; exit 2; }
  cd $r/fresh
}
c() { mkdir -p "$(dirname "$1")"; printf '%s\n' "$2" > "$1"; git add -- "$1"; git commit -qm "touch $1"; }
has() { git ls-remote ${2:-origin} "$1" | wc -l | tr -d ' '; }
row() { # row <name> <ref-to-check-landed|-> <git push args...>
  local name=$1 ref=$2; shift 2
  local out rc rem=$1
  out=$(git push "$@" 2>&1); rc=$?
  printf '%-66s rc=%-3s landed=%s preflight=%s notHEAD=%s gateFAILED=%s onremote=%s banner=%s\n' "$name" "$rc" "$( [ "$ref" = - ] && echo - || has "$ref" "$rem")" \
    "$(printf '%s' "$out" | grep -c '\[preflight\] ran')" "$(printf '%s' "$out" | grep -c 'REFUSED — this push sends')" \
    "$(printf '%s' "$out" | grep -c 'formatting gate FAILED')" "$(printf '%s' "$out" | grep -c 'is already on the remote')" "$(printf '%s' "$out" | grep -c -i 'UNCONDITIONALLY')"
  { echo "=== $name"; printf '%s\n' "$out" | sed 's/^/      | /'; } >> $W/full.log
}
echo "hook md5=$(md5 -q $HOOK) gate md5=$(md5 -q $GATE)"
# ---- 1540 Minor 1 shapes
build r4; git checkout -q -b f4 --no-track origin/develop; c Blockchain/Dev/file.txt x; git push -q --no-verify origin f4; git tag t4; git checkout -q main
row "R4 tag on ALREADY-PUSHED feature commit (Blockchain/Dev), HEAD=main" refs/tags/t4 origin t4
git checkout -q -b f4c --no-track origin/develop; c Blockchain/Dev/file.txt notpushed; git tag t4c; git checkout -q main
row "R4c tag on NOT-pushed, not-checked-out Blockchain/Dev commit" refs/tags/t4c origin t4c
row "R4d same tag t4 pushed to the SECOND remote (fork lacks it)" refs/tags/t4 fork t4
build r12; git checkout -q -b f12 --no-track origin/develop; c docs/readme.md q
row "R12b origin/develop:refs/heads/rel2 (nothing new), HEAD=f12" refs/heads/rel2 origin origin/develop:refs/heads/rel2
git checkout -q -b f12c --no-track origin/develop; c Blockchain/Dev/file.txt pushedfeat; git push -q --no-verify origin f12c; git checkout -q f12
row "R12c new branch at an already-pushed FEATURE commit (BD), HEAD elsewhere" refs/heads/n12c origin f12c:refs/heads/n12c
row "R12d the same commit to the SECOND remote fork (fork lacks it)" refs/heads/n12d fork f12c:refs/heads/n12d
# ---- the trunk fast-forwarded to an already-pushed feature commit: once gated, now?
build r20; git checkout -q -b f20 --no-track origin/develop; c Blockchain/Dev/file.txt feat20; c systemTest/pkgB/src/r.ts bad; git push -q --no-verify origin f20
git checkout -q develop 2>/dev/null || git checkout -q -b develop --track origin/develop; git merge -q --ff-only f20
row "R20 HEAD=develop ff to already-pushed RED feature (BD+systemTest): push develop" - origin develop
build r21; git checkout -q -b f21 --no-track origin/develop; c systemTest/pkgB/src/r.ts bad; git push -q --no-verify origin f21; git checkout -q main
row "R21 f21:develop, RED systemTest commit already on origin/f21, not HEAD" - origin f21:develop
# ---- stale tracking refs (author's (d)): the remote NO LONGER has the commit, the local tracking ref says it does
build r22; git checkout -q -b f22 --no-track origin/develop; c systemTest/pkgB/src/r.ts bad; c Blockchain/Dev/file.txt f22; git push -q --no-verify origin f22
git --git-dir=$W/r22/origin.git update-ref -d refs/heads/f22    # someone deletes the branch at the remote (e.g. after a squash merge)
git checkout -q main
echo "      [R22 setup] remote has f22? $(has refs/heads/f22)  local refs/remotes/origin/f22 still there? $(git rev-parse -q --verify refs/remotes/origin/f22 >/dev/null && echo yes || echo no)  remote branches containing the commit: $(git --git-dir=$W/r22/origin.git branch --contains $(git rev-parse f22) 2>/dev/null | wc -l | tr -d ' ')"
row "R22 STALE: f22 deleted at remote, tracking ref kept; f22:again (RED, BD), HEAD=main" refs/heads/again origin f22:refs/heads/again
build r22b; git checkout -q -b f22 --no-track origin/develop; c systemTest/pkgB/src/r.ts bad; c Blockchain/Dev/file.txt f22; git push -q --no-verify origin f22
git --git-dir=$W/r22b/origin.git update-ref -d refs/heads/f22
row "R22b STALE: same shape, HEAD = f22 (own fixture)" refs/heads/again2 origin f22:refs/heads/again2
build r22c; git checkout -q -b f22 --no-track origin/develop; c systemTest/pkgB/src/r.ts bad; c Blockchain/Dev/file.txt f22; git push -q --no-verify origin f22
git --git-dir=$W/r22c/origin.git update-ref -d refs/heads/f22; git checkout -q main; git fetch -q --prune origin
row "R22c CONTROL: R22 after git fetch --prune (tracking ref fresh)" refs/heads/again3 origin f22:refs/heads/again3
build r23; git checkout -q -b f23 --no-track origin/develop; c systemTest/pkgB/src/r.ts bad; git push -q --no-verify origin f23
git --git-dir=$W/r23/origin.git update-ref refs/heads/f23 $(git rev-parse origin/develop)   # someone force-moves f23 at the remote
git checkout -q main
row "R23 STALE: f23 force-moved at remote; push f23 (RED) as n23, HEAD=main" refs/heads/n23 origin f23:refs/heads/n23
build r23b; git checkout -q -b f23 --no-track origin/develop; c systemTest/pkgB/src/r.ts bad; git push -q --no-verify origin f23
git --git-dir=$W/r23b/origin.git update-ref refs/heads/f23 $(git rev-parse origin/develop); git checkout -q main; git fetch -q --prune origin
row "R23b CONTROL: R23 after git fetch (tracking ref fresh)" refs/heads/n23b origin f23:refs/heads/n23b
# ---- other shapes from the brief
build r30; git checkout -q -b f30 --no-track origin/develop; c systemTest/pkgB/src/g.ts good
git checkout -q -b b30 --no-track origin/develop; c systemTest/pkgB/src/g.ts bad
git checkout -q -b d30 --no-track origin/develop; c docs/readme.md z; git checkout -q main
row "R30 several refs, one RED (d30 docs, f30 green, b30 RED)" refs/heads/f30 origin d30 f30 b30
row "R31 deletion of an existing branch" - origin :develop
git checkout -q --detach origin/main; c Blockchain/Dev/file.txt det
row "R32 detached HEAD:refs/heads/det (Blockchain/Dev)" refs/heads/det origin HEAD:refs/heads/det
build r33; git checkout -q -b f33 --no-track origin/develop; c systemTest/pkgB/src/w.ts good; echo bad > systemTest/pkgB/src/w.ts
row "R33 dirty tree: commit GREEN, working tree RED" refs/heads/f33 origin f33
git checkout -q -- .; c systemTest/pkgB/src/w.ts bad; echo good > systemTest/pkgB/src/w.ts
row "R33b dirty tree: commit RED, working tree GREEN" - origin f33
git checkout -q -- .
build r34; git checkout -q -b f34 --no-track origin/develop; c Blockchain/Dev/file.txt up; git push -q --no-verify -u origin f34; c Blockchain/Dev/file.txt up2
row "R34 HEAD branch WITH upstream (X04 shape), Blockchain/Dev" refs/heads/f34 origin f34
build r35; git checkout -q -b f35 --no-track origin/develop; c Blockchain/Dev/file.txt u; git checkout -q --orphan unborn; git rm -rq --cached . >/dev/null
row "R35 unborn HEAD, push f35 (Blockchain/Dev)" refs/heads/f35 origin f35
echo DONE
