#!/bin/bash
# Gate 1545 (A) install environment: what a REAL lifecycle script (real npm, real gate at the head) is handed.
# Planted values all contain PLANTED; the dump prints only planted values and a few structural keys, everything else as <present>.
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1545
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1545/evidence
GATE=${GATE_UNDER_TEST:-$S/gates/gate_50f0552ce.sh}
W=$S/env_$(date +%H%M%S)_$$; mkdir -p $W/hits $W/cases; export TMPDIR=$S/tmp
SENT=$W/hits/hits.log; SRVLOG=$W/srv.log; : > $SRVLOG; PN=gate1545-probe-dep
mkdir -p $W/src/pkg; printf '{ "name": "%s", "version": "1.0.0", "scripts": { "postinstall": "node pi.js" } }\n' $PN > $W/src/pkg/package.json
cat > $W/src/pkg/pi.js <<J
const fs=require('fs'),os=require('os'),path=require('path');
const keep=/^(HOME|TERM|TMPDIR|LANG|LC_ALL|npm_config_cache|npm_config_userconfig|npm_lifecycle_event|INIT_CWD)$/;
const env={}; for (const [k,v] of Object.entries(process.env)) env[k]=(keep.test(k)||/PLANTED/.test(v))?v:'<present>';
let realhome=''; try{realhome=os.userInfo().homedir}catch(e){}
let cacheWrite='n/a'; if(process.env.npm_config_cache){try{fs.writeFileSync(path.join(process.env.npm_config_cache,'WRITTEN_BY_INSTALL_SCRIPT'),'x');cacheWrite='yes'}catch(e){cacheWrite='no:'+e.code}}
let agent=false; try{agent=fs.readdirSync('/private/tmp').some(d=>d.startsWith('com.apple.launchd.')&&fs.existsSync('/private/tmp/'+d+'/Listeners'))}catch(e){}
let npmrcReadable=false; try{fs.accessSync(realhome+'/.npmrc',fs.constants.R_OK);npmrcReadable=true}catch(e){}
fs.appendFileSync('$SENT', JSON.stringify({cwd:process.cwd(),realhome_via_os_userInfo:realhome,real_npmrc_readable_by_abs_path:npmrcReadable,launchd_agent_socket_findable:agent,cacheWrite,env},null,1)+'\n');
J
( cd $W/src/pkg && npm pack --pack-destination $W/src --cache $W/packcache --silent ) >/dev/null 2>&1
TGZ=$W/src/$PN-1.0.0.tgz; INTEG="sha512-$(openssl dgst -sha512 -binary $TGZ | base64 | tr -d '\n')"
python3 -I $EV/tools/srv.py $W/port $TGZ $SRVLOG & SRVPID=$!
for i in 1 2 3 4 5 6 7 8 9 10; do [ -s $W/port ] && break; sleep 0.3; done; PORT=$(cat $W/port); LOC="http://127.0.0.1:$PORT"
echo "gate md5=$(md5 -q $GATE) npm=$(npm -v) port=$PORT"
mkcase() { local r=$W/cases/$1; mkdir -p $r/systemTest/scripts $r/systemTest/p; cp $GATE $r/systemTest/scripts/check-package-format.sh
  printf '{ "name": "p", "version": "1.0.0", "scripts": { "format:check": "exit 0" }, "dependencies": { "%s": "1.0.0" } }\n' $PN > $r/systemTest/p/package.json
  printf '{"name":"p","version":"1.0.0","lockfileVersion":3,"requires":true,"packages":{"":{"name":"p","version":"1.0.0","dependencies":{"%s":"1.0.0"}},"node_modules/%s":{"version":"1.0.0","resolved":"%s/%s-1.0.0.tgz","integrity":"%s","hasInstallScript":true}}}\n' $PN $PN "$LOC" $PN "$INTEG" > $r/systemTest/p/package-lock.json; echo $r; }
FAKEHOME=$W/fakehome; mkdir -p $FAKEHOME/.npm; printf '//127.0.0.1:%s/:_authToken=PLANTED-token-in-home-npmrc\n' $PORT > $FAKEHOME/.npmrc
echo "== E1: a developer shell full of secrets; registry and proxy URLs carry userinfo (Wednesday's case 1); npm_config_cache unset, ~/.npm exists"
r=$(mkcase E1)
( cd $r && printf 'systemTest/p/x.ts\n' | env -i PATH="$PATH" HOME=$FAKEHOME TMPDIR=$TMPDIR LANG=en_AU.UTF-8 TERM=xterm \
  FORMAT_GATE_LOCK_ALLOW="$LOC/" \
  NPM_TOKEN=PLANTED-NPM_TOKEN GITHUB_TOKEN=PLANTED-GITHUB_TOKEN GH_TOKEN=PLANTED-GH_TOKEN NODE_AUTH_TOKEN=PLANTED-NODE_AUTH_TOKEN \
  AWS_ACCESS_KEY_ID=PLANTED-AKID AWS_SECRET_ACCESS_KEY=PLANTED-AWS-SECRET AWS_SESSION_TOKEN=PLANTED-AWS-SESSION AZURE_CLIENT_SECRET=PLANTED-AZ \
  SSH_AUTH_SOCK=/tmp/PLANTED-agent.sock GIT_ASKPASS=/PLANTED/askpass NODE_OPTIONS=--title=PLANTED-node-options DATABASE_URL=postgres://u:PLANTED-dbpw@h/db \
  npm_config__authToken=PLANTED-authToken npm_config__auth=PLANTED-auth npm_config__password=PLANTED-password NPM_CONFIG_PASSWORD=PLANTED-PW2 \
  npm_config_otp=PLANTED-otp-123456 npm_config_username=PLANTED-username npm_config_email=PLANTED@example.invalid \
  npm_config_certfile=/PLANTED/cert npm_config_keyfile=/PLANTED/key npm_config_ca=PLANTED-ca-pem npm_config_cafile=/PLANTED/cafile \
  npm_config_credential_helper=PLANTED-cred npm_config_bearer=PLANTED-bearer npm_config_sig=PLANTED-sig npm_config_jwt=PLANTED-jwt npm_config_pat=PLANTED-pat npm_config_session=PLANTED-session npm_config_cookie=PLANTED-cookie npm_config_apikey=PLANTED-apikey npm_config_api_key=PLANTED-api_key npm_config_pwd=PLANTED-pwd npm_config_passwd=PLANTED-passwd npm_config_private=PLANTED-private npm_config_signature=PLANTED-signature \
  npm_config_registry="http://PLANTEDuser:PLANTEDpw@127.0.0.1:$PORT/" npm_config_https_proxy="http://PLANTEDpxu:PLANTEDpxp@127.0.0.1:9/" npm_config_proxy="http://PLANTEDpxu2:PLANTEDpxp2@127.0.0.1:9/" \
  HTTPS_PROXY="http://PLANTEDu:PLANTEDp@127.0.0.1:9/" NO_PROXY="127.0.0.1,localhost" no_proxy="127.0.0.1,localhost" Npm_Config_Mixed=PLANTED-mixedcase \
  MY_EXTRA=PLANTED-extra FORMAT_GATE_INSTALL_ENV_PASS="MY_EXTRA" \
  bash $r/systemTest/scripts/check-package-format.sh ) > $W/E1.out 2>&1; echo "gate rc=$?  $(grep -o -E 'INSTALLED[^:]*|could not install its deps \(npm ci exited [0-9]+' $W/E1.out | head -1)"
echo "-- the script's environment (keys sorted):"; node -e 'const l=require("fs").readFileSync(process.argv[1],"utf8").trim();const o=JSON.parse(l);const e=o.env;delete o.env;console.log(JSON.stringify(o,null,1));for(const k of Object.keys(e).sort())console.log("  "+k+"="+e[k])' $SENT
echo "-- planted names the script did NOT receive:"; for n in NPM_TOKEN GITHUB_TOKEN GH_TOKEN NODE_AUTH_TOKEN AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AZURE_CLIENT_SECRET SSH_AUTH_SOCK GIT_ASKPASS NODE_OPTIONS DATABASE_URL npm_config__authToken npm_config__auth npm_config__password NPM_CONFIG_PASSWORD npm_config_otp npm_config_username npm_config_email npm_config_certfile npm_config_keyfile npm_config_ca npm_config_cafile npm_config_credential_helper npm_config_bearer npm_config_sig npm_config_jwt npm_config_pat npm_config_session npm_config_cookie npm_config_apikey npm_config_api_key npm_config_pwd npm_config_passwd npm_config_private npm_config_signature npm_config_registry npm_config_https_proxy npm_config_proxy HTTPS_PROXY Npm_Config_Mixed MY_EXTRA; do grep -q "\"$n\":" $SENT && echo "  RECEIVED $n" || echo "  withheld $n"; done
echo "-- does the PLANTED token in the fake ~/.npmrc reach the script anywhere in its env? $(grep -c 'PLANTED-token-in-home-npmrc' $SENT)"
echo "-- listener saw Authorization on the tarball GET (userinfo in npm_config_registry is used by npm):"; cat $SRVLOG
echo "-- cache: written by the install script into the developer's ~/.npm? $(ls $FAKEHOME/.npm/WRITTEN_BY_INSTALL_SCRIPT 2>/dev/null && echo YES || echo no)"
echo "== E2: bad FORMAT_GATE_INSTALL_ENV_PASS names"; for v in 'A-B' '1ABC' 'A=B' 'OK ALSO_OK' '$(id)' 'A*'; do r=$(mkcase E2_$RANDOM); ( cd $r && printf 'systemTest/p/x.ts\n' | env FORMAT_GATE_INSTALL_ENV_PASS="$v" FORMAT_GATE_LOCK_ALLOW="$LOC/" npm_config_cache=$W/c2 bash $r/systemTest/scripts/check-package-format.sh ) > $W/E2.out 2>&1; echo "  '$v' -> rc=$? $(grep -o 'FORMAT_GATE_INSTALL_ENV_PASS must[^(]*' $W/E2.out | head -1)"; done
kill $SRVPID; echo workdir=$W
