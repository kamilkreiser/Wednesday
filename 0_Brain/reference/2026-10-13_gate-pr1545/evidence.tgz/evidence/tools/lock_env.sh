#!/bin/bash
# Gate 1545: (A) lock-source check and install environment, against the REAL gate at the head (or GATE_UNDER_TEST), real npm,
# a local HTTP listener (no external network needed). Every refusal row has a control row in the same run that FETCHES and RUNS.
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1545
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1545/evidence
GATE=${GATE_UNDER_TEST:-$S/gates/gate_50f0552ce.sh}
W=$S/lock_$(date +%H%M%S)_$$; mkdir -p $W/hits $W/cases; export TMPDIR=$S/tmp
SENT=$W/hits/hits.log; SRVLOG=$W/srv.log; : > $SRVLOG
PN=gate1545-probe-dep
# --- the probe package: its postinstall records where it ran and what it was handed (planted values only; others "<present>")
mkdir -p $W/src/pkg; cat > $W/src/pkg/package.json <<J
{ "name": "$PN", "version": "1.0.0", "scripts": { "postinstall": "node pi.js" } }
J
cat > $W/src/pkg/pi.js <<J
const fs=require('fs'),os=require('os'),path=require('path');
const keep=/^(HOME|PATH|TERM|TMPDIR|LANG|npm_config_cache|npm_config_registry|npm_config_userconfig|npm_lifecycle_event|HTTPS_PROXY|https_proxy|npm_config_proxy|npm_config_https_proxy|INIT_CWD)$/;
const env={}; for (const [k,v] of Object.entries(process.env)) env[k]=(keep.test(k)||/PLANTED/.test(v))?v:'<present>';
let realhome=''; try{realhome=os.userInfo().homedir}catch(e){}
let cacheWrite='n/a'; if(process.env.npm_config_cache){try{fs.writeFileSync(path.join(process.env.npm_config_cache,'WRITTEN_BY_INSTALL_SCRIPT'),'x');cacheWrite='yes'}catch(e){cacheWrite='no:'+e.code}}
let agent=false; try{agent=fs.readdirSync('/private/tmp').some(d=>d.startsWith('com.apple.launchd.')&&fs.existsSync('/private/tmp/'+d+'/Listeners'))}catch(e){}
fs.appendFileSync('$SENT', JSON.stringify({cwd:process.cwd(),INIT_CWD:process.env.INIT_CWD||'',realhome,realNpmrcReadable:(()=>{try{fs.accessSync(realhome+'/.npmrc',fs.constants.R_OK);return true}catch(e){return false}})(),agentSocketFindable:agent,cacheWrite,env})+'\n');
J
( cd $W/src/pkg && npm pack --pack-destination $W/src --cache $W/packcache --silent ) >/dev/null 2>&1
TGZ=$W/src/$PN-1.0.0.tgz; [ -f $TGZ ] || { echo FATAL no tgz; exit 2; }
INTEG="sha512-$(openssl dgst -sha512 -binary $TGZ | base64 | tr -d '\n')"
python3 -I $EV/tools/srv.py $W/port $TGZ $SRVLOG & SRVPID=$!
for i in 1 2 3 4 5 6 7 8 9 10; do [ -s $W/port ] && break; sleep 0.3; done; PORT=$(cat $W/port)
echo "gate=$GATE md5=$(md5 -q $GATE) node=$(node -v) npm=$(npm -v) port=$PORT tgz_integrity=${INTEG:0:20}..."
LOC="http://127.0.0.1:$PORT"
# mkcase <name> <lockjson> [npmrc-text]: fixture repo with the gate, one package p depending on the probe
mkcase() { local r=$W/cases/$1; mkdir -p $r/systemTest/scripts $r/systemTest/p $r/cache; cp $GATE $r/systemTest/scripts/check-package-format.sh
  printf '{ "name": "p", "version": "1.0.0", "scripts": { "format:check": "exit 0" }, "dependencies": { "%s": "1.0.0" } }\n' $PN > $r/systemTest/p/package.json
  printf '%s\n' "$2" > $r/systemTest/p/package-lock.json; [ -n "${3:-}" ] && printf '%s\n' "$3" > $r/systemTest/p/.npmrc; echo $r; }
v3() { printf '{"name":"p","version":"1.0.0","lockfileVersion":3,"requires":true,"packages":{"":{"name":"p","version":"1.0.0","dependencies":{"%s":"1.0.0"}},"node_modules/%s":{"version":"1.0.0","resolved":"%s","integrity":"%s","hasInstallScript":true}}}' $PN $PN "$1" "$2"; }
# row <name> <root> [env...]: run the real gate in normal mode on systemTest/p, then count GETs and script runs for this case
row() { local name=$1 r=$2; shift 2; local before=$(wc -l < $SRVLOG)
  out=$(cd $r && printf 'systemTest/p/x.ts\n' | env npm_config_cache=$r/cache npm_config_registry=http://127.0.0.1:9/ "$@" bash $r/systemTest/scripts/check-package-format.sh 2>&1); rc=$?
  local gets=$(( $(wc -l < $SRVLOG) - before )); local runs=$(grep -c "\"cwd\":\"$r/" $SENT 2>/dev/null); runs=${runs:-0}
  local why=$(printf '%s\n' "$out" | grep -o -i -E 'lockfile has a source[^)]*|could not install its deps \(npm ci exited [0-9]+|INSTALLED' | head -1)
  printf '%-34s rc=%-2s GETs=%-2s script_ran=%-2s %s\n' "$name" "$rc" "$gets" "$runs" "$why"; printf '%s\n' "$out" > $W/cases/$name.out; }
echo "== LOCK SOURCES (default allow list unless stated) =="
row C0_CONTROL_local_host_ALLOWED $(mkcase C0 "$(v3 $LOC/c/C0/$PN-1.0.0.tgz $INTEG)") FORMAT_GATE_LOCK_ALLOW="$LOC/"
row L1_other_host $(mkcase L1 "$(v3 $LOC/c/L1/$PN-1.0.0.tgz $INTEG)")
row L2_http_registry $(mkcase L2 "$(v3 http://registry.npmjs.org/$PN/-/$PN-1.0.0.tgz $INTEG)")
row L3_git_ssh $(mkcase L3 "$(v3 git+ssh://git@github.com/x/y.git#abc $INTEG)")
row L3b_tarball_other_host $(mkcase L3b "$(v3 https://codeload.github.com/x/y/tar.gz/abc $INTEG)")
row L4_missing_integrity $(mkcase L4 "$(v3 https://registry.npmjs.org/$PN/-/$PN-1.0.0.tgz '' | sed 's/,"integrity":""//')")
row L5_file_url $(mkcase L5 "$(v3 file:$TGZ $INTEG)")
row L5b_file_url_with_file_allowed $(mkcase L5b "$(v3 file:$TGZ $INTEG)") FORMAT_GATE_LOCK_ALLOW="file:"
row L6_link_outside_repo $(mkcase L6 '{"name":"p","version":"1.0.0","lockfileVersion":3,"requires":true,"packages":{"":{"name":"p","version":"1.0.0","dependencies":{"x":"file:../../.."}},"node_modules/x":{"resolved":"../../..","link":true},"../../..":{"name":"x","version":"1.0.0"}}}')
row L7_userinfo_at_evil $(mkcase L7 "$(v3 "https://registry.npmjs.org@127.0.0.1:$PORT/c/L7/$PN-1.0.0.tgz" $INTEG)")
row L8_lookalike_host $(mkcase L8 "$(v3 https://registry.npmjs.org.evil.example/$PN-1.0.0.tgz $INTEG)")
row L8b_UPPERCASE_registry $(mkcase L8b "$(v3 HTTPS://REGISTRY.NPMJS.ORG/$PN/-/$PN-1.0.0.tgz $INTEG)")
row L9_v1_dependencies_evil $(mkcase L9 "{\"name\":\"p\",\"version\":\"1.0.0\",\"lockfileVersion\":1,\"requires\":true,\"dependencies\":{\"$PN\":{\"version\":\"1.0.0\",\"resolved\":\"$LOC/c/L9/$PN-1.0.0.tgz\",\"integrity\":\"$INTEG\"}}}")
row L9c_v1_CONTROL_allowed $(mkcase L9c "{\"name\":\"p\",\"version\":\"1.0.0\",\"lockfileVersion\":1,\"requires\":true,\"dependencies\":{\"$PN\":{\"version\":\"1.0.0\",\"resolved\":\"$LOC/c/L9c/$PN-1.0.0.tgz\",\"integrity\":\"$INTEG\"}}}") FORMAT_GATE_LOCK_ALLOW="$LOC/"
row L10_v1_benign_packages_evil_deps $(mkcase L10 "{\"name\":\"p\",\"version\":\"1.0.0\",\"lockfileVersion\":1,\"requires\":true,\"packages\":{\"\":{\"name\":\"p\",\"version\":\"1.0.0\"},\"node_modules/$PN\":{\"version\":\"1.0.0\",\"resolved\":\"https://registry.npmjs.org/$PN/-/$PN-1.0.0.tgz\",\"integrity\":\"$INTEG\"}},\"dependencies\":{\"$PN\":{\"version\":\"1.0.0\",\"resolved\":\"$LOC/c/L10/$PN-1.0.0.tgz\",\"integrity\":\"$INTEG\"}}}")
row L10b_v2_empty_packages_evil_deps $(mkcase L10b "{\"name\":\"p\",\"version\":\"1.0.0\",\"lockfileVersion\":2,\"requires\":true,\"packages\":{\"\":{\"name\":\"p\",\"version\":\"1.0.0\"}},\"dependencies\":{\"$PN\":{\"version\":\"1.0.0\",\"resolved\":\"$LOC/c/L10b/$PN-1.0.0.tgz\",\"integrity\":\"$INTEG\"}}}")
row L11_pkg_npmrc_registry_redirect $(mkcase L11 "$(v3 https://registry.npmjs.org/$PN/-/$PN-1.0.0.tgz $INTEG)" "registry=$LOC/c/L11/")
row L11c_CONTROL_same_no_npmrc $(mkcase L11c "$(v3 https://registry.npmjs.org/$PN/-/$PN-1.0.0.tgz $INTEG)")
row L11d_npmrc_replace_host_always $(mkcase L11d "$(v3 https://registry.npmjs.org/$PN/-/$PN-1.0.0.tgz $INTEG)" "registry=$LOC/c/L11d/
replace-registry-host=always")
echo "== FORMAT_GATE_LOCK_ALLOW from a FILE must not count (each row: lock on the listener, allow-list only in a file) =="
r=$(mkcase F1 "$(v3 $LOC/c/F1/$PN-1.0.0.tgz $INTEG)" "FORMAT_GATE_LOCK_ALLOW=$LOC/
format_gate_lock_allow=$LOC/"); printf 'FORMAT_GATE_LOCK_ALLOW=%s/\n' $LOC > $r/.env; cp $r/.env $r/systemTest/p/.env
node -e 'const f=process.argv[1],j=require(f);j.config={FORMAT_GATE_LOCK_ALLOW:process.argv[2]};require("fs").writeFileSync(f,JSON.stringify(j))' $r/systemTest/p/package.json "$LOC/"
row F1_allow_in_npmrc_env_pkgjson $r
r=$(mkcase F2 "$(v3 $LOC/c/F2/$PN-1.0.0.tgz $INTEG)"); ( cd $r && git init -q && git config format-gate.lock-allow "$LOC/" && git config FORMAT_GATE_LOCK_ALLOW.x "$LOC/" ) 2>/dev/null
row F2_allow_in_git_config $r
echo "== IN-REPO CONTENT THAT STILL RUNS (stated limit) =="
r=$(mkcase R1 '{"name":"p","version":"1.0.0","lockfileVersion":3,"requires":true,"packages":{"":{"name":"p","version":"1.0.0"}}}'); node -e 'const f=process.argv[1],j=require(f);delete j.dependencies;j.scripts.postinstall="node -e \"require(\x27fs\x27).appendFileSync(process.argv[1],JSON.stringify({cwd:process.cwd(),root_postinstall:1})+\x27\\n\x27)\" '"$SENT"'";require("fs").writeFileSync(f,JSON.stringify(j))' $r/systemTest/p/package.json
row R1_root_pkg_own_postinstall $r
r=$W/cases/R2; mkdir -p $r/systemTest/scripts $r/systemTest/p $r/systemTest/linked $r/cache; cp $GATE $r/systemTest/scripts/check-package-format.sh
printf '{ "name": "p", "version": "1.0.0", "scripts": { "format:check": "exit 0" }, "dependencies": { "linked": "file:../linked" } }\n' > $r/systemTest/p/package.json
printf '{"name":"p","version":"1.0.0","lockfileVersion":3,"requires":true,"packages":{"":{"name":"p","version":"1.0.0","dependencies":{"linked":"file:../linked"}},"node_modules/linked":{"resolved":"../linked","link":true},"../linked":{"name":"linked","version":"1.0.0","hasInstallScript":true}}}\n' > $r/systemTest/p/package-lock.json
printf '{ "name": "linked", "version": "1.0.0", "scripts": { "postinstall": "node -e \\"require(%sfs%s).appendFileSync(%s%s%s, JSON.stringify({cwd:process.cwd(),link_postinstall:1})+String.fromCharCode(10))\\"" } }\n' "'" "'" "'" "$SENT" "'" > $r/systemTest/linked/package.json
row R2_in_repo_link_target_postinstall $r
echo "== hits (one JSON line per postinstall run) =="; cat $SENT 2>/dev/null | cut -c1-400
echo "== listener log =="; cat $SRVLOG
kill $SRVPID 2>/dev/null; echo "workdir=$W"
