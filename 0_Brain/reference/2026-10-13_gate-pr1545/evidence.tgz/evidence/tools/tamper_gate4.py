#!/usr/bin/env python3
"""KS-998 items 1+2+3 + the #1540 Minors (final gate) - mutation proof for check-package-format.sh.
Each mutant is a COPY of the gate with one (or a few) exact-once text edits, run through the REAL suite via
PACKAGE_FORMAT_GATE_SH. Nothing is restored from git: the working gate is never touched.
A mutant counts as KILLED BY NAME only when every expected cell description is among the FAIL lines.
Guards: the unmutated gate must be green first (a runner that cannot see green proves nothing); a mutant that
fails `bash -n` or yields 0 passed + 0 failed is a LOADFAIL, not a kill."""
import datetime, glob, json, os, re, shutil, subprocess, sys, time
GATE, SUITE, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
ONLY = set(sys.argv[4:])
os.makedirs(OUT, exist_ok=True)
src = open(GATE, encoding="utf-8").read()
def now(): return datetime.datetime.now(datetime.timezone.utc).strftime("%H:%M:%SZ")

M = []   # (name, [(old,new)], [expected FAIL substrings], expect_survive_note)
def mut(name, edits, kills, survive=None): M.append((name, edits, kills, survive))

mut("m01_drop_fetch_retries", [("--fetch-retries=0 --fetch-timeout=20000 )", "--fetch-timeout=20000 )")],
    ["in under 15 s (npm's own retry schedule would take ~70 s)", "the install runs exactly: npm ci --no-audit --no-fund --no-update-notifier --fetch-retries=0 --fetch-timeout=20000"])
mut("m02_npm_install_not_ci", [('_run_grouped env -i "${INSTENV[@]}" npm ci --no-audit', '_run_grouped env -i "${INSTENV[@]}" npm install --no-audit')],
    ["drifted lockfile, normal mode -> exit 1", "...REFUSED, as 'could not install'", "the install runs exactly: npm ci --no-audit --no-fund --no-update-notifier --fetch-retries=0 --fetch-timeout=20000"])
mut("m02b_drop_no_audit", [("npm ci --no-audit --no-fund", "npm ci --no-fund")],
    ["the install runs exactly: npm ci --no-audit --no-fund --no-update-notifier --fetch-retries=0 --fetch-timeout=20000"])
mut("m03_inplace_install_no_staging", [
    ('( cd "$stage" && _run_grouped env', '( cd "$dir" && _run_grouped env'),
    ('elif ! _prettier_ok "$stage"; then', 'elif ! _prettier_ok "$dir"; then'),
    ('elif [ -e "$dir/node_modules" ] || [ -L "$dir/node_modules" ]; then\n        # Someone made', 'elif false; then\n        # Someone made'),
    ('\n        rn="$(_rename_dir "$stage/node_modules" "$dir/node_modules")"; rrc=$?', '\n        rn=""; rrc=0')],
    ["SIGKILL mid-install -> the package still has NO node_modules", "...the package has NO node_modules (the partial one was in the stage)"])
mut("m04_install_over_hollow", [('        elif [ -e "$dir/node_modules" ] || [ -L "$dir/node_modules" ]; then\n            unready="hollow"', '        elif false; then\n            unready="hollow"')],
    ["...npm ci was NEVER RUN (an install over it is not even attempted)"])
mut("m04b_dangling_symlink_not_present", [('        elif [ -e "$dir/node_modules" ] || [ -L "$dir/node_modules" ]; then\n            unready="hollow"', '        elif [ -e "$dir/node_modules" ]; then\n            unready="hollow"')],
    ["...npm ci was NEVER RUN for it either"])
mut("m05_key_on_npm_message", [('wait "$_FG_NPM_PID" 2>/dev/null; INST_RC=$?', 'wait "$_FG_NPM_PID" 2>/dev/null; INST_RC=$?; if grep -q "npm error" "$log"; then INST_RC=1; else INST_RC=0; fi')],
    ["npm prints 'added 1 package' but exits 1 -> still REFUSED", "npm prints 'npm error code E404' but exits 0 with prettier -> INSTALLED"])
mut("m06_no_watchdog", [('while [ "$_i" -lt "$INSTALL_CEILING" ]; do', 'while [ "$_i" -lt 99999 ]; do')],
    ["...REFUSED, as a TIMEOUT with the ceiling in the line"])
mut("m07_no_breaker", [('elif [ -n "$BREAKER_PKG" ]; then', 'elif false; then')],
    ["...npm was run for ONE package only"])
mut("m08_breaker_trips_on_any_failure", [('                *)\n                    unready="$INST_STATE"', '                *)\n                    BREAKER_PKG="$p"; unready="$INST_STATE"')],
    ["CONTROL a FAST failure does not trip the breaker: npm run for all three"])
mut("m09_no_look_before_the_rename", [('elif [ -e "$dir/node_modules" ] || [ -L "$dir/node_modules" ]; then\n        # Someone made', 'elif false; then\n        # Someone made')],
    ["...the empty directory was not replaced by the staged tree"])
mut("m10_no_sweep", [('# A stage whose run was SIGKILLed is garbage; remove it before making new ones.\n_sweep_dead_stages\n', ': # sweep removed\n')],
    ["a stage of a DEAD pid is swept", "...and swept the dead run's orphaned stage"])
mut("m11_sweep_removes_live_pid", [('        ps -p "$pid" >/dev/null 2>&1 && continue\n', '')],
    ["a stage of a LIVE pid is left"])
mut("m12_sweep_removes_nonnumeric_pid", [("        case \"$pid\" in ''|*[!0-9]*) continue ;; esac\n", "        case \"$pid\" in '') continue ;; esac\n")],
    ["a non-numeric pid is left (death cannot be proved)"])
mut("m13a_sweep_symlink_guard_dropped_ALONE", [('        [ -L "$d" ] && continue\n', '')], [],
    survive="EQUIVALENT: the sweep hands the symlink to _rm_stage, whose own -L refusal holds; no input distinguishes them")
mut("m13b_rm_stage_symlink_guard_dropped_ALONE", [('    [ -d "$d" ] && [ ! -L "$d" ] || return 1', '    [ -d "$d" ] || return 1')],
    ["a SYMLINK named like a stage is refused, and left in place"])
mut("m13ab_both_symlink_guards_dropped", [('        [ -L "$d" ] && continue\n', ''), ('    [ -d "$d" ] && [ ! -L "$d" ] || return 1', '    [ -d "$d" ] || return 1')],
    ["...and the symlink itself is left", "a SYMLINK named like a stage is refused, and left in place"])
mut("m14_hint_always_on", [('        if [ "$BASE_MAY_BE_STALE" -eq 1 ]; then', '        if true; then')],
    ["hint absent (variable unset): no hint", "hint explicitly 0: no hint"])
mut("m15_hint_never", [('        if [ "$BASE_MAY_BE_STALE" -eq 1 ]; then', '        if false; then')],
    ["hint ON, install refused: the hint is there"])
mut("m16_refusal_not_in_exit_code", [('\n[ "$failed" -eq 0 ] && [ "$refused" -eq 0 ]\n', '\n[ "$failed" -eq 0 ]\n')],
    ["deps missing + not installable, normal mode -> exit 1"])
mut("m17_ceiling_ignores_override", [('    INSTALL_CEILING="$FORMAT_GATE_INSTALL_TIMEOUT"', '    INSTALL_CEILING=120')],
    ["a valid override is used (the line says ceiling 7s)"])
mut("m18_accepts_garbage_override", [('        *[!0-9]*|0*) _bad=1 ;;', '        *[!0-9]*|0*) _bad=0 ;;')],
    ["FORMAT_GATE_INSTALL_TIMEOUT='abc' -> exit 2, naming the variable", "FORMAT_GATE_INSTALL_TIMEOUT='0' -> exit 2, naming the variable"])
mut("m19_all_mode_refuses", [('            if [ "$MODE" = "all" ]; then\n                # --all has no changed set', '            if false; then\n                # --all has no changed set')],
    ["--all -> SKIP names the package", "--all: the same drifted package is SKIPPED, named"])
mut("m20_normal_mode_skips", [('            if [ "$MODE" = "all" ]; then\n                # --all has no changed set', '            if true; then\n                # --all has no changed set')],
    ["...REFUSED, naming the package", "...REFUSED, as 'could not install'"])
mut("m21_npm_stdin_not_isolated", [('--fetch-timeout=20000 ) </dev/null >"$log" 2>&1 &', '--fetch-timeout=20000 ) >"$log" 2>&1 &')],
    ["an install that drains stdin: both packages still installed and checked", "...two installs, two checks (trailer)"])
mut("m22_stage_kept_after_run", [('    if [ "$keep_stage" -ne 1 ]; then _rm_stage "$stage"; fi\n    _FG_STAGE=""\n    return 0', '    _FG_STAGE=""\n    return 0')],
    ["...no staging dir is left behind"])
mut("m23_no_term_trap_ALONE", [("trap '_fg_cleanup; exit 143' TERM\n", "")], [],
    survive="EQUIVALENT alone: bash runs the EXIT trap when it dies of SIGTERM, and that trap does the same cleanup; only dropping BOTH is observable (m23c)")
mut("m23b_no_exit_trap_ALONE", [("trap '_fg_cleanup' EXIT\n", "")],
    ["SIGUSR1 mid-install -> non-zero, the hung npm is gone, no stage", "SIGALRM mid-install -> non-zero, the hung npm is gone, no stage", "SIGPIPE mid-install -> non-zero, the hung npm is gone, no stage"])
mut("m23c_no_traps_at_all", [("trap '_fg_cleanup' EXIT\n", ""), ("trap '_fg_cleanup; exit 130' INT\n", ""), ("trap '_fg_cleanup; exit 143' TERM\n", ""), ("trap '_fg_cleanup; exit 129' HUP\n", ""), ("trap '_fg_cleanup; exit 131' QUIT      # bash 3.2 does not run the EXIT trap for SIGQUIT (gate review, Minor 6)\n", "")],
    ["...the hung npm is gone", "...no staging dir is left"])
mut("m24_timeout_without_marker", [('    if [ "$INST_RC" -ne 0 ] && [ -e "$marker" ]; then\n        INST_STATE="timeout"', '    if [ "$INST_RC" -ne 0 ]; then\n        INST_STATE="timeout"')],
    ["...REFUSED, as 'could not install'"])
ARM = '        "$TREE_PREFIX"*)  rest="${d#"$TREE_PREFIX"}" ;;\n        *) return 1 ;;\n'
mut("m25_rm_prefix_guard_dropped_ALONE", [(ARM, ARM.replace("*) return 1 ;;", "*) rest='' ;;"))], [],
    survive="EQUIVALENT alone: an unrecognised path leaves rest empty, and the empty-rest guard right below refuses it; m25b lets it through instead")
mut("m25b_rm_prefix_guard_lets_outside_paths_through", [(ARM, ARM.replace("*) return 1 ;;", '*) rest="${d##*/}" ;;'))],
    ["a path OUTSIDE the stage prefix is refused"])
mut("m26_rm_single_component_guard_dropped", [("    case \"$rest\" in ''|*/*|*..*) return 1 ;; esac\n", "    case \"$rest\" in '') return 1 ;; esac\n")],
    ["a '..' escape that starts with the prefix is refused", "a path BELOW a stage (more than one component) is refused"])
mut("m27_rm_file_guard_dropped", [('    [ -d "$d" ] && [ ! -L "$d" ] || return 1', '    [ ! -L "$d" ] || return 1')],
    ["a regular FILE named like a stage is refused"])
mut("m28_stage_outside_systemTest", [('STAGE_PREFIX="$REPO_ROOT/systemTest/.format-gate-stage."', 'STAGE_PREFIX="${TMPDIR:-/tmp}/.format-gate-stage."')],
    ["CONTROL the install is really in flight (one hung npm, a partial node_modules in the stage)"])
mut("m29_no_prettier_check_after_install", [('    elif ! _prettier_ok "$stage"; then\n        INST_STATE="noprettier"', '    elif false; then\n        INST_STATE="noprettier"')],
    ["npm ci exits 0 but installs no prettier -> REFUSED, not INSTALLED"])
mut("m37_no_undo_after_a_broken_move", [('            rn="$(_rename_dir "$dir/node_modules" "$stage/node_modules")"; rrc=$?', '            rn=""; rrc=0')],
    ["...the package has NO node_modules (it was moved back out)"])
mut("m38_no_check_after_the_move", [('        elif _prettier_ok "$dir"; then\n            rm -f', '        elif true; then\n            rm -f')],
    ["an install that embeds the stage path -> exit 1", "...REFUSED, saying the install embeds its staging path"])
# ---- KS-998 item 2: the gate judges the pushed commit ----
mut("g01_tree_ignored_working_tree_judged", [('    if [ -z "$TREE_SHA" ]; then\n        out="$(cd "$dir" && npm run', '    if true; then\n        out="$(cd "$dir" && npm run')],
    ["red at the pushed commit, fix uncommitted -> exit 1", "green at the pushed commit, dirty working tree -> exit 0"])
mut("g02_no_ancestor_config_archived", [('    anc="$(git -C "$REPO_ROOT" ls-tree --name-only "$TREE_SHA" -- $ANC_CANDIDATES 2>/dev/null)"', '    anc=""')],
    ["the PUSHED root config (A) is judged, the on-disk B is shadowed -> exit 0"])
mut("g03_no_node_modules_borrowed", [('    ln -s "$dir/node_modules" "$tree/systemTest/$p/node_modules"\n', '')],
    ["absent node_modules + a tree: installed FIRST (item 1), then checked from the archive", "...the check saw node_modules as a SYMLINK and ran prettier through it"])
mut("g04_discovery_from_working_tree", [('if [ -n "$TREE_SHA" ]; then\n    # KS-998 item 2: discovered from the COMMIT', 'if false; then\n    # KS-998 item 2: discovered from the COMMIT')],
    ["a package that exists at the pushed commit but not in the checked-out tree -> exit 1", "a package the pushed commit REMOVED is not selected -> exit 0, silent"])
mut("g05_notintree_state_dropped", [('        if [ -n "$TREE_SHA" ] && [ ! -f "$dir/package.json" ]; then', '        if false; then')],
    ["...saying it is not in the checked-out tree, so its deps cannot be installed here"])
mut("g06_tree_dir_kept_after_the_check", [('    out="$(cat "$tree/.check.log" 2>/dev/null)"\n    _rm_stage "$tree"; _FG_TREE=""', '    out="$(cat "$tree/.check.log" 2>/dev/null)"\n    _FG_TREE=""')],
    ["...no tree dir left behind"])
mut("g07_cleanup_ignores_the_tree_dir", [('    if [ -n "$_FG_TREE" ]; then _rm_stage "$_FG_TREE"; _FG_TREE=""; fi\n', '')],
    ["...no tree dir is left"])
mut("g08_cleanup_ignores_the_running_check", [('    if [ -n "$_FG_CHK_PID" ]; then\n        _kill_proc TERM "$_FG_CHK_PID"\n        while kill -0 "$_FG_CHK_PID" 2>/dev/null && [ "$i" -lt 20 ]; do sleep 0.1; i=$((i + 1)); done\n        _kill_proc KILL "$_FG_CHK_PID"\n        _FG_CHK_PID=""; i=0\n    fi\n', '')],
    ["...the hung check is gone"])
mut("g09_sweep_skips_the_tree_family", [('"$REPO_ROOT"/systemTest/.format-gate-stage.* "$REPO_ROOT"/systemTest/.format-gate-tree.*; do', '"$REPO_ROOT"/systemTest/.format-gate-stage.*; do')],
    ["a tree dir of a DEAD pid is swept"])
mut("g10_rm_stage_refuses_tree_dirs", [('        "$TREE_PREFIX"*)  rest="${d#"$TREE_PREFIX"}" ;;\n        *) return 1 ;;\n', '        *) return 1 ;;\n')],
    ["_rm_stage removes a real TREE dir too", "...no tree dir left behind"])
mut("g11_tree_validation_dropped", [('could not exist\n', 'x')] if False else [("(got '${FORMAT_GATE_TREE}').\" >&2\n        exit 2", "(got '${FORMAT_GATE_TREE}').\" >&2\n        TREE_SHA=\"\"")],
    ["FORMAT_GATE_TREE='notasha...' is not a commit -> exit 2, naming the variable"])
mut("g12_extract_failure_ignored", [('    if ! { GIT_INDEX_FILE="$tree/.idx" git -C "$REPO_ROOT" -c core.sparseCheckout=false read-tree "$TREE_SHA" &&\n           GIT_INDEX_FILE="$tree/.idx" git -C "$REPO_ROOT" ls-files -z -- "systemTest/$p" $anc |\n               GIT_INDEX_FILE="$tree/.idx" xargs -0 git -C "$REPO_ROOT" checkout-index -f -q --prefix="$tree/" -- &&\n           [ -d "$tree/systemTest/$p" ]; } 2>"$tree/.archive.err"; then\n', '    if false; then\n')],
    ["...says it could not extract the package at that commit"])
mut("g13_tree_dir_outside_systemTest", [('TREE_PREFIX="$REPO_ROOT/systemTest/.format-gate-tree."', 'TREE_PREFIX="${TMPDIR:-/tmp}/.format-gate-tree."')],
    ["CONTROL the check is really in flight (one hung check, a tree dir holding the archive)"])
mut("g14_commit_advice_never_given", [('    if [ -n "$TREE_SHA" ]; then\n        echo "[format-gate]   fix: (cd systemTest/$p && npm run format) — then COMMIT it', '    if false; then\n        echo "[format-gate]   fix: (cd systemTest/$p && npm run format) — then COMMIT it')],
    ["...the fix line tells the author to COMMIT the fix (the gate judges the pushed commit)"])
mut("g15_commit_advice_always_given", [('    if [ -n "$TREE_SHA" ]; then\n        echo "[format-gate]   fix: (cd systemTest/$p && npm run format) — then COMMIT it', '    if true; then\n        echo "[format-gate]   fix: (cd systemTest/$p && npm run format) — then COMMIT it')],
    ["CONTROL ...and its fix line carries no commit advice (it judges the working tree, so none is needed)"])
mut("m30_selecting_path_not_named", [("index($0, pre) == 1 { print; exit }", "index($0, pre) == 99999 { print; exit }")],
    ["...names the path in the push that selected it"])
mut("m31_no_lifecycle_disclosure", [("This runs the dependency install scripts from the lockfile, exactly as a manual npm ci does.", "")],
    ["...and names the lifecycle-scripts trade-off in that line"])
mut("m32_ceiling_not_in_the_line", [("(ceiling ${INSTALL_CEILING}s). This runs", "(). This runs")],
    ["...states the ceiling in force (the default is 120s)"])
mut("m02c_drop_no_update_notifier", [("--no-fund --no-update-notifier --fetch-retries=0", "--no-fund --fetch-retries=0")],
    ["the install runs exactly: npm ci --no-audit --no-fund --no-update-notifier --fetch-retries=0 --fetch-timeout=20000"])
mut("m36_nostage_misreported_as_mvfail", [('INST_STATE="nostage"; INST_RC=1; return 0', 'INST_STATE="mvfail"; INST_RC=1; return 0')],
    ["...says the STAGING DIR could not be created (not 'moved into place')"])
mut("m33_fetch_timeout_flag_dropped", [(" --fetch-timeout=20000 )", " )")],
    ["the install runs exactly: npm ci --no-audit --no-fund --no-update-notifier --fetch-retries=0 --fetch-timeout=20000"])
mut("m34_trailer_hides_refusals", [('[ "$refused" -gt 0 ]   && trailer="${trailer}, ${refused} refused"\n', '')],
    ["...counted as refused, not as skipped or failed"])
mut("m35_nothing_checked_fires_on_refusal", [('&& [ "$skipped" -gt 0 ] && [ "$refused" -eq 0 ]; then', '&& [ "$skipped" -gt 0 ]; then')], [],
    survive="EQUIVALENT in every reachable state: a refused package leaves skipped==0 unless a package was ALSO skipped, which only --all can do, and --all never refuses")

# ================= the gate review's Minors 1, 2, 5, 6 (added in the final pass) =================
RN = 'rn="$(_rename_dir "$stage/node_modules" "$dir/node_modules")"; rrc=$?'
MAP = '                ENOTEMPTY|EEXIST|ENOTDIR) INST_STATE="raced" ;;\n                *)                        INST_STATE="mvfail" ;;\n'
mut("n01_rename_is_mv_again", [('\n        ' + RN, '\n        mv "$stage/node_modules" "$dir/node_modules" 2>/dev/null; rrc=$?; rn=""')],
    ["...ours was NOT nested inside it", "...nothing of ours was written THROUGH the link into the outside directory"])
mut("n02_enotdir_not_a_race", [(MAP, MAP.replace("ENOTEMPTY|EEXIST|ENOTDIR)", "ENOTEMPTY|EEXIST)"))], ["...REFUSED as hollow"])
mut("n03_enotempty_not_a_race", [(MAP, MAP.replace("ENOTEMPTY|EEXIST|ENOTDIR)", "EEXIST|ENOTDIR)"))], ["...says node_modules appeared during the install"])
mut("n03b_eexist_alone_not_a_race", [(MAP, MAP.replace("ENOTEMPTY|EEXIST|ENOTDIR)", "ENOTEMPTY|ENOTDIR)"))], [],
    survive="EQUIVALENT on every platform measured: rename(2) onto a non-empty directory returns ENOTEMPTY on Darwin (measured); POSIX permits EEXIST, which is why it is in the list")
mut("n04_other_rename_error_is_a_race", [(MAP, MAP.replace('INST_STATE="mvfail"', 'INST_STATE="raced"'))],
    ["the rename fails for ANOTHER reason (EACCES) -> exit 1, REFUSED as 'could not be moved into place'"])
mut("n05_marker_not_required_for_the_move_back", [('        elif [ ! -f "$dir/node_modules/$tag" ]; then', '        elif false; then')],
    ["...REFUSED as hollow (it exists, it has no prettier)"])
mut("n06_marker_left_behind", [('            rm -f "$dir/node_modules/$tag"\n', '')],
    ["...no move marker is left in the package's node_modules"])
mut("n07_stuck_move_back_reported_as_done", [('            if [ "$rrc" -ne 0 ]; then\n                INST_STATE="mvstuck"', '            if [ "$rrc" -ne 0 ]; then\n                INST_STATE="mvbroken"')],
    ["...the refusal says it could not be moved back (not that it was)"])
mut("n08_hollow_recheck_after_a_race_dropped", [('_prettier_ok "$dir" || unready="hollow"', ':')],
    ["a HOLLOW node_modules (another actor's, no prettier yet) arrives -> exit 1"])
mut("n09_prettier_exists_is_enough", [('    elif ! _prettier_ok "$stage"; then\n        INST_STATE="noprettier"', '    elif [ ! -e "$stage/node_modules/.bin/prettier" ]; then\n        INST_STATE="noprettier"')],
    ["...says prettier is absent or not executable (the true reason)", "...does NOT blame the move"])
mut("n10_npmrc_not_copied", [('for f in package.json package-lock.json npm-shrinkwrap.json .npmrc; do', 'for f in package.json package-lock.json npm-shrinkwrap.json; do')],
    ["a package .npmrc is copied into the stage the install runs in"])
mut("n11_ceiling_length_guard_dropped", [('        *)           _bad=0; [ "${#FORMAT_GATE_INSTALL_TIMEOUT}" -gt 6 ] && _bad=1 ;;', '        *)           _bad=0 ;;')],
    ["FORMAT_GATE_INSTALL_TIMEOUT=<20 digits> -> exit 2, naming the variable (not a timeout)", "...7 digits is refused too"])
mut("n12_install_not_in_a_group", [('( cd "$stage" && _run_grouped env', '( cd "$stage" && exec env')],
    ["the child of the killed npm is gone too - no orphan (watchdog path)", "SIGTERM to the gate mid-install [child] -> non-zero, no orphan, no stage"])
mut("n13_check_not_in_a_group", [('( cd "$tree/systemTest/$p" && _run_grouped npm run', '( cd "$tree/systemTest/$p" && exec npm run')],
    ["SIGTERM mid-check [plain] -> the check's CHILD is gone too, and no tree dir is left"])
mut("n14_run_grouped_never_groups", [('    if [ "$HAVE_PERL" -eq 1 ]; then\n        exec perl', '    if false; then\n        exec perl')],
    ["the child of the killed npm is gone too - no orphan (watchdog path)"])
mut("n15_watchdog_signals_the_pid_only", [('        _kill_proc TERM "$_FG_NPM_PID"\n        sleep 2\n        _kill_proc KILL "$_FG_NPM_PID"', '        kill -TERM "$_FG_NPM_PID" 2>/dev/null\n        sleep 2\n        kill -KILL "$_FG_NPM_PID" 2>/dev/null')],
    ["the watchdog's TERM reaches the install's grandchild (it records it) and nothing survives"])
mut("n16_no_group_sweep_after_the_wait", [('    [ -e "$marker" ] && _kill_proc KILL "$_FG_NPM_PID"\n', '')],
    ["a child that IGNORES TERM is ended by the group KILL (watchdog path) - no orphan"])
CLN = '    if [ -n "$_FG_NPM_PID" ]; then\n        _kill_proc TERM "$_FG_NPM_PID"\n        while kill -0 "$_FG_NPM_PID" 2>/dev/null && [ "$i" -lt 20 ]; do sleep 0.1; i=$((i + 1)); done\n        _kill_proc KILL "$_FG_NPM_PID"       # always: the leader may be gone while a child that ignores TERM is not\n'
mut("n17a_cleanup_TERM_to_the_pid_only", [(CLN, CLN.replace('        _kill_proc TERM "$_FG_NPM_PID"\n', '        kill -TERM "$_FG_NPM_PID" 2>/dev/null\n'))],
    ["a SIGTERM to the gate reaches the grandchild gracefully (it records it) and nothing survives"])
mut("n17b_cleanup_final_KILL_to_the_pid_only", [(CLN, CLN.replace('        _kill_proc KILL "$_FG_NPM_PID"       # always', '        kill -KILL "$_FG_NPM_PID" 2>/dev/null       # always'))],
    ["SIGTERM to the gate mid-install [child-deaf] -> non-zero, no orphan, no stage"])
mut("n17c_cleanup_signals_the_pid_only", [(CLN, CLN.replace('        _kill_proc TERM "$_FG_NPM_PID"\n', '        kill -TERM "$_FG_NPM_PID" 2>/dev/null\n').replace('        _kill_proc KILL "$_FG_NPM_PID"       # always', '        kill -KILL "$_FG_NPM_PID" 2>/dev/null       # always'))],
    ["SIGTERM to the gate mid-install [child] -> non-zero, no orphan, no stage"])
CHK = '        _kill_proc KILL "$_FG_CHK_PID"\n'
mut("n18a_check_final_KILL_to_the_pid_only", [(CHK, '        kill -KILL "$_FG_CHK_PID" 2>/dev/null\n')],
    ["SIGTERM mid-check [deaf] -> the check's CHILD is gone too, and no tree dir is left"])
mut("n18b_check_signals_the_pid_only", [('        _kill_proc TERM "$_FG_CHK_PID"\n', '        kill -TERM "$_FG_CHK_PID" 2>/dev/null\n'), (CHK, '        kill -KILL "$_FG_CHK_PID" 2>/dev/null\n')],
    ["SIGTERM mid-check [plain] -> the check's CHILD is gone too, and no tree dir is left"])
mut("n19_no_quit_trap", [("trap '_fg_cleanup; exit 131' QUIT      # bash 3.2 does not run the EXIT trap for SIGQUIT (gate review, Minor 6)\n", "")],
    ["...the hung npm is gone and no stage is left"])
mut("n20_perl_precondition_dropped", [('    if [ "$HAVE_PERL" -ne 1 ]; then\n        INST_STATE="nopgrp"; INST_RC=1; return 0       # cannot promise to end what the install starts: do not start it\n    fi\n', '')],
    ["no perl, normal mode -> exit 1, REFUSED naming perl and the process group", "...npm was never started"])
mut("n21_perl_assumed_present", [('HAVE_PERL=0\ncommand -v perl >/dev/null 2>&1 && HAVE_PERL=1\n', 'HAVE_PERL=1\n')],
    ["no perl, normal mode -> exit 1, REFUSED naming perl and the process group", "no perl, tree mode, node_modules present -> the check still runs and passes"])
mut("n22_kill_proc_group_only", [('    kill -"$1" "$2" 2>/dev/null\n    return 0', '    return 0')],
    ["...SIGTERM still ends the (ungrouped) check by its pid, and no tree dir is left"])
mut("n23_rename_error_ignored", [('process.stdout.write(String(e.code || "EUNKNOWN")); process.exit(1); }', 'process.stdout.write(String(e.code || "EUNKNOWN")); }')],
    ["...says node_modules appeared during the install"])
mut("n24_no_marker_written", [(': > "$stage/node_modules/$tag" 2>/dev/null          # proves, after the rename, that what is there is the tree WE moved\n', '')],
    ["CONTROL an ordinary embedded-path install is still moved back out"])
mut("n25_wait_not_for_the_group_leader", [('    [ -e "$marker" ] && _kill_proc KILL "$_FG_NPM_PID"\n', '    [ -e "$marker" ] && kill -KILL "$_FG_NPM_PID" 2>/dev/null\n')],
    ["a child that IGNORES TERM is ended by the group KILL (watchdog path) - no orphan"])

# ================= KS-998 item 3: lock sources, install environment, Info 3 and 5 =================
LJ = lambda a, b: (a, b)
mut("p01_lock_check_skipped", [('    LOCK_REASON="$(_check_lock_sources "$dir" "$REPO_ROOT" "${_allow[@]+"${_allow[@]}"}")" || {\n        INST_STATE="lockbad"; INST_RC=1; return 0\n    }\n', '')],
    ["a lock entry resolved to a LOCAL HTTP listener (not the registry) -> exit 1, REFUSED naming the entry"])
mut("p02_default_allow_widened", [('LOCK_ALLOW="${FORMAT_GATE_LOCK_ALLOW:-https://registry.npmjs.org/}"', 'LOCK_ALLOW="${FORMAT_GATE_LOCK_ALLOW:-http}"')],
    ["a lock entry resolved to a LOCAL HTTP listener (not the registry) -> exit 1, REFUSED naming the entry"])
mut("p03_override_extends_instead_of_replacing", [('LOCK_ALLOW="${FORMAT_GATE_LOCK_ALLOW:-https://registry.npmjs.org/}"', 'LOCK_ALLOW="${FORMAT_GATE_LOCK_ALLOW:-} https://registry.npmjs.org/"')],
    ["FORMAT_GATE_LOCK_ALLOW REPLACES the default (a registry entry is refused when only file: is allowed) -> exit 1, REFUSED as a lock-source refusal"])
mut("p04_integrity_not_required", [('            if (typeof e.integrity !== "string" || e.integrity === "") bad(what, "has no integrity");\n', '')],
    ["an allowed source with NO integrity -> exit 1, REFUSED as a lock-source refusal"])
mut("p05_prefix_is_a_substring_match", [('allow.some((p) => p !== "" && r.startsWith(p))', 'allow.some((p) => p !== "" && r.includes(p))')],
    ["an allowed prefix appearing LATER in the URL does not count (a prefix match, not a substring match)"])
mut("p06_link_target_not_checked", [('if (typeof e.resolved !== "string" || !inside(path.resolve(dir, e.resolved))) {', 'if (typeof e.resolved !== "string") {')],
    ["a link OUTSIDE the repository is refused"])
mut("p07_local_entry_always_allowed", [('if (local && inside(path.resolve(dir, key))) continue;', 'if (local) continue;')],
    ["a local entry (no resolved) whose KEY is outside the repository is refused"])
mut("p08_bundled_entries_refused", [('                    if (e.inBundle === true) continue;\n', '')],
    ["a bundled entry (inBundle, no resolved) is accepted"])
mut("p09_shrinkwrap_not_checked", [('for (const name of ["package-lock.json", "npm-shrinkwrap.json"]) {', 'for (const name of ["package-lock.json"]) {')],
    ["a bad entry in npm-shrinkwrap.json only (package-lock.json is fine) -> exit 1, REFUSED as a lock-source refusal"])
mut("p10_v1_not_walked", [('                walk(lock.dependencies, "");\n', '')],
    ["...and a NESTED v1 entry from another host is refused"])
mut("p11_v1_nested_not_walked", [('                        if (e.dependencies && typeof e.dependencies === "object") walk(e.dependencies, trail + n + " > ");\n', '')],
    ["...and a NESTED v1 entry from another host is refused"])
mut("p12_unknown_format_accepted", [('                bad(name, "has neither packages nor dependencies (unknown lockfile format)");', '                continue;')],
    ["a lockfile with neither packages nor dependencies -> exit 1, REFUSED as a lock-source refusal"])
mut("p13_invalid_json_accepted", [('catch (err) { bad(name, "is not valid JSON"); }', 'catch (err) { continue; }')],
    ["a lockfile that is not valid JSON -> exit 1, REFUSED as a lock-source refusal"])
mut("p14_entry_without_resolved_accepted", [('bad(what, local ? "local entry resolves outside the repository" : "has no resolved source");', 'if (local) bad(what, "local entry resolves outside the repository"); else continue;')],
    ["an entry under node_modules with no resolved and not bundled is refused"])
mut("p15_lockbad_has_no_reason_text", [('                lockbad)      why_ref="the lockfile has a source the gate will not install from: ${LOCK_REASON}"\n                              why_skip=" and could not be installed (the lockfile has a source the gate will not install from: ${LOCK_REASON})" ;;\n', '                lockbad)      why_ref="could not install its deps"\n                              why_skip=" and could not be installed" ;;\n')],
    ["a lock entry resolved to a LOCAL HTTP listener (not the registry) -> exit 1, REFUSED naming the entry"])
mut("p16_no_remedy_for_a_lock_refusal", [('        if [ "${INST_STATE:-}" = "lockbad" ]; then\n            echo "[format-gate]   The gate installs only', '        if false; then\n            echo "[format-gate]   The gate installs only')],
    ["the lock-source refusal says how to proceed: FORMAT_GATE_LOCK_ALLOW + the npm_config_* variables, or npm ci by hand"])
mut("p17_no_remedy_for_a_failed_install", [('        if [ "${INST_STATE:-}" = "failed" ] || [ "${INST_STATE:-}" = "timeout" ]; then\n            echo "[format-gate]   The install runs with a private HOME', '        if false; then\n            echo "[format-gate]   The install runs with a private HOME')],
    ["a FAILED install's refusal says the install no longer reads ~/.npmrc, and how to opt in (npm_config_userconfig / FORMAT_GATE_LOCK_ALLOW)"])
mut("p18_install_not_scrubbed", [('_run_grouped env -i "${INSTENV[@]}" npm ci', '_run_grouped npm ci')],
    ["the install does NOT see NPM_TOKEN"])
mut("p19_home_is_the_developers", [('INSTENV=("PATH=$PATH" "HOME=$stage/.home" "TERM=dumb")', 'INSTENV=("PATH=$PATH" "HOME=$HOME" "TERM=dumb")')],
    ["HOME is a private directory inside the stage, not the developer's"])
mut("p20_term_forwarded", [('INSTENV=("PATH=$PATH" "HOME=$stage/.home" "TERM=dumb")', 'INSTENV=("PATH=$PATH" "HOME=$stage/.home" "TERM=${TERM:-dumb}")')],
    ["TERM is dumb, MY_PASSTHRU keeps its value, the proxy keeps its value"])
for pat, who in (("auth", "npm_config__auth"), ("token", "npm_config_x_token"), ("pass", "npm_config__password"), ("secret", "npm_config_client_secret"), ("cert", "npm_config_cert"), ("key", "npm_config_key")):
    old = '                case "$lc" in *auth*|*token*|*pass*|*secret*|*cert*|*key*) continue ;; esac ;;'
    new = old.replace(f"*{pat}*|", "", 1) if pat != "key" else old.replace("|*key*", "", 1)
    mut(f"p21_{pat}_pattern_dropped", [(old, new)], [f"the install does NOT see {who}"])
mut("p22_proxy_variables_not_passed", [('LANG|LC_*|HTTP_PROXY|HTTPS_PROXY|NO_PROXY|ALL_PROXY|http_proxy|https_proxy|no_proxy|all_proxy|SSL_CERT_FILE', 'LANG|LC_*|NO_PROXY|ALL_PROXY|http_proxy|https_proxy|no_proxy|all_proxy|SSL_CERT_FILE')],
    ["the install DOES see HTTPS_PROXY"])
mut("p23_lang_not_passed", [('            LANG|LC_*|HTTP_PROXY', '            LC_*|HTTP_PROXY')],
    ["the install DOES see LANG"])
mut("p24_pass_list_ignored", [('            *) case " $INSTALL_ENV_PASS " in *" $n "*) ;; *) continue ;; esac ;;', '            *) continue ;;')],
    ["the install DOES see MY_PASSTHRU"])
mut("p25_everything_passed", [('            *) case " $INSTALL_ENV_PASS " in *" $n "*) ;; *) continue ;; esac ;;', '            *) ;;')],
    ["the install does NOT see NPM_TOKEN"])
mut("p26_cache_fallback_dropped", [('    case " ${INSTENV[*]:-} " in *" npm_config_cache="*) ;; *) [ -n "${HOME:-}" ] && [ -d "$HOME/.npm" ] && INSTENV[${#INSTENV[@]}]="npm_config_cache=$HOME/.npm" ;; esac\n', '')],
    ["npm_config_cache unset and ~/.npm exists -> the install gets npm_config_cache=<that directory>"])
mut("p27_cache_fallback_without_dir_check", [('[ -n "${HOME:-}" ] && [ -d "$HOME/.npm" ] && INSTENV', '[ -n "${HOME:-}" ] && INSTENV')],
    ["...and with no ~/.npm there is no npm_config_cache to pass"])
mut("p28_empty_values_passed", [('        [ -n "${!n}" ] || continue             # an empty value says nothing (and would hide the cache fallback below)\n', '')],
    ["npm_config_cache unset and ~/.npm exists -> the install gets npm_config_cache=<that directory>"])
mut("p29_pass_names_not_validated", [('    if [ "$_bad" -ne 0 ]; then\n        echo "[format-gate] FORMAT_GATE_INSTALL_ENV_PASS must', '    if false; then\n        echo "[format-gate] FORMAT_GATE_INSTALL_ENV_PASS must')],
    ["FORMAT_GATE_INSTALL_ENV_PASS with a token that is not a variable name -> exit 2, naming the variable"])
RMP = '    [ -n "$STAGE_PREFIX" ] && [ -n "$TREE_PREFIX" ] || return 1\n'
RMA = '    case "$d" in /*) ;; *) return 1 ;; esac\n'
mut("p30_rm_stage_empty_prefix_guard_dropped_ALONE", [(RMP, '')], [],
    survive="REDUNDANT with the absolute-path guard: an empty prefix matches every path, but a relative path is refused by the next guard and an absolute one has more than one component, which the single-component guard refuses; p32 drops both")
mut("p31_rm_stage_absolute_guard_dropped_ALONE", [(RMA, '')], ["a RELATIVE prefix plus a relative path is refused too"])
mut("p32_rm_stage_both_guards_dropped", [(RMP, ''), (RMA, '')], ["an EMPTY prefix plus a relative single-component path is refused (it used to delete the directory)"])
mut("p33_prettier_may_be_a_directory", [('_prettier_ok() { [ -f "$1/node_modules/.bin/prettier" ] && [ -x "$1/node_modules/.bin/prettier" ]; }', '_prettier_ok() { [ -x "$1/node_modules/.bin/prettier" ]; }')],
    ["npm ci exits 0 and leaves a DIRECTORY at .bin/prettier -> REFUSED (absent or not executable), nothing installed"])
mut("p34_prettier_need_not_be_executable", [('_prettier_ok() { [ -f "$1/node_modules/.bin/prettier" ] && [ -x "$1/node_modules/.bin/prettier" ]; }', '_prettier_ok() { [ -f "$1/node_modules/.bin/prettier" ]; }')],
    ["npm ci exits 0 and leaves a prettier that is not executable -> REFUSED"])
mut("p35_empty_prefix_token_matches_everything", [('allow.some((p) => p !== "" && r.startsWith(p))', 'allow.some((p) => r.startsWith(p))')], [],
    survive="UNREACHABLE: the prefixes reach the checker from `read -a`, which never yields an empty word; the guard is defence in depth (an empty prefix would match every source)")
mut("p36_repo_root_counts_as_inside", [('            return r !== "" && r !== ".." &&', '            return r !== ".." &&')],
    ["a link that resolves to the REPOSITORY ROOT itself is refused"])
mut("p37_parent_of_repo_counts_as_inside", [('r !== "" && r !== ".." && !r.startsWith', 'r !== "" && !r.startsWith')],
    ["a link that resolves to the PARENT of the repository is refused"])
mut("p38_absolute_relative_path_guard", [('&& !path.isAbsolute(r);', ';')], [],
    survive="EQUIVALENT on POSIX: path.relative never returns an absolute path (it can on Windows, across drives)")

# ================= gate verdict on #1540: Minors 2 and 3, Info 4 =================
mut("q01_extract_via_git_archive_again", [('    if ! { GIT_INDEX_FILE="$tree/.idx" git -C "$REPO_ROOT" -c core.sparseCheckout=false read-tree "$TREE_SHA" &&\n           GIT_INDEX_FILE="$tree/.idx" git -C "$REPO_ROOT" ls-files -z -- "systemTest/$p" $anc |\n               GIT_INDEX_FILE="$tree/.idx" xargs -0 git -C "$REPO_ROOT" checkout-index -f -q --prefix="$tree/" -- &&\n           [ -d "$tree/systemTest/$p" ]; } 2>"$tree/.archive.err"; then\n', '    if ! git -C "$REPO_ROOT" archive "$TREE_SHA" -- "systemTest/$p" $anc 2>"$tree/.archive.err" | tar -x -C "$tree" 2>>"$tree/.archive.err"; then\n')],
    ["a PUSHED .gitattributes marking the red file export-ignore does not hide it -> exit 1"])
mut("q02_discovery_quoted", [("while IFS= read -r -d '' ent; do", "while IFS= read -r ent; do"), ('ls-tree -z --name-only "$TREE_SHA" systemTest/', 'ls-tree --name-only "$TREE_SHA" systemTest/')],
    ["tree mode: the red non-ASCII package is discovered and FAILS -> exit 1"])
mut("q03_ancestor_config_not_extracted", [('ls-files -z -- "systemTest/$p" $anc |', 'ls-files -z -- "systemTest/$p" |')],
    ["the PUSHED root config (A) is judged, the on-disk B is shadowed -> exit 0"])
mut("q04_marker_not_rechecked_in_the_stage", [('            elif [ -f "$stage/node_modules/$tag" ]; then\n                INST_STATE="mvbroken"', '            elif true; then\n                INST_STATE="mvbroken"')],
    ["...it was PUT BACK where it was found, not deleted"])
mut("q05_foreign_tree_never_put_back", [('                rn="$(_rename_dir "$stage/node_modules" "$dir/node_modules")"; rrc=$?\n                if [ "$rrc" -eq 0 ]; then\n                    INST_STATE="mvforeign"', '                rn=""; rrc=1\n                if [ "$rrc" -eq 0 ]; then\n                    INST_STATE="mvforeign"')],
    ["...it was PUT BACK where it was found, not deleted"])
mut("q06_kept_stage_removed_anyway", [('                    keep_stage=1; _FG_STAGE=""\n                    INST_STATE="mvaside"', '                    keep_stage=0; _FG_STAGE=""\n                    INST_STATE="mvaside"')],
    ["...and if even the move aside fails, the foreign tree stays in the stage, which is kept (not removed) -> exit 1"])
mut("q07_keep_marker_not_written", [(' || { ASIDE_PATH="$stage"; : > "$stage/.format-gate-keep"; }', ' || { ASIDE_PATH="$stage"; }')],
    ["...and a later run does NOT sweep that stage away (its keep marker), while it still sweeps an ordinary dead one"])
mut("q08_sweep_ignores_the_keep_marker", [('        [ -e "$d/.format-gate-keep" ] && continue         # holds a tree that is not ours (gate 1540 Minor 3): never swept\n', '')],
    ["...and a later run does NOT sweep that stage away (its keep marker), while it still sweeps an ordinary dead one"])
mut("q09_aside_rename_never_attempted", [('mv -- "$stage" "$ASIDE_PATH" 2>/dev/null ||', 'false ||')],
    ["...the foreign tree is LEFT in a gitignored .format-gate-aside dir, not deleted"])
mut("q10_no_perl_remedy_missing", [('        if [ "${INST_STATE:-}" = "nopgrp" ]; then\n            echo "[format-gate]   install perl (macOS ships it; elsewhere your package manager), or run the command above by hand."\n        fi\n', '')],
    ["the no-perl refusal's remedy says to install perl (or run npm ci by hand)"])
mut("q11_extract_dir_check_dropped", [('&&\n           [ -d "$tree/systemTest/$p" ]; } 2>', ';} 2>')], [],
    survive="UNREACHABLE: a package is selected because it was found in the commit's tree, so `ls-files` lists its files and the directory exists; the guard is defence in depth against a package that vanished between discovery and extraction")
mut("q12_sparse_checkout_not_disabled", [(' -c core.sparseCheckout=false read-tree', ' read-tree')], [],
    survive="UNREACHABLE here: sparse patterns would only matter in a repository that sets core.sparseCheckout, and such a working tree lacks the package (and its node_modules) so the run ends in notintree before extraction; no cell sets core.sparseCheckout")
mut("q13_extract_not_via_nul_list", [('xargs -0 git -C', 'xargs git -C')],
    ["a PUSHED .gitattributes marking the red file export-ignore does not hide it -> exit 1"])

def run_suite(gate_path, tag):
    env = dict(os.environ, PACKAGE_FORMAT_GATE_SH=gate_path)
    t = time.time()
    # Popen, so the suite's pid is known: its hang stub sleeps "47.<that pid>", and that is the ONLY
    # thing cleaned up afterwards. (A blanket `pkill sleep 47.*` would kill another suite's stub.)
    proc = subprocess.Popen(["/bin/bash", SUITE], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env)
    try:
        out, _ = proc.communicate(timeout=900); rc = proc.returncode
    except subprocess.TimeoutExpired:
        proc.kill(); out, _ = proc.communicate(); rc = 124
    subprocess.run(["pkill", "-fx", f"sleep 47.{proc.pid}"], capture_output=True)
    for d in glob.glob(os.path.join(os.environ.get("TMPDIR", "/tmp"), ".format-gate-stage.*")):
        shutil.rmtree(d, ignore_errors=True)
    open(f"{OUT}/{tag}.out", "w", encoding="utf-8").write(out)
    m = re.findall(r"package_format_gate: (\d+) passed, (\d+) failed", out)
    passed, failed = (int(m[-1][0]), int(m[-1][1])) if m else (0, 0)
    fails = [l[5:] for l in out.splitlines() if l.startswith("FAIL ")]
    return rc, passed, failed, fails, time.time() - t

if os.environ.get("CHECK_ANCHORS"):
    bad = 0
    for name, edits, kills, survive in M:
        s2 = src
        for old, new in edits:
            if s2.count(old) != 1: print(f"ANCHOR-ERROR {name}: found {s2.count(old)}x: {old[:80]!r}"); bad += 1; break
            s2 = s2.replace(old, new, 1)
        else:
            open(f"{OUT}/_anchor_check.sh", "w").write(s2)
            if subprocess.run(["/bin/bash", "-n", f"{OUT}/_anchor_check.sh"], capture_output=True).returncode: print(f"DOES-NOT-PARSE {name}"); bad += 1
    print(f"anchor check: {len(M)} mutants, {bad} problems"); sys.exit(1 if bad else 0)
results = []
print(f"[{now()}] tamper_gate: {len(M)} mutants + 1 control; gate={GATE}", flush=True)
rc, p, f, fails, dt = run_suite(GATE, "00_control_unmutated")
ok = rc == 0 and f == 0 and p > 0
print(f"[{now()}] CONTROL unmutated gate: {p} passed / {f} failed rc={rc} {dt:.0f}s -> {'GREEN (runner can see green)' if ok else 'NOT GREEN - ABORT'}", flush=True)
if not ok: sys.exit(3)
for i, (name, edits, kills, survive) in enumerate(M, 1):
    if ONLY and name not in ONLY: continue
    s = src; bad = None
    for old, new in edits:
        if s.count(old) != 1: bad = f"anchor found {s.count(old)}x: {old[:70]!r}"; break
        s = s.replace(old, new, 1)
    path = f"{OUT}/{name}.sh"
    if bad:
        results.append(dict(name=name, verdict="ANCHOR-ERROR", detail=bad)); print(f"[{now()}] {i}/{len(M)} {name}: ANCHOR-ERROR {bad}", flush=True); continue
    open(path, "w", encoding="utf-8").write(s)
    if subprocess.run(["/bin/bash", "-n", path], capture_output=True).returncode != 0:
        results.append(dict(name=name, verdict="LOADFAIL (does not parse)")); print(f"[{now()}] {i}/{len(M)} {name}: LOADFAIL does not parse", flush=True); continue
    rc, p, f, fails, dt = run_suite(path, name)
    if p == 0 and f == 0:
        verdict = "LOADFAIL (0 passed, 0 failed)"
    elif f == 0:
        verdict = "SURVIVED-BY-DESIGN" if survive else "SURVIVED"
    else:
        missing = [k for k in kills if not any(k in x for x in fails)]
        verdict = "KILLED-BY-NAME" if kills and not missing else ("KILLED-BUT-NOT-BY-THE-NAMED-CELL" if kills else "KILLED (no name declared)")
    r = dict(name=name, verdict=verdict, passed=p, failed=f, secs=round(dt), missing=[k for k in kills if not any(k in x for x in fails)] if f else kills, survive_note=survive, first_fails=fails[:4])
    results.append(r)
    print(f"[{now()}] {i}/{len(M)} {name}: {verdict}  ({p} passed/{f} failed, {dt:.0f}s)" + (f"  MISSING-NAME: {r['missing']}" if verdict.startswith("KILLED-BUT") else ""), flush=True)
json.dump(results, open(f"{OUT}/results.json", "w"), indent=1)
from collections import Counter
print(f"[{now()}] DONE. verdicts:", dict(Counter(r['verdict'] for r in results)), flush=True)
