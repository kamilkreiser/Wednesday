#!/usr/bin/env python3
"""Gate 1545: the gate's OWN mutants (not in the author's list), each an exact-once edit of a COPY of the head's gate or hook,
run through the real suites. Gate mutants: package_format_gate + ks998_pre_push_judges_the_push (via PACKAGE_FORMAT_GATE_SH).
Hook mutants: the three hook suites (via HOOK_SH). A comment-only control of each must redden nothing.
TMPDIR must be a path without a UUID (npm redaction, see verdict Info)."""
import concurrent.futures as cf, json, os, re, subprocess, sys, time
S = "/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1545"
OUT = sys.argv[1]; os.makedirs(OUT, exist_ok=True)
H = S + "/head"
GATE = open(S + "/gates/gate_50f0552ce.sh").read(); HOOK = open(S + "/gates/hook_50f0552ce.sh").read()
GS = H + "/systemTest/__tests__/package_format_gate.test.sh"
HD = H + "/Blockchain/Dev/scripts/__tests__/"
HOOK_SUITES = [HD + "ks998_pre_push_judges_the_push.test.sh", HD + "ks998_pre_push_stale_base_hint.test.sh", HD + "pre_push_hook_base.test.sh"]
M = []
def g(name, edits, why): M.append(("gate", name, edits, why))
def h(name, edits, why): M.append(("hook", name, edits, why))
g("Y00_gate_comment_only_CONTROL", [("_prettier_ok() {", "# gate-1545 control comment\n_prettier_ok() {")], "must redden nothing")
h("Y00h_hook_comment_only_CONTROL", [('ZERO=0000000000000000000000000000000000000000\n', 'ZERO=0000000000000000000000000000000000000000\n# gate-1545 control comment\n')], "must redden nothing")
g("Y01_allowed_prefix_is_a_substring_match", [("allow.some((p) => p !== \"\" && r.startsWith(p))", "allow.some((p) => p !== \"\" && r.includes(p))")], "brief: prefix -> substring")
LOCKCHK = 'LOCK_REASON="$(_check_lock_sources "$dir" "$REPO_ROOT" "${_allow[@]+"${_allow[@]}"}")" || {\n        INST_STATE="lockbad"; INST_RC=1; return 0\n    }\n'
g("Y02_lock_check_after_the_install", [(LOCKCHK, ''),
    ('wait "$_FG_NPM_PID" 2>/dev/null; INST_RC=$?', 'wait "$_FG_NPM_PID" 2>/dev/null; INST_RC=$?\n    LOCK_REASON="$(_check_lock_sources "$dir" "$REPO_ROOT" "${_allow[@]+"${_allow[@]}"}")" || { INST_STATE="lockbad"; INST_RC=1; _rm_stage "$stage"; _FG_STAGE=""; return 0; }')],
    "brief: the lock check run after the first fetch")
g("Y03_credential_test_not_case_folded", [("lc=\"$(printf '%s' \"$n\" | tr 'A-Z' 'a-z')\"", "lc=\"$n\"")], "credential-name test loses one form (UPPER-case names)")
g("Y04_private_HOME_removed", [('INSTENV=("PATH=$PATH" "HOME=$stage/.home" "TERM=dumb")', 'INSTENV=("PATH=$PATH" "HOME=$HOME" "TERM=dumb")')], "brief: the private HOME removed")
g("Y05_aside_rename_replaced_by_delete", [('mv -- "$stage" "$ASIDE_PATH" 2>/dev/null || { ASIDE_PATH="$stage"; : > "$stage/.format-gate-keep"; }',
                                          '_rm_stage "$stage"; ASIDE_PATH="$stage"')], "brief: the aside rename replaced by a delete")
g("Y06_shrinkwrap_not_checked", [('for (const name of ["package-lock.json", "npm-shrinkwrap.json"]) {', 'for (const name of ["package-lock.json"]) {')], "npm-shrinkwrap.json (which npm prefers) unchecked")
g("Y07_cache_fallback_overrides_a_set_cache", [('case " ${INSTENV[*]:-} " in *" npm_config_cache="*) ;; *) [ -n "${HOME:-}" ]', 'case " ${INSTENV[*]:-} " in *" npm_config_cache_NEVER="*) ;; *) [ -n "${HOME:-}" ]')], "~/.npm appended even when npm_config_cache is set")
g("Y08_xargs_without_NUL", [('ls-files -z -- "systemTest/$p" $anc |', 'ls-files -- "systemTest/$p" $anc |'), ('xargs -0 git', 'xargs git')], "tree-mode extraction splits on whitespace")
h("Y09_onremote_reads_EVERY_remote", [('"refs/remotes/${_remote}/"', '"refs/remotes/"')], "brief: already-on-the-remote reads the wrong remote")
h("Y10_remote_name_ignored_always_origin", [('_remote="${1:-origin}"', '_remote="origin"')], "pushing to a second remote judged by origin's refs")
h("Y11_banner_before_the_refusal", [('    if [ -n "$changed" ] && [ "$_tip" != "$_head_c" ]; then\n', '    [ -z "$_jr_banner" ] || printf \'%s\\n\' "$_jr_banner" >&2\n    if [ -n "$changed" ] && [ "$_tip" != "$_head_c" ]; then\n')], "1540 Minor 1 contradictory text back")
h("Y12_quotePath_dropped_at_the_third_site", [('_files=$(git -c core.quotePath=false diff --name-only "$_b" "$_tip" || true)', '_files=$(git diff --name-only "$_b" "$_tip" || true)')], "non-ASCII package on the merge-base path")
h("Y13_onremote_skip_removed", [('then _jr_skip=onremote; return 0; fi', 'then :; fi')], "1540 Minor 1 false refusals back")

def run(cmd, env):
    t = time.time(); p = subprocess.run(["/bin/bash", cmd], capture_output=True, text=True, env=env, timeout=1500)
    out = p.stdout + p.stderr
    m = re.findall(r"(\d+) passed, (\d+) failed", out)
    return (int(m[-1][0]), int(m[-1][1])) if m else (0, 0), [l[5:] for l in out.splitlines() if l.startswith("FAIL ")], out, time.time() - t

def one(mt):
    kind, name, edits, why = mt
    s = GATE if kind == "gate" else HOOK
    for old, new in edits:
        n = s.count(old)
        if n != 1: return dict(name=name, verdict=f"ANCHOR-ERROR ({n}x) {old[:60]!r}")
        s = s.replace(old, new, 1)
    path = f"{OUT}/{name}.sh"; open(path, "w").write(s); os.chmod(path, 0o755)
    if subprocess.run(["/bin/bash", "-n", path], capture_output=True).returncode: return dict(name=name, verdict="DOES-NOT-PARSE")
    env = dict(os.environ)
    res = {}
    if kind == "gate":
        env["PACKAGE_FORMAT_GATE_SH"] = path; suites = [GS, HOOK_SUITES[0]]
    else:
        env["HOOK_SH"] = path; suites = HOOK_SUITES
    fails_all = []
    for su in suites:
        pf, fails, out, dt = run(su, env)
        res[os.path.basename(su)] = dict(passed=pf[0], failed=pf[1], secs=round(dt), first_fails=fails[:3])
        fails_all += fails
        open(f"{OUT}/{name}.{os.path.basename(su)}.out", "w").write(out)
    tot_p = sum(v["passed"] for v in res.values()); tot_f = sum(v["failed"] for v in res.values())
    verdict = "LOADFAIL" if tot_p == 0 and tot_f == 0 else ("SURVIVED" if tot_f == 0 else "KILLED")
    return dict(name=name, kind=kind, why=why, verdict=verdict, suites=res, first_failing_cell=fails_all[0] if fails_all else None)

with cf.ThreadPoolExecutor(max_workers=int(os.environ.get("WORKERS", "3"))) as ex:
    results = list(ex.map(one, M))
for r in results:
    print(f"{r['name']:<46} {r['verdict']:<9} " + "  ".join(f"{k.split('.')[0]}={v['passed']}/{v['failed']}" for k, v in r.get('suites', {}).items()) + (f"\n      first failing cell: {r['first_failing_cell']}" if r.get('first_failing_cell') else ""), flush=True)
json.dump(results, open(f"{OUT}/my_mutants_results.json", "w"), indent=1)
