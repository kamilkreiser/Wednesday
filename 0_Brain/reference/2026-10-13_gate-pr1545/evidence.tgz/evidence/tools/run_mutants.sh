#!/bin/bash
# Gate 1545: the AUTHOR'S runners on the exact head (gate: 3 shards, each with its own unmutated control; hook: one run).
# TMPDIR goes through a symlink whose path has no UUID: npm's redaction treats a UUID in a path as a secret, and two
# cells call `npm config get userconfig` (see verdict, Info).
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1545
T=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1545/evidence/tools
export TMPDIR=$T/tmp_link_no_uuid
G=$S/head/systemTest/scripts/check-package-format.sh; SU=$S/head/systemTest/__tests__/package_format_gate.test.sh
for sh in aa ab ac; do python3 -I $T/tamper_gate4.py $G $SU $S/mut_gate_$sh $(cat $S/shard_$sh) > $S/mut_gate_$sh.log 2>&1 & done
python3 -I $T/tamper_hook3.py $S/head/.githooks/pre-push $S/mut_hook > $S/mut_hook.log 2>&1 &
wait
echo ALL MUTANTS DONE
