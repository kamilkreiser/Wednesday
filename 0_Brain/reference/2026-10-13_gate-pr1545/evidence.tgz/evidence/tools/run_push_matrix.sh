#!/bin/bash
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1545
E=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1545/evidence
export TMPDIR=$S/tmp
tag=${1:-1}
bash $E/tools/push_matrix.sh $S/gates/hook_50f0552ce.sh $S/gates/gate_50f0552ce.sh $S/pm_head_$tag > $E/logs/B1_push_matrix_HEAD_$tag.txt 2>&1
bash $E/tools/push_matrix.sh $S/gates/hook_026c2d161.sh $S/gates/gate_026c2d161.sh $S/pm_dev_$tag > $E/logs/B1_push_matrix_DEVELOP_$tag.txt 2>&1
cp $S/pm_head_$tag/full.log $E/logs/B1_push_matrix_HEAD_${tag}_full.log
cp $S/pm_dev_$tag/full.log $E/logs/B1_push_matrix_DEVELOP_${tag}_full.log
cat $E/logs/B1_push_matrix_HEAD_$tag.txt; echo; cat $E/logs/B1_push_matrix_DEVELOP_$tag.txt
