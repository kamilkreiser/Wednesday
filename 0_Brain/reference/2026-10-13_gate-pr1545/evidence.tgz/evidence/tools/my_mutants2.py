#!/usr/bin/env python3
"""Gate 1545: the gate's OWN mutants (not in the author's list), each an exact-once edit of a COPY of the head's gate or hook,
run through the real suites. Gate mutants: package_format_gate + ks998_pre_push_judges_the_push (via PACKAGE_FORMAT_GATE_SH).
Hook mutants: the three hook suites (via HOOK_SH). A comment-only control of each must redden nothing.
TMPDIR must be a path without a UUID (npm redaction, see verdict Info)."""
import concurrent.futures as cf, json, os, re, subprocess, sys, time
S = "/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1545"
OUT = sys.argv[1]; os.makedirs(OUT, exist_ok=True)
H = S + "/head"
GATE = open(S + "/gates/gate_50f0552ce.sh").read(); HOOK = open(S + "/gates/hook_50f0552ce.sh").read()
GS = H + "/systemTest/__tests__/package_format_gate.test.sh"
HD = H + "/Blockchain/Dev/scripts/__tests__/"
HOOK_SUITES = [HD + "ks998_pre_push_judges_the_push.test.sh", HD + "ks998_pre_push_stale_base_hint.test.sh", HD + "pre_push_hook_base.test.sh"]
M = []
def g(name, edits, why): M.append(("gate", name, edits, why))
def h(name, edits, why): M.append(("hook", name, edits, why))
FC = '    if [ -n "$changed" ] && [ "$_tip" != "$_head_c" ]; then\n'
h("X02_refusal_skipped_for_tags", [(FC, '    if [ -n "$changed" ] && [ "$_tip" != "$_head_c" ] && case "$_lr" in refs/tags/*) false ;; *) true ;; esac; then\n')], "1540 X02 on the head")
h("X04_head_c_is_the_upstream", [("_head_c=$(git rev-parse --verify --quiet 'HEAD^{commit}' 2>/dev/null || true)", "_head_c=$(git rev-parse '@{upstream}' 2>/dev/null || git rev-parse HEAD)")], "1540 X04 on the head")
g("X09_int_trap_exits_0", [("trap '_fg_cleanup; exit 130' INT", "trap '_fg_cleanup; exit 0' INT")], "1540 X09 on the head")
g("X10_hup_trap_exits_0", [("trap '_fg_cleanup; exit 129' HUP", "trap '_fg_cleanup; exit 0' HUP")], "1540 X10 on the head")
g("X14_ancestor_config_from_HEAD", [('anc="$(git -C "$REPO_ROOT" ls-tree --name-only "$TREE_SHA" -- $ANC_CANDIDATES 2>/dev/null)"', 'anc="$(git -C "$REPO_ROOT" ls-tree --name-only HEAD -- $ANC_CANDIDATES 2>/dev/null)"')], "1540 X14 on the head")
g("X15_notintree_remedy_is_npm_ci", [('if [ "${INST_STATE:-}" = "notintree" ]; then', 'if false; then')], "1540 X15 on the head")
h("Y15_onremote_direction_inverted", [('git for-each-ref --contains "$_tip" "refs/remotes/${_remote}/"', 'git for-each-ref --merged "$_tip" "refs/remotes/${_remote}/"')], "refs the tip CONTAINS, not refs that contain the tip")
g("Y16_integrity_OR_source_suffices", [('if (!okSource(e.resolved)) bad(what, "resolved " + String(e.resolved) + " is not under an allowed source prefix");\n            if (typeof e.integrity !== "string" || e.integrity === "") bad(what, "has no integrity");',
   'if (!okSource(e.resolved) && (typeof e.integrity !== "string" || e.integrity === "")) bad(what, "resolved " + String(e.resolved) + " is not under an allowed source prefix and has no integrity");')], "a bad source passes when it carries an integrity")
g("Y18_put_back_failure_reported_as_put_back", [('                if [ "$rrc" -eq 0 ]; then\n                    INST_STATE="mvforeign"', '                if true; then\n                    INST_STATE="mvforeign"')], "the stage (with the foreign tree) is then deleted")
def run(cmd, env):
    t = time.time(); p = subprocess.run(["/bin/bash", cmd], capture_output=True, text=True, env=env, timeout=1500)
    out = p.stdout + p.stderr
    m = re.findall(r"(\d+) passed, (\d+) failed", out)
    return (int(m[-1][0]), int(m[-1][1])) if m else (0, 0), [l[5:] for l in out.splitlines() if l.startswith("FAIL ")], out, time.time() - t

def one(mt):
    kind, name, edits, why = mt
    s = GATE if kind == "gate" else HOOK
    for old, new in edits:
        n = s.count(old)
        if n != 1: return dict(name=name, verdict=f"ANCHOR-ERROR ({n}x) {old[:60]!r}")
        s = s.replace(old, new, 1)
    path = f"{OUT}/{name}.sh"; open(path, "w").write(s); os.chmod(path, 0o755)
    if subprocess.run(["/bin/bash", "-n", path], capture_output=True).returncode: return dict(name=name, verdict="DOES-NOT-PARSE")
    env = dict(os.environ)
    res = {}
    if kind == "gate":
        env["PACKAGE_FORMAT_GATE_SH"] = path; suites = [GS, HOOK_SUITES[0]]
    else:
        env["HOOK_SH"] = path; suites = HOOK_SUITES
    fails_all = []
    for su in suites:
        pf, fails, out, dt = run(su, env)
        res[os.path.basename(su)] = dict(passed=pf[0], failed=pf[1], secs=round(dt), first_fails=fails[:3])
        fails_all += fails
        open(f"{OUT}/{name}.{os.path.basename(su)}.out", "w").write(out)
    tot_p = sum(v["passed"] for v in res.values()); tot_f = sum(v["failed"] for v in res.values())
    verdict = "LOADFAIL" if tot_p == 0 and tot_f == 0 else ("SURVIVED" if tot_f == 0 else "KILLED")
    return dict(name=name, kind=kind, why=why, verdict=verdict, suites=res, first_failing_cell=fails_all[0] if fails_all else None)

with cf.ThreadPoolExecutor(max_workers=int(os.environ.get("WORKERS", "3"))) as ex:
    results = list(ex.map(one, M))
for r in results:
    print(f"{r['name']:<46} {r['verdict']:<9} " + "  ".join(f"{k.split('.')[0]}={v['passed']}/{v['failed']}" for k, v in r.get('suites', {}).items()) + (f"\n      first failing cell: {r['first_failing_cell']}" if r.get('first_failing_cell') else ""), flush=True)
json.dump(results, open(f"{OUT}/my_mutants_results.json", "w"), indent=1)
