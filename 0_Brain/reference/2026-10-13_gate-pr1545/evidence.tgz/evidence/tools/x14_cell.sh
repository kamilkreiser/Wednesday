#!/bin/bash
# The cell that distinguishes X14 (ancestor-config NAMES listed from HEAD instead of the pushed commit): the pushed commit
# carries .prettierrc, HEAD has DELETED it. CASE 48 (config at both commits, different content) cannot: the content is
# extracted from the pushed commit's private index either way.
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1545
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null TMPDIR=$S/tmp
for gate in $S/gates/gate_50f0552ce.sh $S/my_mut2/X14_ancestor_config_from_HEAD.sh; do
  for shape in deleted_at_HEAD both_differ; do
    r=$S/x14b_$(basename $gate .sh)_$shape; mkdir -p $r/systemTest/scripts $r/systemTest/cfg/src $r/systemTest/cfg/node_modules/.bin
    git -C $r init -q -b main; cp $gate $r/systemTest/scripts/check-package-format.sh
    printf 'node_modules/\nsystemTest/.format-gate-*/\n' > $r/.gitignore
    printf 'A\n' > $r/.prettierrc
    printf '%s\n' '[ "$(cat ../../.prettierrc 2>/dev/null)" = A ] || { echo "[warn] .prettierrc (ancestor config)"; exit 1; }' > $r/systemTest/cfg/check.sh
    printf '{ "name": "c", "version": "0.0.0", "scripts": { "format:check": "sh check.sh" } }\n' > $r/systemTest/cfg/package.json
    printf '#!/bin/sh\nexit 0\n' > $r/systemTest/cfg/node_modules/.bin/prettier; chmod +x $r/systemTest/cfg/node_modules/.bin/prettier
    echo x > $r/systemTest/cfg/src/a.ts
    git -C $r add -A; git -C $r -c user.email=t@t -c user.name=t commit -qm old; OLD=$(git -C $r rev-parse HEAD)
    if [ $shape = deleted_at_HEAD ]; then git -C $r rm -q .prettierrc; else printf 'B\n' > $r/.prettierrc; git -C $r add -A; fi
    git -C $r -c user.email=t@t -c user.name=t commit -qm new
    printf 'systemTest/cfg/src/a.ts\n' | FORMAT_GATE_TREE=$OLD bash $r/systemTest/scripts/check-package-format.sh >/dev/null 2>&1; rc=$?
    echo "$(basename $gate .sh) shape=$shape: pushed OLD commit (config A) judged rc=$rc (want 0)"
  done
done
