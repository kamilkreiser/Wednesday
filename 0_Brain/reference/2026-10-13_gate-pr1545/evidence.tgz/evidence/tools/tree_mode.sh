#!/bin/bash
# tree_mode.sh <gate> <workdir(new)>: FORMAT_GATE_TREE attacks on fixture repos (gate run directly, stdin = changed paths).
# Gate 1545. Never deletes: files are moved into $W/_quarantine. The script changes directory inside its own process only.
set -u
GATE=$1; W=$2
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null npm_config_registry="http://127.0.0.1:9/" npm_config_cache="$W/npmcache"
mkdir -p "$W/_quarantine"
q() { mv -- "$@" "$W/_quarantine/$(date +%s%N)_$RANDOM" 2>/dev/null; }
mk() { # mk <name>: fresh repo with pkgB (check.sh: every file under src must say good), deps present (stub prettier)
  local r=$W/$1; mkdir -p $r; cd $r; git init -q -b main .; git config user.email t@t.t; git config user.name t
  mkdir -p systemTest/scripts systemTest/pkgB/src; cp "$GATE" systemTest/scripts/check-package-format.sh
  printf 'node_modules/\nsystemTest/.format-gate-stage.*/\nsystemTest/.format-gate-tree.*/\nsystemTest/.format-gate-aside.*/\n' > .gitignore
  cat > systemTest/pkgB/check.sh <<'SH'
#!/bin/bash
n=0; bad=0
while IFS= read -r -d '' f; do n=$((n+1)); c=$(cat "$f" 2>/dev/null); [ "$c" = good ] || { echo "[warn] ${f#./} ($(printf '%s' "$c" | od -An -c | tr -s ' ' | head -c 40))"; bad=1; }
  case "$f" in *exe*) [ -x "$f" ] && echo "mode: $f is executable" >&2 || echo "mode: $f NOT executable" >&2 ;; esac
done < <(find src \( -type f -o -type l \) -print0)
echo "checked $n file(s)" >&2
exit $bad
SH
  printf '{ "name": "p", "version": "0.0.0", "scripts": { "format:check": "bash check.sh" } }\n' > systemTest/pkgB/package.json
  echo good > systemTest/pkgB/src/a.ts
  git add -A; git commit -qm init
  mkdir -p systemTest/pkgB/node_modules/.bin; printf '#!/bin/sh\nexit 0\n' > systemTest/pkgB/node_modules/.bin/prettier; chmod +x systemTest/pkgB/node_modules/.bin/prettier
}
gate() { # gate <label> <sha> <paths...>
  local label=$1 sha=$2; shift 2
  local out rc
  out=$(printf '%s\n' "$@" | FORMAT_GATE_TREE=$sha bash systemTest/scripts/check-package-format.sh 2>&1); rc=$?
  printf '%-74s rc=%s trees_left=%s | %s\n' "$label" "$rc" "$(ls -A systemTest | grep -c '^\.format-gate-tree')" "$(printf '%s' "$out" | grep -E 'FAILED|OK|REFUSED|checked [0-9]|could not|SKIP|mode:' | tr '\n' ' ' | cut -c1-230)"
}
wt() { local out rc; out=$(printf '%s\n' "$@" | bash systemTest/scripts/check-package-format.sh 2>&1); rc=$?; printf '   %-71s rc=%s | %s\n' "CONTROL working-tree mode" "$rc" "$(printf '%s' "$out" | grep -E 'FAILED|OK|checked [0-9]|mode:' | tr '\n' ' ' | cut -c1-200)"; }
echo "gate md5=$(md5 -q $GATE)"
echo "== T1 export-ignore: pushed .gitattributes / .git/info/attributes / core.attributesFile"
mk t1; echo bad > systemTest/pkgB/src/red.ts; printf 'src/red.ts export-ignore\n' > systemTest/pkgB/.gitattributes; git add -A; git commit -qm red
gate "T1a red.ts export-ignore'd by the PUSHED .gitattributes" HEAD systemTest/pkgB/src/red.ts
mk t1b; echo bad > systemTest/pkgB/src/red.ts; git add -A; git commit -qm red
gate "T1b CONTROL no attributes: red caught" HEAD systemTest/pkgB/src/red.ts
printf '*.ts export-ignore\n' > .git/info/attributes
gate "T1b .git/info/attributes '*.ts export-ignore'" HEAD systemTest/pkgB/src/red.ts
q .git/info/attributes; printf '*.ts export-ignore\n' > $W/attrs; git config core.attributesFile $W/attrs
gate "T1c core.attributesFile '*.ts export-ignore'" HEAD systemTest/pkgB/src/red.ts
echo "== T2 non-ASCII package name"
mk t2; mkdir -p "systemTest/pkgé/src"; cp systemTest/pkgB/package.json systemTest/pkgB/check.sh "systemTest/pkgé/"; echo bad > "systemTest/pkgé/src/x.ts"; cp -R systemTest/pkgB/node_modules "systemTest/pkgé/"; git add -A; git commit -qm nonascii
gate "T2 red file in systemTest/pkgé (tree mode)" HEAD "systemTest/pkgé/src/x.ts"
gate "T2b --all equivalent: same, discovery only (stdin empty)" HEAD
echo "== T3 symlinks, exec bit, nested dirs"
mk t3; echo bad > $W/outside_red.txt; ln -s $W/outside_red.txt systemTest/pkgB/src/link.ts; git add -A; git commit -qm link
gate "T3a src/link.ts -> absolute outside file (red)" HEAD systemTest/pkgB/src/link.ts
mk t3b; ln -s ../../nonexistent systemTest/pkgB/src/dang.ts; git add -A; git commit -qm dang
gate "T3b dangling symlink" HEAD systemTest/pkgB/src/dang.ts
mk t3c; echo good > systemTest/pkgB/src/exe.ts; chmod +x systemTest/pkgB/src/exe.ts; git add -A; git commit -qm exe; chmod -x systemTest/pkgB/src/exe.ts
gate "T3c exec bit in the commit (WT copy chmod -x): check sees mode" HEAD systemTest/pkgB/src/exe.ts
mk t3d; mkdir -p systemTest/pkgB/src/a/b/c/d; echo bad > systemTest/pkgB/src/a/b/c/d/deep.ts; git add -A; git commit -qm deep
gate "T3d red file 5 dirs deep" HEAD systemTest/pkgB/src/a/b/c/d/deep.ts
echo "== T4 filters and eol (checkout-index applies working-tree conversions)"
mk t4; echo bad > systemTest/pkgB/src/f.ts; printf '*.ts filter=fix\n' > systemTest/pkgB/.gitattributes; git add -A; git commit -qm filt
git config filter.fix.smudge "sed s/bad/good/"; git config filter.fix.clean cat
gate "T4a red blob, DEVELOPER smudge filter bad->good (pushed attr + local driver)" HEAD systemTest/pkgB/src/f.ts
wt systemTest/pkgB/src/f.ts
git config --unset filter.fix.smudge
gate "T4a' CONTROL same commit, no smudge driver configured" HEAD systemTest/pkgB/src/f.ts
mk t4b; echo good > systemTest/pkgB/src/e.ts; printf '*.ts text eol=crlf\n' > systemTest/pkgB/.gitattributes; git add -A; git commit -qm crlf
gate "T4b green LF blob, pushed attr 'text eol=crlf' (checkout gives CRLF)" HEAD systemTest/pkgB/src/e.ts
mk t4c; echo good > systemTest/pkgB/src/e.ts; git add -A; git commit -qm lf; git config core.autocrlf true
gate "T4c green LF blob, developer core.autocrlf=true" HEAD systemTest/pkgB/src/e.ts
mk t4d; printf 'good$Id$\n' > systemTest/pkgB/src/i.ts; printf '*.ts ident\n' > systemTest/pkgB/.gitattributes; git add -A; git commit -qm ident
gate "T4d 'ident' attribute expands \$Id\$ on checkout" HEAD systemTest/pkgB/src/i.ts
echo "== T5 sparse checkout (q12): the package's src is OUTSIDE the developer's sparse patterns"
mk t5; echo bad > systemTest/pkgB/src/red.ts; git add -A; git commit -qm red
git sparse-checkout init --no-cone >/dev/null 2>&1; printf '/*\n!/systemTest/pkgB/src/\n' > .git/info/sparse-checkout; git read-tree -mu HEAD 2>/dev/null
echo "   [setup] core.sparseCheckout=$(git config core.sparseCheckout) src in WT? $(ls systemTest/pkgB/src 2>/dev/null | wc -l | tr -d ' ') files; package.json in WT? $(test -f systemTest/pkgB/package.json && echo yes)"
gate "T5a non-cone sparse: red src not in WT" HEAD systemTest/pkgB/src/red.ts
mk t5b; echo bad > systemTest/pkgB/src/red.ts; git add -A; git commit -qm red
git sparse-checkout set --cone --sparse-index systemTest/pkgB/node_modules >/dev/null 2>&1 ; git sparse-checkout add systemTest/scripts >/dev/null 2>&1
echo "   [setup] sparseCheckout=$(git config core.sparseCheckout) cone=$(git config core.sparseCheckoutCone) index.sparse=$(git config index.sparse) pkgB/package.json in WT? $(test -f systemTest/pkgB/package.json && echo yes || echo no)"
gate "T5b cone + sparse index: package outside the cone (notintree expected)" HEAD systemTest/pkgB/src/red.ts
echo "== T6 cleanup of the tree dir and its private index on each exit path"
mk t6; printf '{ "name": "p", "version": "0.0.0", "scripts": { "format:check": "sleep 30; bash check.sh" } }\n' > systemTest/pkgB/package.json; git add -A; git commit -qm slow
for sig in INT TERM HUP QUIT KILL; do
  ( printf 'systemTest/pkgB/package.json\n' | FORMAT_GATE_TREE=HEAD bash systemTest/scripts/check-package-format.sh >/dev/null 2>&1 ) & bgp=$!
  for i in $(seq 1 50); do ls -d systemTest/.format-gate-tree.* >/dev/null 2>&1 && [ -n "$(ls systemTest/.format-gate-tree.*/.idx 2>/dev/null)" ] && break; sleep 0.1; done
  sleep 0.5; gp=$(pgrep -P $bgp -f check-package-format | head -1); [ -n "$gp" ] || gp=$bgp
  idx_during=$(ls systemTest/.format-gate-tree.*/.idx 2>/dev/null | wc -l | tr -d ' ')
  kill -$sig $gp 2>/dev/null; wait $bgp 2>/dev/null; sleep 1.5
  echo "   SIG$sig: .idx present during the check=$idx_during  tree dirs left after=$(ls -d systemTest/.format-gate-tree.* 2>/dev/null | wc -l | tr -d ' ')  sleep-30 survivors=$(pgrep -f 'sleep 30' | wc -l | tr -d ' ')"
done
printf '{ "name": "p", "version": "0.0.0", "scripts": { "format:check": "bash check.sh" } }\n' > systemTest/pkgB/package.json; echo bad > systemTest/pkgB/src/z.ts; git add -A; git commit -qm red
gate "T6b next run (red, exit 1): sweeps dead runs' tree dirs, leaves none of its own" HEAD systemTest/pkgB/src/z.ts
echo "== T7 where the private index lives: GIT_INDEX_FILE=<tree>/.idx; the real index untouched"
mk t7; before=$(md5 -q .git/index); gate "T7 tree mode run" HEAD systemTest/pkgB/src/a.ts; echo "   .git/index unchanged: $([ "$before" = "$(md5 -q .git/index)" ] && echo yes || echo NO)  index.lock left: $(ls .git/index.lock 2>/dev/null | wc -l | tr -d ' ')"
echo DONE
