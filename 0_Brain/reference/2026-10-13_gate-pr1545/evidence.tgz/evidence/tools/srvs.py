# HTTPS variant of srv.py (self-signed cert): argv = portfile tgz log certfile keyfile
import http.server, ssl, sys, os
portfile, tgz, log, cert, key = sys.argv[1:6]
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        with open(log, 'a') as f: f.write(f"GET {self.path} host={self.headers.get('Host')} auth={'yes' if self.headers.get('Authorization') else 'no'}\n")
        if self.path.endswith('.tgz'):
            b = open(tgz, 'rb').read(); self.send_response(200); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
        else:
            self.send_response(404); self.end_headers()
s = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H)
ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.load_cert_chain(cert, key)
s.socket = ctx.wrap_socket(s.socket, server_side=True)
open(portfile, 'w').write(str(s.server_address[1]))
s.serve_forever()
