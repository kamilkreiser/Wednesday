#!/bin/bash
# minor3.sh <gate> <workdir(new)>: the move-BACK window of gate 1540 Minor 3, on the REAL gate.
# An npm stub makes an install whose prettier is an ABSOLUTE symlink into the stage (so the gate moves the tree back);
# a node shim plays "another actor" at the worst moments. Nothing is deleted: displaced trees are mv'd into _quarantine.
set -u
GATE=$1; W=$2
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null npm_config_registry="http://127.0.0.1:9/"
mkdir -p "$W/bin" "$W/_quarantine"
REAL_NODE=$(command -v node); REAL_NPM=$(command -v npm); REAL_MV=/bin/mv
cat > $W/bin/npm <<'N'
#!/bin/bash
if [ "${1:-}" = ci ]; then
  mkdir -p node_modules/.bin node_modules/real; printf '#!/bin/sh\nexit 0\n' > node_modules/real/p; chmod +x node_modules/real/p
  ln -s "$PWD/node_modules/real/p" node_modules/.bin/prettier; exit 0
fi
exec "$REAL_NPM" "$@"
N
cat > $W/bin/node <<'N'
#!/bin/bash
# SWAP=1/2/3: on the BACK rename (package -> stage) another actor replaces the package's node_modules with ITS tree first.
# SWAP=2/3: on the PUT-BACK rename (stage -> package) a THIRD tree appears in the package first, so the put-back fails.
case "${2:-}" in *renameSync*)
  case "${3:-}" in
    */systemTest/p/node_modules)
      if [ "${SWAP:-0}" -ge 1 ]; then /bin/mv "$3" "$QDIR/ours_$$"; mkdir -p "$3"; echo precious > "$3/FOREIGN_DEVELOPER_TREE"; fi ;;
    */.format-gate-stage.*/node_modules)
      case "${4:-}" in */systemTest/p/node_modules)
        # the FIRST stage->package rename is the gate's forward move; only the SECOND is the put-back
        n=$(cat "$QDIR/.fwd_count_$SWAP" 2>/dev/null || echo 0); n=$((n+1)); echo $n > "$QDIR/.fwd_count_$SWAP"
        if [ "${SWAP:-0}" -ge 2 ] && [ "$n" -ge 2 ]; then mkdir -p "$4"; echo third > "$4/THIRD_TREE"; fi ;;
      esac ;;
  esac ;;
esac
exec "$REAL_NODE" "$@"
N
cat > $W/bin/mv <<'N'
#!/bin/bash
# SWAP=3: the rename of the stage to .format-gate-aside.* fails
case "$*" in *format-gate-stage.*format-gate-aside.*) [ "${SWAP:-0}" = 3 ] && { echo "mv: simulated failure" >&2; exit 1; } ;; esac
exec /bin/mv "$@"
N
chmod +x $W/bin/*
export REAL_NODE REAL_NPM QDIR=$W/_quarantine
echo "gate md5=$(md5 -q $GATE)"
for swap in 0 1 2 3; do
  r=$W/m3-$swap; mkdir -p $r/systemTest/scripts $r/systemTest/p; cp "$GATE" $r/systemTest/scripts/check-package-format.sh
  printf '{ "name": "p", "version": "0.0.0", "scripts": { "format:check": "exit 0" } }\n' > $r/systemTest/p/package.json
  out=$(printf 'systemTest/p/x\n' | PATH="$W/bin:$PATH" SWAP=$swap bash $r/systemTest/scripts/check-package-format.sh 2>&1); rc=$?
  ref=$(printf '%s' "$out" | grep -o 'REFUSED[^—]*— [^:]*: [^(]*([^)]*)' | head -1 | cut -c1-260)
  echo "SWAP=$swap rc=$rc"
  echo "   refusal: $ref"
  echo "   foreign tree in package: $( [ -e $r/systemTest/p/node_modules/FOREIGN_DEVELOPER_TREE ] && echo yes || echo no)  third tree in package: $( [ -e $r/systemTest/p/node_modules/THIRD_TREE ] && echo yes || echo no)"
  echo "   foreign tree in an aside dir: $(ls $r/systemTest/.format-gate-aside.*/node_modules/FOREIGN_DEVELOPER_TREE 2>/dev/null | wc -l | tr -d ' ')  in a kept stage: $(ls $r/systemTest/.format-gate-stage.*/node_modules/FOREIGN_DEVELOPER_TREE 2>/dev/null | wc -l | tr -d ' ')  keep markers: $(ls $r/systemTest/.format-gate-stage.*/.format-gate-keep 2>/dev/null | wc -l | tr -d ' ')"
  echo "   foreign tree ANYWHERE under the fixture: $(find $r -name FOREIGN_DEVELOPER_TREE | wc -l | tr -d ' ')   aside path named in the refusal: $(printf '%s' "$out" | grep -c 'format-gate-aside\.')"
  if [ $swap = 3 ]; then
    q1=$(ls -d $r/systemTest/.format-gate-stage.* 2>/dev/null | head -1)
    mkdir -p $r/systemTest/.format-gate-stage.999999.DEADxx   # an ordinary dead run's stage (pid 999999 not alive)
    out2=$(printf 'systemTest/p/x\n' | PATH="$W/bin:$PATH" SWAP=0 bash $r/systemTest/scripts/check-package-format.sh 2>&1)
    echo "   next run: kept stage still there: $( [ -d "$q1" ] && echo yes || echo no)  ordinary dead stage swept: $( [ -d $r/systemTest/.format-gate-stage.999999.DEADxx ] && echo no || echo yes)  foreign tree still exists: $(find $r -name FOREIGN_DEVELOPER_TREE | wc -l | tr -d ' ')"
  fi
done
echo "== window: wall time of the node process that performs one rename(2), 30 runs (instrument: python perf_counter around subprocess)"
python3 -I - "$REAL_NODE" "$W" <<'PY'
import subprocess,sys,time,statistics,os
d=os.path.join(sys.argv[2],'win'); os.makedirs(d,exist_ok=True); ts=[]
for i in range(30):
    a=os.path.join(d,'a%d'%i); os.mkdir(a); b=os.path.join(d,'b%d'%i)
    t=time.perf_counter(); subprocess.run([sys.argv[1],'-e','require("fs").renameSync(process.argv[1], process.argv[2])',a,b]); ts.append((time.perf_counter()-t)*1000)
print("  node rename process wall ms: min %.1f median %.1f max %.1f"%(min(ts),statistics.median(ts),max(ts)))
PY
