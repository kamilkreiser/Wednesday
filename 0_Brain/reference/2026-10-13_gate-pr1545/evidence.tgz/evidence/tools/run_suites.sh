#!/bin/bash
# Gate 1545 suite runner: head + develop red/green, controls, QUIT/INT ignored, dash, bash 3.2
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1545
E=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1545/evidence/logs/suites
mkdir -p $E
H=$S/head; D=$S/dev; GT=$S/gates
export TMPDIR=$S/tmp; mkdir -p $TMPDIR
GS=$H/systemTest/__tests__/package_format_gate.test.sh
HS=$H/Blockchain/Dev/scripts/__tests__/ks998_pre_push_judges_the_push.test.sh
HG=$GT/gate_50f0552ce.sh; HH=$GT/hook_50f0552ce.sh; DG=$GT/gate_026c2d161.sh; DH=$GT/hook_026c2d161.sh
sum() { grep -E '[0-9]+ passed, [0-9]+ failed' "$1" | tail -1; }
run() { local tag=$1; shift; local t0=$(date +%s)
  "$@" > $E/$tag.log 2>&1; local rc=$?
  echo "$(date +%H:%M:%S) $tag rc=$rc $(( $(date +%s)-t0 ))s :: $(sum $E/$tag.log)" | tee -a $E/SUMMARY_suites.txt; }
sed '2i\
exit 0' $HG > $GT/C1_gate_exit0.sh
sed '2i\
exit 0' $HH > $GT/C3_hook_exit0.sh
sed '1s|.*|#!/bin/dash|' $HH > $GT/hook_dash.sh
sed '1s|.*|#!/bin/bash|' $HH > $GT/hook_bash32.sh
awk '{print} /^_judge_ref\(\) \{/{print "    [[ x == x ]] || { _jr_skip=empty; return 0; }"}' $GT/hook_dash.sh > $GT/hook_dash_bashism.sh
chmod +x $GT/*.sh
echo "bash: $(/bin/bash --version | head -1); dash: $(ls -l /bin/dash); sh: $(/bin/sh --version 2>&1|head -1)" | tee -a $E/SUMMARY_suites.txt
grep -c '\[\[ x == x \]\]' $GT/hook_dash_bashism.sh | sed 's/^/bashism lines injected: /' | tee -a $E/SUMMARY_suites.txt
for i in 1 2; do run G_head_$i /bin/bash $GS; done
run G_head_QUIT_INT_ignored /bin/bash -c "trap '' QUIT INT; exec /bin/bash $GS"
run G_C1_exit0 env PACKAGE_FORMAT_GATE_SH=$GT/C1_gate_exit0.sh /bin/bash $GS
for i in 1 2; do run G_red_develop_$i env PACKAGE_FORMAT_GATE_SH=$DG /bin/bash $GS; done
for i in 1 2; do run G_develop_own_suite_$i /bin/bash $D/systemTest/__tests__/package_format_gate.test.sh; done
for i in 1 2; do run H_head_$i /bin/bash $HS; done
for i in 1 2; do run H_red_develop_$i env HOOK_SH=$DH PACKAGE_FORMAT_GATE_SH=$DG /bin/bash $HS; done
run H_develop_own_suite /bin/bash $D/Blockchain/Dev/scripts/__tests__/ks998_pre_push_judges_the_push.test.sh
run H_head_dash env HOOK_SH=$GT/hook_dash.sh /bin/bash $HS
run H_head_bash32 env HOOK_SH=$GT/hook_bash32.sh /bin/bash $HS
run H_C_dash_bashism env HOOK_SH=$GT/hook_dash_bashism.sh /bin/bash $HS
run H_C3_exit0 env HOOK_SH=$GT/C3_hook_exit0.sh /bin/bash $HS
run H_head_QUIT_INT_ignored /bin/bash -c "trap '' QUIT INT; exec /bin/bash $HS"
for su in ks998_pre_push_stale_base_hint pre_push_hook_base pre_push_hook_base_fixture_guard pre_push_hook_current_develop ks884_pre_push_tag_named_develop pre_push_hook_base_leg_comment pre_push_stack_legs_comment; do
  for i in 1 2; do run O_head_${su}_$i /bin/bash $H/Blockchain/Dev/scripts/__tests__/$su.test.sh; done
  run O_develop_${su} /bin/bash $D/Blockchain/Dev/scripts/__tests__/$su.test.sh
  case $su in pre_push_hook_base_leg_comment|pre_push_stack_legs_comment) ;; *)
    run O_C3_${su} env HOOK_SH=$GT/C3_hook_exit0.sh /bin/bash $H/Blockchain/Dev/scripts/__tests__/$su.test.sh ;; esac
done
for su in ks998_format_gate_push_label_is_literal ks998_format_gate_stdin_isolated; do
  for i in 1 2; do run O_head_${su}_$i /bin/bash $H/systemTest/__tests__/$su.test.sh; done
  run O_C1_${su} env PACKAGE_FORMAT_GATE_SH=$GT/C1_gate_exit0.sh /bin/bash $H/systemTest/__tests__/$su.test.sh
done
echo "$(date +%H:%M:%S) ALL DONE" | tee -a $E/SUMMARY_suites.txt
