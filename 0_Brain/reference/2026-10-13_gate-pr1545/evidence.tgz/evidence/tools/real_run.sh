#!/bin/bash
# Gate 1545: the real four systemTest packages at the head, in a scratch worktree of the head.
# (1) the lock check alone on each real lockfile (+ a planted bad entry as control), timed;
# (2) the real gate, tree mode, --all, EMPTY cache, scrubbed env, real registry; (3) the same with the network denied.
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1545
R=$S/head; export TMPDIR=$S/tmp
G=$R/systemTest/scripts/check-package-format.sh
echo "worktree HEAD=$(git -C $R rev-parse HEAD)  gate md5=$(md5 -q $G)"
sed -n '/^_check_lock_sources() {/,/^}/p' $G > $S/lockfn.sh
echo "== (1) lock check alone (instrument: python perf_counter around 'bash -c source+call'; 3 runs each, median)"
for p in akto api-explorer performance playwright; do
  python3 -I - "$S/lockfn.sh" "$R/systemTest/$p" "$R" <<'PY'
import subprocess,sys,time,statistics
ts=[];rcs=set();outs=set()
for i in range(3):
    t=time.perf_counter(); r=subprocess.run(["/bin/bash","-c",'source "$1"; _check_lock_sources "$2" "$3" https://registry.npmjs.org/',"x",*sys.argv[1:]],capture_output=True,text=True); ts.append((time.perf_counter()-t)*1000); rcs.add(r.returncode); outs.add(r.stdout[:120])
print("  %-14s rc=%s out=%r median %.0f ms"%(sys.argv[2].split('/')[-1],rcs,outs,statistics.median(ts)))
PY
done
mkdir -p $S/lockctl/systemTest/akto; node -e 'const f=process.argv[1],j=require(f);j.packages["node_modules/zz-planted"]={version:"1.0.0",resolved:"https://evil.example/zz.tgz",integrity:"sha512-AAAA"};require("fs").writeFileSync(process.argv[2],JSON.stringify(j))' $R/systemTest/akto/package-lock.json $S/lockctl/systemTest/akto/package-lock.json
bash -c 'source "$1"; _check_lock_sources "$2" "$3" https://registry.npmjs.org/; echo "  CONTROL real akto lock + one planted evil.example entry: rc=$?"' x $S/lockfn.sh $S/lockctl/systemTest/akto $S/lockctl
echo "== (2) real gate, tree mode (FORMAT_GATE_TREE=HEAD), --all, empty cache, scrubbed env, real registry"
EC=$S/realcache_$$; mkdir -p $EC $S/realhome_$$
echo "  before: node_modules dirs: $(ls -d $R/systemTest/*/node_modules 2>/dev/null | wc -l | tr -d ' ')  cache entries: $(find $EC -type f | wc -l | tr -d ' ')  git status lines: $(git -C $R status --porcelain | wc -l | tr -d ' ')"
locks_before=$(md5 -q $R/systemTest/*/package-lock.json | tr '\n' ' ')
t0=$(python3 -c 'import time;print(time.time())')
out=$(env -i PATH="$PATH" HOME=$S/realhome_$$ TMPDIR=$TMPDIR npm_config_cache=$EC FORMAT_GATE_TREE=HEAD bash $G --all </dev/null 2>&1); rc=$?
t1=$(python3 -c 'import time;print(time.time())')
printf '%s\n' "$out" > $S/real_run_gate.out
echo "  rc=$rc wall=$(python3 -c "print(round($t1-$t0,1))")s"
printf '%s\n' "$out" | grep -E 'INSTALLED|format:check (OK|FAILED)|REFUSED|SKIP|lockfile|checked|NOTHING' | sed 's/^/  | /'
echo "  after: node_modules dirs: $(ls -d $R/systemTest/*/node_modules 2>/dev/null | wc -l | tr -d ' ')  stage/tree/aside dirs: $(ls -d $R/systemTest/.format-gate-* 2>/dev/null | wc -l | tr -d ' ')  prettier executable: $(for p in akto api-explorer performance playwright; do [ -x $R/systemTest/$p/node_modules/.bin/prettier ] && printf '%s ' $p; done)  locks byte-identical: $([ "$locks_before" = "$(md5 -q $R/systemTest/*/package-lock.json | tr '\n' ' ')" ] && echo yes || echo NO)  git status lines: $(git -C $R status --porcelain | wc -l | tr -d ' ')  marker files: $(find $R/systemTest/*/node_modules -maxdepth 1 -name '.format-gate-*' 2>/dev/null | wc -l | tr -d ' ')"
echo "== (3) the same packages' installs with the network denied (sandbox-exec deny network*), a fresh empty cache"
mkdir -p $S/offline_$$/systemTest/scripts; cp $G $S/offline_$$/systemTest/scripts/; for p in akto playwright; do mkdir -p $S/offline_$$/systemTest/$p; cp $R/systemTest/$p/package.json $R/systemTest/$p/package-lock.json $S/offline_$$/systemTest/$p/; done
mkdir -p $S/offline_$$/observability; cp -R $R/observability/. $S/offline_$$/observability/ 2>/dev/null
EC2=$S/realcache2_$$; mkdir -p $EC2
out=$(sandbox-exec -p '(version 1)(allow default)(deny network-outbound (remote ip "*:*"))' env -i PATH="$PATH" HOME=$S/realhome_$$ TMPDIR=$TMPDIR npm_config_cache=$EC2 bash $S/offline_$$/systemTest/scripts/check-package-format.sh --all </dev/null 2>&1); rc=$?
echo "  rc=$rc"; printf '%s\n' "$out" | grep -E 'INSTALLED|OK|REFUSED|SKIP|NOTHING|ENOTFOUND|EAI_AGAIN|ECONNREFUSED|EPERM' | head -6 | cut -c1-200 | sed 's/^/  | /'
echo "  CONTROL curl inside the sandbox: $(sandbox-exec -p '(version 1)(allow default)(deny network-outbound (remote ip "*:*"))' curl -s -o /dev/null -w '%{http_code}' --max-time 5 https://registry.npmjs.org/ 2>/dev/null)  outside: $(curl -s -o /dev/null -w '%{http_code}' --max-time 5 https://registry.npmjs.org/)"
