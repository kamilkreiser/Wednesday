// Gate cell (PR 1549): POST /api/anchors/batch persists each item through the SAME upsert (index.ts:792) with a
// batch-shaped payload (index.ts:772-781) and IGNORES the returned id. What does a batch item do to an existing
// single-anchor row on the same (document_id, network)? argv: tree arm
import * as fs from 'fs';
import * as path from 'path';
import { createRequire } from 'module';
const [tree, arm] = process.argv.slice(2);
const A = path.join(tree, 'Blockchain/Dev/services/anchoring');
const req = createRequire(path.join(A, 'package.json'));
const { Client } = req('pg');
const { anchorDocumentSchema, buildFlatAnchorMetadataPayload } = req(path.join(A, 'src/anchorSchema.ts'));
const src = fs.readFileSync(path.join(A, 'src/index.ts'), 'utf8');
const s = src.indexOf('`INSERT INTO anchor_store');
const sql = src.slice(s + 1, src.indexOf('`', s + 1));
const NET = 'preprod';
const DOC = `doc-${Date.now()}-batch${arm}`;
const H = 'e'.repeat(64);
(async () => {
  const c = new Client({ connectionString: process.env.GATE_DB });
  await c.connect();
  const d = anchorDocumentSchema.parse({ documentId: DOC, contentHash: H, identity: { actorDid: 'did:key:zUPLOADER', actorLevel: 2 } });
  const now = new Date();
  await c.query(sql, ['anchor_single_'+DOC, DOC, 'single', H, null, null, NET, 674, JSON.stringify(buildFlatAnchorMetadataPayload(d, NET)),
    'confirmed', '9'.repeat(64), null, null, null, null, 1, now, null, 0, false, now, now]);
  const batchPayload = { secuura: { version: '1.0', type: 'batch', merkleRoot: 'r'.repeat(64), documentCount: 2, batchId: 'batch_x', timestamp: now.toISOString() } };
  await c.query(sql, ['anchor_batchitem_0_'+DOC, DOC, 'batch', H, 'r'.repeat(64), JSON.stringify(['p']), NET, 675, JSON.stringify(batchPayload),
    'pending', null, null, null, null, null, 0, null, null, 0, false, now, now]);
  const r = (await c.query('SELECT id, anchor_type, metadata_label, merkle_root, status, transaction_hash, metadata_payload FROM anchor_store WHERE document_id=$1', [DOC])).rows[0];
  const byNewId = (await c.query('SELECT 1 FROM anchor_store WHERE id=$1', ['anchor_batchitem_0_' + DOC])).rows.length;
  console.log(JSON.stringify({ arm, id: r.id, anchor_type: r.anchor_type, label: r.metadata_label, merkle_root: r.merkle_root, status: r.status,
    tx: r.transaction_hash, payloadType: r.metadata_payload.secuura.type, payloadHash: r.metadata_payload.secuura.hash ?? 'ABSENT',
    actorDid: r.metadata_payload.secuura.actorDid ?? 'ABSENT', rowsFoundByBatchItemId: byNewId }));
  await c.end();
})().catch((e) => { console.error(e); process.exit(1); });
