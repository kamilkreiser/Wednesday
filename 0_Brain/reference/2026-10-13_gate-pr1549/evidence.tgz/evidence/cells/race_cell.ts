// Gate cell (PR 1549): does "the identity stored beside a transaction hash is the identity of the event that
// produced that hash" hold when a second event lands while the first is being submitted?
// Uses the PRODUCT's createAnchorSubmitter (real wallet lock, real guards), the PRODUCT's upsert SQL extracted
// from index.ts, the PRODUCT's payload builder, and real Postgres. Only the chain is faked: submit() records the
// payload it was handed under a tx hash = sha256(payload), so "what the chain says" is checkable.
// updateStatus mirrors index.ts dbUpdateAnchorStatus (status / transaction_hash / block fields / confirmed_at).
// argv: tree arm mode   (mode = race | serial)
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import { createRequire } from 'module';

const [tree, arm, mode] = process.argv.slice(2);
const A = path.join(tree, 'Blockchain/Dev/services/anchoring');
const req = createRequire(path.join(A, 'package.json'));
const { Client } = req('pg');
const { anchorDocumentSchema, buildFlatAnchorMetadataPayload } = req(path.join(A, 'src/anchorSchema.ts'));
const { createAnchorSubmitter } = req(path.join(A, 'src/anchorSubmission.ts'));

const src = fs.readFileSync(path.join(A, 'src/index.ts'), 'utf8');
const s = src.indexOf('`INSERT INTO anchor_store');
const sql = src.slice(s + 1, src.indexOf('`', s + 1));

const NET = 'preprod';
const DOC = `doc-${Date.now()}-race${arm}${mode}`;
const HASH = 'c'.repeat(64);
const chain = new Map<string, any>();
let gateRelease: () => void = () => {};
let gate = new Promise<void>((r) => { gateRelease = r; });
let firstSubmitEntered: () => void = () => {};
const firstSubmitSeen = new Promise<void>((r) => { firstSubmitEntered = r; });

async function main() {
  const c = new Client({ connectionString: process.env.GATE_DB });
  await c.connect();
  const upsert = async (identity: any) => {
    const data = anchorDocumentSchema.parse({ documentId: DOC, contentHash: HASH, network: NET, identity });
    const payload = buildFlatAnchorMetadataPayload(data, NET);
    const now = new Date();
    const r = await c.query(sql, [`anchor_${crypto.randomUUID()}`, DOC, 'single', HASH, null, null, NET, 674,
      JSON.stringify(payload), 'pending', null, null, null, null, null, 0, null, null, 0, false, now, now]);
    return r.rows[0].id as string;
  };
  let submits = 0;
  const submitter = createAnchorSubmitter({
    getAnchor: async (id: string) => {
      const r = (await c.query('SELECT * FROM anchor_store WHERE id=$1', [id])).rows[0];
      return r ? { id: r.id, status: r.status, transactionHash: r.transaction_hash || undefined, retryCount: r.retry_count,
        metadataLabel: r.metadata_label, metadataPayload: r.metadata_payload } : null;
    },
    submit: async (_label: number, payload: any, options?: any) => {
      submits++;
      const tx = crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex');
      chain.set(tx, payload);
      if (submits === 1) { firstSubmitEntered(); await gate; }
      await options?.onSigned?.(tx);
      return { txHash: tx, fee: 1 };
    },
    confirm: async () => ({ confirmed: true, blockNumber: 1, slot: 1, blockHash: 'f'.repeat(64), confirmations: 1, polled: 1, errored: 0 }),
    updateStatus: async (id: string, u: any) => {
      const sets: string[] = []; const p: any[] = []; let i = 1;
      if (u.status !== undefined) { sets.push(`status=$${i++}`); p.push(u.status); }
      if (u.transactionHash !== undefined) { sets.push(`transaction_hash=$${i++}`); p.push(u.transactionHash); }
      if (u.blockHash !== undefined) { sets.push(`block_hash=$${i++}`); p.push(u.blockHash); }
      if (u.confirmedAt !== undefined) { sets.push(`confirmed_at=$${i++}`); p.push(u.confirmedAt); }
      sets.push(`updated_at=$${i++}`); p.push(new Date()); p.push(id);
      await c.query(`UPDATE anchor_store SET ${sets.join(', ')} WHERE id=$${i}`, p);
    },
    bumpRetryCount: async () => {},
    scheduleRetry: () => {},
    log: () => {},
  });

  const id = await upsert({ actorDid: 'did:key:zUPLOADER', actorLevel: 1 });
  const p1 = submitter(id);                       // processAnchor for event 1
  if (mode === 'race') {
    await firstSubmitSeen;                        // event 1 has read its payload and is building/signing
    await upsert({ actorDid: 'did:key:zSHARER', actorLevel: 3 });   // event 2 lands (POST /api/anchors)
    const p2 = submitter(id);                     // processAnchor for event 2
    await new Promise((r) => setTimeout(r, 50));
    gateRelease();
    await Promise.all([p1, p2]);
  } else {
    gateRelease();
    await p1;
    await upsert({ actorDid: 'did:key:zSHARER', actorLevel: 3 });
    await submitter(id);
  }
  const row = (await c.query('SELECT status, transaction_hash, metadata_payload FROM anchor_store WHERE id=$1', [id])).rows[0];
  const onChain = chain.get(row.transaction_hash);
  const stored = row.metadata_payload.secuura.actorDid;
  const chained = onChain?.secuura?.actorDid;
  console.log(JSON.stringify({ arm, mode, submits, status: row.status, tx: row.transaction_hash?.slice(0, 8),
    storedActor: stored, actorInTheTxOnChain: chained, invariantHolds: stored === chained }));
  await c.end();
}
main().catch((e) => { console.error(e); process.exit(1); });
