#!/usr/bin/env python3
"""Gate 1549 mutation runner. Each mutant: exact-once string replacement in the mut worktree, run the
originate ks1385 suites (jest --json) and the anchoring integration lane (vitest --reporter=json), record
which NAMED cells failed and the total cell count, then restore the file with `git checkout` (scratch clone).
A kill only counts if (a) >=1 named assertion failed, (b) every failing cell carries a non-empty message,
(c) the cell count did not collapse (no suite load failure)."""
import json, os, subprocess, sys, pathlib

G = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1549'
W = G + '/mut'
D = W + '/Blockchain/Dev'
O = D + '/services/originate'
A = D + '/services/anchoring'
EV = G + '/ev/mutants'
os.makedirs(EV, exist_ok=True)
DOCS = 'Blockchain/Dev/services/originate/src/routes/documents.ts'
ANCH = 'Blockchain/Dev/services/originate/src/routes/anchors.ts'
CERT = 'Blockchain/Dev/services/originate/src/routes/certifications.ts'
HELP = 'Blockchain/Dev/services/originate/src/utils/anchorIdentity.ts'
IDX = 'Blockchain/Dev/services/anchoring/src/index.ts'

S1 = """        certId: id,
        ...anchorIdentityFields(req.body),
      });"""
S2 = """            // KS-1385 site 2: the re-anchor path carries S's identity too.
            ...anchorIdentityFields(req.body),"""
S3 = "        ...anchorIdentityFields({ identity }),"
S4 = """            // KS-1385 site 4: originate's OWN POST /api/anchors carries S's identity.
            ...anchorIdentityFields(req.body),"""
S6 = """            // KS-1385 site 6: certification issue carries S's identity.
            ...anchorIdentityFields(req.body),"""
S7 = """            // KS-1385 site 7: verification-certification anchor carries S's identity.
            ...anchorIdentityFields(req.body),"""
S5_ANCHOR = """          body: JSON.stringify({
            documentId,
            contentHash: documentHash,"""
UPS = "         metadata_payload = EXCLUDED.metadata_payload,\n"
HRET = "  return identity === undefined || identity === null ? {} : { identity };"
ERR = "              try { detail = (await anchorResp.text()).slice(0, 500); } catch { detail = ''; }"

def call(evt):
    return f"""        eventType: '{evt}',
        identity: (req.body as any)?.identity,"""

M = {
  # --- reconstruction of the author's 14 (their list is not enumerated in the commit; see verdict) ---
  'k01-site1-spread-deleted': [(DOCS, S1, "        certId: id,\n      });")],
  'k02-site2-spread-deleted': [(DOCS, S2, "            // KS-1385 site 2 removed")],
  'k03-emitLifecycleAnchor-spread-neutralised': [(DOCS, S3, "        ...anchorIdentityFields({ identity: identity && undefined }),")],
  'k04-call-transfer-custody-identity-dropped': [(DOCS, call('transfer-custody'), "        eventType: 'transfer-custody',")],
  'k05-call-share-identity-dropped': [(DOCS, call('share'), "        eventType: 'share',")],
  'k06-call-revoke-identity-dropped': [(DOCS, call('revoke'), "        eventType: 'revoke',")],
  'k07-call-lifecycle-events-identity-dropped': [(DOCS, "        eventType: action as LifecycleEventAction,\n        identity: (req.body as any)?.identity,", "        eventType: action as LifecycleEventAction,")],
  'k08-site4-spread-deleted': [(ANCH, S4, "            // site 4 removed")],
  'k08b-site4-spread-neutralised-compile-valid': [(ANCH, S4, "            // site 4 removed\n            ...anchorIdentityFields({}),")],
  'k09-site5-spread-added': [(ANCH, S5_ANCHOR, S5_ANCHOR.replace("documentId,\n", "documentId,\n            ...anchorIdentityFields(req.body),\n", 1))],
  'k10-site6-spread-deleted': [(CERT, S6, "            // site 6 removed")],
  'k11-site7-spread-deleted': [(CERT, S7, "            // site 7 removed")],
  'k12-upsert-metadata-line-deleted': [(IDX, UPS, "")],
  'k13-helper-null-forwarded': [(HELP, HRET, "  return identity === undefined ? {} : { identity };")],
  'k14-error-detail-dropped': [(DOCS, ERR, "              detail = '';")],
  # --- the gate's own ---
  'g01-helper-forwards-CALLER-identity': [(DOCS, S1, "        certId: id,\n        ...anchorIdentityFields({ identity: (req as any).user ? { actorDid: 'did:key:z' + String((req as any).user.userId).replace(/-/g, '') } : undefined }),\n      });")],
  'g02-site5-forwards-raw-not-via-helper': [(ANCH, S5_ANCHOR, S5_ANCHOR.replace("documentId,\n", "documentId,\n            identity: req.body?.identity,\n", 1))],
  'g03-upsert-overwrites-content_hash': [(IDX, UPS, UPS + "         content_hash = EXCLUDED.content_hash,\n")],
  'g04-helper-drops-identity-when-another-field-present': [(HELP, HRET, "  return identity === undefined || identity === null || Object.keys(body as object).length > 1 ? {} : { identity };")],
  'g05-helper-clones-the-block': [(HELP, HRET, "  return identity === undefined || identity === null ? {} : { identity: (typeof identity === 'object' && !Array.isArray(identity)) ? { ...(identity as object) } : identity };")],
  'g06-upsert-keeps-first-payload-COALESCE': [(IDX, UPS, "         metadata_payload = COALESCE(anchor_store.metadata_payload, EXCLUDED.metadata_payload),\n")],
  'g07-helper-truthiness': [(HELP, HRET, "  return !identity ? {} : { identity };")],
  'g08-share-forwards-caller-jwt-not-body': [(DOCS, call('share'), "        eventType: 'share',\n        identity: (req as any).user,")],
  'CTRL-comment-only': [(HELP, HRET, "  // gate-1549 comment-only control\n" + HRET)],
  'CTRL-none': [],
}

ORIG_TESTS = ['ks1385-create-anchor-carries-the-identity-block.test.ts', 'ks1385-certification-anchors-carry-the-identity-block.test.ts']

def run_originate(tag):
    out = f'{EV}/{tag}.originate.json'
    pat = '|'.join(t.replace('.', '\\.') for t in ORIG_TESTS)
    subprocess.run([D + '/node_modules/.bin/jest', '--config', O + '/jest.config.js', '--rootDir', O, '--ci', '--silent',
                    '--json', '--outputFile', out, '--testPathPattern', pat], capture_output=True, text=True)
    j = json.load(open(out))
    cells, fails, loadfail = 0, [], []
    for s in j['testResults']:
        if s.get('status') == 'failed' and not s.get('assertionResults'):
            loadfail.append((os.path.basename(s['name']), (s.get('message') or '')[:300]))
        for a in s.get('assertionResults', []):
            cells += 1
            if a['status'] == 'failed':
                fails.append((a['title'][:60], ' '.join(m[:160] for m in a.get('failureMessages', [])).replace('\n', ' ')))
    return cells, fails, loadfail

def run_anchoring(tag):
    out = f'{EV}/{tag}.anchoring.json'
    env = dict(os.environ, TEST_DATABASE_URL='postgres://gate@127.0.0.1:55549/g1549')
    subprocess.run([D + '/node_modules/.bin/vitest', 'run', '--root', A, '--config', A + '/vitest.integration.config.ts',
                    '--reporter=json', '--outputFile=' + out], capture_output=True, text=True, env=env)
    j = json.load(open(out))
    cells, fails, loadfail = 0, [], []
    for s in j['testResults']:
        if s.get('status') == 'failed' and not s.get('assertionResults'):
            loadfail.append((os.path.basename(s['name']), (s.get('message') or '')[:300]))
        for a in s.get('assertionResults', []):
            cells += 1
            if a['status'] == 'failed':
                fails.append((a['title'][:60], ' '.join(m[:160] for m in a.get('failureMessages', [])).replace('\n', ' ')))
    return cells, fails, loadfail

def main(names):
    results = {}
    for name in names:
        edits = M[name]
        touched = set()
        ok = True
        for f, old, new in edits:
            p = pathlib.Path(W) / f
            t = p.read_text()
            if t.count(old) != 1:
                print(f'{name}: anchor text matched {t.count(old)} times in {f} — mutant NOT applied'); ok = False; break
            p.write_text(t.replace(old, new, 1)); touched.add(f)
        if ok:
            diff = subprocess.run(['git', '-C', W, 'diff', '--stat'], capture_output=True, text=True).stdout.strip().splitlines()
            oc, of, ol = run_originate(name)
            ac, af, al = run_anchoring(name)
            killed = (len(of) + len(af)) > 0 and all(m.strip() for _, m in of + af) and not ol and not al
            results[name] = dict(applied=diff[-1] if diff else 'NO DIFF', originate_cells=oc, anchoring_cells=ac,
                                 failed=[t for t, _ in of + af], first_msg=(of + af)[0][1][:200] if (of + af) else '',
                                 load_failures=ol + al, verdict='KILLED' if killed else ('LOAD-FAIL (not a kill)' if (ol or al) else 'SURVIVED'))
            print(json.dumps({name: results[name]}))
        for f in touched:
            subprocess.run(['git', '-C', W, 'checkout', '--', f], check=True)
    st = subprocess.run(['git', '-C', W, 'status', '--porcelain', '--untracked-files=no'], capture_output=True, text=True).stdout
    print('worktree clean after run:', st.strip() == '')
    json.dump(results, open(f'{EV}/summary_{names[0]}_{len(names)}.json', 'w'), indent=1)

if __name__ == '__main__':
    main(sys.argv[1:] or list(M))
