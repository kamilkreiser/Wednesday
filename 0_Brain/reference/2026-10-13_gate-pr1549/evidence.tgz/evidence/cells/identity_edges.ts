// Gate cell (PR 1549): what the helper forwards for each identity shape, and what anchoring's schema then does.
// Product code only: originate's anchorIdentityFields + anchoring's anchorDocumentSchema / payload builder.
import * as path from 'path';
import { createRequire } from 'module';
const tree = process.argv[2];
const D = path.join(tree, 'Blockchain/Dev/services');
const reqA = createRequire(path.join(D, 'anchoring/package.json'));
const reqO = createRequire(path.join(D, 'originate/package.json'));
const { anchorIdentityFields } = reqO(path.join(D, 'originate/src/utils/anchorIdentity.ts'));
const { anchorDocumentSchema, buildFlatAnchorMetadataPayload } = reqA(path.join(D, 'anchoring/src/anchorSchema.ts'));
const base = { documentId: '33333333-3333-4333-8333-333333333333', contentHash: 'c'.repeat(64) };
const cases: Record<string, unknown> = {
  'absent': undefined,
  'null': null,
  'string': 'did:key:zX',
  'number': 7,
  'false': false,
  'array': [{ actorDid: 'did:key:zX' }],
  'empty object': {},
  'oversized actorDid (513)': { actorDid: 'did:key:' + 'a'.repeat(505) },
  'DID at max (512)': { actorDid: 'did:key:' + 'a'.repeat(504) },
  'extra fields (PII-ish)': { actorDid: 'did:key:zX', actorName: 'Jane Doe', actorEmail: 'j@x.io', nested: { a: 1 } },
  'enum outside contract (actorLevel 4)': { actorLevel: 4 },
  'different actor, max claims': { actorDid: 'did:key:zSOMEONEELSE', actorLevel: 3, actorSource: 'entra-verified-id', actorVerified: true, orgDid: 'did:web:bank.example', orgTrust: 'government', orgVerified: true },
};
for (const [label, v] of Object.entries(cases)) {
  const body = v === undefined ? {} : { identity: v };
  const fwd = anchorIdentityFields(body);
  const forwarded = 'identity' in fwd;
  let outcome: string;
  try {
    const data = anchorDocumentSchema.parse({ ...base, ...fwd });
    const sec = buildFlatAnchorMetadataPayload(data, 'preprod').secuura;
    const idKeys = ['actorDid', 'actorLevel', 'actorSource', 'actorVerified', 'orgDid', 'orgTrust', 'orgVerified', 'actorName', 'actorEmail', 'nested'].filter((k) => k in sec);
    outcome = `202 path; anchored identity keys = [${idKeys.join(',')}]`;
  } catch (e: any) {
    outcome = `400 ZodError: ${(e.errors || []).map((x: any) => `${x.path.join('.')}:${x.message}`).join(' | ').slice(0, 140)}`;
  }
  console.log(JSON.stringify({ case: label, helperForwardsKey: forwarded, anchoring: outcome }));
}
