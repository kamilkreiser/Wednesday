// Gate cell (PR 1549): against a BOOTED anchoring service (real index.ts, real Postgres, mock chain), can a caller
// from a DIFFERENT tenant overwrite another tenant's stored anchor attestation through POST /api/anchors?
// argv: baseUrl privKeyPath arm
import * as fs from 'fs';
import * as path from 'path';
import { createRequire } from 'module';
const [base, keyPath, arm, tree] = process.argv.slice(2);
const req = createRequire(path.join(tree, 'Blockchain/Dev/services/anchoring/package.json'));
const jwt = req('jsonwebtoken');
const key = fs.readFileSync(keyPath, 'utf8');
const tok = (userId: string, tenantId: string, role: string) =>
  jwt.sign({ userId, email: `${userId}@x.invalid`, role, verificationLevel: 'basic', tenantId, organizationId: tenantId }, key, { algorithm: 'RS256', expiresIn: '10m' });
const VICTIM = tok('11111111-1111-4111-8111-111111111111', 'tenant-A', 'ISSUER_ADMIN');
const STRANGER = tok('22222222-2222-4222-8222-222222222222', 'tenant-B', 'USER');
const DOC = `doc-${Date.now()}-http${arm}`;
const HA = 'a1'.repeat(32), HB = 'b2'.repeat(32);
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
async function post(token: string, body: any) {
  const r = await fetch(`${base}/api/anchors`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
  return { status: r.status, body: await r.json() as any };
}
(async () => {
  const v = await post(VICTIM, { documentId: DOC, contentHash: HA, issuerOrgId: 'org-A', metadata: { documentType: 'upload' }, identity: { actorDid: 'did:key:zVICTIM', actorLevel: 2, actorSource: 'platform' } });
  console.log(JSON.stringify({ arm, step: 'victim POST', status: v.status, id: v.body?.data?.id }));
  await sleep(3500);
  const verify1 = await (await fetch(`${base}/api/anchors/verify/${HA}`)).json() as any;
  console.log(JSON.stringify({ arm, step: 'verify(HA) before', verified: verify1.verified, tx: String(verify1.txHash ?? verify1.simulatedTxRef).slice(0, 12), contentHash: String(verify1.metadata?.contentHash).slice(0, 6), issuerOrgId: verify1.metadata?.issuerOrgId, documentType: verify1.metadata?.documentType, identity: verify1.metadata?.identity }));
  const s = await post(STRANGER, { documentId: DOC, contentHash: HB, issuerOrgId: 'org-B', identity: { actorDid: 'did:key:zSTRANGER', actorLevel: 3, actorSource: 'entra-verified-id', orgTrust: 'government', orgVerified: true } });
  console.log(JSON.stringify({ arm, step: 'stranger (other tenant) POST same documentId', status: s.status, id: s.body?.data?.id, sameRowId: s.body?.data?.id === v.body?.data?.id }));
  await sleep(3500);
  const verify2 = await (await fetch(`${base}/api/anchors/verify/${HA}`)).json() as any;
  console.log(JSON.stringify({ arm, step: 'verify(HA) after', verified: verify2.verified, tx: String(verify2.txHash ?? verify2.simulatedTxRef).slice(0, 12), contentHash: String(verify2.metadata?.contentHash).slice(0, 6), issuerOrgId: verify2.metadata?.issuerOrgId, documentType: verify2.metadata?.documentType, identity: verify2.metadata?.identity }));
  const g = await (await fetch(`${base}/api/anchors/${v.body?.data?.id}`, { headers: { authorization: `Bearer ${VICTIM}` } })).json() as any;
  console.log(JSON.stringify({ arm, step: 'victim GET /api/anchors/:id after', contentHash: String(g.contentHash).slice(0, 6), identity: g.identity, identityCommitment: g.identityCommitment }));
})().catch((e) => { console.error(e); process.exit(1); });
