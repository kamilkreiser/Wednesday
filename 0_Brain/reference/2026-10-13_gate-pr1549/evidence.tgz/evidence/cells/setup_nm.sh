#!/bin/bash
# usage: setup_nm.sh <worktree> — symlink node_modules to the project's install; @secuura/* resolve inside THIS worktree. Never writes into the project.
set -e
W="$1"; PD="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files/Blockchain/Dev"
WD="$W/Blockchain/Dev"
mkdir -p "$WD/node_modules/@secuura"
for e in "$PD/node_modules/"* "$PD/node_modules/".bin; do
  n=$(basename "$e"); [ "$n" = "@secuura" ] && continue
  [ -e "$WD/node_modules/$n" ] || ln -s "$e" "$WD/node_modules/$n"
done
for e in "$PD/node_modules/@secuura/"*; do
  n=$(basename "$e"); t=$(readlink "$e")
  [ -e "$WD/node_modules/@secuura/$n" ] || ln -s "$t" "$WD/node_modules/@secuura/$n"
done
for s in services/originate services/anchoring packages/shared; do
  [ -e "$WD/$s/node_modules" ] || ln -s "$PD/$s/node_modules" "$WD/$s/node_modules"
done
