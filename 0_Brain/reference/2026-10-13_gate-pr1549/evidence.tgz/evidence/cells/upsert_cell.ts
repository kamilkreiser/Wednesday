// Gate cell (PR 1549): run the PRODUCT's anchor_store upsert (extracted from index.ts of the tree passed
// as argv[2]) against real Postgres, feeding payloads built by the PRODUCT's schema + payload builder, and
// the PRODUCT's verify-by-hash response builder. argv[3] = arm label.
import * as fs from 'fs';
import * as path from 'path';
import { createRequire } from 'module';

const tree = process.argv[2];
const arm = process.argv[3];
const A = path.join(tree, 'Blockchain/Dev/services/anchoring');
const req = createRequire(path.join(A, 'package.json'));
const { Client } = req('pg');
const { anchorDocumentSchema, buildFlatAnchorMetadataPayload } = req(path.join(A, 'src/anchorSchema.ts'));
const { buildVerifyResponse, anchorIdentityView } = req(path.join(A, 'src/anchorReadback.ts'));

const src = fs.readFileSync(path.join(A, 'src/index.ts'), 'utf8');
const n = (src.match(/INSERT INTO anchor_store/g) || []).length;
if (n !== 1) throw new Error('expected exactly one INSERT INTO anchor_store, got ' + n);
const s = src.indexOf('`INSERT INTO anchor_store');
const sql = src.slice(s + 1, src.indexOf('`', s + 1));

const NET = 'preprod';
const DOC = `doc-${Date.now()}-gate1549${arm}`;
const HASH_A = 'a'.repeat(64);
const HASH_B = 'b'.repeat(64);
const UPLOADER = { actorDid: 'did:key:zUPLOADER', actorLevel: 1, actorSource: 'platform', identityCommitment: 'identity.v1:' + '1'.repeat(64) };
const SHARER = { actorDid: 'did:key:zSHARER', actorLevel: 3, actorSource: 'entra-verified-id', identityCommitment: 'identity.v1:' + '2'.repeat(64) };

function anchorFor(body: any) {
  // Same construction as POST /api/anchors (index.ts): parse, build payload, pending, no tx.
  const data = anchorDocumentSchema.parse(body);
  const payload = buildFlatAnchorMetadataPayload(data, NET);
  const now = new Date();
  return [
    `anchor_${Math.random().toString(16).slice(2)}`, data.documentId, 'single', data.contentHash, null, null,
    NET, 674, JSON.stringify(payload), 'pending', null, null, null, null, null, 0, null, null, 0, false, now, now,
  ];
}

async function main() {
  const c = new Client({ connectionString: process.env.GATE_DB });
  await c.connect();
  const read = async () => (await c.query(
    `SELECT id, content_hash, transaction_hash, status, created_at, metadata_payload FROM anchor_store WHERE document_id=$1 AND network=$2`, [DOC, NET])).rows;
  const show = (label: string, rows: any[]) => {
    const r = rows[0];
    const sec = r.metadata_payload.secuura;
    console.log(JSON.stringify({ arm, step: label, rows: rows.length, id: r.id, status: r.status, tx: r.transaction_hash,
      content_hash: r.content_hash.slice(0, 4), payload_hash: String(sec.hash).slice(0, 4), actorDid: sec.actorDid ?? null,
      actorLevel: sec.actorLevel ?? null, identityCommitment: (sec.identityCommitment ?? 'ABSENT').slice(0, 13), documentType: sec.documentType ?? null,
      issuerOrgId: sec.issuerOrgId ?? null, timestamp: sec.timestamp }));
  };

  // E1: upload by UPLOADER (S flat call with documentType)
  await c.query(sql, anchorFor({ documentId: DOC, contentHash: HASH_A, network: NET, issuerOrgId: 'org-victim', metadata: { documentType: 'upload' }, identity: UPLOADER }));
  let rows = await read(); show('E1 inserted', rows);
  const firstId = rows[0].id;
  // processAnchor's effect (dbUpdateAnchorStatus): tx T1 lands on the row
  await c.query(`UPDATE anchor_store SET status='confirmed', transaction_hash=$1 WHERE id=$2`, ['1'.repeat(64), firstId]);
  rows = await read(); show('E1 confirmed tx=T1', rows);

  // E2: a later event, different actor, same doc+hash, no documentType (K-internal calls send none)
  await c.query(sql, anchorFor({ documentId: DOC, contentHash: HASH_A, network: NET, identity: SHARER }));
  rows = await read(); show('E2 upserted (before its tx)', rows);
  console.log(JSON.stringify({ arm, check: 'id kept across conflict', ok: rows[0].id === firstId }));
  await c.query(`UPDATE anchor_store SET status='confirmed', transaction_hash=$1 WHERE id=$2`, ['2'.repeat(64), firstId]);
  rows = await read(); show('E2 confirmed tx=T2', rows);

  // E3: the SAME event replayed (identical body as E2)
  await c.query(sql, anchorFor({ documentId: DOC, contentHash: HASH_A, network: NET, identity: SHARER }));
  rows = await read(); show('E3 same event replayed', rows);
  await c.query(`UPDATE anchor_store SET status='confirmed', transaction_hash=$1 WHERE id=$2`, ['3'.repeat(64), firstId]);

  // E4: a DIFFERENT contentHash for the same (document_id, network) — reachable on anchoring's own
  // POST /api/anchors (no document-ownership check) — with a third-party org and identity.
  await c.query(sql, anchorFor({ documentId: DOC, contentHash: HASH_B, network: NET, issuerOrgId: 'org-other', identity: { actorDid: 'did:key:zOTHER', actorLevel: 3, actorSource: 'entra-verified-id' } }));
  await c.query(`UPDATE anchor_store SET status='confirmed', transaction_hash=$1 WHERE id=$2`, ['4'.repeat(64), firstId]);
  rows = await read(); show('E4 different contentHash, confirmed tx=T4', rows);

  // verify-by-hash DB fast path (index.ts: WHERE LOWER(content_hash)=$1) for the ORIGINAL bytes, built by the product builder
  const v = (await c.query(`SELECT id, document_id, content_hash, transaction_hash, block_number, block_hash, confirmed_at, created_at, metadata_payload, status
      FROM anchor_store WHERE LOWER(content_hash) = $1 AND status IN ('submitting','submitted','confirmed') AND document_id=$2`, [HASH_A, DOC])).rows;
  const resp = buildVerifyResponse('db', v[0].metadata_payload, v[0], { hash: HASH_A, network: NET });
  console.log(JSON.stringify({ arm, step: 'verify-by-hash(HASH_A)', verified: resp.verified, txHash: resp.txHash?.slice(0, 4),
    requested: HASH_A.slice(0, 4), metadata_contentHash: String(resp.metadata.contentHash).slice(0, 4), issuerOrgId: resp.metadata.issuerOrgId,
    identity: resp.metadata.identity }));
  const vb = (await c.query(`SELECT 1 FROM anchor_store WHERE LOWER(content_hash)=$1 AND document_id=$2`, [HASH_B, DOC])).rows.length;
  console.log(JSON.stringify({ arm, step: 'verify-by-hash(HASH_B) DB rows', rows: vb }));
  console.log(JSON.stringify({ arm, step: 'GET /:id identity view', view: anchorIdentityView(rows[0].metadata_payload.secuura) }));
  await c.end();
}
main().catch((e) => { console.error(e); process.exit(1); });
