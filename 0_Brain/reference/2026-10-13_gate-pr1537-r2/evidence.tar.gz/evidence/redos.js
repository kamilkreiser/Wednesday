for (const n of [20000,40000,80000]) { const s=' '.repeat(n)+'x'; const t=process.hrtime.bigint(); s.replace(/[.\s]*$/, ''); console.log(n, Number(process.hrtime.bigint()-t)/1e6,'ms'); }
const s2='a'.repeat(80000); let t=process.hrtime.bigint(); s2.replace(/[.\s]*$/,''); console.log('plain 80k', Number(process.hrtime.bigint()-t)/1e6,'ms');
