import subprocess,sys,shutil,re
W='/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/087c4316-bb15-4161-a5ec-601b737a6e98/scratchpad/r2'
D=W+'/repo/Blockchain/Dev'
P=D+'/frontend/admin/src/pages/ApiKeys.tsx'
orig=open(P).read()
G="if (seq !== keysReqRef.current) return;"
FK="const result = await fetchApiKeys(orgId);"
assert orig.count(G)==1 and orig.count(FK)==1
def sub(a,b,n=1):
    assert orig.count(a)>=1,a
    return orig.replace(a,b,n)
M={
 'CONTROL_comment_only': orig.replace("export default function ApiKeys() {","// harmless comment\nexport default function ApiKeys() {"),
 'N1_loadKeys_guard_deleted': sub(G,""),
 'N2_guard_moved_after_setKeys': sub("    if (seq !== keysReqRef.current) return;\n    if (!result.ok) {\n      // Audit B-06 spirit","    if (!result.ok) {\n      // Audit B-06 spirit").replace("    setLoading(false);\n  }, [orgId, orgName]);","    if (seq !== keysReqRef.current) return;\n    setLoading(false);\n  }, [orgId, orgName]);"),
 'N3_guard_turned_into_comment': sub(G,"// "+G),
 'N4_guard_before_await': sub(FK,G+"\n    "+FK).replace(FK+"\n    "+G,FK) if False else sub("    const result = await fetchApiKeys(orgId);\n    "+G,"    "+G+"\n    const result = await fetchApiKeys(orgId);"),
 'N5_nullish_fallback': sub(FK,"const result = await fetchApiKeys(orgId ?? 'x');"),
 'N6_nested_paren_arg_with_built_literal': sub(FK,"const result = await fetchApiKeys(String(orgId) || ['default','org'].join('-'));"),
 'N7_alias_call_elsewhere': sub("export default function ApiKeys() {","const aliasFetch = fetchApiKeys;\nvoid (() => aliasFetch('x' as string));\nexport default function ApiKeys() {"),
 'N8_comment_quoting_fallback': sub("export default function ApiKeys() {","// note: never fetchApiKeys(orgId || 'x') here\nexport default function ApiKeys() {"),
 'N9_orgs_loader_guard_deleted': sub("    if (seq !== orgsReqRef.current) return;\n",""),
 'N10_submit_guard_deleted': sub("if (!dialogOrgId || submitRef.current) return;","if (!dialogOrgId) return;"),
 'N11_multiline_fallback': sub(FK,"const result = await fetchApiKeys(\n      orgId || 'x');"),
 'N12_guard_text_kept_but_inert': sub(G,"if (seq !== keysReqRef.current) return; // inert\n    void 0;").replace("if (seq !== keysReqRef.current) return; // inert","if (seq !== keysReqRef.current) { /* x */ }") ,
}
# N12 note: guard text changed so cell 5 should be red; kept to show text sensitivity
for k,v in M.items():
    open(P,'w').write(v)
    r=subprocess.run(['npm','run','test','--prefix',D+'/packages/shared','--','ks1564'],capture_output=True,text=True)
    out=r.stdout+r.stderr
    red=re.findall(r'×\s+(\S+)',out)
    m=re.search(r'Tests\s+(.*)',out)
    print(f"{k}: rc={r.returncode} red={red} :: {m.group(1).strip() if m else '?'}")
open(P,'w').write(orig)
print('restored identical:',open(P).read()==orig)
