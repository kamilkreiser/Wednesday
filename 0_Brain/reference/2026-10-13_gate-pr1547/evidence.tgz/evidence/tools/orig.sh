#!/bin/bash
# orig.sh <tree> <outfile> <MT true|false> [jest args]  (gate 1547, PG on 55463)
W=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad
T=$1; OUT=$2; export MULTI_TENANCY_ENABLED=$3; shift 3
export TEST_DATABASE_URL="postgresql://secuura@127.0.0.1:55463/secuura"
export TEST_APP_DATABASE_URL="postgresql://secuura_app:$(cat $W/pg/app_pw)@127.0.0.1:55463/secuura"
export TEST_PLATFORM_DATABASE_URL="postgresql://secuura@127.0.0.1:55463/secuura_platform"
exec python3 -I $W/bin/runin.py $W/$T/Blockchain/Dev/services/originate $OUT npx jest --config jest.integration.config.js --verbose "$@"
