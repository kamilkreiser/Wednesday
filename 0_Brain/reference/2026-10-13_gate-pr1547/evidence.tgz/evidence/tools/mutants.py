#!/usr/bin/env python3
"""Gate 1547 mutation pass. Each mutant edits the SCRATCH head worktree's adminConfig.ts (never the project),
runs the 16 KS-1594 cells, records per-cell pass/fail, and restores the pristine bytes (asserted by sha256)."""
import hashlib, os, re, shutil, subprocess, sys, json
W = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad'
F = W + '/head/Blockchain/Dev/services/originate/src/routes/adminConfig.ts'
PRISTINE = open(F).read()
SHA = hashlib.sha256(PRISTINE.encode()).hexdigest()

A_BLOCK = """    if (isProvisioningCapable(requestedScopes) && !callerIsPlatform) {
      return res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: 'Provisioning-capable permissions require a platform role' },
      });
    }
"""
RET = """      ) RETURNING id, key_prefix, name, scopes, rate_limit, is_active, expires_at, created_at
    `;
"""
C_IF = "if (!callerIsPlatform && requestedOrg !== null && requestedOrg !== callerOrg) {"
A_IF = "if (isProvisioningCapable(requestedScopes) && !callerIsPlatform) {"
WRITE = "const orgId = requestedOrg ?? callerOrg;"
PLAT = "const callerIsPlatform = isPlatformRole((req as any).user?.role as string | undefined);"

M = {
  # the author's six, re-derived
  'T1 (a) disabled': [(A_IF, "if (false && isProvisioningCapable(requestedScopes) && !callerIsPlatform) {")],
  'T2 (a) platform test inverted': [(A_IF, "if (isProvisioningCapable(requestedScopes) && callerIsPlatform) {")],
  'T3 write not normalised': [(WRITE, "const orgId = (d.organizationId as string) || ((req as any).user?.organizationId as string | undefined) || null;")],
  'T4 (c) requested side not normalised': [(C_IF, "if (!callerIsPlatform && requestedOrg !== null && (d.organizationId as string) !== callerOrg) {")],
  'T5 (c) disabled': [(C_IF, "if (false && !callerIsPlatform && requestedOrg !== null && requestedOrg !== callerOrg) {")],
  'T6 (c) caller side not normalised': [(C_IF, "if (!callerIsPlatform && requestedOrg !== null && requestedOrg !== (((req as any).user?.organizationId as string | undefined) ?? null)) {")],
  # the gate's own
  'G1 hasScope replaced by exact match': [(A_IF, "void isProvisioningCapable;\n    if (requestedScopes.includes('organizations:register') && !callerIsPlatform) {")],
  'G2 platform check on the wrong principal field (tenantId)': [(PLAT, "const callerIsPlatform = isPlatformRole((req as any).user?.tenantId as string | undefined);")],
  'G3 (a) 403 moved AFTER the INSERT': [(A_BLOCK, ""), (RET, RET + A_BLOCK)],
  'G4 (c) only when MULTI_TENANCY_ENABLED=true': [(C_IF, "if (process.env.MULTI_TENANCY_ENABLED === 'true' && !callerIsPlatform && requestedOrg !== null && requestedOrg !== callerOrg) {")],
  'G5 blank body org stores NULL (unbounded) instead of the claim': [(WRITE, "const orgId = d.organizationId !== undefined ? requestedOrg : callerOrg;")],
  'G6 (c) nested under (a): only provisioning sets are org-bound': [(C_IF, "if (isProvisioningCapable(requestedScopes) && !callerIsPlatform && requestedOrg !== null && requestedOrg !== callerOrg) {")],
  'G7 (a) waived when the ORG_ADMIN names an organisation (own)': [(A_IF, "if (isProvisioningCapable(requestedScopes) && !callerIsPlatform && normaliseOrgId(d.organizationId as string | null | undefined) === null) {")],
  'G8 platform = literal SYSTEM_ADMIN only (super_admin/SUPER_ADMIN lose platform)': [(PLAT, "void isPlatformRole;\n    const callerIsPlatform = (req as any).user?.role === 'SYSTEM_ADMIN';")],
  'G9 (b) normalisation trim-only (case kept) on both sides': [
     ("const requestedOrg = normaliseOrgId(d.organizationId as string | null | undefined);",
      "const requestedOrg = typeof d.organizationId === 'string' && d.organizationId.trim() ? d.organizationId.trim() : null;"),
     ("const callerOrg = normaliseOrgId((req as any).user?.organizationId as string | null | undefined);",
      "const callerOrg = typeof (req as any).user?.organizationId === 'string' && (req as any).user.organizationId.trim() ? (req as any).user.organizationId.trim() : null;\n    void normaliseOrgId;")],
  'X0 tsc control (deliberate type error)': [(WRITE, WRITE + "\n    const _gateTypeErr: number = 'not a number';")],
  'C0 comment-only control': [(A_IF, "// gate1547 comment-only control\n    " + A_IF)],
}
only = sys.argv[1:] or list(M)
modes = {'G4 (c) only when MULTI_TENANCY_ENABLED=true': ['false', 'true']}
res = {}
os.makedirs(W + '/ev/mutants', exist_ok=True)
try:
    for name in only:
        src = PRISTINE
        for old, new in M[name]:
            n = src.count(old)
            assert n == 1, f'{name}: anchor count {n}'
            src = src.replace(old, new)
        assert src != PRISTINE
        open(F, 'w').write(src)
        t = subprocess.run(['npx', 'tsc', '--noEmit', '-p', 'tsconfig.json'], cwd=W + '/head/Blockchain/Dev/services/originate', capture_output=True, text=True)
        tsc_err = [l for l in (t.stdout + t.stderr).splitlines() if 'error TS' in l]
        print(f'{name}: tsc rc={t.returncode} errors={tsc_err[:2]}', flush=True)
        for mt in modes.get(name, ['false']):
            tag = re.sub(r'[^A-Za-z0-9]+', '_', name.split(' ')[0]) + f'_mt{mt}'
            out = f'{W}/ev/mutants/{tag}.txt'
            subprocess.run([W + '/bin/orig.sh', 'head', out, mt, 'ks1594-admin-mint'], capture_output=True, text=True)
            txt = re.sub(r'\x1b\[[0-9;]*m', '', open(out).read())
            cells = re.findall(r'^\s+([✓✕])\s+(c\d+b?)\s', txt, re.M)
            red = [c for s, c in cells if s == '✕']
            tot = re.search(r'^Tests:.*$', txt, re.M)
            res[f'{name} [MT={mt}]'] = {'tsc_rc': t.returncode, 'loaded': len(cells), 'red': red, 'tests': tot.group(0) if tot else 'NO TESTS LINE'}
            print(f'{name} [MT={mt}] loaded={len(cells)} red={red} | {res[name + " [MT=" + mt + "]"]["tests"]}', flush=True)
finally:
    open(F, 'w').write(PRISTINE)
    assert hashlib.sha256(open(F).read().encode()).hexdigest() == SHA
    print('restored, sha256 matches pristine', SHA[:16])
json.dump(res, open(W + '/ev/mutants/summary.json', 'w'), indent=1)
