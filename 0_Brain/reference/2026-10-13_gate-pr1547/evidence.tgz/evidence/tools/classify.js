// classify.js <shared-dist-index.js> <matrix.json>  — gate 1547
const [, , SHARED, FILE] = process.argv;
const { isProvisioningCapable, normaliseOrgId } = require(SHARED);
const d = require(FILE);
const PLATFORM = new Set(['SYSTEM_ADMIN', 'SUPER_ADMIN', 'super_admin']);
const ADMITTED = new Set(['SYSTEM_ADMIN', 'SUPER_ADMIN', 'super_admin', 'ORG_ADMIN']);
const roleOf = (label) => label.replace(/\(.*$/, '');
const parseJsonArray = (v) => (!v ? [] : Array.isArray(v) ? v : typeof v === 'string' ? (() => { try { return JSON.parse(v); } catch { return []; } })() : []);
const out = { total: 0, statusHist: {}, s500: [], fpProv: [], fpOrg: [], unnormStored: [], unboundedWithClaim: [], falseRefusal: [], wrongTenant: [], rowOnRefusal: [], admittedByRole: {} };
const LEGIT_ORGS = new Set(['O-absent', 'O-own', 'O-own-UPPER', 'O-own-ws', 'O-own-tabnl', 'O-empty', 'O-blank', 'O-nbsp', 'O-nbsp-own', 'O-null']);
for (const r of d.results) {
  out.total++;
  out.statusHist[r.status] = (out.statusHist[r.status] || 0) + 1;
  const role = roleOf(r.role);
  const reachedHandler = !(r.status === 403 && r.err === 'Insufficient permissions') && r.status !== 401;
  out.admittedByRole[r.role] = out.admittedByRole[r.role] || { reached: 0, refusedByRequireRole: 0 };
  out.admittedByRole[r.role][reachedHandler ? 'reached' : 'refusedByRequireRole']++;
  const key = `${r.role} | ${r.perm} | ${r.org}${r.hdrTenant !== d.T ? ' | hdr=T2' : ''}`;
  if (r.status >= 500) out.s500.push(`${key} -> ${r.status} ${r.err}`);
  if (r.status !== 201 && r.nrows > 0) out.rowOnRefusal.push(key);
  const platform = PLATFORM.has(role) && !r.role.includes('-');
  if (r.status === 201 && r.row) {
    const scopes = parseJsonArray(r.row.scopes);
    const claimN = normaliseOrgId(typeof r.claim === 'string' && r.claim !== '<absent>' ? r.claim : null);
    const storedN = normaliseOrgId(r.row.organization_id);
    if (r.row.organization_id !== null && r.row.organization_id !== storedN) out.unnormStored.push(`${key} stored=${JSON.stringify(r.row.organization_id)}`);
    if (r.row.tenant !== d.T) out.wrongTenant.push(`${key} tenant=${r.row.tenant}`);
    if (!platform) {
      if (isProvisioningCapable(scopes)) out.fpProv.push(`${key} scopes=${JSON.stringify(r.row.scopes)}`);
      if (storedN !== null && storedN !== claimN) out.fpOrg.push(`${key} stored=${JSON.stringify(r.row.organization_id)} claim=${JSON.stringify(r.claim)}`);
      if (storedN === null && claimN !== null) out.unboundedWithClaim.push(`${key} claim=${JSON.stringify(r.claim)}`);
    }
  }
  // false refusal: admitted role, non-provisioning request, legitimate org shape, not 201
  const provReq = ['P-register', 'P-star', 'P-org*', 'P-read+register', 'P-null+register'].includes(r.perm);
  if (ADMITTED.has(role) && reachedHandler && r.hdrTenant === d.T) {
    if (platform && r.status !== 201) out.falseRefusal.push(`${key} -> ${r.status} ${r.err}`);
    if (!platform && !provReq && LEGIT_ORGS.has(r.org) && r.status !== 201) out.falseRefusal.push(`${key} -> ${r.status} ${r.err}`);
  }
}
const summ = {};
for (const [k, v] of Object.entries(out)) summ[k] = Array.isArray(v) ? v.length : v;
console.log(JSON.stringify({ mt: d.mt, summary: summ }, null, 1));
for (const k of ['s500', 'fpProv', 'fpOrg', 'unnormStored', 'unboundedWithClaim', 'falseRefusal', 'wrongTenant', 'rowOnRefusal']) {
  console.log(`--- ${k} (${out[k].length})`);
  for (const l of out[k].slice(0, 400)) console.log('  ' + l);
}
