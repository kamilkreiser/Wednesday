import json,sys
W=sys.argv[1]
def load(n):
    d=json.load(open(f'{W}/ev/{n}.json'));return [(r['role'],r['perm'],r['org'],r['hdrTenant'],r['status'],(r['row'] or {}).get('organization_id'),json.dumps((r['row'] or {}).get('scopes'))) for r in d['results']]
for t in ('head','dev'):
    a,b=load(f'matrix_{t}_mtfalse'),load(f'matrix_{t}_mttrue')
    diff=[(x,y) for x,y in zip(a,b) if x!=y]
    print(t,'rows',len(a),len(b),'MT-false vs MT-true differing rows:',len(diff)); [print('  ',x,'\n  ',y) for x,y in diff[:5]]
h=load('matrix_head_mtfalse');d=load('matrix_dev_mtfalse')
ch=[(x,y) for x,y in zip(h,d) if x[4:6]!=y[4:6]]
print('head vs dev rows differing in status or stored org:',len(ch))
# control: the compare can see a difference -- perturb one row
hh=list(h);hh[0]=hh[0][:4]+(999,)+hh[0][5:]
print('control: perturbed copy differs in', sum(1 for x,y in zip(hh,h) if x!=y),'row')
print('\nORG_ADMIN(A1) table (MT=false): perm | org | head status/stored org | dev status/stored org')
for x,y in zip(h,d):
    if x[0]=='ORG_ADMIN(A1)' and x[1] in('P-read','P-register') and x[3].endswith('aa'):
        print(f'{x[1]:11}|{x[2]:16}| {x[4]} {x[5]!r:42} | {y[4]} {y[5]!r}')
