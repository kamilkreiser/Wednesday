/**
 * Gate PR 1547 (KS-1594) boundary matrix. NOT part of the PR. Same wiring as the author's cell file
 * (real adminConfigRouter, real authenticate/requireRole, extractTenantContext in MT mode, the KS-458
 * resolver, tenantGucContext; app connects as secuura_app under FORCE RLS). Every request's status and
 * stored row are written to GATE_OUT as JSON for offline classification. Never skipped.
 */
import http from 'http';
import fs from 'fs';
import { Client } from 'pg';
import jwt from 'jsonwebtoken';

const SU_DB = process.env.TEST_DATABASE_URL;
const APP_DB = process.env.TEST_APP_DATABASE_URL;
const PLATFORM_DB = process.env.TEST_PLATFORM_DATABASE_URL;
const OUT = process.env.GATE_OUT;
if (PLATFORM_DB) process.env.PLATFORM_DATABASE_URL = PLATFORM_DB;
if (SU_DB) process.env.DATABASE_URL = APP_DB || SU_DB;
process.env.JWT_SECRET = 'g1547-unused';
const { privateKey: _priv, publicKey: _pub } = require('crypto').generateKeyPairSync('rsa', { modulusLength: 2048 });
const PEM = _priv.export({ type: 'pkcs8', format: 'pem' }).toString();
process.env.JWT_PUBLIC_KEY = Buffer.from(_pub.export({ type: 'spki', format: 'pem' }).toString()).toString('base64');
process.env.MULTI_TENANCY_ENABLED = process.env.MULTI_TENANCY_ENABLED || 'true';
process.env.NODE_ENV = 'test';

const T = 'a0000000-0000-4000-8000-0000001547aa';
const T2 = 'a0000000-0000-4000-8000-0000001547bb';
const A1 = 'abcdef00-1547-4547-8547-0000000000a1';
const A2 = 'abcdef00-1547-4547-8547-0000000000a2';
const NAME = 'g1547m:';

let server: http.Server;
let base: string;
let platform: Client;
let su: Client;
let disconnect: () => Promise<void>;

const sign = (p: object): string => jwt.sign(p, PEM, { algorithm: 'RS256', expiresIn: 600 });
const tok = (role: unknown, org?: unknown): string =>
  sign({ userId: `g1547-${String(role)}`, email: 'g@g1547.test', role, tenantId: T,
    ...(org !== undefined ? { organizationId: org } : {}), verificationLevel: 'full' });

// [label, role, orgClaim(undefined=absent)]
const ROLES: Array<[string, unknown, unknown]> = [
  ['ORG_ADMIN(A1)', 'ORG_ADMIN', A1],
  ['ORG_ADMIN(none)', 'ORG_ADMIN', undefined],
  ['ORG_ADMIN(A1-UPPER)', 'ORG_ADMIN', A1.toUpperCase()],
  ['ORG_ADMIN(ws-A1)', 'ORG_ADMIN', `  ${A1}\t`],
  ['ORG_ADMIN(blank)', 'ORG_ADMIN', '   '],
  ['SYSTEM_ADMIN(none)', 'SYSTEM_ADMIN', undefined],
  ['SYSTEM_ADMIN(A1)', 'SYSTEM_ADMIN', A1],
  ['SUPER_ADMIN(none)', 'SUPER_ADMIN', undefined],
  ['super_admin(none)', 'super_admin', undefined],
  ['super_admin(A1)', 'super_admin', A1],
  ['system_admin-lower', 'system_admin', undefined],
  ['org_admin-lower', 'org_admin', A1],
  ['ADMIN(A1)', 'ADMIN', A1],
  ['ISSUER_ADMIN(A1)', 'ISSUER_ADMIN', A1],
  ['platform_admin', 'platform_admin', undefined],
  ['connector(A1)', 'connector', A1],
  ['SYSTEM_ADMıN-dotless', 'SYSTEM_ADMıN', undefined],
  ['role-array[SUPER_ADMIN]', ['SUPER_ADMIN'], undefined],
  ['ORG_ADMIN-ws-role', ' ORG_ADMIN', A1],
];
const PERMS: Array<[string, unknown]> = [
  ['P-absent', undefined],
  ['P-read', ['read']],
  ['P-docs', ['documents:read', 'documents:write']],
  ['P-register', ['organizations:register']],
  ['P-star', ['*']],
  ['P-org*', ['organizations:*']],
  ['P-REGISTER-upper', ['ORGANIZATIONS:REGISTER']],
  ['P-ws-register', [' organizations:register ']],
  ['P-Org*-mixed', ['Organizations:*']],
  ['P-star-ws', ['* ']],
  ['P-read+register', ['read', 'organizations:register']],
  ['P-string-register', 'organizations:register'],
  ['P-nested', [['organizations:register']]],
  ['P-null+register', [null, 'organizations:register']],
  ['P-empty', []],
  ['P-object', { 0: 'organizations:register', length: 1 }],
  ['P-space-joined', ['read organizations:register']],
  ['P-comma-joined', ['read,organizations:register']],
];
const ORGS: Array<[string, unknown, boolean]> = [
  ['O-absent', undefined, false],
  ['O-own', A1, true],
  ['O-own-UPPER', A1.toUpperCase(), true],
  ['O-own-ws', `  ${A1}  `, true],
  ['O-own-tabnl', `\t${A1}\n`, true],
  ['O-foreign', A2, true],
  ['O-foreign-UPPER', A2.toUpperCase(), true],
  ['O-empty', '', true],
  ['O-blank', '   ', true],
  ['O-nbsp', ' ', true],
  ['O-nbsp-own', ` ${A1} `, true],
  ['O-zwsp-own', `​${A1}`, true],
  ['O-null', null, true],
  ['O-number', 12345, true],
  ['O-array-own', [A1], true],
  ['O-array-foreign', [A2], true],
  ['O-object', { id: A2 }, true],
  ['O-true', true, true],
];

beforeAll(async () => {
  if (!SU_DB || !APP_DB || !PLATFORM_DB || !OUT) throw new Error('gate1547 matrix needs DB urls and GATE_OUT');
  const db = require('../db');
  const { adminConfigRouter } = require('../routes/adminConfig');
  const { extractTenantContext, tenantGucContext } = require('@secuura/shared');
  const express = require('express');
  disconnect = db.disconnectDb;
  platform = new Client({ connectionString: PLATFORM_DB }); await platform.connect();
  su = new Client({ connectionString: SU_DB }); await su.connect();
  const u = new URL(SU_DB);
  for (const [id, slug] of [[T, 'g1547a'], [T2, 'g1547b']]) {
    await platform.query(`INSERT INTO tenants (id,name,slug,status) VALUES ($1,$2,$2,'active') ON CONFLICT (id) DO NOTHING`, [id, slug]);
    await platform.query(`INSERT INTO tenant_config (tenant_id,db_name,db_host,db_port) VALUES ($1,$2,$3,$4) ON CONFLICT (tenant_id) DO NOTHING`,
      [id, u.pathname.slice(1), u.hostname, parseInt(u.port, 10)]);
  }
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  await db.initDb();
  const manager = db.getTenantManager();
  if (!manager && process.env.MULTI_TENANCY_ENABLED === 'true') throw new Error('no tenant manager');
  if (manager) await db.refreshTenantConfigs();
  const app = express();
  app.use(express.json());
  if (manager) app.use((req: any, res: any, next: any) => extractTenantContext(manager)(req, res, next));
  app.use((req: any, _res: any, next: any) => {
    const attached = req.tenantId; const header = req.headers['x-tenant-id'];
    req.tenantId = (typeof attached === 'string' && attached.length > 0 ? attached : undefined)
      || (typeof header === 'string' && header.length > 0 ? header : undefined) || 'a0000000-0000-4000-8000-000000000001';
    next();
  });
  app.use(tenantGucContext());
  app.use('/api/admin', adminConfigRouter);
  server = http.createServer(app);
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  const addr = server.address();
  base = `http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}`;
}, 30000);

afterAll(async () => {
  if (server) await new Promise<void>((r) => server.close(() => r()));
  if (su) { await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]); await su.end(); }
  if (platform) {
    for (const id of [T, T2]) {
      await platform.query('DELETE FROM tenant_config WHERE tenant_id=$1', [id]);
      await platform.query('DELETE FROM tenants WHERE id=$1', [id]);
    }
    await platform.end();
  }
  if (disconnect) await disconnect();
});

it('matrix: every role x permissions x organizationId (and a tenant-header probe)', async () => {
  const results: any[] = [];
  let i = 0;
  const one = async (role: string, roleV: unknown, claim: unknown, perm: string, permV: unknown, org: string, orgV: unknown, orgPresent: boolean, hdrTenant = T) => {
    const label = `${NAME}${i++}`;
    const body: Record<string, unknown> = { name: label };
    if (permV !== undefined) body.permissions = permV;
    if (orgPresent) body.organizationId = orgV;
    const res = await fetch(`${base}/api/admin/api-keys`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-tenant-id': hdrTenant, authorization: `Bearer ${tok(roleV, claim)}` },
      body: JSON.stringify(body),
    });
    const json: any = await res.json().catch(() => null);
    const rows = (await su.query('SELECT organization_id, scopes, tenant_id::text AS tenant FROM svc_api_keys WHERE name = $1', [label])).rows;
    results.push({ role, claim: claim === undefined ? '<absent>' : claim, perm, org, hdrTenant, status: res.status,
      err: json?.error?.message ?? null, nrows: rows.length, row: rows[0] ?? null });
  };
  for (const [role, roleV, claim] of ROLES)
    for (const [perm, permV] of PERMS)
      for (const [org, orgV, present] of ORGS)
        await one(role, roleV, claim, perm, permV, org, orgV, present);
  // tenant-header probe: token tenant T, header T2 (pre-existing surface; gateway sets the header from the JWT)
  await one('ORG_ADMIN(A1)', 'ORG_ADMIN', A1, 'P-read', ['read'], 'O-absent', undefined, false, T2);
  await one('ORG_ADMIN(A1)', 'ORG_ADMIN', A1, 'P-register', ['organizations:register'], 'O-absent', undefined, false, T2);
  fs.writeFileSync(OUT as string, JSON.stringify({ mt: process.env.MULTI_TENANCY_ENABLED, A1, A2, T, T2, results }, null, 1));
  expect(results.length).toBe(ROLES.length * PERMS.length * ORGS.length + 2);
}, 600000);
