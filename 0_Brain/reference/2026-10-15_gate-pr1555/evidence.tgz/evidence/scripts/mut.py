import io, re, subprocess, os, json, sys
G = '/private/tmp/claude-501/gate1555-1792045119'
DEV = G + '/wt/m/Blockchain/Dev'
O = DEV + '/services/originate'
V = O + '/src/routes/verification.ts'; RT = O + '/src/utils/requestTenant.ts'
SUPER = 'postgresql://secuura:secuura@127.0.0.1:55731/secuura'; APP = 'postgresql://secuura_app:app@127.0.0.1:55731/secuura'
PS = 'postgresql://secuura:secuura@127.0.0.1:55731/secuura_platform'; PA = 'postgresql://secuura_app:app@127.0.0.1:55731/secuura_platform'
def run(mode, mt='false'):
    env = dict(os.environ, TEST_DATABASE_URL=SUPER, DATABASE_URL=SUPER, TEST_SUPER_PLATFORM_DATABASE_URL=PS,
               TEST_PLATFORM_DATABASE_URL=PA if mode == 'app' else PS, MULTI_TENANCY_ENABLED=mt)
    if mode == 'app': env['TEST_APP_DATABASE_URL'] = APP
    else: env.pop('TEST_APP_DATABASE_URL', None)
    p = subprocess.run([DEV + '/node_modules/.bin/jest', '--rootDir', O, '--config', O + '/jest.integration.config.js', 'ks1114', '--forceExit'],
                       capture_output=True, text=True, env=env, timeout=900)
    out = p.stdout + p.stderr
    m = re.search(r'^Tests:\s+(?:(\d+) failed, )?(\d+) passed, (\d+) total', out, re.M)
    red = sorted(set(re.findall(r'●[^\n]*›\s*(T\d+b?)\b', out)))
    return ((int(m.group(1) or 0), int(m.group(3))) if m else None), red, out
SQL_TENANT = "              AND d.tenant_id::text = ${tenantForTitle}\n"
M = [
 ('m1 tenant predicate removed (app role, FORCE RLS on)', V, [(SQL_TENANT, "")], 'app', 'SURVIVES by design'),
 ('m1 tenant predicate removed (superuser, RLS bypassed)', V, [(SQL_TENANT, "")], 'super', 'T2'),
 ('m2 caller tenant hard-coded to DEFAULT', V, [("const tenantForTitle = callerTenantOf(req);", "const tenantForTitle = 'a0000000-0000-4000-8000-000000000001'; void callerTenantOf;")], 'app', 'T2b'),
 ('m3 newest-first flipped to oldest-first', V, [("ORDER BY d.created_at DESC NULLS LAST, d.id DESC", "ORDER BY d.created_at ASC NULLS LAST, d.id DESC")], 'app', 'T4'),
 ('m4 id tie-break flipped', V, [("ORDER BY d.created_at DESC NULLS LAST, d.id DESC", "ORDER BY d.created_at DESC NULLS LAST, d.id ASC")], 'app', 'T4b'),
 ('m5 case-insensitive match', V, [("            WHERE d.title = ${titleToFind}\n", "            WHERE lower(d.title) = lower(${titleToFind})\n")], 'app', 'T5'),
 ('m6a sentinel early-return removed ONLY', V, [("if (!tenantForTitle || titleToFind === ERASED_MARKER) return titleNotFound();", "if (!tenantForTitle) return titleNotFound();")], 'app', 'SURVIVES by design'),
 ('m6b sentinel SQL exclusion removed ONLY', V, [("              AND d.title <> ${ERASED_MARKER}\n", "")], 'app', 'SURVIVES by design'),
 ('m6c BOTH sentinel lines removed', V, [("if (!tenantForTitle || titleToFind === ERASED_MARKER) return titleNotFound();", "if (!tenantForTitle) return titleNotFound();"), ("              AND d.title <> ${ERASED_MARKER}\n", "")], 'app', 'T6'),
 ('m7 not-found echoes the title', V, [("            verified: false,\n            error: 'Document not found in the registry',\n            checks: { documentExists: false, hashValid: false, integrityVerified: false },\n          });\n          const tenantForTitle", "            verified: false,\n            title: titleToFind,\n            error: 'Document not found in the registry',\n            checks: { documentExists: false, hashValid: false, integrityVerified: false },\n          });\n          const tenantForTitle")], 'app', 'T6'),
 ('m8 whitespace-only title treated as present', V, [("typeof title === 'string' && title.trim().length > 0 ? title : undefined;", "typeof title === 'string' && title.length > 0 ? title : undefined;")], 'app', 'T7'),
 ('m9 integrity CLAIMED on an existence answer', V, [("            hashValid: false,\n            isCertified,\n", "            hashValid: true,\n            isCertified,\n")], 'app', 'T1/T9'),
 ('m10 KS-1032 gate removed: x-tenant-id read unvouched', RT, [("  const header = isGatewayVouched(req) ? nonEmpty(req.headers['x-tenant-id']) : undefined;", "  void isGatewayVouched; const header = nonEmpty(req.headers['x-tenant-id']);")], 'app', 'T3'),
 # gate's own
 ('o1 documentId ignored when a title is present (title wins)', V, [("        if (documentId) {\n          let rows: any[] = await db.$queryRaw`", "        if (documentId && !titleToFind) {\n          let rows: any[] = await db.$queryRaw`")], 'app', 'T8 (and T9 documentId+title)'),
 ('o2 the title is matched TRIMMED', V, [("            WHERE d.title = ${titleToFind}\n", "            WHERE d.title = ${titleToFind.trim()}\n")], 'app', 'T5'),
 ('o3 null-tenant guard dropped', V, [("if (!tenantForTitle || titleToFind === ERASED_MARKER) return titleNotFound();", "if (titleToFind === ERASED_MARKER) return titleNotFound();")], 'app', 'SURVIVES: dead guard (resolveRequestTenantId never returns empty)'),
 ('o4 title answer strips contentHash/issuer/lineage (existence-only shape)', V, [("          return respondExistenceOnly(\n            titleRows[0],", "          return res.json({ verified: false, warning: 'x', checks: { documentExists: true, hashValid: false, integrityVerified: false } }); void respondExistenceOnly(\n            titleRows[0],")], 'app', 'predicted: KILLED only via T1 documentId/title asserts'),
 ('o5 tenant predicate removed AND RLS bypass (MT=true superuser)', V, [(SQL_TENANT, "")], 'super-mt', 'T2'),
 ('CONTROL comment-only line', V, [("        if (titleToFind && !documentId && !computedHash) {\n", "        // gate1555 comment-only control\n        if (titleToFind && !documentId && !computedHash) {\n")], 'app', 'SURVIVES (control)'),
]
EXP = 12; res = []
for name, path, edits, mode, pred in M:
    src = io.open(path, encoding='utf-8').read(); mut = src; ok = True
    for o, n in edits:
        if mut.count(o) != 1: print(f'{name}: ANCHOR FAULT ({mut.count(o)})', flush=True); ok = False; break
        mut = mut.replace(o, n)
    if not ok: res.append((name, 'ANCHOR', pred, [])); continue
    io.open(path, 'w', encoding='utf-8').write(mut)
    try:
        md, mt = (('super', 'true') if mode == 'super-mt' else (mode, 'false'))
        tally, red, out = run(md, mt)
    finally: io.open(path, 'w', encoding='utf-8').write(src)
    if tally is None or tally[1] != EXP:
        print(f'{name}: LOAD FAILURE ({tally}) - NOT scored', flush=True); open(G + '/ev/mut_loadfail_' + name.split()[0] + '.log', 'w').write(out); res.append((name, 'LOADFAIL', pred, red)); continue
    st = 'KILLED' if tally[0] > 0 else 'SURVIVED'
    print(f'{name}: {st} ({tally[0]} red) red={red} | predicted: {pred}', flush=True); res.append((name, st, pred, red))
for mode in ('app', 'super'):
    t, r, _ = run(mode); print(f'CLEAN ({mode}):', t, r, flush=True)
# restoration check
print('worktree clean after mutants:', subprocess.run(['git', '-C', G + '/wt/m', 'diff', '--stat'], capture_output=True, text=True).stdout.strip() == '')
json.dump(res, open(G + '/ev/mutants.json', 'w'), indent=1)
