#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555-1792045119; R=$G/repo
SRC="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files"
echo "== live refs (ls-remote from the checkout)"
git -C "$SRC" ls-remote origin refs/heads/develop refs/pull/1555/head refs/pull/1552/head refs/pull/1554/head
git -C $R fetch -q origin '+refs/heads/develop:refs/remotes/origin/develop' '+refs/pull/1555/head:refs/remotes/pr/1555'
DEV=$(git -C $R rev-parse origin/develop); HEADP=$(git -C $R rev-parse pr/1555)
echo "develop=$DEV pr1555=$HEADP mergebase=$(git -C $R merge-base $DEV $HEADP)"
echo "develop..pr commits: $(git -C $R rev-list --count $DEV..$HEADP)  pr..develop commits: $(git -C $R rev-list --count $HEADP..$DEV)"
echo "== merge-tree pr1555 onto live develop"
git -C $R merge-tree --write-tree --name-only $DEV $HEADP; echo "rc=$?"
T=$(git -C $R merge-tree --write-tree $DEV $HEADP | head -1)
echo "merged tree=$T  pr head tree=$(git -C $R rev-parse $HEADP^{tree})  equal=$([ "$T" = "$(git -C $R rev-parse $HEADP^{tree})" ] && echo yes || echo no)"
echo "== planted conflicting control: a develop-side edit of the title SQL line"
WTC=$G/wt/ctl-$(date +%s)
git -C $R worktree add -q --detach $WTC $DEV
F=Blockchain/Dev/services/originate/src/routes/verification.ts
python3 -I - "$WTC/$F" <<'PY'
import sys
p=sys.argv[1]; s=open(p).read()
old="      const { documentId, providedHash, documentData, contentHash, documentHash, hash } = req.body;"
assert s.count(old)==1
open(p,'w').write(s.replace(old, old + " // planted control"))
PY
git -C $WTC -c user.email=gate@x -c user.name=gate commit -q -am "planted control"
C=$(git -C $WTC rev-parse HEAD)
git -C $R merge-tree --write-tree --name-only $C $HEADP; echo "control rc=$? (expect 1 = conflict)"
echo "== cross-lane file overlap"
for p in 1552 1554; do
  H=$(git -C $R rev-parse pr/$p); MB=$(git -C $R merge-base $DEV $H)
  echo "PR $p head=$H subject: $(git -C $R log -1 --format=%s $H)"
  git -C $R diff --name-only $MB $H | grep -E 'secuura-api.yaml|originate.openapi.ts|routes/verification.ts' || echo "   (touches none of yaml / originate.openapi.ts / verification.ts)"
  echo "   files changed: $(git -C $R diff --name-only $MB $H | wc -l)"
done
