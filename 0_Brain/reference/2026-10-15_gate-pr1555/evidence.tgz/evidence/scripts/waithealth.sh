#!/bin/bash
for i in $(seq 1 60); do curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:$1/health 2>/dev/null | grep -q 200 && { echo "UP after ${i}s"; exit 0; }; sleep 1; done; echo "NOT UP"
