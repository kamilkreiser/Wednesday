#!/bin/bash
S=/private/tmp/claude-501/gate1555-1792045119/scripts
for mt in false true; do for role in super app; do
  echo "== ks1114 mt=$mt role=$role"; /bin/bash $S/itest.sh h it_h_ks1114_${mt}_${role} $mt $role ks1114
done; done
