import io, re, subprocess, os, json, sys
G = '/private/tmp/claude-501/gate1555-1792045119'
DEV = G + '/wt/m/Blockchain/Dev'
O = DEV + '/services/originate'
V = O + '/src/routes/verification.ts'; RT = O + '/src/utils/requestTenant.ts'
SUPER = 'postgresql://secuura:secuura@127.0.0.1:55731/secuura'; APP = 'postgresql://secuura_app:app@127.0.0.1:55731/secuura'
PS = 'postgresql://secuura:secuura@127.0.0.1:55731/secuura_platform'; PA = 'postgresql://secuura_app:app@127.0.0.1:55731/secuura_platform'
def run(mode, mt='false'):
    env = dict(os.environ, TEST_DATABASE_URL=SUPER, DATABASE_URL=SUPER, TEST_SUPER_PLATFORM_DATABASE_URL=PS,
               TEST_PLATFORM_DATABASE_URL=PA if mode == 'app' else PS, MULTI_TENANCY_ENABLED=mt)
    if mode == 'app': env['TEST_APP_DATABASE_URL'] = APP
    else: env.pop('TEST_APP_DATABASE_URL', None)
    p = subprocess.run([DEV + '/node_modules/.bin/jest', '--rootDir', O, '--config', O + '/jest.integration.config.js', 'ks1114', '--forceExit'],
                       capture_output=True, text=True, env=env, timeout=900)
    out = p.stdout + p.stderr
    m = re.search(r'^Tests:\s+(?:(\d+) failed, )?(\d+) passed, (\d+) total', out, re.M)
    red = sorted(set(re.findall(r'●[^\n]*›\s*(T\d+b?)\b', out)))
    return ((int(m.group(1) or 0), int(m.group(3))) if m else None), red, out
SQL_TENANT = "              AND d.tenant_id::text = ${tenantForTitle}\n"
M = [
 ('m6c-prime BOTH sentinel lines removed (import kept used)', V, [("if (!tenantForTitle || titleToFind === ERASED_MARKER) return titleNotFound();", "if (!tenantForTitle) return titleNotFound(); void ERASED_MARKER;"), ("              AND d.title <> ${ERASED_MARKER}\n", "")], 'app', 'T6'),
 ('m1 tenant predicate removed (app role, MULTI_TENANCY_ENABLED=true)', V, [(SQL_TENANT, "")], 'app-mt', 'SURVIVES by design (RLS)'),
 ('o6 erasure sentinel compared case-insensitively removed -> sentinel lookup reaches SQL with tenant predicate dropped too', V, [("if (!tenantForTitle || titleToFind === ERASED_MARKER) return titleNotFound();", "if (!tenantForTitle) return titleNotFound(); void ERASED_MARKER;"), ("              AND d.title <> ${ERASED_MARKER}\n", ""), (SQL_TENANT, "")], 'super', 'T2/T6'),
]
EXP = 12; res = []
for name, path, edits, mode, pred in M:
    src = io.open(path, encoding='utf-8').read(); mut = src; ok = True
    for o, n in edits:
        if mut.count(o) != 1: print(f'{name}: ANCHOR FAULT ({mut.count(o)})', flush=True); ok = False; break
        mut = mut.replace(o, n)
    if not ok: res.append((name, 'ANCHOR', pred, [])); continue
    io.open(path, 'w', encoding='utf-8').write(mut)
    try:
        md, mt = {'super-mt': ('super', 'true'), 'app-mt': ('app', 'true')}.get(mode, (mode, 'false'))
        tally, red, out = run(md, mt)
    finally: io.open(path, 'w', encoding='utf-8').write(src)
    if tally is None or tally[1] != EXP:
        print(f'{name}: LOAD FAILURE ({tally}) - NOT scored', flush=True); open(G + '/ev/mut_loadfail_' + name.split()[0] + '.log', 'w').write(out); res.append((name, 'LOADFAIL', pred, red)); continue
    st = 'KILLED' if tally[0] > 0 else 'SURVIVED'
    print(f'{name}: {st} ({tally[0]} red) red={red} | predicted: {pred}', flush=True); res.append((name, st, pred, red))
for mode in ('app', 'super'):
    t, r, _ = run(mode); print(f'CLEAN ({mode}):', t, r, flush=True)
# restoration check
print('worktree clean after mutants:', subprocess.run(['git', '-C', G + '/wt/m', 'diff', '--stat'], capture_output=True, text=True).stdout.strip() == '')
json.dump(res, open(G + '/ev/mutants2.json', 'w'), indent=1)
