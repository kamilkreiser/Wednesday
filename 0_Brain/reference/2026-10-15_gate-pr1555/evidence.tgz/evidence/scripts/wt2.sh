#!/bin/bash
# usage: wt2.sh <name> <commit> — worktree with a private generated Prisma client
set -u
G=/private/tmp/claude-501/gate1555-1792045119
R=$G/repo
N="$1"; C="$2"
W=$G/wt/$N
git -C $R worktree add --detach $W $C 2>&1 | tail -1
PD="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files/Blockchain/Dev"
WD="$W/Blockchain/Dev"
mkdir -p "$WD/node_modules/@secuura"
for e in "$PD/node_modules/"* "$PD/node_modules/".bin; do
  n=$(basename "$e"); [ "$n" = "@secuura" ] && continue
  [ -e "$WD/node_modules/$n" ] || ln -s "$e" "$WD/node_modules/$n"
done
for e in "$PD/node_modules/@secuura/"*; do
  n=$(basename "$e"); t=$(readlink "$e")
  [ -e "$WD/node_modules/@secuura/$n" ] || ln -s "$t" "$WD/node_modules/@secuura/$n"
done
for s in services/anchoring services/api-gateway packages/shared; do
  [ -e "$WD/$s/node_modules" ] || [ ! -e "$PD/$s/node_modules" ] || ln -s "$PD/$s/node_modules" "$WD/$s/node_modules"
done
ON="$WD/services/originate/node_modules"; PON="$PD/services/originate/node_modules"
mkdir -p "$ON/@prisma"
for e in "$PON/"* "$PON/".bin; do
  n=$(basename "$e"); [ "$n" = "@prisma" ] && continue
  ln -s "$e" "$ON/$n"
done
for e in "$PON/@prisma/"*; do
  n=$(basename "$e")
  if [ "$n" = client ]; then cp -R "$e" "$ON/@prisma/client"; else ln -s "$e" "$ON/@prisma/$n"; fi
done
"$WD/node_modules/.bin/tsc" -p "$WD/packages/shared/tsconfig.json" > $G/ev/build_shared_$N.log 2>&1
echo "shared build rc=$?"
PRISMA_GENERATE_SVC_DIR="$WD/services/originate" node "$WD/scripts/prisma-generate.cjs" > $G/ev/prisma_gen_$N.log 2>&1
echo "prisma gen rc=$?"; tail -3 $G/ev/prisma_gen_$N.log
ls "$ON/.prisma/client" | head -3
git -C $W status --porcelain | head -5
echo "HEAD=$(git -C $W rev-parse HEAD)"
