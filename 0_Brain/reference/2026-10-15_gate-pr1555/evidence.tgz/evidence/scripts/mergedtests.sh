#!/bin/bash
G=/private/tmp/claude-501/gate1555-1792045119
/bin/bash $G/scripts/itest2.sh mg mg_verify_false_app false app 'ks1114|ks1119|ks1557' --runInBand --forceExit
/bin/bash $G/scripts/itest2.sh mg mg_verify_true_super true super 'ks1114|ks1119|ks1557' --runInBand --forceExit
O_DIR=$G/wt/mg/Blockchain/Dev/services/originate
env -u DATABASE_URL -u TEST_DATABASE_URL $G/wt/mg/Blockchain/Dev/node_modules/.bin/jest --rootDir $O_DIR --config $O_DIR/jest.config.js --json --outputFile=$G/ev/unit_mg.json --forceExit > $G/ev/unit_mg.log 2>&1
python3 -I -c "
import json; d=json.load(open('$G/ev/unit_mg.json')); print('merged unit suites',d['numTotalTestSuites'],'passedSuites',d['numPassedTestSuites'],'tests',d['numTotalTests'],'passed',d['numPassedTests'],'failed',d['numFailedTests'])"
$G/wt/mg/Blockchain/Dev/node_modules/.bin/tsx $G/wt/mg/Blockchain/Dev/scripts/generate-openapi.ts --check > $G/ev/oapi_check_mg.log 2>&1; echo "merged generate-openapi --check rc=$?"; tail -1 $G/ev/oapi_check_mg.log
