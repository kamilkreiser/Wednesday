#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555-1792045119
E=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-15_gate-pr1555/evidence
mkdir -p $E/scripts $E/runs
cp $G/scripts/*.sh $G/scripts/*.py $E/scripts/
cp $G/probe/seed.sql $G/probe/seed_docs.sql $E/scripts/
for f in lsremote.txt golden_head_copy.json; do cp $G/out/$f $E/runs/; done
cd_free=1
for f in verifymatrix.txt unit_summary.txt mutants_r2.txt mutants2.txt mutants.txt merged_tests.txt \
  probe_h_st_final.json probe_h_st_final.txt probe_h_st.json probe_h_mt.json probe_h_mt_prod.json probe_d_st.json \
  chain_h_st.txt chain_h_st_final.txt oapi_check_h.log spec_examples_h.log oapi_ctl_pre.log oapi_ctl_planted.log oapi_check_mg.log \
  it_h_st_super.log it_h_st_super_utc.log it_d_ks1114_red.log it_d_record.log clean_m_dbg.log clean_m_dbg2.log; do
  [ -e $G/ev/$f ] && cp $G/ev/$f $E/runs/ || echo "missing $f"
done
python3 -I - $G/ev/timing_h_st.json $E/runs/timing_h_st_summary.json <<'PY'
import json,sys; d=json.load(open(sys.argv[1])); json.dump(d['summary'],open(sys.argv[2],'w'),indent=1)
PY
cp $G/wt/d/Blockchain/Dev/services/originate/src/__tests__/fixtures/ks1114-non-title-bodies.develop.json $E/runs/golden_rerecorded_on_develop_53b429ed.json
ls $E/runs | wc -l; du -sh $E
