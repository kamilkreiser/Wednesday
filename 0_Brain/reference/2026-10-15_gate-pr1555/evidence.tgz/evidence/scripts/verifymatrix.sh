#!/bin/bash
S=/private/tmp/claude-501/gate1555-1792045119/scripts
for wt in h d; do for mt in false true; do for role in app super; do
  echo "== $wt verify-int mt=$mt $role"; /bin/bash $S/itest2.sh $wt v2_${wt}_${mt}_${role} $mt $role 'ks1114|ks1119|ks1557' --runInBand --forceExit
done; done; done
