#!/bin/bash
S=/private/tmp/claude-501/gate1555-1792045119/scripts
for wt in h d; do for mt in false true; do
  echo "== $wt verify-int mt=$mt app"; /bin/bash $S/itest.sh $wt it_${wt}_verify_${mt}_app $mt app 'ks1114|ks1119|ks1557' --runInBand
done; done
for wt in h d; do
  echo "== $wt ALL integration mt=false app"; /bin/bash $S/itest.sh $wt it_${wt}_all_false_app false app --runInBand
done
