import json, sys, urllib.request
port = sys.argv[1]
def post(b):
    r = urllib.request.urlopen(urllib.request.Request(f'http://127.0.0.1:{port}/api/verification/verify', data=json.dumps(b).encode(), headers={'content-type': 'application/json'}, method='POST'))
    return json.loads(r.read())
s1 = post({'title': 'G1555 Alpha'})
print('step1 title -> contentHash', s1['contentHash'], 'newerVersions ids', [x['id'] for x in s1.get('newerVersions', [])], 'lineage ids', [x['id'] for x in s1.get('lineage', [])])
s2 = post({'hash': s1['contentHash']})
print('step2 {hash} -> verified', s2['verified'], 'integrityVerified', s2['checks']['integrityVerified'], 'issuer', s2.get('issuer'))
child = s1['newerVersions'][0]
s3 = post({'hash': child['contentHash']})
print('step3 child hash (never guessed) -> verified', s3['verified'], 'title', s3['title'])
s4 = post({'documentId': child['id']})
print('step4 child documentId -> title', s4['title'], 'documentExists', s4['checks']['documentExists'])
