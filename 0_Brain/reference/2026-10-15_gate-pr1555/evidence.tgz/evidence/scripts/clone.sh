#!/bin/bash
set -euo pipefail
S=/private/tmp/claude-501/gate1555-1792045119
SRC="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files"
SSHC='ssh -i "/Volumes/DevMASTER/!CODING/Secuura/Blockchain/3_Access_Keys/github_deploy_rw" -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new'
git -C "$SRC" ls-remote origin refs/pull/1555/head refs/heads/develop refs/pull/1552/head refs/pull/1554/head 2>&1 | tee $S/out/lsremote.txt || true
git clone --shared --no-checkout "$SRC" $S/repo
git -C $S/repo config core.sshCommand "$SSHC"
git -C $S/repo remote set-url origin git@github.com:Secuura/Distributed_Secuura.git
git -C $S/repo fetch origin '+refs/pull/1555/head:refs/remotes/pr/1555' '+refs/pull/1552/head:refs/remotes/pr/1552' '+refs/pull/1554/head:refs/remotes/pr/1554' '+refs/heads/develop:refs/remotes/origin/develop'
git -C $S/repo rev-parse pr/1555 pr/1552 pr/1554 origin/develop
