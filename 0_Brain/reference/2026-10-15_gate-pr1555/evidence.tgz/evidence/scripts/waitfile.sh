#!/bin/bash
# usage: waitfile.sh <file> <maxsec>
for i in $(seq 1 $2); do [ -s "$1" ] && { cat "$1"; exit 0; }; sleep 1; done; echo "still waiting"
