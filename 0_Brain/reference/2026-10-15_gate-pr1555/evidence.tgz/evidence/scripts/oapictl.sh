#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555-1792045119
W=$G/wt/head/Blockchain/Dev
F=$W/services/originate/src/originate.openapi.ts
echo "== positive run on wt/head (=c85cc28d) before planting"
$W/node_modules/.bin/tsx $W/scripts/generate-openapi.ts --check > $G/ev/oapi_ctl_pre.log 2>&1; echo "rc=$?"; tail -1 $G/ev/oapi_ctl_pre.log
cp $F $G/out/originate.openapi.ts.orig
python3 -I - $F <<'PY'
import sys
p=sys.argv[1]; s=open(p).read(); o="share the title, and the GDPR"
assert s.count(o)==1; open(p,'w').write(s.replace(o,"share a title, and the GDPR"))
PY
echo "== planted one-word spec change (control): --check must FAIL"
$W/node_modules/.bin/tsx $W/scripts/generate-openapi.ts --check > $G/ev/oapi_ctl_planted.log 2>&1; echo "rc=$?"; tail -2 $G/ev/oapi_ctl_planted.log
cp $G/out/originate.openapi.ts.orig $F
git -C $G/wt/head diff --stat -- Blockchain/Dev/services/originate/src/originate.openapi.ts | tail -1; echo "restored (empty diff above)"
