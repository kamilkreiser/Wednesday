#!/bin/bash
set -euo pipefail
R=/private/tmp/claude-501/gate1555-1792045119/repo
git -C $R checkout -q --detach "$1"
git -C $R rev-parse HEAD
