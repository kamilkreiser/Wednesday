INSERT INTO tenants (id, name, slug, status, created_at, updated_at) VALUES ('b1555000-0000-4000-8000-000000001555','g1555-b','g1555-b','active',NOW(),NOW()) ON CONFLICT (id) DO NOTHING;
