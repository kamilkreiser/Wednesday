#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555-1792045119
B=/opt/homebrew/opt/postgresql@18/bin
$B/pg_ctl -D $G/pgdata-55731 stop -m fast
$B/pg_ctl -D $G/pgdata-55731 -o "-p 55731 -k $G -c listen_addresses=127.0.0.1 -c TimeZone=UTC" -l $G/ev/pg_server.log start
sleep 2
$B/psql -h 127.0.0.1 -p 55731 -U secuura -d secuura -tAc "show timezone"
