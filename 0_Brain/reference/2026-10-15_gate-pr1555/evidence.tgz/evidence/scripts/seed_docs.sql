\set D '''a0000000-0000-4000-8000-000000000001'''
\set B '''b1555000-0000-4000-8000-000000001555'''
INSERT INTO documents (id, tenant_id, external_id, title, document_type, content_hash, status, created_at, certified_at, metadata, certification_metadata, parent_document_id) VALUES
 ('15550000-0000-4000-8000-0000000000f0', :D, 'g1555-parent', 'G1555 Parent', 'DIPLOMA', repeat('f0',32), 'certified', '2026-01-01Z', '2026-01-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-0000000000a1', :D, 'g1555-alpha', 'G1555 Alpha', 'DIPLOMA', repeat('a1',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{"issuerName":"Acme Private Issuer Pty"}', '{"certificationType":"academic","blockchain":{"txHash":"0xsim","simulated":true}}', '15550000-0000-4000-8000-0000000000f0'),
 ('15550000-0000-4000-8000-0000000000c1', :D, 'g1555-child', 'G1555 Child', 'DIPLOMA', repeat('c1',32), 'certified', '2026-03-01Z', '2026-03-01Z', '{}', '{}', '15550000-0000-4000-8000-0000000000a1'),
 ('15550000-0000-4000-8000-0000000000b1', :B, 'g1555-bravo', 'G1555 Bravo only', 'DIPLOMA', repeat('b1',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{"issuerName":"Tenant B Issuer"}', '{}', NULL),
 ('15550000-0000-4000-8000-0000000000b2', :B, 'g1555-both-b', 'G1555 In both', 'DIPLOMA', repeat('b2',32), 'certified', '2026-09-01Z', '2026-09-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-0000000000d2', :D, 'g1555-both-d', 'G1555 In both', 'DIPLOMA', repeat('d2',32), 'certified', '2026-01-01Z', '2026-01-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-0000000000e1', :D, 'g1555-erased', '[erased]', 'DIPLOMA', repeat('e1',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-0000000000e2', :D, 'g1555-draft', 'G1555 Draft', 'DIPLOMA', repeat('e2',32), 'draft', '2026-02-01Z', NULL, '{}', '{}', NULL),
 ('15550000-0000-4000-8000-0000000000e3', :D, 'g1555-revoked', 'G1555 Revoked', 'DIPLOMA', repeat('e3',32), 'revoked', '2026-02-01Z', '2026-02-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000101', :D, 'g1555-pct', 'G1555 100% off_x', 'DIPLOMA', repeat('11',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000102', :D, 'g1555-quote', 'G1555 O''Brien "q" \x', 'DIPLOMA', repeat('12',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000103', :D, 'g1555-long', 'G1555 L' || repeat('x', 493), 'DIPLOMA', repeat('13',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{}', '{}', NULL),
 ('15550000-0000-4000-8000-000000000104', :D, 'g1555-unicode', 'G1555 Café', 'DIPLOMA', repeat('14',32), 'certified', '2026-02-01Z', '2026-02-01Z', '{}', '{}', NULL)
ON CONFLICT (id) DO NOTHING;
SELECT external_id, tenant_id, length(title), status FROM documents WHERE external_id LIKE 'g1555-%' ORDER BY external_id;
