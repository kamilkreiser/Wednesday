#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555-1792045119
B=/opt/homebrew/opt/postgresql@18/bin
D=$G/wt/h/Blockchain/Dev
L=$G/ev/pg_platform_setup.log
P="$B/psql -h 127.0.0.1 -p 55731 -v ON_ERROR_STOP=0 -q"
$P -U postgres -d postgres -c "CREATE DATABASE secuura_platform OWNER secuura" >$L 2>&1
$P -U secuura -d secuura_platform -f $D/docker/init-platform/01-platform-schema.sql >>$L 2>&1
for f in $(ls $D/docker/init-platform/ | grep -v '^01-platform-schema.sql$'); do echo "== $f" >>$L; case $f in *.sql) $P -U secuura -d secuura_platform -f $D/docker/init-platform/$f >>$L 2>&1;; esac; done
$P -U secuura -d secuura_platform >>$L 2>&1 <<'EOSQL'
GRANT CONNECT ON DATABASE secuura_platform TO secuura_app;
GRANT USAGE ON SCHEMA public TO secuura_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO secuura_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO secuura_app;
EOSQL
echo "errors: $(grep -c ERROR $L)"; grep ERROR $L | head -5
ls $D/docker/init-platform/
$B/psql -h 127.0.0.1 -p 55731 -U secuura -d secuura_platform -tAc "select count(*) from information_schema.tables where table_schema='public'"
$B/psql -h 127.0.0.1 -p 55731 -U secuura -d secuura_platform -tAc "select id, slug, status from tenants"
