#!/bin/bash
# usage: itest.sh <wt> <outname> <mt:true|false> <role:super|app> [jest args...]
set -u
G=/private/tmp/claude-501/gate1555-1792045119
W=$G/wt/$1; O="$2"; MT="$3"; ROLE="$4"; shift 4
O_DIR=$W/Blockchain/Dev/services/originate
export TEST_DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:55731/secuura"
if [ "$ROLE" = app ]; then export TEST_APP_DATABASE_URL="postgresql://secuura_app:app@127.0.0.1:55731/secuura"; else unset TEST_APP_DATABASE_URL; fi
export DATABASE_URL="$TEST_DATABASE_URL"
export MULTI_TENANCY_ENABLED="$MT"
J=$W/Blockchain/Dev/node_modules/.bin/jest
$J --rootDir $O_DIR --config $O_DIR/jest.integration.config.js --json --outputFile=$G/ev/$O.json "$@" > $G/ev/$O.log 2>&1
rc=$?
python3 -I - "$G/ev/$O.json" <<'PY'
import json,sys
try: d=json.load(open(sys.argv[1]))
except Exception as e: print("no json",e); sys.exit()
print("suites",d.get("numTotalTestSuites"),"tests",d["numTotalTests"],"passed",d["numPassedTests"],"failed",d["numFailedTests"],"failedSuites",d.get("numFailedTestSuites"))
for f in d["testResults"]:
    for a in f["assertionResults"]:
        if a["status"]!="passed":
            print("  FAIL", a["fullName"][:150], "|", (a.get("failureMessages") or [""])[0].splitlines()[0][:300])
    if f.get("status")=="failed" and not f["assertionResults"]:
        print("  SUITE-FAIL", f["name"], f.get("message","")[:600])
PY
echo "rc=$rc"
