#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555-1792045119
H=$G/wt/h/Blockchain/Dev/services/originate/src/__tests__
D=$G/wt/d/Blockchain/Dev/services/originate/src/__tests__
mkdir -p $D/fixtures
cp $H/ks1114-anonymous-title-lookup-one-tenant.integration.test.ts $D/
cp $H/fixtures/ks1114-non-title-bodies.develop.json $D/fixtures/
echo "== develop running head's cells against head's golden (expect title cells RED, T9 GREEN)"
/bin/bash $G/scripts/itest.sh d it_d_ks1114_red false super ks1114
cp $D/fixtures/ks1114-non-title-bodies.develop.json $G/out/golden_head_copy.json
echo "== record on develop 53b429ed"
KS1114_RECORD=1 /bin/bash $G/scripts/itest.sh d it_d_record false super ks1114 -t T9
python3 -I - $G/out/golden_head_copy.json $D/fixtures/ks1114-non-title-bodies.develop.json <<'PY'
import json,sys
a=json.load(open(sys.argv[1]))['bodies']; b=json.load(open(sys.argv[2]))['bodies']
print("keys equal:", list(a)==list(b), "bodies equal:", a==b)
for k in a:
    if a[k]!=b[k]: print("DIFF", k)
PY
