import json, re, sys
n = lambda s: re.sub(r'"verifiedAt":"[^"]*"', '', s)
a = json.load(open(sys.argv[1])); b = json.load(open(sys.argv[2]))
same = [x['case'] for x, y in zip(a, b) if (x['status'], n(x['body'])) == (y['status'], n(y['body']))]
diff = [x['case'] for x, y in zip(a, b) if (x['status'], n(x['body'])) != (y['status'], n(y['body']))]
print(sys.argv[1].split('/')[-1], 'vs', sys.argv[2].split('/')[-1], ': same', len(same), 'differ', len(diff))
for x, y in zip(a, b):
    if x['case'] in diff and len(sys.argv) > 3: print('  ', x['case'], '|', x['status'], x['body'][:90], '||', y['status'], y['body'][:90])
