#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1555-1792045119; R=$G/repo
DEV=0bb4f17ca5010baa3ad9d91b790522e87b8c9dc1; H=c85cc28d0232e5641901bfd12ca6960a9711e783
T=$(git -C $R merge-tree --write-tree $DEV $H | head -1)
C=$(git -C $R -c user.email=gate@x -c user.name=gate commit-tree $T -p $DEV -p $H -m "gate1555 predicted merge")
echo "predicted merge commit $C tree $T"
/bin/bash $G/scripts/wt2.sh mg $C | tail -1
