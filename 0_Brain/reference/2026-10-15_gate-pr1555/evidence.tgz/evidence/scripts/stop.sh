#!/bin/bash
for p in 37846 37860 59061 59068 59179 59215 62878 62897; do kill $p 2>/dev/null; done
sleep 2
ps -o pid,command -ax | grep "gate1555-1792045119/wt/.*index.ts" | grep -v grep | wc -l
/opt/homebrew/opt/postgresql@18/bin/pg_ctl -D /private/tmp/claude-501/gate1555-1792045119/pgdata-55731 stop -m fast
lsof -nP -iTCP:55731 -sTCP:LISTEN | wc -l
