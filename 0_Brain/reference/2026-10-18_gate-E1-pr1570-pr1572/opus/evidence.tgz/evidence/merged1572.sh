#!/bin/bash
# api-gateway suite + leg 16 on the MERGED tree 6581d8d6db39 (develop 9251ae54d + #1570 + #1572): overlay the merged tree's api-gateway files into wt-1572
S=/private/tmp/claude-501/e1-opus; R=$S/repo; WT=$S/wt-1572; W=$WT/Blockchain/Dev; G=$W/services/api-gateway
M=6581d8d6db3987ddc57bdc427e7d350920c9ef36
files=$(git -C $R diff --name-only pr1572 $M -- Blockchain/Dev/services/api-gateway)
echo "api-gateway files differing pr1572 vs merged: $files"
for f in $files; do mkdir -p $(dirname $WT/$f); [ -f $WT/$f ] && cp $WT/$f $S/merged.bak.$(basename $f); git -C $R show $M:$f > $WT/$f; done
# prove the working api-gateway source equals the merged tree's
bad=0; for f in $(git -C $R ls-tree -r --name-only $M -- Blockchain/Dev/services/api-gateway/src); do cmp -s $WT/$f <(git -C $R show $M:$f) || { bad=$((bad+1)); echo "DIFF $f"; }; done; echo "api-gateway/src files differing from merged tree: $bad"
( $W/node_modules/.bin/vitest run --root $G > $S/merged.suite.txt 2>&1 ); echo "merged suite rc=$? $(grep -E '^ +(Test Files|Tests) ' $S/merged.suite.txt | tr -s ' ' | tr '\n' ' ')"
/bin/bash $W/scripts/preflight/test-types-ratchet.sh services/api-gateway 2>&1 | tail -2
( $W/node_modules/.bin/tsc -p $G/tsconfig.json --noEmit > $S/merged.tsc.txt 2>&1 ); echo "merged tsc product rc=$?"
for f in $files; do git -C $WT checkout -q -- $f 2>/dev/null || mv $WT/$f $S/merged.moved.$(basename $f); done
echo "restored: $(git -C $WT status --porcelain | grep -v node_modules | grep -v dist | wc -l | tr -d ' ') dirty/untracked"
