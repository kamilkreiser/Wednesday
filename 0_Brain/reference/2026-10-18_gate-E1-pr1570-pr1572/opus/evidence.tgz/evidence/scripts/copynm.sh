#!/bin/bash
set -e
SRC="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files/Blockchain/Dev"
W=/private/tmp/claude-501/e1-opus/wt-1572/Blockchain/Dev
rsync -a "$SRC/node_modules/" "$W/node_modules/"
rsync -a "$SRC/services/api-gateway/node_modules/" "$W/services/api-gateway/node_modules/"
[ -d "$SRC/packages/shared/node_modules" ] && rsync -a "$SRC/packages/shared/node_modules/" "$W/packages/shared/node_modules/"
echo COPY-DONE
