#!/bin/bash
# full shell-suite runner, with a workspace install present: before (#1570's two files as on base) and after (as on #1570)
S=/private/tmp/claude-501/e1-opus; W=$S/wt-1572/Blockchain/Dev
P=scripts/preflight/preflight.sh; T=scripts/__tests__/ks1547_preflight_step_header_denominator.test.sh
cp $W/$P $S/runner.P.orig; cp $W/$T $S/runner.T.orig
for v in origin/develop pr1570; do
  git -C $S/repo show $v:Blockchain/Dev/$P > $W/$P; git -C $S/repo show $v:Blockchain/Dev/$T > $W/$T
  /bin/bash $W/scripts/run-shell-suites.sh > $S/runner.$(echo $v | tr / _).txt 2>&1; rc=$?
  /bin/bash $W/scripts/run-shell-suites.sh --check-unreached > $S/runner.unreached.$(echo $v | tr / _).txt 2>&1; urc=$?
  echo "$v: runner rc=$rc [$(tail -3 $S/runner.$(echo $v | tr / _).txt | tr '\n' ' ')] check-unreached rc=$urc"
done
cp $S/runner.P.orig $W/$P; cp $S/runner.T.orig $W/$T
echo "restored: $(git -C $S/wt-1572 status --porcelain -- Blockchain/Dev/$P Blockchain/Dev/$T | wc -l | tr -d ' ') dirty"
