#!/bin/bash
# Gate E1 opus: run step() from two preflight.sh versions on every header; compare.
# usage: probe1570.sh <dev preflight.sh> <pr preflight.sh> <outdir>
DEVP=$1; PRP=$2; OUT=$3; mkdir -p $OUT
CANARY=$OUT/CANARY-INJECTED
mk() { # mk <preflight> <header-file> <runfile>
  awk '/^fail=0$/{on=1} /^step "1\//{on=0} on' "$1" > "$3.helpers"
  { printf 'set -uo pipefail\nGATEWAY=http://127.0.0.1:9\n'; cat "$3.helpers"; printf 'step "$(cat %q)"\necho STEP-RETURNED\n' "$2"; } > "$3"
}
run() { # run <preflight> <header-file> <tag>  -> prints rc and writes output
  mk "$1" "$2" "$OUT/run.$3.sh"
  /bin/bash "$OUT/run.$3.sh" > "$OUT/out.$3.txt" 2>&1; echo $?
}
n=0; diffs=0
probe() { # probe <header>
  n=$((n+1)); printf '%s' "$1" > $OUT/hdr.$n
  drc=$(run $DEVP $OUT/hdr.$n dev.$n); prc=$(run $PRP $OUT/hdr.$n pr.$n)
  dab=$(grep -c 'PREFLIGHT ABORTED' $OUT/out.dev.$n.txt); pab=$(grep -c 'PREFLIGHT ABORTED' $OUT/out.pr.$n.txt)
  dsr=$(grep -c STEP-RETURNED $OUT/out.dev.$n.txt); psr=$(grep -c STEP-RETURNED $OUT/out.pr.$n.txt)
  # outputs must be identical except the 5th abort line's new suffix
  sed 's/; the header.s text after the slash is ".*$/)/' $OUT/out.pr.$n.txt > $OUT/out.pr.$n.norm
  if cmp -s $OUT/out.dev.$n.txt $OUT/out.pr.$n.norm; then same=SAME; else same=DIFF; diffs=$((diffs+1)); fi
  says=$(grep -o 'says /[0-9]*' $OUT/out.pr.$n.txt | head -1)
  printf '%s\tdev rc=%s ab=%s ret=%s | pr rc=%s ab=%s ret=%s | %s %s\n' "$(printf '%q' "$1")" $drc $dab $dsr $prc $pab $psr "$says" $same
}
echo "--- every step header in the PR's preflight.sh"
grep -E '^step "' $PRP | sed -E 's/^step "(.*)"[[:space:]]*$/\1/' > $OUT/headers.txt
echo "count=$(wc -l < $OUT/headers.txt) (positive control: TOTAL_LEGS=$(grep -E '^TOTAL_LEGS=' $PRP))"
while IFS= read -r h; do probe "$h"; done < $OUT/headers.txt
echo "--- empty / non-digit / malformed"
for h in "3/" "3/x" "3/x  Title" "3" "" "/" "/16" "3/16x" "3/1" "3/017  T" "3/016  T" "3/ 16  T" "3/-16" "3/+16" "3/16.0" "3/１６" "3/16/16" "3/16 /x"; do probe "$h"; done
echo "--- injection payloads (the header's text is attacker-written)"
for h in "3/\$(touch $CANARY)" "3/\`touch $CANARY\`" '3/x"; touch '"$CANARY"'; echo "' '3/x\nINJECTED-LINE' '3/x\c' '3/%s%n' "3/x"$'\n'"PREFLIGHT PASSED fake" "3/x"$'\r'"overwrite" "3/x"$'\e'"[2Jesc" '3/${TOTAL_LEGS}' '3/$TOTAL_LEGS' "3/\${PATH}" "3/-n -e" "3/$(printf 'a%.0s' $(seq 1 3000))"; do probe "$h"; done
[ -e $CANARY ] && echo "CANARY EXISTS (injection executed)" || echo "canary absent: no command in a header ran"
echo "probes=$n diffs(outside the new suffix)=$diffs"
