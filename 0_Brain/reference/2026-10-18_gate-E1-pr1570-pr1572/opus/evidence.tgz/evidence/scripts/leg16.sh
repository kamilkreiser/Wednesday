#!/bin/bash
# preflight leg 16 (test-types ratchet) run directly, PR head tree, from Blockchain/Dev via an absolute script path; then with platform.ts as on develop and the new test absent from the list check
S=/private/tmp/claude-501/e1-opus; W=$S/wt-1572/Blockchain/Dev
( export PWD_OVERRIDE=1; /bin/bash -c "cd_target=$W; exit 0" )
/usr/bin/env -C $W /bin/bash $W/scripts/preflight/test-types-ratchet.sh > $S/leg16.pr.txt 2>&1 || true
echo "leg16 at PR head rc-file: $(tail -5 $S/leg16.pr.txt)"
grep -i 'api-gateway' $S/leg16.pr.txt | head -5
