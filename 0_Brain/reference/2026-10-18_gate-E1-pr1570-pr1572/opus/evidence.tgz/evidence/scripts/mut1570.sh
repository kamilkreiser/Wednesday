#!/bin/bash
# Gate E1 opus: mutants of #1570, in place in the scratch worktree, restored after each.
S=/private/tmp/claude-501/e1-opus; W=$S/wt-1570
P=$W/Blockchain/Dev/scripts/preflight/preflight.sh
T=$W/Blockchain/Dev/scripts/__tests__/ks1547_preflight_step_header_denominator.test.sh
TD=$W/Blockchain/Dev/scripts/__tests__
OUT=$S/mut1570-$(date +%H%M%S); mkdir -p $OUT
declare -a ID FILE EX DESC
add() { ID+=("$1"); FILE+=("$2"); DESC+=("$3"); EX+=("$4"); }
# --- preflight.sh hunk
add PM1 P 'drop the new suffix (develop message)' 's/; the header.s text after the slash is \\"\$_hdr_tail\\"\)/)/'
add PM2 P 'suffix quotes $_hdr_total not $_hdr_tail' 's/after the slash is \\"\$_hdr_tail\\"/after the slash is \\"\$_hdr_total\\"/'
add PM3 P 'suffix quotes $1 (whole header) not the tail' 's/after the slash is \\"\$_hdr_tail\\"/after the slash is \\"\$1\\"/'
add PM4 P 'greedy ##*/ for the tail (last slash)' 's/_hdr_tail="\$\{1#\*\/\}"/_hdr_tail="\${1##*\/}"/'
add PM5 P 'single % (shortest suffix) on the digit cut' 's/_hdr_total="\$\{_hdr_tail%%\[!0-9\]\*\}"/_hdr_total="\${_hdr_tail%[!0-9]*}"/'
add PM6 P 'N4: class [!1-9]' 's/_hdr_tail%%\[!0-9\]\*/_hdr_tail%%[!1-9]*/'
add PM7 P 'N5: cut at space/tab/colon only' 's/_hdr_tail%%\[!0-9\]\*/_hdr_tail%%[[:space:]:]*/'
add PM8 P 'N7: numeric -ne compare' 's/if \[ "\$_hdr_total" != "\$TOTAL_LEGS" \]/if [ "\$_hdr_total" -ne "\$TOTAL_LEGS" ] 2>\/dev\/null/'
add PM9 P 'tail read from $CURRENT_LEG side (${1%/*})' 's/_hdr_tail="\$\{1#\*\/\}"/_hdr_tail="\${1%\/*}"/'
add PC0 P 'CONTROL comment-only line in step()' 's/(    _hdr_tail=)/    # gate-e1 comment-only control\n$1/'
# --- test-file hunk
add TM1 T 'call_step_total sets TOTAL_LEGS BEFORE the helpers (override lost)' 's/cat "\$tmp\/helpers.sh"\n    printf .TOTAL_LEGS=%s\\nstep %q\\necho STEP-RETURNED\\n. "\$1" "\$2"/printf "TOTAL_LEGS=%s\\n" "\$1"\n    cat "\$tmp\/helpers.sh"\n    printf "step %q\\necho STEP-RETURNED\\n" "\$2"/'
add TM2 T 'RED empty-tail cell asserts the wrong text' 's/the slash is \\"\\"\x27*\)/the slash is \\"16\\"")/; s/has "the header.s text after the slash is \\"\\""/has "the header\x27s text after the slash is \\"16\\""/'
add TC0 T 'CONTROL comment-only line in the test hunk' 's/(call_step_total\(\) \{)/# gate-e1 comment-only control\n$1/'
for i in "${!ID[@]}"; do
  id=${ID[$i]}; f=$P; [ "${FILE[$i]}" = T ] && f=$T
  cp $f $OUT/$id.orig; perl -0pi -e "${EX[$i]}" $f
  if cmp -s $f $OUT/$id.orig; then echo "$id DID NOT LAND (${DESC[$i]})"; continue; fi
  diff $OUT/$id.orig $f > $OUT/$id.diff
  /bin/bash -n $f || echo "$id bash -n FAILED"
  out=$(/bin/bash $T 2>&1); rc=$?
  fails=$(printf '%s\n' "$out" | grep '^FAIL' | sed 's/^FAIL //' | tr '\n' '|')
  sib=""
  for s in $TD/preflight_*.test.sh; do o=$(/bin/bash $s 2>&1); src=$?; sib="$sib $(basename $s .test.sh)=$src"; done
  # real leg headers through the mutant's step()
  awk '/^fail=0$/{on=1} /^step "1\//{on=0} on' $P > $OUT/$id.helpers
  hab=0; while IFS= read -r h; do { printf 'set -uo pipefail\nGATEWAY=http://127.0.0.1:9\n'; cat $OUT/$id.helpers; printf 'step %q\n' "$h"; } > $OUT/$id.run; /bin/bash $OUT/$id.run >/dev/null 2>&1 || hab=$((hab+1)); done < <(grep -E '^step "' $P | sed -E 's/^step "(.*)"[[:space:]]*$/\1/')
  echo "$id (${DESC[$i]}): ks1547 rc=$rc [$(printf '%s\n' "$out" | tail -1)] fails={$fails} real-headers-aborting=$hab/16 siblings:$sib"
  cp $OUT/$id.orig $f
done
echo "restored: $(git -C $W status --porcelain | wc -l | tr -d ' ') dirty paths; HEAD $(git -C $W rev-parse HEAD)"
