#!/bin/bash
# merge prediction on live develop: each PR alone, both in each order, overlap check, planted conflict control
S=/private/tmp/claude-501/e1-opus; R=$S/repo
D=$(git -C $R rev-parse origin/develop); A=$(git -C $R rev-parse pr1570); B=$(git -C $R rev-parse pr1572)
echo "git $(git --version)"; echo "develop=$D 1570=$A 1572=$B"
mt() { git -C $R merge-tree --write-tree --messages "$@"; }
t1=$(mt $D $A); r1=$?; echo "1570 alone: rc=$r1 tree=$(echo "$t1" | head -1)"
t2=$(mt $D $B); r2=$?; echo "1572 alone: rc=$r2 tree=$(echo "$t2" | head -1)"
# order 1570 then 1572: make a commit for develop+1570 in the scratch clone, then merge 1572 into it
c1=$(git -C $R commit-tree $(echo "$t1" | head -1) -p $D -p $A -m "sim 1570"); t12=$(mt $c1 $B); r12=$?
c2=$(git -C $R commit-tree $(echo "$t2" | head -1) -p $D -p $B -m "sim 1572"); t21=$(mt $c2 $A); r21=$?
echo "1570 then 1572: rc=$r12 tree=$(echo "$t12" | head -1)"
echo "1572 then 1570: rc=$r21 tree=$(echo "$t21" | head -1)"
[ "$(echo "$t12" | head -1)" = "$(echo "$t21" | head -1)" ] && echo "both orders land the SAME tree" || echo "ORDERS DIFFER"
echo "--- overlap: files touched by each PR (vs merge-base) and by develop since base"
fa=$(git -C $R diff --name-only $(git -C $R merge-base $D $A) $A); fb=$(git -C $R diff --name-only $(git -C $R merge-base $D $B) $B)
fd=$(git -C $R diff --name-only 1197ab38a $D)
echo "1570: $fa"; echo "1572: $fb"
echo "1570∩1572: [$(comm -12 <(echo "$fa" | sort) <(echo "$fb" | sort))]"
echo "1570∩develop-since-base: [$(comm -12 <(echo "$fa" | sort) <(echo "$fd" | sort))]"
echo "1572∩develop-since-base: [$(comm -12 <(echo "$fb" | sort) <(echo "$fd" | sort))]"
echo "--- merged tree content check: each PR's files in the 2-way merged tree equal the PR head's blobs"
T=$(echo "$t12" | head -1)
for f in $fa; do [ "$(git -C $R rev-parse $T:$f)" = "$(git -C $R rev-parse $A:$f)" ] && echo "same $f" || echo "DIFFERENT $f"; done
for f in $fb; do [ "$(git -C $R rev-parse $T:$f)" = "$(git -C $R rev-parse $B:$f)" ] && echo "same $f" || echo "DIFFERENT $f"; done
echo "--- planted conflicting control: a develop-side commit that edits #1570's changed line and #1572's catch line"
TMPI=$S/planted.index; export GIT_INDEX_FILE=$TMPI; git -C $R read-tree $D
P=Blockchain/Dev/scripts/preflight/preflight.sh; G=Blockchain/Dev/services/api-gateway/src/routes/platform.ts
git -C $R show $D:$P | sed 's/disagrees with TOTAL_LEGS \$TOTAL_LEGS)"/disagrees with TOTAL_LEGS $TOTAL_LEGS) PLANTED"/' > $S/planted.P
git -C $R show $D:$G | sed 's/      } catch {$/      } catch (planted) { void planted;/' > $S/planted.G
cmp -s $S/planted.P <(git -C $R show $D:$P) && echo "PLANTED P DID NOT LAND"; cmp -s $S/planted.G <(git -C $R show $D:$G) && echo "PLANTED G DID NOT LAND"
git -C $R update-index --cacheinfo 100644,$(git -C $R hash-object -w $S/planted.P),$P
git -C $R update-index --cacheinfo 100644,$(git -C $R hash-object -w $S/planted.G),$G
PT=$(git -C $R write-tree); unset GIT_INDEX_FILE
PC=$(git -C $R commit-tree $PT -p $D -m planted)
mt $PC $A > $S/planted.1570.txt; echo "planted vs 1570: rc=$? $(grep -i -c CONFLICT $S/planted.1570.txt) conflict line(s): $(grep -i CONFLICT $S/planted.1570.txt | head -2)"
mt $PC $B > $S/planted.1572.txt; echo "planted vs 1572: rc=$? $(grep -i -c CONFLICT $S/planted.1572.txt) conflict line(s): $(grep -i CONFLICT $S/planted.1572.txt | head -2)"
