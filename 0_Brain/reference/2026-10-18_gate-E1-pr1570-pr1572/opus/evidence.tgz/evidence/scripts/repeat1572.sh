#!/bin/bash
# repeat the new KS-1545 test 5 times at the PR head (flake check)
S=/private/tmp/claude-501/e1-opus; W=$S/wt-1572/Blockchain/Dev; G=$W/services/api-gateway
for i in 1 2 3 4 5; do ( $W/node_modules/.bin/vitest run --root $G src/__tests__/ks1545-platform-audit-log-logs-the-dropped-platform-half.test.ts > $S/repeat.$i.txt 2>&1 ); echo "run $i rc=$? $(grep -E '^ +Tests ' $S/repeat.$i.txt | tr -s ' ')"; done
