#!/bin/bash
# Gate E1 opus: #1572 red-first / green / full api-gateway suite before+after / tsc incl. the new test + planted control
S=/private/tmp/claude-501/e1-opus; R=$S/repo; W=$S/wt-1572/Blockchain/Dev; G=$W/services/api-gateway
F=Blockchain/Dev/services/api-gateway/src/routes/platform.ts
NT=src/__tests__/ks1545-platform-audit-log-logs-the-dropped-platform-half.test.ts
OUT=$S/out1572; mkdir -p $OUT
VT=$W/node_modules/.bin/vitest; TSC=$W/node_modules/.bin/tsc
echo "node $(node --version) vitest $($VT --version 2>/dev/null) tsc $($TSC --version)"
if [ ! -f $W/packages/shared/dist/index.js ]; then (npm --prefix $W/packages/shared run build > $OUT/shared-build.txt 2>&1); echo "shared build rc=$?"; fi
cp $W/../../$F $OUT/platform.pr.ts 2>/dev/null || git -C $R show pr1572:$F > $OUT/platform.pr.ts
git -C $R show pr1572:$F > $OUT/platform.pr.ts; git -C $R show origin/develop:$F > $OUT/platform.dev.ts
cmp -s $OUT/platform.dev.ts <(git -C $R show 1197ab38a:$F) && echo "develop platform.ts == base platform.ts"
echo "=== GREEN: new test at PR head"
( $VT run --root $G $NT > $OUT/green.txt 2>&1 ); echo "rc=$?"; grep -E '✓|✗|×|Test Files|Tests ' $OUT/green.txt | head -12
echo "=== RED-FIRST: new test with platform.ts as on develop"
cp $OUT/platform.dev.ts $G/src/routes/platform.ts
( $VT run --root $G $NT > $OUT/redfirst.txt 2>&1 ); echo "rc=$?"; grep -E '✓|✗|×|Test Files|Tests ' $OUT/redfirst.txt | head -12
echo "=== full api-gateway suite BEFORE (develop platform.ts, new test excluded)"
( $VT run --root $G --exclude '**/ks1545-*' --exclude '**/node_modules/**' > $OUT/suite.before.txt 2>&1 ); echo "rc=$?"; grep -E 'Test Files|Tests ' $OUT/suite.before.txt
cp $OUT/platform.pr.ts $G/src/routes/platform.ts
echo "=== full api-gateway suite AFTER (PR head)"
( $VT run --root $G > $OUT/suite.after.txt 2>&1 ); echo "rc=$?"; grep -E 'Test Files|Tests ' $OUT/suite.after.txt
grep -E '(FAIL|×) ' $OUT/suite.before.txt | sort -u > $OUT/fail.before; grep -E '(FAIL|×) ' $OUT/suite.after.txt | sort -u > $OUT/fail.after
echo "failing lines before=$(wc -l < $OUT/fail.before) after=$(wc -l < $OUT/fail.after); new in after:"; comm -13 $OUT/fail.before $OUT/fail.after | head
echo "=== tsc: product build (tsconfig as shipped) and a program that INCLUDES the new test"
( $TSC -p $G/tsconfig.json --noEmit > $OUT/tsc.prod.txt 2>&1 ); echo "tsc product rc=$? errors=$(grep -c 'error TS' $OUT/tsc.prod.txt)"
cat > $G/tsconfig.gate-e1.json <<'J'
{ "extends": "./tsconfig.json", "compilerOptions": { "noEmit": true, "rootDir": "./src", "types": ["node", "vitest/globals"] }, "include": ["src/routes/platform.ts", "src/__tests__/ks1545-platform-audit-log-logs-the-dropped-platform-half.test.ts"], "exclude": [] }
J
( $TSC -p $G/tsconfig.gate-e1.json --listFilesOnly > $OUT/tsc.files.txt 2>&1 ); echo "program includes new test: $(grep -c 'ks1545-platform-audit-log' $OUT/tsc.files.txt)"
( $TSC -p $G/tsconfig.gate-e1.json > $OUT/tsc.test.txt 2>&1 ); echo "tsc incl. new test rc=$? errors=$(grep -c 'error TS' $OUT/tsc.test.txt)"; head -5 $OUT/tsc.test.txt
cp $G/$NT $OUT/newtest.orig
printf '\nconst __gateE1Planted: number = "not a number";\n' >> $G/$NT
( $TSC -p $G/tsconfig.gate-e1.json > $OUT/tsc.planted.txt 2>&1 ); echo "PLANTED control rc=$? errors=$(grep -c 'error TS' $OUT/tsc.planted.txt): $(grep 'error TS' $OUT/tsc.planted.txt | head -2)"
cp $OUT/newtest.orig $G/$NT
mv $G/tsconfig.gate-e1.json $OUT/tsconfig.gate-e1.json
echo "restored: $(git -C $S/wt-1572 status --porcelain --untracked-files=no | wc -l | tr -d ' ') tracked dirty; untracked: $(git -C $S/wt-1572 status --porcelain | grep '^??' | grep -v node_modules | grep -v dist | head -3)"
