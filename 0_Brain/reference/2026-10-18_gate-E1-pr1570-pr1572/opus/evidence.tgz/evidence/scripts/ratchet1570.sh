#!/bin/bash
# ratchet-leg suite with a workspace install present: preflight.sh as develop, then as #1570
S=/private/tmp/claude-501/e1-opus; W=$S/wt-1572; P=$W/Blockchain/Dev/scripts/preflight/preflight.sh
cp $P $S/ratchet.orig
for v in develop pr1570; do
  git -C $S/repo show $v:Blockchain/Dev/scripts/preflight/preflight.sh > $P
  out=$(/bin/bash $W/Blockchain/Dev/scripts/__tests__/preflight_test_types_ratchet_leg.test.sh 2>&1); rc=$?
  echo "$v preflight.sh: ratchet_leg rc=$rc [$(printf '%s\n' "$out" | grep -i passed | tail -1)]"
done
cp $S/ratchet.orig $P
echo "restored: $(git -C $W status --porcelain -- $P | wc -l | tr -d ' ') dirty"
