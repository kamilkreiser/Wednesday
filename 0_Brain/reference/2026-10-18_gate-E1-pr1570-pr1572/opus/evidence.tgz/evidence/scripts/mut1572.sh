#!/bin/bash
# Gate E1 opus: mutants of #1572's three platform.ts sites (+ comment-only control), each run against the new test; restored after each.
S=/private/tmp/claude-501/e1-opus; W=$S/wt-1572/Blockchain/Dev; G=$W/services/api-gateway; F=$G/src/routes/platform.ts
NT=src/__tests__/ks1545-platform-audit-log-logs-the-dropped-platform-half.test.ts
VT=$W/node_modules/.bin/vitest
OUT=$S/mut1572-$(date +%H%M%S); mkdir -p $OUT; cp $F $OUT/platform.orig
declare -a ID EX DESC
add() { ID+=("$1"); DESC+=("$2"); EX+=("$3"); }
add S1a 'site1: windowsRead starts at 1' 's/let windowsRead = 0;/let windowsRead = 1;/'
add S1b 'site1: const windowsRead (the increment throws inside try)' 's/let windowsRead = 0;/const windowsRead = 0 as number;/'
add S1c 'site1: windowsRead declared in the try (catch sees an outer 0)' 's/let windowsRead = 0;\n      try \{/const windowsRead = 0;\n      try {\n        let windowsRead = 0; void windowsRead;/'
add S2a 'site2: increment removed' 's/\n          windowsRead \+= 1;//'
add S2b 'site2: increment before the not-a-list check' 's/(\n          const data = await r.json\(\) as \{ entries\?: any\[\]; total\?: number \};)/$1\n          windowsRead += 1;/; s/(collected.push\(...rowsInWindow\);)\n          windowsRead \+= 1;/$1/'
add S2c 'site2: increment twice' 's/windowsRead \+= 1;/windowsRead += 2;/'
add S3a 'site3: warn removed' 's/\n        logger.warn\(.GET \/api\/platform\/audit-log dropped the platform half.*\n/\n/'
add S3b 'site3: logs the raw err object' 's/\{ error: err instanceof Error \? err.message : .*?, windowsRead \}\);/{ error: err, windowsRead });/'
add S3c 'site3: windowsRead dropped from meta' 's/: .thrown . \+ typeof err, windowsRead \}\);/: "thrown " + typeof err });/'
add S3d 'site3: logger.error not warn' 's/logger.warn\(.GET \/api\/platform\/audit-log dropped/logger.error("GET \/api\/platform\/audit-log dropped/; s/(logger.error\("GET \/api\/platform\/audit-log dropped)[^,]*,/$1 the platform half",/'
add S3e 'site3: context does not name the route' "s/'GET \\/api\\/platform\\/audit-log dropped the platform half'/'dropped the platform half'/"
add S3f 'site3: also logs err.stack' 's/err instanceof Error \? err.message :/err instanceof Error ? err.message + "\\n" + err.stack :/'
add S3g 'site3: also logs on success (warn moved after the try/catch)' 's/(platformTotal = total \?\? collected.length;)/$1\n        logger.warn("GET \/api\/platform\/audit-log dropped the platform half", { error: "none", windowsRead });/'
add SC0 'CONTROL comment-only line at site 3' 's/(        \/\/ KS-1545: log the dropped platform half)/        \/\/ gate-e1 comment-only control\n$1/'
for i in "${!ID[@]}"; do
  id=${ID[$i]}; cp $OUT/platform.orig $F; perl -0pi -e "${EX[$i]}" $F
  if cmp -s $F $OUT/platform.orig; then echo "$id DID NOT LAND (${DESC[$i]})"; continue; fi
  diff $OUT/platform.orig $F > $OUT/$id.diff
  ( $VT run --root $G $NT > $OUT/$id.txt 2>&1 ); rc=$?
  sum=$(grep -E '^ +Tests ' $OUT/$id.txt | tr -s ' ')
  failed=$(grep -E '^ +(×|✗) ' $OUT/$id.txt | sed -E 's/.*(W[0-9]|control).*/\1/' | sort -u | tr '\n' ',')
  echo "$id (${DESC[$i]}): rc=$rc$sum failed={$failed} diff=$(grep -c '^[<>]' $OUT/$id.diff)"
done
cp $OUT/platform.orig $F
echo "restored: $(git -C $S/wt-1572 status --porcelain --untracked-files=no | wc -l | tr -d ' ') tracked dirty"
