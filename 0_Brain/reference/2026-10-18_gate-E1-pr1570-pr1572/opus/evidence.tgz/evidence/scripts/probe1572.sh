#!/bin/bash
# run the gate probe under develop's and the PR's platform.ts; record reply, SQL and log calls per upstream mode
S=/private/tmp/claude-501/e1-opus; R=$S/repo; W=$S/wt-1572/Blockchain/Dev; G=$W/services/api-gateway; F=$G/src/routes/platform.ts
VT=$W/node_modules/.bin/vitest; OUT=$S/probe1572-$(date +%H%M%S); mkdir -p $OUT
cp $F $OUT/platform.orig; cp $S/probe/gatee1-probe.test.ts $G/src/__tests__/gatee1-probe.test.ts
for v in origin/develop pr1572; do
  git -C $R show $v:Blockchain/Dev/services/api-gateway/src/routes/platform.ts > $F
  t=$(echo $v | tr / _)
  ( GATE_E1_PROBE_OUT=$OUT/$t.json $VT run --root $G src/__tests__/gatee1-probe.test.ts > $OUT/$t.txt 2>&1 ); echo "$v probe rc=$?"
done
cp $OUT/platform.orig $F; mv $G/src/__tests__/gatee1-probe.test.ts $OUT/probe.test.ts.moved
echo "restored: $(git -C $S/wt-1572 status --porcelain | grep -v node_modules | grep -v dist | wc -l | tr -d ' ') dirty/untracked"
node -e '
const a=require(process.argv[1]), b=require(process.argv[2]);
for (const m of Object.keys(a)) {
  const x=a[m], y=b[m];
  const same=(k)=>JSON.stringify(x[k])===JSON.stringify(y[k]);
  console.log(m.padEnd(20), "status", x.status, y.status, "| body", same("body")?"SAME":"DIFF", "| sql", same("sqls")?"SAME":"DIFF", "| upstreamCalls", x.upstreamCalls, y.upstreamCalls, "| entries", (y.body.entries||[]).map(e=>e.id).join(","));
  console.log("   dev logs:", JSON.stringify(x.logs)); console.log("   pr  logs:", JSON.stringify(y.logs));
}' $OUT/origin_develop.json $OUT/pr1572.json
grep -c 'CALLER-TOKEN-SECRET\|ROW-SECRET' $OUT/pr1572.json | sed 's/^/secret-marker lines anywhere in PR record (bodies+logs): /'
node -e 'const b=require(process.argv[1]); let n=0; for (const m of Object.keys(b)) { const s=JSON.stringify(b[m].logs); if (/CALLER-TOKEN-SECRET|ROW-SECRET|P-0/.test(s)) { n++; console.log("LEAK in logs:", m); } } console.log("modes whose LOGS carry the caller token, a row secret or a row id:", n)' $OUT/pr1572.json
