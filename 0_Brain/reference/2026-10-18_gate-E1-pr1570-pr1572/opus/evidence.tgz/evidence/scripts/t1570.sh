#!/bin/bash
# Gate E1 opus: #1570 red-first / green / sibling suites before+after
S=/private/tmp/claude-501/e1-opus
R=$S/repo; WP=$S/wt-1570; WD=$S/wt-dev
P=Blockchain/Dev/scripts/preflight/preflight.sh
T=Blockchain/Dev/scripts/__tests__/ks1547_preflight_step_header_denominator.test.sh
OUT=$S/out1570; mkdir -p $OUT
echo "bash: $(/bin/bash --version | head -1)"
echo "PR head: $(git -C $WP rev-parse HEAD)  develop: $(git -C $WD rev-parse HEAD)"
echo "=== RED-FIRST: PR test vs develop preflight.sh (in a copy of the dev tree)"
RF=$S/redfirst1570-$(date +%H%M%S); mkdir -p $RF/scripts/preflight $RF/scripts/__tests__
git -C $R show origin/develop:$P > $RF/scripts/preflight/preflight.sh
git -C $R show pr1570:$T > $RF/scripts/__tests__/t.test.sh
/bin/bash $RF/scripts/__tests__/t.test.sh > $OUT/redfirst.txt 2>&1; echo "rc=$?"; grep -E '^(FAIL|ok)' $OUT/redfirst.txt | sed 's/^/  /'; tail -1 $OUT/redfirst.txt
echo "=== GREEN: PR test at PR head"
/bin/bash $WP/$T > $OUT/green.txt 2>&1; echo "rc=$?"; tail -1 $OUT/green.txt
echo "=== file identity: pr vs develop vs base"
for f in $P $T; do a=$(git -C $R show pr1570:$f | shasum -a 256 | cut -c1-16); b=$(git -C $R show origin/develop:$f | shasum -a 256 | cut -c1-16); c=$(git -C $R show 1197ab38a:$f | shasum -a 256 | cut -c1-16); echo "$f pr=$a develop=$b base=$c"; done
echo "=== every preflight-related suite, BEFORE (develop) and AFTER (PR head)"
for t in $(ls $WD/Blockchain/Dev/scripts/__tests__/ | grep -i -E 'preflight|ks1547'); do
  b=$(/bin/bash $WD/Blockchain/Dev/scripts/__tests__/$t 2>&1); brc=$?
  a=$(/bin/bash $WP/Blockchain/Dev/scripts/__tests__/$t 2>&1); arc=$?
  echo "$t  before rc=$brc [$(printf '%s\n' "$b" | grep -i -E 'passed' | tail -1)]  after rc=$arc [$(printf '%s\n' "$a" | grep -i -E 'passed' | tail -1)]"
done
echo "=== bash -n / mode"
/bin/bash -n $WP/$P; echo "bash -n preflight rc=$?"; /bin/bash -n $WP/$T; echo "bash -n test rc=$?"
git -C $R ls-tree pr1570 $P $T
git -C $R ls-tree origin/develop $P $T
