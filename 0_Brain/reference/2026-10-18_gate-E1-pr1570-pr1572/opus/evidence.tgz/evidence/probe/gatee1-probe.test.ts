/** Gate E1 (opus) probe — NOT part of the PR. Records the full HTTP reply, every SQL issued and every logger call per upstream mode. */
import { describe, it, beforeAll, afterAll, vi } from 'vitest';
import express, { type RequestHandler } from 'express';
import http from 'http';
import fs from 'fs';
import type { AddressInfo } from 'net';
import { createPlatformRoutes } from '../routes/platform';
import { logger } from '../utils/logger';

vi.hoisted(() => { process.env.PLATFORM_UPSTREAM_TIMEOUT_MS = '400'; });
const OUT = process.env.GATE_E1_PROBE_OUT as string;
type Mode = 'ok' | 'destroy' | 'second-not-a-list' | 'slow' | 'http500-json' | 'http401-json-first' | 'nonjson-short' | 'nonjson-long' | 'null-json' | 'first-not-a-list';
let mode: Mode = 'ok';
let calls = 0;
const T0 = Date.UTC(2026, 0, 1);
const PLATFORM = Array.from({ length: 3 }, (_, i) => ({ id: `P-${i}`, action: 'tenant_created', created_at: new Date(T0 - (10 + i) * 1000).toISOString(), secret: 'ROW-SECRET-' + i }));
const sqls: string[] = [];
const logs: unknown[] = [];
let upstream: http.Server; let gateway: http.Server; let base = '';
const spies = (['warn', 'error', 'info', 'debug'] as const).map((lvl) => vi.spyOn(logger, lvl).mockImplementation(((...a: unknown[]) => { logs.push([lvl, ...a]); return logger; }) as never));

beforeAll(async () => {
  upstream = http.createServer(async (req, res) => {
    calls += 1;
    const seenAuth = req.headers.authorization;
    void seenAuth;
    if (mode === 'destroy') { req.socket.destroy(); return; }
    if (mode === 'slow') await new Promise((r) => setTimeout(r, 700));
    if (mode === 'http500-json') { res.writeHead(500, { 'Content-Type': 'application/json' }).end(JSON.stringify({ success: false, error: 'db down' })); return; }
    if (mode === 'http401-json-first') { res.writeHead(401, { 'Content-Type': 'application/json' }).end(JSON.stringify({ success: false, error: 'No token provided' })); return; }
    if (mode === 'nonjson-short') { res.writeHead(502).end('tok=SECRETabc'); return; }
    if (mode === 'nonjson-long') { res.writeHead(502).end('Bearer eyJSECRETSECRETSECRET.payload.sig and more body text '.repeat(20)); return; }
    if (mode === 'null-json') { res.writeHead(200, { 'Content-Type': 'application/json' }).end('null'); return; }
    if (mode === 'first-not-a-list') { res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ success: true })); return; }
    if (mode === 'second-not-a-list' && calls === 2) { res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ success: true })); return; }
    const url = new URL(req.url ?? '/', 'http://x');
    const limit = Number(url.searchParams.get('limit')) || 50; const offset = Number(url.searchParams.get('offset')) || 0;
    const rowsOut = mode === 'second-not-a-list' ? PLATFORM.slice(offset, offset + 1) : PLATFORM.slice(offset, offset + limit);
    res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ success: true, entries: rowsOut, total: PLATFORM.length }));
  });
  await new Promise<void>((r) => upstream.listen(0, '127.0.0.1', () => r()));
  const superAdmin = (() => ((req, _res, next) => { (req as unknown as { user: object }).user = { userId: 'u', email: 'a@b.c', role: 'super_admin', verificationLevel: 'none' }; next(); }) as RequestHandler) as (required?: boolean) => RequestHandler;
  const app = express();
  app.use(createPlatformRoutes({
    authenticateToken: superAdmin,
    tenantProvisioningUrl: 'http://127.0.0.1:' + (upstream.address() as AddressInfo).port,
    setTenantKey: () => {}, getTenantKey: () => undefined, removeTenantKey: () => {},
    query: async (sql: string) => {
      sqls.push(sql.replace(/\s+/g, ' ').trim());
      if (/COUNT\(\*\)/.test(sql)) return { rows: [{ total: 2 }] };
      return { rows: ['A-0', 'A-1'].map((id, i) => ({ id, user_id: null, action: 'doc_verified', resource_type: null, resource_id: null, details: null, ip_address: null, success: true, created_at: new Date(T0 - i * 1000) })) };
    },
  }));
  gateway = http.createServer(app);
  await new Promise<void>((r) => gateway.listen(0, '127.0.0.1', () => r()));
  base = 'http://127.0.0.1:' + (gateway.address() as AddressInfo).port;
});
afterAll(async () => {
  upstream.closeAllConnections();
  await new Promise<void>((r) => gateway.close(() => r()));
  await new Promise<void>((r) => upstream.close(() => r()));
  spies.forEach((s) => s.mockRestore());
});

describe('gate E1 probe', () => {
  it('records every mode', { timeout: 30_000 }, async () => {
    const result: Record<string, unknown> = {};
    for (const m of ['ok', 'destroy', 'second-not-a-list', 'slow', 'http500-json', 'http401-json-first', 'nonjson-short', 'nonjson-long', 'null-json', 'first-not-a-list'] as Mode[]) {
      mode = m; calls = 0; sqls.length = 0; logs.length = 0;
      const r = await fetch(`${base}/api/platform/audit-log?limit=50&offset=0`, { headers: { Authorization: 'Bearer CALLER-TOKEN-SECRET' } });
      const text = await r.text();
      result[m] = { status: r.status, headers: { 'content-type': r.headers.get('content-type') }, body: JSON.parse(text), sqls: [...sqls], logs: JSON.parse(JSON.stringify(logs)), upstreamCalls: calls };
    }
    fs.writeFileSync(OUT, JSON.stringify(result, null, 2));
  });
});
