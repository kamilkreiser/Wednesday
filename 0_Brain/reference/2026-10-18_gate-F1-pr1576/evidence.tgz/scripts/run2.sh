#!/bin/bash
G=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/db9b2375-e430-4d46-b18c-db37397c2500/scratchpad
for role in super app; do
  for w in head base833; do
    echo "== probe $w $role"; /bin/bash $G/scripts/itest.sh $w probe_${w}_$role $role gatef1-probe
  done
done
echo "== dev ks1557 app (control: is the KS-1557 x-tenant failure pre-existing on develop?)"; /bin/bash $G/scripts/itest.sh dev dev_1557_app app ks1557
echo "== head ks1557 super"; /bin/bash $G/scripts/itest.sh head head_1557_super super ks1557
echo "== head ks1557 app rerun"; /bin/bash $G/scripts/itest.sh head head_1557_app2 app ks1557
