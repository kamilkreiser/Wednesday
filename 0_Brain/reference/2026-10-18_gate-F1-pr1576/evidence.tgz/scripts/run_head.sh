#!/bin/bash
G=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/db9b2375-e430-4d46-b18c-db37397c2500/scratchpad
for role in super app; do
  echo "== head ks1114 $role"; /bin/bash $G/scripts/itest.sh head head_ks1114_$role $role ks1114-anonymous-title-lookup-one-tenant
done
echo "== head ks1119+ks1557 app"; /bin/bash $G/scripts/itest.sh head head_1119_1557_app app 'ks1119|ks1557'
for role in super app; do
  for w in head base833; do
    echo "== probe $w $role"; /bin/bash $G/scripts/itest.sh $w probe_${w}_$role $role gatef1-probe
  done
done
