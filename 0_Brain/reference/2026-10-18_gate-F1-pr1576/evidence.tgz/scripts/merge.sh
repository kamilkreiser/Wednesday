#!/bin/bash
# merge prediction on live develop 1f73d7ac, all orders of #1573-#1576, overlap check, planted conflict control
set -u
G=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/db9b2375-e430-4d46-b18c-db37397c2500/scratchpad
R=$G/repo
DEV=1f73d7ac8cc17add318601c6c572bcace3d5a596
export GIT_AUTHOR_NAME=gate GIT_AUTHOR_EMAIL=gate@invalid GIT_COMMITTER_NAME=gate GIT_COMMITTER_EMAIL=gate@invalid
export GIT_AUTHOR_DATE='2026-10-18T00:00:00Z' GIT_COMMITTER_DATE='2026-10-18T00:00:00Z'
echo "develop live: $(git -C $R ls-remote origin refs/heads/develop)"
declare -A H=( [1573]=pr/1573 [1574]=pr/1574 [1575]=pr/1575 [1576]=pr/1576 )
echo "== files per PR (vs merge-base with develop)"
for p in 1573 1574 1575 1576; do
  mb=$(git -C $R merge-base $DEV ${H[$p]})
  echo "#$p head $(git -C $R rev-parse ${H[$p]}) base $mb"
  git -C $R diff --name-only $mb ${H[$p]} | sed 's/^/   /' | tee $G/ev/files_$p.txt
done
echo "== overlap (files touched by more than one PR)"
cat $G/ev/files_15*.txt | sort | uniq -d
echo "== #1576 alone onto develop (merge-tree)"
git -C $R merge-tree --write-tree $DEV pr/1576; echo "rc=$?"
echo "== all orders of the four, tree after each sequence"
python3 -I - <<'PY' > $G/ev/orders.txt
import itertools
for o in itertools.permutations(['1573','1574','1575','1576']): print(' '.join(o))
PY
while read -r a b c d; do
  t=$DEV; ok=1
  for p in $a $b $c $d; do
    out=$(git -C $R merge-tree --write-tree --merge-base=$(git -C $R merge-base $t ${H[$p]} 2>/dev/null || echo $DEV) $t ${H[$p]} 2>&1); rc=$?
    tree=$(echo "$out" | head -1)
    if [ $rc -ne 0 ]; then ok=0; echo "$a $b $c $d CONFLICT at $p"; break; fi
    # commit the tree so the next step has a commit to merge from
    t=$(git -C $R commit-tree $tree -p $t -p ${H[$p]} -m "gate merge $p")
  done
  [ $ok = 1 ] && echo "$a $b $c $d -> tree $(git -C $R rev-parse $t^{tree})"
done < $G/ev/orders.txt | tee $G/ev/order_trees.txt | sort -k6 | awk '{print $NF}' | sort | uniq -c
echo "== planted conflicting control: a develop-side commit that rewrites the same product line"
P=$G/planted; [ -d $P ] || git -C $R worktree add -q --detach $P $DEV
F=$P/Blockchain/Dev/services/originate/src/routes/verification.ts
python3 -I - "$F" <<'PY'
import sys
p=sys.argv[1]; s=open(p).read()
old="AND d.status NOT IN ('draft', 'revoked')"
assert s.count(old)==1
open(p,'w').write(s.replace(old,"AND d.status NOT IN ('draft', 'revoked', 'planted')"))
PY
git -C $P commit -q -am "planted conflicting control"
PC=$(git -C $P rev-parse HEAD)
git -C $R merge-tree --write-tree $PC pr/1576 > $G/ev/planted.txt 2>&1; echo "planted rc=$? (expect 1)"; sed -n 1,8p $G/ev/planted.txt
