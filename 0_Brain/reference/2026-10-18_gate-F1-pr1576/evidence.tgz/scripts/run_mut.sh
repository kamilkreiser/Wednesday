#!/bin/bash
G=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/db9b2375-e430-4d46-b18c-db37397c2500/scratchpad
for m in none M0_revert_to_develop M1_drop_expired M1b_drop_deleted M1c_drop_draft M2_drop_lower M3_drop_btrim M4_comment_only M5_equiv_btrim_of_lower; do
  echo "################ $m"
  python3 -I $G/scripts/mutate.py $m
  git -C $G/mut diff --stat | tail -1
  echo "-- unit"; /bin/bash $G/scripts/unit.sh mut unit_$m ks1114-title-lookup-hidden-statuses
  echo "-- T11 integration (super)"; /bin/bash $G/scripts/itest.sh mut int_$m super ks1114-anonymous-title-lookup-one-tenant
done
python3 -I $G/scripts/mutate.py none
git -C $G/mut status --porcelain | grep -v node_modules
