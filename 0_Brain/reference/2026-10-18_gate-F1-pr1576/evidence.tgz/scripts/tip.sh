#!/bin/bash
set -u
G=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/db9b2375-e430-4d46-b18c-db37397c2500/scratchpad
R=$G/repo
DEV=1f73d7ac8cc17add318601c6c572bcace3d5a596
export GIT_AUTHOR_NAME=gate GIT_AUTHOR_EMAIL=gate@invalid GIT_COMMITTER_NAME=gate GIT_COMMITTER_EMAIL=gate@invalid
echo "develop-side files since the PR base:"; git -C $R diff --name-only 9251ae54d $DEV
T=$(git -C $R merge-tree --write-tree $DEV pr/1576)
C=$(git -C $R commit-tree $T -p $DEV -p pr/1576 -m "gate: develop + #1576")
echo "tipgreen commit $C tree $T"
/bin/bash $G/scripts/deps.sh tipgreen $C | tail -1
/bin/bash $G/scripts/deps.sh tipred $C | tail -1
F=Blockchain/Dev/services/originate/src/routes/verification.ts
git -C $G/tipred show $DEV:$F > $G/tipred/$F
echo "tipred diff vs tipgreen (product file reverted to live develop, tests kept):"; git -C $G/tipred diff --stat
git -C $G/tipred diff | grep '^[-+] '
for w in tipred tipgreen; do
  echo "== $w unit"; /bin/bash $G/scripts/unit.sh $w unit_$w ks1114-title-lookup-hidden-statuses
  for role in super app; do echo "== $w T11 $role"; /bin/bash $G/scripts/itest.sh $w int_${w}_$role $role ks1114-anonymous-title-lookup-one-tenant; done
done
