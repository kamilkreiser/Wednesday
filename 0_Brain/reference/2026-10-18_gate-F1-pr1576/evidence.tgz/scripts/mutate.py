import sys
G = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/db9b2375-e430-4d46-b18c-db37397c2500/scratchpad'
REL = '/Blockchain/Dev/services/originate/src/routes/verification.ts'
src = open(G + '/head' + REL).read()
LINE = "AND lower(btrim(d.status)) NOT IN ('draft', 'revoked', 'deleted', 'expired')"
assert src.count(LINE) == 1, 'product line not unique'
M = {
  'none': None,
  'M0_revert_to_develop': "AND d.status NOT IN ('draft', 'revoked')",
  'M1_drop_expired': "AND lower(btrim(d.status)) NOT IN ('draft', 'revoked', 'deleted')",
  'M1b_drop_deleted': "AND lower(btrim(d.status)) NOT IN ('draft', 'revoked', 'expired')",
  'M1c_drop_draft': "AND lower(btrim(d.status)) NOT IN ('revoked', 'deleted', 'expired')",
  'M2_drop_lower': "AND btrim(d.status) NOT IN ('draft', 'revoked', 'deleted', 'expired')",
  'M3_drop_btrim': "AND lower(d.status) NOT IN ('draft', 'revoked', 'deleted', 'expired')",
  'M5_equiv_btrim_of_lower': "AND btrim(lower(d.status)) NOT IN ('draft', 'revoked', 'deleted', 'expired')",
}
m = sys.argv[1]
if m == 'M4_comment_only':
    old = '//     follow-up: the status is lower-cased and trimmed before it is compared). Every other status can be a hit.'
    assert src.count(old) == 1
    out = src.replace(old, '//     follow-up: GATE F1 COMMENT-ONLY CONTROL MUTANT, no code change). Every other status can be a hit.')
elif M[m] is None:
    out = src
else:
    out = src.replace(LINE, M[m])
open(G + '/mut' + REL, 'w').write(out)
print('applied', m, 'changed' if out != src else 'identical')
