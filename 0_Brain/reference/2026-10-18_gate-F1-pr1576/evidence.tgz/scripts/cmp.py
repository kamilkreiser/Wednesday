import json, sys
G = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/db9b2375-e430-4d46-b18c-db37397c2500/scratchpad/ev/'
HIT = '200 {"verified":false,"checks":{"documentExists":true}}'
names = sys.argv[1:]
recs = {n: json.load(open(G + 'probe_' + n + '.json')) for n in names}
labels = list(recs[names[0]].keys())
absent = recs[names[0]]['absent']
def short(v):
    if v == HIT: return 'HIT'
    if v == absent: return 'MISS(=absent)'
    return 'OTHER:' + v[:120]
print('label'.ljust(48), *[n.ljust(22) for n in names])
for l in labels:
    vals = [short(recs[n].get(l, 'MISSING')) for n in names]
    flag = '' if len(set(vals)) == 1 else '   <-- differs'
    print(l[:48].ljust(48), *[v.ljust(22) for v in vals], flag)
for n in names:
    print(n, 'absent==absent@B:', recs[n]['absent'] == recs[n]['absent@B'], '| absent body:', recs[n]['absent'])
