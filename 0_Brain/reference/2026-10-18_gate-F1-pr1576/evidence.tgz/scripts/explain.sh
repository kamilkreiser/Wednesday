#!/bin/bash
set -u
B=/opt/homebrew/opt/postgresql@15/bin
Q="$B/psql -h 127.0.0.1 -p 56152 -U secuura -d secuura -v ON_ERROR_STOP=1 -q"
T=a0000000-0000-4000-8000-000000000001
TB=b1140000-0000-4000-8000-000000001114
$Q <<EOSQL
\pset pager off
-- seed 200k rows across two tenants with a status mix (gate's own DB only); removed at the end
CREATE TEMP TABLE _gate_ids AS SELECT gen_random_uuid() id, g FROM generate_series(1,200000) g;
INSERT INTO documents (id, tenant_id, external_id, title, document_type, content_hash, status, metadata, certification_metadata)
SELECT id, CASE WHEN g % 4 = 0 THEN '$TB'::uuid ELSE '$T'::uuid END, 'gatef1-seed-'||g, 'gatef1 seed title '||(g % 50000), 'DOCUMENT', md5(g::text)||md5(g::text),
  (ARRAY['certified','signed','draft','revoked','anchored','deleted','Expired',' Draft '])[1 + g % 8], '{}'::jsonb, '{}'::jsonb
FROM _gate_ids;
ANALYZE documents;
\echo ===== BEFORE predicate (develop / 833984fc9), superuser
EXPLAIN (ANALYZE, COSTS, BUFFERS OFF, TIMING OFF) SELECT 1 AS found FROM documents d WHERE d.title = 'gatef1 seed title 1234' AND d.title <> '[erased]' AND d.tenant_id::text = '$T' AND d.status NOT IN ('draft', 'revoked') LIMIT 1;
\echo ===== AFTER predicate (head), superuser
EXPLAIN (ANALYZE, COSTS, BUFFERS OFF, TIMING OFF) SELECT 1 AS found FROM documents d WHERE d.title = 'gatef1 seed title 1234' AND d.title <> '[erased]' AND d.tenant_id::text = '$T' AND lower(btrim(d.status)) NOT IN ('draft', 'revoked', 'deleted', 'expired') LIMIT 1;
\echo ===== BEFORE, miss title, superuser
EXPLAIN (ANALYZE, COSTS, BUFFERS OFF, TIMING OFF) SELECT 1 AS found FROM documents d WHERE d.title = 'no such' AND d.title <> '[erased]' AND d.tenant_id::text = '$T' AND d.status NOT IN ('draft', 'revoked') LIMIT 1;
\echo ===== AFTER, miss title, superuser
EXPLAIN (ANALYZE, COSTS, BUFFERS OFF, TIMING OFF) SELECT 1 AS found FROM documents d WHERE d.title = 'no such' AND d.title <> '[erased]' AND d.tenant_id::text = '$T' AND lower(btrim(d.status)) NOT IN ('draft', 'revoked', 'deleted', 'expired') LIMIT 1;
SET ROLE secuura_app;
SELECT set_config('app.current_tenant_id', '$T', false);
\echo ===== BEFORE, secuura_app under RLS
EXPLAIN (ANALYZE, COSTS, BUFFERS OFF, TIMING OFF) SELECT 1 AS found FROM documents d WHERE d.title = 'no such' AND d.title <> '[erased]' AND d.tenant_id::text = '$T' AND d.status NOT IN ('draft', 'revoked') LIMIT 1;
\echo ===== AFTER, secuura_app under RLS
EXPLAIN (ANALYZE, COSTS, BUFFERS OFF, TIMING OFF) SELECT 1 AS found FROM documents d WHERE d.title = 'no such' AND d.title <> '[erased]' AND d.tenant_id::text = '$T' AND lower(btrim(d.status)) NOT IN ('draft', 'revoked', 'deleted', 'expired') LIMIT 1;
RESET ROLE;
\echo ===== SQL-level NULL semantics (literal, no table)
SELECT (NULL::varchar NOT IN ('draft','revoked')) IS NULL AS before_is_null, (lower(btrim(NULL::varchar)) NOT IN ('draft','revoked','deleted','expired')) IS NULL AS after_is_null;
\echo ===== btrim default trims only spaces
SELECT quote_literal(btrim(E'\tdeleted')) tab, quote_literal(btrim(E'revoked\n')) nl, quote_literal(btrim(' x ')) sp, quote_literal(btrim(U&'deleted\00A0')) nbsp;
\echo ===== NOT NULL write is refused
DO \$\$ BEGIN
  BEGIN
    INSERT INTO documents (tenant_id, title, document_type, content_hash, status) VALUES ('$T', 'gatef1 null', 'DOCUMENT', 'x', NULL);
    RAISE NOTICE 'NULL insert ACCEPTED';
  EXCEPTION WHEN not_null_violation THEN RAISE NOTICE 'NULL insert refused: not_null_violation';
  END;
END \$\$;
DELETE FROM documents WHERE id IN (SELECT id FROM _gate_ids);
SELECT count(*) AS seed_rows_left FROM documents WHERE external_id LIKE 'gatef1-seed-%';
EOSQL
