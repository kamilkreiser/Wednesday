#!/bin/bash
# usage: wt.sh name ref
set -e
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/db9b2375-e430-4d46-b18c-db37397c2500/scratchpad
git -C $S/repo worktree add -q --detach $S/$1 $2
git -C $S/$1 rev-parse HEAD
