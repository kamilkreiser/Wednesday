#!/bin/bash
# usage: itest.sh <wt> <outname> <role:super|app> [jest args...]
set -u
G=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/db9b2375-e430-4d46-b18c-db37397c2500/scratchpad
PORT=56152
W=$G/$1; O="$2"; ROLE="$3"; shift 3
O_DIR=$W/Blockchain/Dev/services/originate
export TEST_DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:$PORT/secuura"
if [ "$ROLE" = app ]; then export TEST_APP_DATABASE_URL="postgresql://secuura_app:app@127.0.0.1:$PORT/secuura"; else unset TEST_APP_DATABASE_URL; fi
export DATABASE_URL="$TEST_DATABASE_URL"
export TEST_SUPER_PLATFORM_DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:$PORT/secuura_platform"
if [ "$ROLE" = app ]; then export TEST_PLATFORM_DATABASE_URL="postgresql://secuura_app:app@127.0.0.1:$PORT/secuura_platform"; else export TEST_PLATFORM_DATABASE_URL="$TEST_SUPER_PLATFORM_DATABASE_URL"; fi
export MULTI_TENANCY_ENABLED="${MT:-true}"
export PROBE_OUT=$G/ev/probe_$O.json
J=$W/Blockchain/Dev/node_modules/.bin/jest
$J --rootDir $O_DIR --config $O_DIR/jest.integration.config.js --runInBand --forceExit --json --outputFile=$G/ev/$O.json "$@" > $G/ev/$O.log 2>&1
rc=$?
python3 -I - "$G/ev/$O.json" <<'PY'
import json,sys
try: d=json.load(open(sys.argv[1]))
except Exception as e: print("no json",e); sys.exit()
print("suites",d.get("numTotalTestSuites"),"tests",d["numTotalTests"],"passed",d["numPassedTests"],"failed",d["numFailedTests"],"failedSuites",d.get("numFailedTestSuites"))
for f in d["testResults"]:
    for a in f["assertionResults"]:
        if a["status"]!="passed":
            print("  FAIL", a["fullName"][:150], "|", " ".join((a.get("failureMessages") or [""])[0].splitlines()[:40])[:1500])
    if f.get("status")=="failed" and not f["assertionResults"]:
        print("  SUITE-FAIL", f["name"], f.get("message","")[:600])
PY
echo "rc=$rc"
