#!/bin/bash
set -e
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/db9b2375-e430-4d46-b18c-db37397c2500/scratchpad
W=$S/repo
P="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files"
[ -d $W/.git ] || git clone -q --shared "$P" $W
git -C $W config core.sshCommand "$(git -C "$P" config core.sshCommand)"
git -C $W remote set-url origin git@github.com:Secuura/Distributed_Secuura.git
git -C $W fetch -q origin '+refs/heads/develop:refs/remotes/origin/develop' '+refs/pull/1576/head:refs/remotes/pr/1576' '+refs/pull/1573/head:refs/remotes/pr/1573' '+refs/pull/1574/head:refs/remotes/pr/1574' '+refs/pull/1575/head:refs/remotes/pr/1575'
git -C $W ls-remote origin refs/heads/develop refs/pull/1576/head refs/pull/1573/head refs/pull/1574/head refs/pull/1575/head
git -C $W rev-parse origin/develop pr/1576 pr/1573 pr/1574 pr/1575
