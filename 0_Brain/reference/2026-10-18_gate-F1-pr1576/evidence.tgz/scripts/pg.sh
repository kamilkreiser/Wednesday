#!/bin/bash
# usage: pg.sh <port> <schema-worktree-name>   PG 15, own cluster, trust auth on 127.0.0.1
set -u
G=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/db9b2375-e430-4d46-b18c-db37397c2500/scratchpad
PORT="$1"; W="$G/$2"
B=/opt/homebrew/opt/postgresql@15/bin
D=$G/pgdata-$PORT
L=$G/ev/pg_setup.log
if lsof -nP -iTCP:$PORT -sTCP:LISTEN >/dev/null 2>&1; then echo "PORT $PORT BUSY"; exit 2; fi
$B/initdb -D $D -U postgres --auth=trust >$L 2>&1 || { echo initdb failed; exit 1; }
$B/pg_ctl -D $D -o "-p $PORT -c unix_socket_directories='' -c listen_addresses=127.0.0.1" -l $G/ev/pg_server.log -w start >>$L 2>&1
P="$B/psql -h 127.0.0.1 -p $PORT -v ON_ERROR_STOP=0 -q"
$P -U postgres -d postgres -c "CREATE ROLE secuura SUPERUSER LOGIN PASSWORD 'secuura'" >>$L 2>&1
$P -U postgres -d postgres -c "CREATE DATABASE secuura OWNER secuura" >>$L 2>&1
$P -U postgres -d postgres -c "CREATE ROLE secuura_app LOGIN PASSWORD 'app' NOSUPERUSER NOBYPASSRLS" >>$L 2>&1
DEV=$W/Blockchain/Dev
for f in $DEV/docker/init/0*.sql; do
  case "$(basename $f)" in 00-create-platform-db.sql) continue;; esac
  echo "== $f" >>$L
  $P -U secuura -d secuura -f $f >>$L 2>&1
done
n=0
for f in $DEV/migrations/*.sql; do
  n=$((n+1)); echo "== $f" >>$L
  $P -U secuura -d secuura -f $f >>$L 2>&1
done
echo "migrations applied: $n"
$P -U secuura -d secuura >>$L 2>&1 <<'EOSQL'
GRANT CONNECT ON DATABASE secuura TO secuura_app;
GRANT USAGE ON SCHEMA public TO secuura_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO secuura_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO secuura_app;
EOSQL
L2=$G/ev/pg_platform_setup.log
$P -U postgres -d postgres -c "CREATE DATABASE secuura_platform OWNER secuura" >$L2 2>&1
$P -U secuura -d secuura_platform -f $DEV/docker/init-platform/01-platform-schema.sql >>$L2 2>&1
for f in $(ls $DEV/docker/init-platform/ | grep -v '^01-platform-schema.sql$'); do echo "== $f" >>$L2; case $f in *.sql) $P -U secuura -d secuura_platform -f $DEV/docker/init-platform/$f >>$L2 2>&1;; esac; done
$P -U secuura -d secuura_platform >>$L2 2>&1 <<'EOSQL'
GRANT CONNECT ON DATABASE secuura_platform TO secuura_app;
GRANT USAGE ON SCHEMA public TO secuura_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO secuura_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO secuura_app;
EOSQL
echo "errors in setup log: $(grep -c ERROR $L)  platform: $(grep -c ERROR $L2)"
grep ERROR $L | sort | uniq -c | head -10
Q="$B/psql -h 127.0.0.1 -p $PORT -U secuura -d secuura -tAc"
$Q "select version()"
$Q "select relname, relrowsecurity, relforcerowsecurity from pg_class where relname='documents'"
$Q "select column_name, data_type, character_maximum_length, is_nullable, column_default from information_schema.columns where table_name='documents' and column_name='status'"
$Q "select conname, pg_get_constraintdef(oid) from pg_constraint where conrelid='documents'::regclass and contype='c'"
$Q "select indexname, indexdef from pg_indexes where tablename='documents'"
$Q "select polname, pg_get_expr(polqual, polrelid) from pg_policy where polrelid='documents'::regclass"
