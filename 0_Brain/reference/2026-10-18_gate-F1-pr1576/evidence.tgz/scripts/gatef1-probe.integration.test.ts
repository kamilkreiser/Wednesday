/**
 * =============================================================================
 * KS-1114 — POST /api/verification/verify looks a document up by TITLE, anonymously, in one tenant
 * =============================================================================
 * Kam's ruling on card `secuura-ks1114-title-lookup-needs-authentication-1013` = b, verbatim:
 * "Title lookup open to anyone, one tenant". That was NOT Wednesday's recommendation (she had
 * recommended requiring authentication for the title strategy); it is his ruling, built as given.
 *
 * ROUND 2 — THE REPLY IS EXISTENCE ONLY. Kam, card `secuura-ks1114-title-reply-leaks-details-fix-
 * now-or-wait-1015` = a, its detail verbatim: "#1555 stays held, unmerged. The J seat fixes it after
 * the reset: an existence-only reply, drafts and revoked kept out, then round 2 of its gate." Round 1
 * answered a title hit with the whole by-id body, so a guessed title gave a contentHash and the hash
 * gave `verified:true` (gate F1, 2026-10-15). The hit body is Wednesday's ruling (2026-10-18T08:31:18Z),
 * not Kam's words: exactly HIT_BODY below — `verified` stays because VerifyResponseSchema requires it,
 * `documentExists` sits at the declared `checks` path, and nothing else.
 *
 * Wednesday's rulings INSIDE Kam's (2026-10-13T10:52:44Z), not Kam's own words:
 *   (a) WITHDRAWN by round 2. It ruled "the NEWEST wins, in the documentId strategy's shape"; with no
 *       identity in the reply there is nothing for "newest" to choose, so T4 now pins only existence.
 *   (b) the GDPR erasure sentinel never matches, and its not-found is BYTE-IDENTICAL to a missing
 *       title's — compared body to body, not status to status.
 *   (c) an empty or whitespace-only title is absent (the 400 it always got).
 *
 * ⚠ AN EXISTENCE ORACLE, BY KAM'S RULING. A hash needs the bytes; a title is a guess. Anyone can
 * now ask whether a document of a given title exists in the default tenant. The per-IP limit on
 * this route is the mitigation (the pen-test enumeration finding). Recorded so nobody rediscovers it.
 *
 * HARNESS. KS-1119's: the real verificationRouter on a bare express app, the real
 * `tenantGucContext()` and per-request Prisma, a real Postgres carrying the repo schema. The
 * caller's tenant is resolved by the REAL `resolveRequestTenantId` (utils/requestTenant.ts), so an
 * anonymous request gets the default tenant exactly as production does, and another tenant only
 * when the request is marked gateway-VOUCHED (KS-1032). DB-gated and never silently skipped.
 *
 * BYTE-IDENTITY (cell T9) is a GOLDEN comparison: every non-title body's raw response was
 * recorded on develop d53d80cb's verification.ts (KS1114_RECORD=1) into
 * `fixtures/ks1114-non-title-bodies.develop.json`, and this branch must reproduce it byte for byte
 * with only `verifiedAt` normalised. Fixed ids, hashes, titles and timestamps make that stable.
 * =============================================================================
 */
import { randomUUID, randomBytes } from 'crypto';
import * as fs from 'fs';
import * as path from 'path';
import { Client } from 'pg';

const SUPER_DB = process.env.TEST_DATABASE_URL || process.env.DATABASE_URL;
const APP_DB = process.env.TEST_APP_DATABASE_URL;
const PLATFORM_DB = process.env.TEST_PLATFORM_DATABASE_URL || process.env.PLATFORM_DATABASE_URL;
const SUPER_PLATFORM_DB = process.env.TEST_SUPER_PLATFORM_DATABASE_URL || PLATFORM_DB || SUPER_DB;
if (PLATFORM_DB) process.env.PLATFORM_DATABASE_URL = PLATFORM_DB;
if (SUPER_DB) process.env.DATABASE_URL = APP_DB || SUPER_DB;
process.env.SIMULATE_ANCHORING = 'true';
process.env.ANCHORING_SERVICE_URL = 'http://127.0.0.1:2'; // the chain fallback is refused, so a miss stays a miss
process.env.AUTH_SERVICE_URL = 'http://ks1114-auth.invalid';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'ks1114-integration-secret';
process.env.PII_ENCRYPTION_KEY = randomBytes(32).toString('hex');
process.env.PII_LOOKUP_HMAC_KEY = randomBytes(32).toString('hex');
if (process.env.NODE_ENV === 'production' || !process.env.NODE_ENV) process.env.NODE_ENV = 'test';

jest.mock('@secuura/shared', () =>
  require('./helpers/sharedModuleMock').makeSharedMock({ ...jest.requireActual('@secuura/shared'), verifyMessageSignature: () => true }),
);
jest.mock('../events', () => ({ publishEvent: jest.fn(async () => undefined), EventTypes: new Proxy({}, { get: (_t, k) => String(k) }) }));

const DEFAULT_T = 'a0000000-0000-4000-8000-000000000001';
const T_B = 'b1140000-0000-4000-8000-000000001114';           // a second tenant
const RUN = randomUUID().slice(0, 8);
const ERASED = '[erased]';

/** Fixed rows (fixed ids, hashes, titles, timestamps) so the T9 golden is stable across runs. */
const FIX = {
  hashDoc:  { id: '11140000-0000-4000-8000-0000000000a1', ext: 'ks1114-fix-hash',  title: 'KS-1114 fixture hash doc',  hash: 'a1'.repeat(32) },
  idDoc:    { id: '11140000-0000-4000-8000-0000000000a2', ext: 'ks1114-fix-id',    title: 'KS-1114 fixture id doc',    hash: 'a2'.repeat(32) },
};
const AT = '2026-01-01T00:00:00.000Z';

let sql: Client; let plat: Client; let server: any; let base = ''; let db: any; let disconnect: any;
let createdDefaultTenant = false;
const insertedIds: string[] = [];

async function insertDoc(o: { id?: string; tenant: string; ext: string; title: string; hash: string; createdAt: string; status?: string }) {
  const id = o.id || randomUUID();
  await sql.query(
    `INSERT INTO documents (id, tenant_id, external_id, title, document_type, content_hash, status, created_at, certified_at, metadata, certification_metadata)
     VALUES ($1::uuid, $2::uuid, $3, $4, 'DOCUMENT', $5, $6, $7::timestamptz, $7::timestamptz, '{}'::jsonb, '{}'::jsonb)
     ON CONFLICT (id) DO NOTHING`,
    [id, o.tenant, o.ext, o.title, o.hash, o.status || 'certified', o.createdAt]);
  insertedIds.push(id);
  return id;
}

/** POST /verify. `vouchedTenant` marks the request gateway-vouched with that x-tenant-id. */
async function verify(body: Record<string, unknown>, vouchedTenant?: string): Promise<{ status: number; text: string; json: any }> {
  const headers: Record<string, string> = { 'content-type': 'application/json' };
  if (vouchedTenant) { headers['x-ks1114-vouched'] = '1'; headers['x-tenant-id'] = vouchedTenant; }
  const r = await fetch(`${base}/api/verification/verify`, { method: 'POST', headers, body: JSON.stringify(body) });
  const text = await r.text();
  let json: any; try { json = JSON.parse(text); } catch { json = null; }
  return { status: r.status, text, json };
}
/** The ONLY body a title hit may answer, byte for byte (so no extra key can ride along). */
const HIT_BODY = '{"verified":false,"checks":{"documentExists":true}}';
/** The one not-found body: absent, another tenant's, draft, revoked and the sentinel all answer it. */
const MISS_BODY = '{"verified":false,"error":"Document not found in the registry","checks":{"documentExists":false,"hashValid":false,"integrityVerified":false}}';
/** Every key round 1's title hit leaked, plus every integrity flag. None may appear on a hit. */
const LEAK_KEYS = ['documentId', 'title', 'status', 'contentHash', 'issuer', 'certification', 'lineage', 'newerVersions',
  'warning', 'strategy', 'hashValid', 'integrityVerified', 'isCertified', 'isAnchored', 'isRevoked', 'verifiedAt'];
const normalise = (text: string) => text.replace(/"verifiedAt":"[^"]*"/g, '"verifiedAt":"<ts>"');

beforeAll(async () => {
  if (!SUPER_DB) throw new Error('KS-1114 cells need a database: set TEST_DATABASE_URL (and TEST_APP_DATABASE_URL for the secuura_app run)');
  require('@secuura/shared').initFromEnv();
  sql = new Client({ connectionString: SUPER_DB }); await sql.connect();
  plat = new Client({ connectionString: SUPER_PLATFORM_DB }); await plat.connect();
  const had = await plat.query('SELECT 1 FROM tenants WHERE id = $1', [DEFAULT_T]);
  if (had.rowCount === 0) {
    await plat.query(`INSERT INTO tenants (id, name, slug, status, created_at, updated_at) VALUES ($1, 'default', 'default', 'active', NOW(), NOW())`, [DEFAULT_T]);
    createdDefaultTenant = true;
  }
  await plat.query(`INSERT INTO tenants (id, name, slug, status, created_at, updated_at) VALUES ($1, $2, $2, 'active', NOW(), NOW()) ON CONFLICT (id) DO NOTHING`, [T_B, 'ks1114-b']);

  // The fixed rows behind the T9 golden.
  await insertDoc({ id: FIX.hashDoc.id, tenant: DEFAULT_T, ext: FIX.hashDoc.ext, title: FIX.hashDoc.title, hash: FIX.hashDoc.hash, createdAt: AT });
  await insertDoc({ id: FIX.idDoc.id, tenant: DEFAULT_T, ext: FIX.idDoc.ext, title: FIX.idDoc.title, hash: FIX.idDoc.hash, createdAt: AT });

  db = require('../db'); await db.initDb(); disconnect = db.disconnectDb;
  const express = require('express');
  const { verificationRouter } = require('../routes/verification');
  const { resolveRequestTenantId } = require('../utils/requestTenant');
  const { tenantGucContext } = require('@secuura/shared');
  const app = express();
  // Production's tenant resolution, not a copy: the KS-458 block calls resolveRequestTenantId.
  // A request marked vouched carries the verdict the provenance middleware would have recorded.
  app.use((req: any, _res: unknown, next: () => void) => {
    req.gatewayProvenance = req.headers['x-ks1114-vouched'] ? 'vouched' : 'unconfigured';
    req.tenantId = resolveRequestTenantId(req);
    next();
  });
  app.use(tenantGucContext());
  app.use((req: any, _res: unknown, next: () => void) => { req.db = db.getRequestPrisma(req); next(); });
  app.use('/api/verification', express.json(), verificationRouter);
  await new Promise<void>((r) => { server = app.listen(0, '127.0.0.1', () => r()); });
  base = 'http://127.0.0.1:' + server.address().port;
}, 60000);

afterAll(async () => {
  if (server) await new Promise<void>((r) => server.close(() => r()));
  // By id ONLY. Never `DELETE ... WHERE tenant_id = DEFAULT`: that tenant holds other rows.
  if (sql && insertedIds.length) await sql.query('DELETE FROM documents WHERE id = ANY($1::uuid[])', [insertedIds]).catch(() => undefined);
  if (plat) {
    await plat.query('DELETE FROM tenants WHERE id = $1', [T_B]).catch(() => undefined);
    if (createdDefaultTenant) await plat.query('DELETE FROM tenants WHERE id = $1', [DEFAULT_T]).catch(() => undefined);
  }
  await sql?.end().catch(() => undefined); await plat?.end().catch(() => undefined);
  if (disconnect) await disconnect().catch(() => undefined);
});

// ===================== GATE F1 (#1576) probe cells — recorded, then asserted by the gate's own compare =====================
describe('GATE-F1 probe', () => {
  const rec: Record<string, string> = {};
  const OUT = process.env.PROBE_OUT as string;
  let n = 0;
  async function cell(label: string, status: string | null, tenant: string, asTenant?: string) {
    n += 1;
    const title = `GATEF1 ${n} ${RUN}`;
    const id = randomUUID();
    await sql.query(
      `INSERT INTO documents (id, tenant_id, external_id, title, document_type, content_hash, status, created_at, certified_at, metadata, certification_metadata)
       VALUES ($1::uuid, $2::uuid, $3, $4, 'DOCUMENT', $5, $6, $7::timestamptz, $7::timestamptz, '{}'::jsonb, '{}'::jsonb)`,
      [id, tenant, `gatef1-${n}-${RUN}`, title, randomBytes(32).toString('hex'), status, AT]);
    insertedIds.push(id);
    const r = await verify({ title }, asTenant);
    rec[label] = `${r.status} ${r.text}`;
  }
  afterAll(() => { fs.writeFileSync(OUT, JSON.stringify(rec, null, 1) + '\n'); });

  it('records the absent body', async () => {
    const r = await verify({ title: 'gatef1-no-such-title-' + RUN });
    rec['absent'] = `${r.status} ${r.text}`;
    const r2 = await verify({ title: 'gatef1-no-such-title-' + RUN }, T_B);
    rec['absent@B'] = `${r2.status} ${r2.text}`;
  });

  it('hidden statuses: case and space variants', async () => {
    for (const base of ['draft', 'revoked', 'deleted', 'expired']) {
      const up = base.toUpperCase(); const ti = base[0].toUpperCase() + base.slice(1);
      const mixed = base.split('').map((c, i) => (i % 2 ? c.toUpperCase() : c)).join('');
      for (const v of [base, up, ti, mixed, ' ' + base, base + ' ', '   ' + ti + '   ', ' ' + up]) await cell(`hidden[${JSON.stringify(v)}]`, v, DEFAULT_T);
    }
  });

  it('non-space whitespace (tab, newline, CR, NBSP) — btrim() default trims spaces only', async () => {
    for (const v of ['\tdeleted', 'revoked\t', '\ndraft', 'expired\n', 'revoked\r', 'deleted ', ' \trevoked\t ']) await cell(`ws[${JSON.stringify(v)}]`, v, DEFAULT_T);
  });

  it('visible statuses stay hits, including odd case and spacing', async () => {
    for (const v of ['certified', 'signed', 'anchored', 'anchor_failed', 'pending_signature', 'CERTIFIED', ' signed ', 'erased', '', ' ', 'revokedx', 'draft_x', 'undeleted']) await cell(`visible[${JSON.stringify(v)}]`, v, DEFAULT_T);
  });

  it('tenancy: cross-tenant title is not-found, the caller tenant is bound, hidden set applies in tenant B', async () => {
    await cell('B-doc certified, anon caller', 'certified', T_B);
    await cell('B-doc certified, vouched B caller', 'certified', T_B, T_B);
    await cell('B-doc " Deleted ", vouched B caller', ' Deleted ', T_B, T_B);
    await cell('B-doc "EXPIRED", vouched B caller', 'EXPIRED', T_B, T_B);
    await cell('default-doc certified, vouched B caller', 'certified', DEFAULT_T, T_B);
    await cell('default-doc certified, anon caller', 'certified', DEFAULT_T);
  });

  it('NULL status (NOT NULL dropped on the gate DB only for this cell, restored after)', async () => {
    await sql.query('ALTER TABLE documents ALTER COLUMN status DROP NOT NULL');
    try {
      await cell('NULL status, anon caller', null, DEFAULT_T);
      await cell('NULL status, vouched B caller (B doc)', null, T_B, T_B);
    } finally {
      await sql.query('DELETE FROM documents WHERE status IS NULL AND id = ANY($1::uuid[])', [insertedIds]);
      await sql.query('ALTER TABLE documents ALTER COLUMN status SET NOT NULL');
    }
  });
});
void path; void LEAK_KEYS; void normalise; void HIT_BODY; void MISS_BODY;
void ERASED;
