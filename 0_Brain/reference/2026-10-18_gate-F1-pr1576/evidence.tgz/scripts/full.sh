#!/bin/bash
set -u
G=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/db9b2375-e430-4d46-b18c-db37397c2500/scratchpad
for w in tipgreen dev; do
  WD=$G/$w/Blockchain/Dev
  $WD/node_modules/.bin/tsc -p $WD/services/originate/tsconfig.json --noEmit > $G/ev/tsc_$w.log 2>&1
  echo "$w tsc rc=$? errors=$(grep -c 'error TS' $G/ev/tsc_$w.log)"
done
for w in tipgreen dev; do
  O_DIR=$G/$w/Blockchain/Dev/services/originate
  J=$G/$w/Blockchain/Dev/node_modules/.bin/jest
  env -u DATABASE_URL -u TEST_DATABASE_URL $J --rootDir $O_DIR --config $O_DIR/jest.config.js --json --outputFile=$G/ev/unitall_$w.json --forceExit > $G/ev/unitall_$w.log 2>&1
  echo "$w unit-all rc=$?"
  python3 -I - "$G/ev/unitall_$w.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
print("  suites",d["numTotalTestSuites"],"passedSuites",d["numPassedTestSuites"],"tests",d["numTotalTests"],"passed",d["numPassedTests"],"failed",d["numFailedTests"])
for f in d["testResults"]:
    for a in f["assertionResults"]:
        if a["status"]=="failed": print("  FAIL", f["name"].split("/")[-1][:50], "|", a["title"][:110])
    if f.get("status")=="failed" and not f["assertionResults"]: print("  SUITE-FAIL", f["name"].split("/")[-1], f.get("message","")[:300].replace("\n"," "))
PY
done
