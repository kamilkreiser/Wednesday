#!/bin/bash
# usage: unit.sh <wt> <outname> <testpattern>
set -u
G=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/db9b2375-e430-4d46-b18c-db37397c2500/scratchpad
W=$G/$1; O=$2; PAT=$3
O_DIR=$W/Blockchain/Dev/services/originate
J=$W/Blockchain/Dev/node_modules/.bin/jest
env -u DATABASE_URL -u TEST_DATABASE_URL $J --rootDir $O_DIR --config $O_DIR/jest.config.js --json --outputFile=$G/ev/$O.json --forceExit "$PAT" > $G/ev/$O.log 2>&1
echo "rc=$?"
python3 -I - "$G/ev/$O.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
print("suites",d["numTotalTestSuites"],"passedSuites",d["numPassedTestSuites"],"tests",d["numTotalTests"],"passed",d["numPassedTests"],"failed",d["numFailedTests"])
for f in d["testResults"]:
    for a in f["assertionResults"]:
        if a["status"]=="failed": print("  FAIL", f["name"].split("/")[-1][:40], "|", a["title"][:110])
    if f.get("status")=="failed" and not f["assertionResults"]: print("  SUITE-FAIL", f["name"].split("/")[-1], f.get("message","")[:300].replace("\n"," "))
PY
