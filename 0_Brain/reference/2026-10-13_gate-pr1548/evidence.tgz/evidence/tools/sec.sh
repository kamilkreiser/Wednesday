#!/bin/bash
# sec.sh <worktree> <outfile> <config: i|u> [vitest args...]
T=$1; OUT=$2; C=$3; shift 3
export TEST_DATABASE_URL="postgresql://secuura@127.0.0.1:55477/secuura"
export TEST_APP_DATABASE_URL="postgresql://secuura_app:$(cat /private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1548/pg/app_pw)@127.0.0.1:55477/secuura"
export NODE_ENV=test MULTI_TENANCY_ENABLED=false; unset PLATFORM_DATABASE_URL
CFG=vitest.integration.config.ts; [ "$C" = u ] && CFG=vitest.config.ts
exec python3 -I /private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1548/bin/runin.py /private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1548/$T/Blockchain/Dev/services/security $OUT npx vitest run --config $CFG --reporter=verbose "$@"
