\pset format unaligned
\pset fieldsep '|'
WITH c(label, v) AS (VALUES
 ('active','active'),('ACTIVE','ACTIVE'),('Active','Active'),('aCtIvE','aCtIvE'),
 ('lead-space',' active'),('trail-space','active '),('trail-tab',E'active\t'),('trail-nl',E'active\n'),
 ('U+0130 dotted-I','act'||U&'\0130'||'ve'),('U+0130 upper','ACT'||U&'\0130'||'VE'),
 ('i+U+0307','acti'||U&'\0307'||'ve'),('fullwidth', U&'\FF41\FF43\FF54\FF49\FF56\FF45'),
 ('U+212A n/a control (kelvin, not in word)', U&'\212A'),
 ('DELETED','DELETED'),('Deleted','Deleted'),('SUSPENDED','SUSPENDED'),('pending','pending'),('empty',''),('NULL',NULL))
SELECT label,
  coalesce(lower(v) IN ('active','pending','suspended','deactivated','invited','inactive','deleted')::text,'null') AS check_admits,
  coalesce((lower(v) = 'active')::text,'null') AS guard_db_default,
  coalesce((lower(v COLLATE "C") = 'active')::text,'null') AS guard_C,
  coalesce((lower(v COLLATE "und-x-icu") = 'active')::text,'null') AS guard_icu,
  coalesce((v = 'active')::text,'null') AS old_guard
FROM c;
