// Gate PR1548 shared harness (scratch only). Boots the real security app on the app role under FORCE RLS.
import crypto from 'crypto';
import type { Server } from 'http';
import type { AddressInfo } from 'net';
import { Pool } from 'pg';
process.env.SECURITY_DISABLE_BOOT = '1';
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const PRIVATE_PEM = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const PUBLIC_PEM = publicKey.export({ type: 'spki', format: 'pem' }).toString();
const b64url = (b: Buffer): string => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
export function token(claims: Record<string, unknown>): string {
  const header = b64url(Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const now = Math.floor(Date.now() / 1000);
  const payload = b64url(Buffer.from(JSON.stringify({ sub: 'gate1548', iat: now, exp: now + 600, ...claims })));
  return `${header}.${payload}.${b64url(crypto.sign('RSA-SHA256', Buffer.from(`${header}.${payload}`), PRIVATE_PEM))}`;
}
export const H: { base: string; su: Pool; server?: Server; db?: any } = { base: '', su: undefined as any };
export async function boot(): Promise<void> {
  const SUPER_URL = process.env.TEST_DATABASE_URL; const APP_URL = process.env.TEST_APP_DATABASE_URL;
  if (!SUPER_URL || !APP_URL) throw new Error('gate1548 cells need TEST_DATABASE_URL and TEST_APP_DATABASE_URL');
  H.su = new Pool({ connectionString: SUPER_URL, max: 3 });
  process.env.DATABASE_URL = APP_URL;
  process.env.JWT_PUBLIC_KEY = Buffer.from(PUBLIC_PEM, 'utf8').toString('base64');
  delete process.env.JWT_JWKS_URL; delete process.env.AUTH_SERVICE_URL;
  H.db = await import('../db');
  if (!(await H.db.initDb())) throw new Error('initDb() did not connect');
  const mod = await import('../index');
  await new Promise<void>((resolve) => { H.server = mod.default.listen(0, '127.0.0.1', resolve); });
  H.base = `http://127.0.0.1:${(H.server!.address() as AddressInfo).port}`;
}
export async function shutdown(): Promise<void> {
  if (H.server) await new Promise<void>((r) => H.server!.close(() => r()));
  await H.su?.end(); await H.db?.closeDb();
}
export async function put(userId: string, tenantId: string, ids: string[]): Promise<{ status: number; json: any; at: number }> {
  const res = await fetch(`${H.base}/api/keys/admin-scopes/${userId}`, { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token({ role: 'SUPER_ADMIN', userId: crypto.randomUUID() })}` }, body: JSON.stringify({ tenantId, organizationIds: ids }) });
  return { status: res.status, json: await res.json().catch(() => ({})), at: Date.now() };
}
