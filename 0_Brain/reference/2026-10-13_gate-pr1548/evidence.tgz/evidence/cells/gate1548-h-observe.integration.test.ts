/** Gate PR1548 H (OBSERVE, records a ledger): spellings the CHECK admits whose lower() is 'active' only under the DB's libc fold. */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import fs from 'fs';
import { H, boot, shutdown, put } from './gate1548-common';
const T = 'a0000000-0000-4000-8000-0000000154d2';
const A1 = 'abcdef00-1548-4548-8548-0000000000c2';
const made: string[] = []; const LEDGER: Record<string, unknown> = {};
beforeAll(async () => {
  await boot();
  await H.su.query(`INSERT INTO organizations (id, name, slug, type, tenant_id) VALUES ($1::uuid,'gate1548 c2','gate1548-c2','issuer',$2::uuid) ON CONFLICT (id) DO NOTHING`, [A1, T]);
  LEDGER.collation = (await H.su.query("SELECT datcollate, datctype FROM pg_database WHERE datname=current_database()")).rows[0];
});
afterAll(async () => {
  if (process.env.GATE_LEDGER) fs.writeFileSync(process.env.GATE_LEDGER, JSON.stringify(LEDGER, null, 1));
  await H.su.query('DELETE FROM admin_organisation_scopes WHERE user_id = ANY($1::uuid[])', [made]);
  await H.su.query("DELETE FROM audit_logs WHERE action='admin_scope.set' AND resource_id = ANY($1::uuid[])", [made]);
  await H.su.query('DELETE FROM users WHERE id = ANY($1::uuid[])', [made]);
  await H.su.query('DELETE FROM organizations WHERE id=$1::uuid', [A1]);
  await shutdown();
});
const CASES: Array<[string, string]> = [
  ['ACTİVE (U+0130 capital I with dot)', 'ACTİVE'], ['actİve', 'actİve'],
  ['CONTROL ACTIVE', 'ACTIVE'], ['CONTROL DELETED', 'DELETED'],
];
describe('gate1548 H: observe', () => {
  for (const [label, s] of CASES) {
    it(`H '${label}'`, async () => {
      const id = crypto.randomUUID(); made.push(id);
      let insert = 'ok';
      try { await H.su.query("INSERT INTO users (id, tenant_id, email, role, status) VALUES ($1::uuid,$2::uuid,$3,'ADMIN',$4)", [id, T, `gate1548h-${id}@example.invalid`, s]); } catch (e: any) { insert = `refused ${e.code}`; }
      const r = insert === 'ok' ? await put(id, T, [A1]) : { status: 0 };
      const rows = (await H.su.query('SELECT organization_id::text o FROM admin_organisation_scopes WHERE user_id=$1::uuid', [id])).rows.map((x) => x.o);
      // what auth's mapper would make of it (mapDbStatus folds with JS toLowerCase, then an exact vocabulary lookup)
      const js = s.toLowerCase();
      LEDGER[label] = { stored: s, codepoints: [...s].map((c) => c.codePointAt(0)!.toString(16)), insert, put: r.status, rows, jsLower: js, jsLowerIsActive: js === 'active' };
      console.log('GATE_H', label, JSON.stringify(LEDGER[label]));
      expect(insert).toBe('ok');
    });
  }
});
