/** Gate PR1548 R: mixed-case concurrency with the waiter instrument bound to THIS (tenant,user) lock key. */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import fs from 'fs';
import { H, boot, shutdown, put } from './gate1548-common';
const T = 'a0000000-0000-4000-8000-0000000154e1';
const A1 = 'abcdef00-1548-4548-8548-0000000000e1';
const A2 = 'abcdef00-1548-4548-8548-0000000000e2';
const A3 = 'abcdef00-1548-4548-8548-0000000000e3';
const U = 'cafe' + crypto.randomUUID().slice(4);
const LEDGER: Record<string, unknown> = {};
beforeAll(async () => {
  await boot();
  for (const id of [A1, A2, A3]) await H.su.query(`INSERT INTO organizations (id, name, slug, type, tenant_id) VALUES ($1::uuid,$2,$3,'issuer',$4::uuid) ON CONFLICT (id) DO NOTHING`, [id, `gate1548 ${id.slice(-2)}`, `gate1548-${id.slice(-2)}`, T]);
  await H.su.query("INSERT INTO users (id, email, tenant_id, role, status) VALUES ($1::uuid,$2,$3::uuid,'ADMIN','active')", [U, `gate1548r-${U}@example.invalid`, T]);
});
afterAll(async () => {
  if (process.env.GATE_LEDGER) fs.writeFileSync(process.env.GATE_LEDGER, JSON.stringify(LEDGER, null, 1));
  await H.su.query('DROP TRIGGER IF EXISTS gate1548_hold ON audit_logs').catch(() => undefined);
  await H.su.query('DROP FUNCTION IF EXISTS gate1548_hold()').catch(() => undefined);
  await H.su.query('DELETE FROM admin_organisation_scopes WHERE user_id=$1::uuid', [U]);
  await H.su.query("DELETE FROM audit_logs WHERE action='admin_scope.set' AND resource_id=$1::uuid", [U]);
  await H.su.query('DELETE FROM users WHERE id=$1::uuid', [U]);
  await H.su.query('DELETE FROM organizations WHERE id = ANY($1::uuid[])', [[A1, A2, A3]]);
  await shutdown();
});
// Waiters on the EXACT key the shipped SQL takes for (T,U) - not "any advisory waiter in the cluster".
const keyWaiters = async (): Promise<number> => Number((await H.su.query(
  `SELECT count(*)::int n FROM pg_locks WHERE locktype='advisory' AND NOT granted AND objsubid=2
     AND classid::bigint = (hashtext(lower($1))::bigint & 4294967295) AND objid::bigint = (hashtext(lower($2))::bigint & 4294967295)`, [T, U])).rows[0].n);
const anyWaiters = async (): Promise<number> => Number((await H.su.query("SELECT count(*)::int n FROM pg_locks WHERE locktype='advisory' AND NOT granted")).rows[0].n);
const chain = async () => (await H.su.query("SELECT details FROM audit_logs WHERE action='admin_scope.set' AND resource_id=$1::uuid ORDER BY created_at", [U])).rows
  .map((r) => { const d = typeof r.details === 'string' ? JSON.parse(r.details) : r.details; return [d.before, d.after]; });
const rows = async () => (await H.su.query('SELECT organization_id::text o FROM admin_organisation_scopes WHERE user_id=$1::uuid ORDER BY 1', [U])).rows.map((x) => x.o);
async function reset() {
  await H.su.query('DELETE FROM admin_organisation_scopes WHERE user_id=$1::uuid', [U]);
  await H.su.query("DELETE FROM audit_logs WHERE action='admin_scope.set' AND resource_id=$1::uuid", [U]);
}
async function hold(after: string) {
  await H.su.query(`CREATE OR REPLACE FUNCTION gate1548_hold() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN IF NEW.details::jsonb -> 'after' = '["${after}"]'::jsonb THEN PERFORM pg_sleep(1.5); END IF; RETURN NEW; END $$`);
  await H.su.query("CREATE TRIGGER gate1548_hold BEFORE INSERT ON audit_logs FOR EACH ROW WHEN (NEW.action = 'admin_scope.set') EXECUTE FUNCTION gate1548_hold()");
}
async function unhold() { await H.su.query('DROP TRIGGER IF EXISTS gate1548_hold ON audit_logs'); await H.su.query('DROP FUNCTION IF EXISTS gate1548_hold()'); }
async function overlap(xUpper: boolean, yUpper: boolean, label: string) {
  await reset();
  const sp = (s: string, up: boolean) => (up ? s.toUpperCase() : s);
  expect((await put(U, T, [A1])).status).toBe(200);
  await hold(A2);
  let x: any; let y: any; let kw = 0; let aw = 0;
  try {
    const px = put(sp(U, xUpper), sp(T, xUpper), [A2]);
    await new Promise((r) => setTimeout(r, 300));
    const py = put(sp(U, yUpper), sp(T, yUpper), [A3]);
    const poll = (async () => { for (let i = 0; i < 25; i += 1) { kw = Math.max(kw, await keyWaiters()); aw = Math.max(aw, await anyWaiters()); await new Promise((r) => setTimeout(r, 40)); } })();
    [x, y] = await Promise.all([px, py]); await poll;
  } finally { await unhold(); }
  const res = { x: x.status, y: y.status, yMinusX: y.at - x.at, keyWaiters: kw, anyWaiters: aw, final: await rows(), chain: await chain() };
  LEDGER[label] = res; console.log('GATE_R', label, JSON.stringify(res));
  return res;
}
describe('gate1548 R: mixed-case concurrent writers', () => {
  it('R1 X UPPER (held) then Y lower: Y waits on the (T,U) key, replace not union, exact chain', async () => {
    const r = await overlap(true, false, 'R1');
    expect([r.x, r.y]).toEqual([200, 200]);
    expect(r.keyWaiters, 'Y waited on the exact (tenant,user) key').toBeGreaterThanOrEqual(1);
    expect(r.final).toEqual([A3]);
    expect(r.chain).toEqual([[[], [A1]], [[A1], [A2]], [[A2], [A3]]]);
  });
  it('R2 X lower (held) then Y UPPER: same', async () => {
    const r = await overlap(false, true, 'R2');
    expect([r.x, r.y]).toEqual([200, 200]);
    expect(r.keyWaiters).toBeGreaterThanOrEqual(1);
    expect(r.final).toEqual([A3]);
    expect(r.chain).toEqual([[[], [A1]], [[A1], [A2]], [[A2], [A3]]]);
  });
  it('R0 INSTRUMENT CONTROL: sequential writers (no overlap) read 0 key waiters with the same poller', async () => {
    await reset();
    expect((await put(U, T, [A1])).status).toBe(200);
    let kw = 0;
    const poll = (async () => { for (let i = 0; i < 10; i += 1) { kw = Math.max(kw, await keyWaiters()); await new Promise((r) => setTimeout(r, 40)); } })();
    expect((await put(U.toUpperCase(), T.toUpperCase(), [A2])).status).toBe(200);
    expect((await put(U, T, [A3])).status).toBe(200);
    await poll; LEDGER.R0 = { keyWaiters: kw, chain: await chain() };
    expect(kw).toBe(0);
    expect(await chain()).toEqual([[[], [A1]], [[A1], [A2]], [[A2], [A3]]]);
  });
});
