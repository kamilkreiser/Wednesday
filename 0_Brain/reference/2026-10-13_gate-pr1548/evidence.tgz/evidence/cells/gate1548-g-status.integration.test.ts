/** Gate PR1548 G: the liveness guard over the WHOLE status vocabulary, in three spellings, at the real route. */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import { H, boot, shutdown, put } from './gate1548-common';
const T = 'a0000000-0000-4000-8000-0000000154d1';
const A1 = 'abcdef00-1548-4548-8548-0000000000c1';
const made: string[] = [];
beforeAll(async () => {
  await boot();
  await H.su.query(`INSERT INTO organizations (id, name, slug, type, tenant_id) VALUES ($1::uuid,'gate1548 c1','gate1548-c1','issuer',$2::uuid) ON CONFLICT (id) DO NOTHING`, [A1, T]);
});
afterAll(async () => {
  await H.su.query('DELETE FROM admin_organisation_scopes WHERE user_id = ANY($1::uuid[])', [made]);
  await H.su.query("DELETE FROM audit_logs WHERE action='admin_scope.set' AND resource_id = ANY($1::uuid[])", [made]);
  await H.su.query('DELETE FROM users WHERE id = ANY($1::uuid[])', [made]);
  await H.su.query('DELETE FROM organizations WHERE id=$1::uuid', [A1]);
  await shutdown();
});
async function probe(status: string) {
  const id = crypto.randomUUID(); made.push(id);
  await H.su.query("INSERT INTO users (id, tenant_id, email, role, status) VALUES ($1::uuid,$2::uuid,$3,'ADMIN',$4)", [id, T, `gate1548-${id}@example.invalid`, status]);
  const r = await put(id, T, [A1]);
  const rows = (await H.su.query('SELECT organization_id::text o FROM admin_organisation_scopes WHERE user_id=$1::uuid', [id])).rows.map((x) => x.o);
  const aud = Number((await H.su.query("SELECT count(*)::int n FROM audit_logs WHERE action='admin_scope.set' AND resource_id=$1::uuid", [id])).rows[0].n);
  return { status: r.status, rows, aud, code: r.json?.error?.code };
}
const spell = (s: string) => [s, s.toUpperCase(), s[0].toUpperCase() + s.slice(1)];
describe('gate1548 G: liveness guard spectrum', () => {
  for (const s of spell('active').concat(['aCtIvE'])) {
    it(`G-live '${s}' -> 200, one row, one audit`, async () => {
      expect(await probe(s)).toEqual({ status: 200, rows: [A1], aud: 1, code: undefined });
    });
  }
  for (const base of ['pending', 'suspended', 'deactivated', 'invited', 'inactive', 'deleted']) {
    for (const s of spell(base)) {
      it(`G-dead '${s}' -> 404 NOT_FOUND, nothing written or audited`, async () => {
        expect(await probe(s)).toEqual({ status: 404, rows: [], aud: 0, code: 'NOT_FOUND' });
      });
    }
  }
});
