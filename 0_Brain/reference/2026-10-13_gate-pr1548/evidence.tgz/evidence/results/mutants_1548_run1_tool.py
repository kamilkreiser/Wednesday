#!/usr/bin/env python3
"""Gate PR1548 mutant runner, HEAD worktree in the scratchpad ONLY. Each mutant alone (anchor must occur exactly once),
every suite run with the JSON reporter, red cells recorded BY NAME WITH their failure message; a kill whose red cells all
carry an empty message is reported EMPTY-MSG and not counted. index.ts restored from a byte snapshot, sha256 asserted each time."""
import hashlib, json, os, subprocess, sys, re
W = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1548'
SEC = W + '/wt_head/Blockchain/Dev/services/security'
IDX = SEC + '/src/index.ts'
APP_PW = open(W + '/pg/app_pw').read().strip()
ENV = dict(os.environ, TEST_DATABASE_URL='postgresql://secuura@127.0.0.1:55477/secuura',
           TEST_APP_DATABASE_URL=f'postgresql://secuura_app:{APP_PW}@127.0.0.1:55477/secuura', NODE_ENV='test', MULTI_TENANCY_ENABLED='false')
ENV.pop('PLATFORM_DATABASE_URL', None)
I = 'vitest.integration.config.ts'
SUITES = [('authorRoute', I, 'src/__tests__/ks1570b-admin-scope-route.integration.test.ts', 18),
          ('authorE', I, 'src/__tests__/ks1570b-concurrent-replace-is-not-a-union.integration.test.ts', 3),
          ('unit888', 'vitest.config.ts', 'src/__tests__/ks888-failed-mint-save-issues-no-key.test.ts', 25),
          ('gateG', I, 'src/__tests__/gate1548-g-status.integration.test.ts', 22),
          ('gateR', I, 'src/__tests__/gate1548-r-race.integration.test.ts', 3)]
LOCK = "      await client.query('SELECT pg_advisory_xact_lock(hashtext(lower($1)), hashtext(lower($2)))', [tenantId, userId]);\n"
PREV = "      const prev = await client.query<{ o: string }>(\n        'SELECT organization_id::text AS o FROM admin_organisation_scopes WHERE tenant_id = $1::uuid AND user_id = $2::uuid ORDER BY 1',\n        [tenantId, userId],\n      );\n"
DEL = "      await client.query('DELETE FROM admin_organisation_scopes WHERE tenant_id = $1::uuid AND user_id = $2::uuid', [tenantId, userId]);\n"
CLS = "/^(08|53|57)|"
RAW = "[String((req.body ?? {}).tenantId), String(req.params.userId)]"
GUARD = " AND lower(status) = 'active' LIMIT 1"
MUT = {
 "C0 comment-only control": [("    // Purging existing rows on demotion or deletion is NOT in this change", "    // gate1548 C0 comment-only control\n    // Purging existing rows on demotion or deletion is NOT in this change")],
 "m1r lower(status) reverted to raw status": [(GUARD, " AND status = 'active' LIMIT 1")],
 "R2 lock AFTER the previous-set SELECT": [(LOCK + PREV, PREV + LOCK)],
 "R3 lock AFTER the DELETE": [(LOCK + PREV + DEL, PREV + DEL + LOCK)],
 "R4 lock keyed on RAW request ids (lower() kept, author's R4)": [(LOCK, LOCK.replace("[tenantId, userId]", RAW))],
 "R10 classifier class 57 dropped": [(CLS, "/^(08|53)|")],
 "R11 classifier class 53 dropped": [(CLS, "/^(08|57)|")],
 "X1 lock removed": [(LOCK, "")],
 "X2 raw ids AND no lower() (the r2 gate's R4 semantics)": [(LOCK, "      await client.query('SELECT pg_advisory_xact_lock(hashtext($1), hashtext($2))', " + RAW + ");\n")],
 "X3 bd11c34e reverted alone (no lower(), parsed ids)": [(LOCK, "      await client.query('SELECT pg_advisory_xact_lock(hashtext($1), hashtext($2))', [tenantId, userId]);\n")],
 "X4 guard over-widened: lower(status) <> 'deleted'": [(GUARD, " AND lower(status) <> 'deleted' LIMIT 1")],
 "X5 the gate's proposed fix lower(status COLLATE \"C\") (expected SURVIVED)": [(GUARD, " AND lower(status COLLATE \"C\") = 'active' LIMIT 1")],
}
sha = lambda b: hashlib.sha256(b).hexdigest()
strip = lambda s: re.sub(r'\x1b\[[0-9;]*m', '', s)
def run_suites(tag):
    res = {}
    for name, cfg, f, n in SUITES:
        jf = f'{W}/ev/mut/{re.sub(r"[^A-Za-z0-9]", "", tag)[:6]}_{name}.json'
        subprocess.run(['npx', 'vitest', 'run', '--config', cfg, f, '--reporter=json', f'--outputFile={jf}'], cwd=SEC, env=ENV, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=900)
        if not os.path.exists(jf): res[name] = {'loadfail': True}; continue
        j = json.load(open(jf)); os.rename(jf, jf + '.done')
        a = [x for t in j['testResults'] for x in t['assertionResults']]
        red = [{'title': x['title'], 'msg': strip((x.get('failureMessages') or [''])[0]).split('\n')[0][:220]} for x in a if x['status'] != 'passed']
        res[name] = {'total': len(a), 'expected': n, 'red': red, 'loadfail': len(a) != n}
    return res
os.makedirs(W + '/ev/mut', exist_ok=True)
snap = open(IDX, 'rb').read(); h0 = sha(snap); out = {}; lines = []
def say(s): print(s, flush=True); lines.append(s)
say(f'index.ts sha256 before = {h0}')
base = run_suites('BASELINE'); out['BASELINE'] = base
say('BASELINE ' + json.dumps({k: (v.get('total'), len(v.get('red', []))) for k, v in base.items()}))
if any(v.get('loadfail') or v.get('red') for v in base.values()): say('BASELINE NOT GREEN: STOP ' + json.dumps(base)); sys.exit(2)
for name, reps in MUT.items():
    s = snap.decode()
    for a, b in reps:
        assert s.count(a) == 1, f'{name}: anchor count {s.count(a)}: {a[:80]!r}'
        s = s.replace(a, b)
    open(IDX, 'w').write(s)
    try:
        r = run_suites(name)
    finally:
        open(IDX, 'wb').write(snap)
    assert sha(open(IDX, 'rb').read()) == h0, 'RESTORE FAILED'
    out[name] = r
    red = {k: v['red'] for k, v in r.items() if v.get('red')}
    lf = [k for k, v in r.items() if v.get('loadfail')]
    msgs = [c['msg'] for v in red.values() for c in v]
    verdict = 'LOADFAIL' if lf and not red else ('SURVIVED' if not red else ('EMPTY-MSG (not counted)' if all(not m.strip() for m in msgs) else 'KILLED'))
    say(f'{name}: {verdict}' + (f' loadfail={lf}' if lf else ''))
    for k, v in red.items():
        for c in v[:8]: say(f'    {k}: {c["title"][:100]}  ::  {c["msg"][:160]}')
    json.dump(out, open(W + '/ev/mutants_1548.json', 'w'), indent=1)
say(f'index.ts sha256 restored == {h0}: {sha(open(IDX,"rb").read()) == h0}')
open(W + '/ev/mutants_1548_run.txt', 'w').write('\n'.join(lines) + '\n')
