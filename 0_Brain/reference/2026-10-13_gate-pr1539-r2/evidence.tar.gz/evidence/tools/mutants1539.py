#!/usr/bin/env python3
"""Gate PR1539 mutant runner (head worktree in the gate scratchpad ONLY).
Each mutant alone: exact-string replacements in services/security/src/index.ts (each anchor must occur exactly
once), then run: the author's 13 cells, gate A (64), gate B (8). Records every red cell BY NAME per suite;
restores index.ts from a byte snapshot and asserts sha256 identical after every mutant.
The author's nine are re-derived verbatim from tools/mutants_ks1570b_v7.py (P*); the gate's own are G*; C0 is a
comment-only control."""
import hashlib, json, os, re, subprocess, sys
W = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad/g2'
SEC = W + '/repo/Blockchain/Dev/services/security'
IDX = SEC + '/src/index.ts'
APP_PW = open(W + '/pg/app_pw').read().strip()
ENV = dict(os.environ, TEST_DATABASE_URL='postgresql://secuura@127.0.0.1:55421/secuura',
           TEST_APP_DATABASE_URL=f'postgresql://secuura_app:{APP_PW}@127.0.0.1:55421/secuura', NODE_ENV='test', MULTI_TENANCY_ENABLED='false')
ENV.pop('PLATFORM_DATABASE_URL', None)
SUITES = [('author', 'src/__tests__/ks1570b-admin-scope-route.integration.test.ts', 13),
          ('gateA', 'src/__tests__/gate1539-a-route.integration.test.ts', 64),
          ('gateB', 'src/__tests__/gate1539-b-atomic.integration.test.ts', 8)]
AUD = "      const st = systemAuditInsertStatement(audit);\n      await client.query(st.text, st.values);\n      return b;\n    }));"
MUT = {
 # ---- the author's nine, verbatim anchors from mutants_ks1570b_v7.py ----
 "P1 the platform gate removed": [("function requireAdminScopeWriter(req: Request, res: Response, next: NextFunction): void {\n  platformRoleGate('Admin organisation scopes', req, res, next);\n}", "function requireAdminScopeWriter(req: Request, res: Response, next: NextFunction): void {\n  void req; void res; next();\n}")],
 "P2 the target-is-an-ADMIN check removed": [("'SELECT 1 FROM users WHERE id = $1::uuid AND tenant_id = $2::uuid AND upper(role) = $3 LIMIT 1',", "'SELECT 1 WHERE $1::uuid IS NOT NULL AND $2::uuid IS NOT NULL AND $3::text IS NOT NULL',")],
 "P3 the organisation-belongs-to-tenant check removed": [("    if (wanted.length > 0) {\n      const found = await runWithTenantId(", "    if (wanted.length > 1000000) {\n      const found = await runWithTenantId(")],
 "P4 the audit written AFTER commit (non-atomic, swallowed)": [(AUD, "      return b;\n    }));\n    try { const st = systemAuditInsertStatement(audit); await runWithTenantId(tenantId, () => query(st.text, st.values)); } catch { /* swallowed */ }")],
 "P5 append instead of replace (no DELETE)": [("      await client.query('DELETE FROM admin_organisation_scopes WHERE tenant_id = $1::uuid AND user_id = $2::uuid', [tenantId, userId]);\n", "")],
 "P6 no dedupe": [("    const wanted = [...new Set(body.organizationIds)].sort();", "    const wanted = [...body.organizationIds].sort();")],
 "P7 the write under the platform bypass, DELETE without the tenant": [("    const before = await runWithTenantId(tenantId, () => transaction(async (client) => {", "    const before = await runWithPlatformScope(() => transaction(async (client) => {"),
     ("      await client.query('DELETE FROM admin_organisation_scopes WHERE tenant_id = $1::uuid AND user_id = $2::uuid', [tenantId, userId]);", "      await client.query('DELETE FROM admin_organisation_scopes WHERE $1::uuid IS NOT NULL AND user_id = $2::uuid', [tenantId, userId]);")],
 "P8 the GET not platform-gated": [("app.get('/api/keys/admin-scopes/:userId', requireAdminScopeWriter,", "app.get('/api/keys/admin-scopes/:userId', (_req: Request, _res: Response, next: NextFunction) => next(),")],
 "P10 the audit details empty": [("      audit.details = { tenantId, targetUserId: userId, before: b, after: wanted, grantedBy };", "      audit.details = {};")],
 # ---- the gate's own ----
 "G1 tenant taken from the x-tenant-id header ahead of the body": [("    const tenantId = body.tenantId;", "    const tenantId = String((req.headers['x-tenant-id'] as string | undefined) || body.tenantId).toLowerCase();")],
 "G2 PUT gated by requireKeyAdmin (tenant ADMIN admitted) instead of the platform gate": [("app.put('/api/keys/admin-scopes/:userId', requireAdminScopeWriter,", "app.put('/api/keys/admin-scopes/:userId', requireKeyAdmin,")],
 "G3 audit outside the transaction, after commit, errors NOT swallowed": [(AUD, "      return b;\n    }));\n    { const st = systemAuditInsertStatement(audit); await runWithTenantId(tenantId, () => query(st.text, st.values)); }")],
 "G4 platform role compared case-sensitively": [("function requireAdminScopeWriter(req: Request, res: Response, next: NextFunction): void {\n  platformRoleGate('Admin organisation scopes', req, res, next);\n}", "function requireAdminScopeWriter(req: Request, res: Response, next: NextFunction): void {\n  if (!['SYSTEM_ADMIN', 'SUPER_ADMIN'].includes(String((req as any).user?.role))) { res.status(403).json({ success: false }); return; }\n  next();\n}")],
 "G5 organisation ids not normalised on write (no lower-case)": [("  organizationIds: z.array(UUID_TEXT).max(1000),", "  organizationIds: z.array(z.string().uuid()).max(1000),")],
 "G6 scope removal also revokes the removed organisations' keys": [(AUD, "      await client.query('UPDATE svc_api_keys SET is_active = false WHERE tenant_id = $1::uuid AND organization_id IS NOT NULL AND NOT (organization_id = ANY($2::text[]))', [tenantId, wanted]);\n" + AUD)],
 "G7 target check without the tenant filter (RLS left as the only bound)": [("'SELECT 1 FROM users WHERE id = $1::uuid AND tenant_id = $2::uuid AND upper(role) = $3 LIMIT 1',", "'SELECT 1 FROM users WHERE id = $1::uuid AND $2::uuid IS NOT NULL AND upper(role) = $3 LIMIT 1',")],
 "G8 organisation check under the platform bypass with no tenant filter": [("      const found = await runWithTenantId(tenantId, () => query<{ id: string }>(\n        'SELECT id::text AS id FROM organizations WHERE tenant_id = $1::uuid AND id = ANY($2::uuid[])',",
                                                                               "      const found = await runWithPlatformScope(() => query<{ id: string }>(\n        'SELECT id::text AS id FROM organizations WHERE $1::uuid IS NOT NULL AND id = ANY($2::uuid[])',")],
 "G9 audit tenant_id taken from the caller's token": [("      id: crypto.randomUUID(),\n      tenantId,\n      userId: callerUuid,", "      id: crypto.randomUUID(),\n      tenantId: String((caller as any)?.tenantId || tenantId),\n      userId: callerUuid,")],
 "G10 GET under the platform bypass without the tenant filter": [("    const r = await runWithTenantId(tenantId, () => query<{ o: string }>(\n      'SELECT organization_id::text AS o FROM admin_organisation_scopes WHERE tenant_id = $1::uuid AND user_id = $2::uuid ORDER BY 1',",
                                                                     "    const r = await runWithPlatformScope(() => query<{ o: string }>(\n      'SELECT organization_id::text AS o FROM admin_organisation_scopes WHERE $1::uuid IS NOT NULL AND user_id = $2::uuid ORDER BY 1',")],
 "G11 granted_by taken from the body when present": [("    const grantedBy = callerId || String(caller?.role ?? 'platform');", "    const grantedBy = String((req.body ?? {}).grantedBy || callerId || caller?.role || 'platform');")],
 "G12 the transaction does not apply the tenant GUC": [("      await applyTenantGuc(client);\n      const prev", "      const prev")],
 "G13 a failed transaction answered 200 (error swallowed)": [("    const before = await runWithTenantId(tenantId, () => transaction(async (client) => {", "    const before = await runWithTenantId(tenantId, () => transaction(async (client) => {")  # placeholder replaced below
 ],
 "G14 ADMIN-role target check case-sensitive (lower-case 'admin' users refused)": [("'SELECT 1 FROM users WHERE id = $1::uuid AND tenant_id = $2::uuid AND upper(role) = $3 LIMIT 1',", "'SELECT 1 FROM users WHERE id = $1::uuid AND tenant_id = $2::uuid AND role = $3 LIMIT 1',")],
 "C0 comment-only control": [(" * KS-1570 PR B: an ADMIN's ORGANISATION SCOPE, written and read by a PLATFORM role only.", " * KS-1570 PR B: an ADMIN's ORGANISATION SCOPE, written and read by a PLATFORM role only. (gate mutant comment)")],
}
# G13: wrap the transaction so an error yields before=[] and the route answers 200.
MUT["G13 a failed transaction answered 200 (error swallowed)"] = [
  ("    const before = await runWithTenantId(tenantId, () => transaction(async (client) => {", "    const before = await (runWithTenantId(tenantId, () => transaction(async (client) => {"),
  ("      return b;\n    }));\n    rememberAuditLog(audit);", "      return b;\n    })) as Promise<string[]>).catch(() => [] as string[]);\n    rememberAuditLog(audit);"),
]
sha = lambda b: hashlib.sha256(b).hexdigest()
def run_suites(tag):
    res = {}
    for name, f, n in SUITES:
        jf = f'{W}/ev/mut/{tag}_{name}.json'
        if os.path.exists(jf): os.remove(jf)
        subprocess.run(['npx', 'vitest', 'run', '--config', 'vitest.integration.config.ts', f, '--reporter=json', f'--outputFile={jf}'], cwd=SEC, env=ENV, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if not os.path.exists(jf): res[name] = {'loadfail': True}; continue
        j = json.load(open(jf)); a = [x for t in j['testResults'] for x in t['assertionResults']]
        res[name] = {'total': len(a), 'expected': n, 'red': [x['title'] for x in a if x['status'] == 'failed'],
                     'loadfail': len(a) != n}
    return res
os.makedirs(W + '/ev/mut', exist_ok=True)
snap = open(IDX, 'rb').read(); h0 = sha(snap); out = {}; lines = []
def say(s): print(s, flush=True); lines.append(s)
base = run_suites('BASELINE'); out['BASELINE'] = base
say('BASELINE ' + json.dumps({k: (v.get('total'), len(v.get('red', []))) for k, v in base.items()}))
if any(v.get('loadfail') or v.get('red') for v in base.values()): say('BASELINE NOT GREEN: STOP'); sys.exit(2)
only = os.environ.get('ONLY')
for name, reps in MUT.items():
    if only and name.split()[0] not in only.split(','): continue
    s = snap.decode()
    for a, b in reps:
        assert s.count(a) == 1, f'{name}: anchor count {s.count(a)}: {a[:80]!r}'
        s = s.replace(a, b)
    if s == snap.decode() and not name.startswith('C0'): say(f'{name}: NO-OP MUTANT'); continue
    open(IDX, 'w').write(s)
    try:
        r = run_suites(name.split()[0])
    finally:
        open(IDX, 'wb').write(snap)
    ok = sha(open(IDX, 'rb').read()) == h0
    red = sum(len(v.get('red', [])) for v in r.values()); lf = [k for k, v in r.items() if v.get('loadfail')]
    if lf: verdict = f'LOADFAIL {lf}'
    elif name.startswith('C0'): verdict = 'CONTROL OK (nothing red)' if red == 0 else 'CONTROL FAILED'
    else: verdict = 'KILLED' if red else 'SURVIVED'
    out[name] = {'verdict': verdict, 'restored_identical': ok, 'suites': r}
    say(f'\n{name}: {verdict}; restored byte-identical={ok}')
    for k, v in r.items():
        for t in v.get('red', []): say(f'   [{k}] red: {t}')
    if not ok: say('RESTORE MISMATCH: STOP'); break
json.dump(out, open(W + '/ev/mutants.json', 'w'), indent=1)
open(W + '/ev/mutants_run.txt', 'w').write('\n'.join(lines) + '\n')
