const yaml = require(process.argv[2]); const fs = require('fs');
for (const f of process.argv.slice(3)) {
  const d = (yaml.parse || yaml.load)(fs.readFileSync(f, 'utf8'));
  const keys = Object.keys(d.paths).filter((k) => k.includes('admin-scopes'));
  const out = {};
  for (const k of keys) for (const m of Object.keys(d.paths[k])) if (d.paths[k][m].responses) out[`${m.toUpperCase()} ${k}`] = { codes: Object.keys(d.paths[k][m].responses), r200: d.paths[k][m].responses['200']?.description, sec: d.paths[k][m].security };
  // control: the real PUT must still carry 404 and 503
  console.log(f.split('/').pop(), JSON.stringify(out, null, 0));
  console.log('paths total', Object.keys(d.paths).length);
}
