// old = the inline predicate at 61c30de5 (mint/revoke), new = isInfrastructureDbError at fdf314e0, both copied verbatim
const oldP = (saveErr) => /^(08|53|57)|^(ECONNREFUSED|ECONNRESET|ETIMEDOUT|EHOSTUNREACH|ENETUNREACH|EPIPE)$/.test(String(saveErr?.code)) || /connection terminated|timeout exceeded when trying to connect|connection timeout|pool is draining|client has encountered a connection error/i.test(String(saveErr?.message));
function newP(err) {
  const e = err;
  return /^(08|53|57)|^(ECONNREFUSED|ECONNRESET|ETIMEDOUT|EHOSTUNREACH|ENETUNREACH|EPIPE)$/.test(String(e?.code))
    || /connection terminated|timeout exceeded when trying to connect|connection timeout|pool is draining|client has encountered a connection error/i.test(String(e?.message));
}
const codes = [];
const A = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
for (const a of A) for (const b of A) { codes.push(a + b + '000'); codes.push(a + b + '001'); codes.push(a + b); }
codes.push('ECONNREFUSED','ECONNRESET','ETIMEDOUT','EHOSTUNREACH','ENETUNREACH','EPIPE','ENOTFOUND','EAI_AGAIN','econnreset','ECONNRESET ',' 08006',8006,57014,undefined,null,'',{},[],['08006'],{toString(){return '08001'}});
const msgs = [undefined,null,'','Connection terminated unexpectedly','connection terminated','timeout exceeded when trying to connect','Connection timeout','pool is draining','Client has encountered a connection error and is not queryable','duplicate key','permission denied for table audit_logs',42,{toString(){return 'connection terminated'}}];
let n = 0, diff = 0, infraTrue = 0;
const cases = [undefined, null, 'string error', 0, 1, true, Symbol.iterator ? 'sym' : ''];
for (const c of codes) for (const m of msgs) cases.push(Object.assign(new Error(typeof m === 'string' ? m : 'x'), { code: c, message: m }), { code: c, message: m });
for (const e of cases) { n++; let a, b; try { a = oldP(e); } catch (x) { a = 'THROW ' + x.message; } try { b = newP(e); } catch (x) { b = 'THROW ' + x.message; } if (a !== b) { diff++; console.log('DIFF', e, a, b); } if (a === true) infraTrue++; }
// control: a mutated predicate (class 57 dropped) must be seen as different
const mut = (e) => /^(08|53)|^(ECONNREFUSED|ECONNRESET|ETIMEDOUT|EHOSTUNREACH|ENETUNREACH|EPIPE)$/.test(String(e?.code)) || /connection terminated|timeout exceeded when trying to connect|connection timeout|pool is draining|client has encountered a connection error/i.test(String(e?.message));
let ctl = 0; for (const e of cases) { if (oldP(e) !== mut(e)) ctl++; }
console.log(JSON.stringify({ cases: n, differences: diff, infraTrueCases: infraTrue, controlMutantDifferences: ctl }));
