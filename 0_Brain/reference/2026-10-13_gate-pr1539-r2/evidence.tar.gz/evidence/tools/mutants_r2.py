#!/usr/bin/env python3
"""Gate PR1539 ROUND 2 mutant runner, on the HEAD worktree in the gate scratchpad ONLY (never !CODING).
Each mutant alone: exact-string replacements in services/security/src/index.ts (each anchor must occur exactly once),
then runs every suite below; records red cells BY NAME; restores index.ts from a byte snapshot and asserts sha256
identical after every mutant. P* = the author's nine (anchors re-derived for the head text where it moved);
G* = round 1 gate's own; R* = round 2 (this gate), aimed at the delta; C0 = comment-only control."""
import hashlib, json, os, subprocess, sys
W = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad/g2'
SEC = W + '/head/Blockchain/Dev/services/security'
IDX = SEC + '/src/index.ts'
APP_PW = open(W + '/pg/app_pw').read().strip()
ENV = dict(os.environ, TEST_DATABASE_URL='postgresql://secuura@127.0.0.1:55421/secuura',
           TEST_APP_DATABASE_URL=f'postgresql://secuura_app:{APP_PW}@127.0.0.1:55421/secuura', NODE_ENV='test', MULTI_TENANCY_ENABLED='false')
ENV.pop('PLATFORM_DATABASE_URL', None)
I = 'vitest.integration.config.ts'
SUITES = [('author', I, 'src/__tests__/ks1570b-admin-scope-route.integration.test.ts', 15),
          ('authorE', I, 'src/__tests__/ks1570b-concurrent-replace-is-not-a-union.integration.test.ts', 1),
          ('gateA', I, 'src/__tests__/gate1539-a-route.integration.test.ts', 64),
          ('gateB', I, 'src/__tests__/gate1539-b-atomic.integration.test.ts', 8),
          ('gateE', I, 'src/__tests__/gate1539-e-race.integration.test.ts', 1),
          ('gateF', I, 'src/__tests__/gate1539r2-f-delta.integration.test.ts', 16),
          ('unit888', 'vitest.config.ts', 'src/__tests__/ks888-failed-mint-save-issues-no-key.test.ts', 19)]
exec(open(W + '/bin/mutblock_r1.py').read())
LOCK = "      await client.query('SELECT pg_advisory_xact_lock(hashtext($1), hashtext($2))', [tenantId, userId]);\n"
PREV = "      const prev = await client.query<{ o: string }>(\n        'SELECT organization_id::text AS o FROM admin_organisation_scopes WHERE tenant_id = $1::uuid AND user_id = $2::uuid ORDER BY 1',\n        [tenantId, userId],\n      );\n"
DEL = "      await client.query('DELETE FROM admin_organisation_scopes WHERE tenant_id = $1::uuid AND user_id = $2::uuid', [tenantId, userId]);\n"
CLS = "  return /^(08|53|57)|^(ECONNREFUSED|ECONNRESET|ETIMEDOUT|EHOSTUNREACH|ENETUNREACH|EPIPE)$/.test(String(e?.code))\n    || /connection terminated|timeout exceeded when trying to connect|connection timeout|pool is draining|client has encountered a connection error/i.test(String(e?.message));"
MUT.update({
 "R1 the advisory lock removed": [(LOCK, "")],
 "R2 the lock taken AFTER the previous-set SELECT": [(LOCK + PREV, PREV + LOCK)],
 "R3 the lock taken AFTER the DELETE": [(LOCK + PREV + DEL, PREV + DEL + LOCK)],
 "R4 the lock keyed on the RAW (un-lower-cased) request ids": [(LOCK, LOCK.replace("[tenantId, userId]", "[String((req.body ?? {}).tenantId), String(req.params.userId)]"))],
 "R5 the lock keyed on the user id ONLY (one-key form)": [(LOCK, "      await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [userId]);\n")],
 "R6 the lock keyed on the tenant ONLY": [(LOCK, "      await client.query('SELECT pg_advisory_xact_lock(hashtext($1), 0)', [tenantId]);\n")],
 "R7 the lock inside a SAVEPOINT that is rolled back": [(LOCK, "      await client.query('SAVEPOINT gate_r2');\n" + LOCK + "      await client.query('ROLLBACK TO SAVEPOINT gate_r2');\n")],
 "R8 m2 status filter dropped": [(" AND status = 'active' LIMIT 1", " LIMIT 1")],
 "R9 m2 status filter case-folded (lower(status)) - the gate's proposed fix, expected to SURVIVE": [(" AND status = 'active' LIMIT 1", " AND lower(status) = 'active' LIMIT 1")],
 "R10 classifier: SQLSTATE class 57 dropped": [(CLS, CLS.replace("^(08|53|57)", "^(08|53)"))],
 "R11 classifier: SQLSTATE class 53 dropped": [(CLS, CLS.replace("^(08|53|57)", "^(08|57)"))],
 "R12 classifier: message arm dropped (code only)": [(CLS, CLS.split("\n")[0] + ";")],
 "R13 503 only at the PUT: mint site reverted to never-infra": [("      const infra = isInfrastructureDbError(saveErr);;\n      log('error', 'KS-888: API key mint refused", "      const infra = false && isInfrastructureDbError(saveErr);\n      log('error', 'KS-888: API key mint refused")],
 "R14 503 only at the PUT: revoke site reverted to never-infra": [("    const infra = isInfrastructureDbError(saveErr);;\n    log('error', 'KS-888: API key revoke not stored", "    const infra = false && isInfrastructureDbError(saveErr);\n    log('error', 'KS-888: API key revoke not stored")],
 "R15 the PUT's 503 branch removed (500 again)": [("    if (isInfrastructureDbError(error)) {\n      // Read off the request", "    if (false && isInfrastructureDbError(error)) {\n      // Read off the request")],
 "R16 the PUT's 503 body echoes the database error message": [("        error: { code: 'SERVICE_UNAVAILABLE', message: 'The admin organisation scope could not be written, so nothing changed' },", "        error: { code: 'SERVICE_UNAVAILABLE', message: String((error as any)?.message) },")],
})
sha = lambda b: hashlib.sha256(b).hexdigest()
def run_suites(tag):
    res = {}
    for name, cfg, f, n in SUITES:
        jf = f'{W}/ev/mut/{tag[:3]}_{name}.json'
        if os.path.exists(jf): os.remove(jf)
        subprocess.run(['npx', 'vitest', 'run', '--config', cfg, f, '--reporter=json', f'--outputFile={jf}'], cwd=SEC, env=ENV, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=900)
        if not os.path.exists(jf): res[name] = {'loadfail': True}; continue
        j = json.load(open(jf)); a = [x for t in j['testResults'] for x in t['assertionResults']]
        res[name] = {'total': len(a), 'expected': n, 'red': [x['title'] for x in a if x['status'] != 'passed'], 'loadfail': len(a) != n}
    return res
os.makedirs(W + '/ev/mut', exist_ok=True)
snap = open(IDX, 'rb').read(); h0 = sha(snap); out = {}; lines = []
def say(s): print(s, flush=True); lines.append(s)
only = os.environ.get('ONLY')
if not os.environ.get('SKIPBASE'):
    base = run_suites('BASELINE'); out['BASELINE'] = base
    say('BASELINE ' + json.dumps({k: (v.get('total'), len(v.get('red', []))) for k, v in base.items()}))
    if any(v.get('loadfail') or v.get('red') for v in base.values()): say('BASELINE NOT GREEN: STOP ' + json.dumps(base)); sys.exit(2)
for name, reps in MUT.items():
    if only and name.split()[0] not in only.split(','): continue
    s = snap.decode()
    for a, b in reps:
        assert s.count(a) == 1, f'{name}: anchor count {s.count(a)}: {a[:80]!r}'
        s = s.replace(a, b)
    open(IDX, 'w').write(s)
    try:
        r = run_suites(name)
    finally:
        open(IDX, 'wb').write(snap)
    assert sha(open(IDX, 'rb').read()) == h0, 'RESTORE FAILED'
    out[name] = r
    red = {k: v.get('red') for k, v in r.items() if v.get('red')}
    lf = [k for k, v in r.items() if v.get('loadfail')]
    verdict = 'LOADFAIL' if lf and not red else ('KILLED' if red else 'SURVIVED')
    say(f'{name}: {verdict}' + (f' loadfail={lf}' if lf else ''))
    for k, v in red.items(): say(f'    {k} ({len(v)} red): ' + ' | '.join(t[:110] for t in v[:12]))
    json.dump(out, open(W + '/ev/mutants_r2.json', 'w'), indent=1)
open(W + '/ev/mutants_r2_run.txt', 'a').write('\n'.join(lines) + f'\nindex.ts sha256 restored == {h0}\n')
