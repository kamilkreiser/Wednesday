"""gate PR1539: per app-role backend, track the GUC set in the current transaction; for every statement that touches
admin_organisation_scopes or INSERTs audit_logs, report (GUC tenant, bypass?, $1 tenant param). Positive control:
count of bypass set_config lines overall (gate D's platform-scope mint must produce >= 1)."""
import re, sys, collections
ev = []
for l in open(sys.argv[1]).read().splitlines():
    m = re.match(r'^\S+ \S+ \S+ \[(\d+)\] (\S*) ?(LOG|DETAIL):\s+(.*)$', l)
    if m:
        pid, user, k, t = m.groups(); ev.append([pid, user, k, t]); continue
    if ev: ev[-1][3] += ' ' + l.strip()
st = collections.defaultdict(lambda: {'guc': None, 'bypass': False}); pend = {}
res = collections.Counter(); bad = []; bypass_total = 0; stmts = collections.Counter()
for i, (pid, user, k, t) in enumerate(ev):
    if user != 'secuura_app': continue
    if k == 'LOG' and re.search(r'statement: BEGIN|execute \S+: BEGIN', t): st[pid] = {'guc': None, 'bypass': False}
    if k == 'LOG' and 'set_config' in t:
        if 'tenant_scope_bypass' in t: st[pid]['bypass'] = True; bypass_total += 1
        else: pend[pid] = 'tenant'
    if k == 'DETAIL' and pend.get(pid) == 'tenant':
        m = re.search(r"\$1 = '([^']*)'", t); st[pid]['guc'] = m.group(1) if m else None; pend[pid] = None
    if k == 'LOG' and ('admin_organisation_scopes' in t or 'INSERT INTO audit_logs' in t):
        kind = ('audit_insert' if 'INSERT INTO audit_logs' in t else re.search(r'(SELECT|DELETE|INSERT)', t).group(1) + '_scopes')
        nxt = ev[i + 1] if i + 1 < len(ev) else None
        pn = '2' if kind == 'audit_insert' else '1'  # audit INSERT: $1 is the audit id, $2 the tenant
        m = re.search(r"\$(" + pn + r") = '([0-9a-f-]{36})'", nxt[3]) if nxt and nxt[2] == 'DETAIL' else None
        wt = m.group(2) if m else None
        s = st[pid]; key = (kind, 'guc==param' if (s['guc'] and s['guc'] == wt) else 'MISMATCH', 'BYPASS' if s['bypass'] else 'nobypass')
        res[key] += 1
        if key[1] != 'guc==param' or key[2] != 'nobypass': bad.append((pid, kind, s, wt))
    if k == 'LOG' and re.search(r'(statement|execute \S+): (COMMIT|ROLLBACK)', t): st[pid] = {'guc': None, 'bypass': False}
for k, v in sorted(res.items()): print(k, v)
print('bad:', bad[:5]); print('bypass set_config lines from secuura_app (positive control, gate D):', bypass_total)
