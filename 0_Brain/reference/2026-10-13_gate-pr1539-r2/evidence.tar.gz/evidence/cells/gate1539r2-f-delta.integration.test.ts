/**
 * GATE PR #1539 ROUND 2, cells F: attacks on the DELTA 61c30de5..fdf314e0 (the advisory lock, the m1 503
 * path, the m2 status filter). Real HTTP against the real app, DB as secuura_app, state read back as the
 * superuser. A request is held inside its transaction by a SECURITY DEFINER BEFORE INSERT trigger on
 * audit_logs driven by the superuser-only table gate_r2_hold (target, after, mode, secs), so a hold fires only
 * for the exact (target, after) pair a cell names. Who waits on what is read from pg_stat_activity
 * (wait_event 'advisory') by the superuser while the hold is active.
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import fs from 'fs';
import type { Server } from 'http';
import type { AddressInfo } from 'net';
import { Pool } from 'pg';

process.env.SECURITY_DISABLE_BOOT = '1';
const T = 'a0000000-0000-4000-8000-0000000f2139';
const ORGS = [1, 2, 3, 4, 5].map((i) => `abcdef00-2139-4539-8539-00000000f2${String(i).padStart(2, '0')}`);
const [A1, A2, A3, A4, A5] = ORGS;
const SUPER_URL = process.env.TEST_DATABASE_URL;
const APP_URL = process.env.TEST_APP_DATABASE_URL;
const LEDGER: Record<string, unknown> = {};
const note = (k: string, v: unknown): void => { LEDGER[k] = v; console.log('GATE_F', k, JSON.stringify(v)); };
const created: string[] = [];

const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const PRIVATE_PEM = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const PUBLIC_PEM = publicKey.export({ type: 'spki', format: 'pem' }).toString();
const b64url = (b: Buffer): string => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function token(claims: Record<string, unknown>): string {
  const header = b64url(Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const now = Math.floor(Date.now() / 1000);
  const payload = b64url(Buffer.from(JSON.stringify({ sub: 'gate1539r2', iat: now, exp: now + 600, ...claims })));
  return `${header}.${payload}.${b64url(crypto.sign('RSA-SHA256', Buffer.from(`${header}.${payload}`), PRIVATE_PEM))}`;
}
const PLATFORM = (extra: Record<string, unknown> = {}) => token({ role: 'SUPER_ADMIN', userId: crypto.randomUUID(), ...extra });

let server: Server; let base: string; let su: Pool;
type Res = { status: number; json: Record<string, any>; text: string; t0: number; at: number };
async function call(method: string, path: string, tok: string, body?: unknown): Promise<Res> {
  const t0 = Date.now();
  const res = await fetch(`${base}${path}`, { method, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` }, body: body === undefined ? undefined : JSON.stringify(body) });
  const text = await res.text();
  let json: Record<string, any> = {};
  try { json = JSON.parse(text); } catch { /* not json */ }
  return { status: res.status, json, text, t0, at: Date.now() };
}
const put = (userPath: string, tenantId: string, ids: string[], tok = PLATFORM()) => call('PUT', `/api/keys/admin-scopes/${userPath}`, tok, { tenantId, organizationIds: ids });
const mint = (u: string, org: string) => call('POST', '/api/keys', token({ role: 'ADMIN', tenantId: T, userId: u }), { name: `gate1539r2:${crypto.randomUUID().slice(0, 6)}`, scopes: ['documents:read'], tenantId: T, organizationId: org });
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const short = (l: string[]) => l.map((x) => `A${x.slice(-1)}`);
async function rows(u: string): Promise<string[]> {
  return (await su.query<{ o: string }>('SELECT organization_id::text o FROM admin_organisation_scopes WHERE user_id=$1::uuid ORDER BY 1', [u])).rows.map((x) => x.o);
}
async function auditsOf(u: string): Promise<{ before: string[]; after: string[] }[]> {
  const r = await su.query("SELECT details FROM audit_logs WHERE action='admin_scope.set' AND resource_id=$1::uuid ORDER BY created_at", [u]);
  return r.rows.map((x) => (typeof x.details === 'string' ? JSON.parse(x.details) : x.details)).map((d) => ({ before: d.before, after: d.after }));
}
async function auditCount(u: string): Promise<number> {
  return Number((await su.query("SELECT count(*) n FROM audit_logs WHERE action='admin_scope.set' AND resource_id=$1::uuid", [u])).rows[0].n);
}
async function newAdmin(status = 'active', id: string = crypto.randomUUID()): Promise<string> {
  await su.query('INSERT INTO users (id, email, tenant_id, role, status) VALUES ($1::uuid, $2, $3::uuid, $4, $5)', [id, `gate1539r2-${id}@example.invalid`, T, 'ADMIN', status]);
  created.push(id);
  return id;
}
async function hold(target: string, after: string[], mode: 'sleep' | 'fail' | 'infra', secs = 1.5): Promise<void> {
  await su.query('INSERT INTO gate_r2_hold (target, after, mode, secs) VALUES ($1::uuid, $2::jsonb, $3, $4)', [target, JSON.stringify([...after].sort()), mode, secs]);
}
async function clearHolds(): Promise<void> { await su.query('DELETE FROM gate_r2_hold'); }
async function advisoryWaiters(): Promise<number> {
  return Number((await su.query("SELECT count(*) n FROM pg_stat_activity WHERE usename='secuura_app' AND wait_event_type='Lock' AND wait_event='advisory'")).rows[0].n);
}
async function advisoryHeld(): Promise<number> {
  return Number((await su.query("SELECT count(*) n FROM pg_locks WHERE locktype='advisory'")).rows[0].n);
}
/** Poll while a hold is active; return the max number of secuura_app backends seen waiting on an advisory lock. */
async function watchWaiters(ms: number): Promise<number> {
  let max = 0; const end = Date.now() + ms;
  while (Date.now() < end) { max = Math.max(max, await advisoryWaiters()); await sleep(40); }
  return max;
}
/** Is there an ordering of the audit rows that forms one chain from `start` whose last `after` equals `final`? */
function chains(audits: { before: string[]; after: string[] }[], start: string[], final: string[]): boolean {
  const key = (l: string[]) => JSON.stringify([...l].sort());
  const used = new Array(audits.length).fill(false);
  const go = (cur: string, n: number): boolean => {
    if (n === audits.length) return cur === key(final);
    for (let i = 0; i < audits.length; i++) {
      if (!used[i] && key(audits[i].before) === cur) { used[i] = true; if (go(key(audits[i].after), n + 1)) return true; used[i] = false; }
    }
    return false;
  };
  return go(key(start), 0);
}

beforeAll(async () => {
  if (!SUPER_URL || !APP_URL) throw new Error('gate1539r2 F needs TEST_DATABASE_URL and TEST_APP_DATABASE_URL');
  su = new Pool({ connectionString: SUPER_URL, max: 4 });
  for (const id of ORGS) await su.query(`INSERT INTO organizations (id, name, slug, type, tenant_id) VALUES ($1::uuid, $2, $3, 'issuer', $4::uuid) ON CONFLICT (id) DO NOTHING`, [id, `gate1539r2 ${id.slice(-2)}`, `gate1539r2-${id.slice(-2)}`, T]);
  await su.query('CREATE TABLE IF NOT EXISTS gate_r2_hold (target uuid, after jsonb, mode text, secs float8)');
  await su.query('DELETE FROM gate_r2_hold');
  await su.query(`CREATE OR REPLACE FUNCTION gate_r2_hold_fn() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
    DECLARE h record; BEGIN
      FOR h IN SELECT * FROM gate_r2_hold WHERE target = NEW.resource_id::uuid AND after = (NEW.details::jsonb -> 'after') LOOP
        IF h.mode = 'sleep' THEN PERFORM pg_sleep(h.secs);
        ELSIF h.mode = 'fail' THEN RAISE EXCEPTION 'gate_r2 injected audit failure';
        ELSIF h.mode = 'infra' THEN RAISE EXCEPTION 'connection terminated unexpectedly (gate_r2 db-host-7.internal:5432)' USING ERRCODE = '08006';
        ELSIF h.mode = 'jitter' THEN PERFORM pg_sleep(random() * h.secs);
        END IF;
      END LOOP; RETURN NEW; END $$`);
  await su.query('DROP TRIGGER IF EXISTS gate_r2_hold ON audit_logs');
  await su.query("CREATE TRIGGER gate_r2_hold BEFORE INSERT ON audit_logs FOR EACH ROW WHEN (NEW.action = 'admin_scope.set') EXECUTE FUNCTION gate_r2_hold_fn()");
  process.env.DATABASE_URL = APP_URL;
  process.env.JWT_PUBLIC_KEY = Buffer.from(PUBLIC_PEM, 'utf8').toString('base64');
  delete process.env.JWT_JWKS_URL; delete process.env.AUTH_SERVICE_URL;
  const db = await import('../db');
  if (!(await db.initDb()) || !db.isDbAvailable()) throw new Error('initDb() did not connect');
  const mod = await import('../index');
  await new Promise<void>((resolve) => { server = mod.default.listen(0, '127.0.0.1', resolve); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

afterAll(async () => {
  if (process.env.GATE_LEDGER) fs.writeFileSync(process.env.GATE_LEDGER, JSON.stringify(LEDGER, null, 1));
  if (server) await new Promise<void>((resolve) => server.close(() => resolve()));
  await su.query('DROP TRIGGER IF EXISTS gate_r2_hold ON audit_logs').catch(() => undefined);
  await su.query('DROP FUNCTION IF EXISTS gate_r2_hold_fn()').catch(() => undefined);
  await su.query('DROP TABLE IF EXISTS gate_r2_hold').catch(() => undefined);
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', ['gate1539r2:%']).catch(() => undefined);
  await su.query('DELETE FROM admin_organisation_scopes WHERE user_id = ANY($1::uuid[])', [created]);
  await su.query("DELETE FROM audit_logs WHERE action='admin_scope.set' AND resource_id = ANY($1::uuid[])", [created]);
  await su.query('DELETE FROM users WHERE id = ANY($1::uuid[])', [created]);
  await su.query('DELETE FROM organizations WHERE id = ANY($1::uuid[])', [ORGS]);
  await su.end();
});

describe('F lock: same key for every spelling, released on every exit, not shared by unrelated writers', () => {
  for (const [label, xCase, yCase] of [['X upper / Y lower', 'upper', 'lower'], ['X lower / Y upper', 'lower', 'upper']] as const) {
    it(`F1 ${label}: case spellings of (tenant, user) take the SAME lock; replace + truthful audit chain`, async () => {
      const u = await newAdmin();
      const sp = (s: string, c: string) => (c === 'upper' ? s.toUpperCase() : s);
      expect((await put(u, T, [A1])).status).toBe(200);
      await hold(u, [A2], 'sleep', 1.5);
      try {
        const px = put(sp(u, xCase), sp(T, xCase), [A2]);
        await sleep(300);
        const py = put(sp(u, yCase), sp(T, yCase), [A3]);
        const waiters = await watchWaiters(900);
        const [x, y] = await Promise.all([px, py]);
        const final = await rows(u); const aud = await auditsOf(u);
        note(`F1.${xCase}-${yCase}`, { x: x.status, y: y.status, yLatencyMs: y.at - y.t0, advisoryWaitersSeen: waiters, final: short(final), audits: aud.map((a) => [short(a.before), short(a.after)]) });
        expect([x.status, y.status]).toEqual([200, 200]);
        expect(waiters, 'Y waited on the advisory lock').toBeGreaterThanOrEqual(1);
        expect(final).toEqual([A3]);
        expect(aud.map((a) => [a.before, a.after])).toEqual([[[], [A1]], [[A1], [A2]], [[A2], [A3]]]);
      } finally { await clearHolds(); }
    });
  }

  it('F2 two PUTs for DIFFERENT users of the same tenant do NOT serialise', async () => {
    const u1 = await newAdmin(); const u2 = await newAdmin();
    await hold(u1, [A2], 'sleep', 1.5);
    try {
      const px = put(u1, T, [A2]);
      await sleep(300);
      const py = put(u2, T, [A3]);
      const waiters = await watchWaiters(600);
      const [x, y] = await Promise.all([px, py]);
      note('F2', { x: x.status, y: y.status, xLatencyMs: x.at - x.t0, yLatencyMs: y.at - y.t0, advisoryWaitersSeen: waiters, u1: short(await rows(u1)), u2: short(await rows(u2)) });
      expect([x.status, y.status]).toEqual([200, 200]);
      expect(waiters).toBe(0);
      expect(y.at - y.t0, 'Y answered while X was still held').toBeLessThan(800);
      expect(y.at, 'Y finished before X').toBeLessThan(x.at);
    } finally { await clearHolds(); }
  });

  it('F3 ROLLBACK releases the lock: a failing audit insert AFTER the lock, then the next PUT is prompt', async () => {
    const u = await newAdmin();
    expect((await put(u, T, [A1])).status).toBe(200);
    await hold(u, [A2], 'fail');
    let r: Res;
    try { r = await put(u, T, [A2]); } finally { await clearHolds(); }
    const heldAfter = await advisoryHeld();
    const n = await put(u, T, [A3]);
    note('F3', { failed: r!.status, code: r!.json?.error?.code, advisoryLocksHeldAfter: heldAfter, next: n.status, nextLatencyMs: n.at - n.t0, final: short(await rows(u)) });
    expect(r!.status).toBe(500);
    expect(heldAfter).toBe(0);
    expect(n.status).toBe(200);
    expect(n.at - n.t0).toBeLessThan(1000);
    expect(await rows(u)).toEqual([A3]);
  });

  it('F3b m1: SQLSTATE 08006 after the lock answers 503 with a fixed body (no db text, code or host), writes nothing, releases the lock', async () => {
    const u = await newAdmin();
    expect((await put(u, T, [A1])).status).toBe(200);
    const a0 = await auditCount(u);
    await hold(u, [A2], 'infra');
    let r: Res;
    try { r = await put(u, T, [A2]); } finally { await clearHolds(); }
    const heldAfter = await advisoryHeld();
    const leak = ['terminated', '08006', 'db-host-7', '5432', 'gate_r2', 'postgres', 'sqlstate', 'stack'].filter((s) => r!.text.toLowerCase().includes(s));
    const n = await put(u, T, [A3]);
    note('F3b', { status: r!.status, body: r!.json, leakedTokens: leak, rowsAfterFault: 'see final', auditDeltaAtFault: (await auditCount(u)) - a0 - 1, advisoryLocksHeldAfter: heldAfter, next: n.status, nextLatencyMs: n.at - n.t0 });
    expect(r!.status).toBe(503);
    expect(Object.keys(r!.json).sort()).toEqual(['error', 'success']);
    expect(Object.keys(r!.json.error).sort()).toEqual(['code', 'message']);
    expect(leak).toEqual([]);
    expect(heldAfter).toBe(0);
    expect(n.status).toBe(200);
    expect(await auditsOf(u)).toEqual([{ before: [], after: [A1] }, { before: [A1], after: [A3] }]);
  });

  it('F4 a KILLED connection mid-transaction (holding the lock): 503, nothing written, the next PUT for the same key does not hang', async () => {
    const u = await newAdmin();
    expect((await put(u, T, [A1])).status).toBe(200);
    await hold(u, [A2], 'sleep', 5);
    let x: Res; let killed = 0; let heldDuring = 0;
    try {
      const px = put(u, T, [A2]);
      await sleep(500);
      heldDuring = await advisoryHeld();
      killed = (await su.query("SELECT count(*) n FROM (SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE usename='secuura_app' AND wait_event='PgSleep') k")).rows[0].n;
      x = await px;
    } finally { await clearHolds(); }
    await sleep(200);
    const heldAfter = await advisoryHeld();
    const n = await put(u, T, [A3]);
    note('F4', { killed: Number(killed), advisoryLocksHeldDuring: heldDuring, x: x!.status, xBody: x!.json, advisoryLocksHeldAfter: heldAfter, next: n.status, nextLatencyMs: n.at - n.t0, final: short(await rows(u)), audits: (await auditsOf(u)).map((a) => [short(a.before), short(a.after)]) });
    expect(Number(killed)).toBe(1);
    expect(heldDuring).toBeGreaterThanOrEqual(1);
    expect(x!.status).toBe(503);
    expect(heldAfter).toBe(0);
    expect(n.status).toBe(200);
    expect(n.at - n.t0).toBeLessThan(1500);
    expect(await auditsOf(u)).toEqual([{ before: [], after: [A1] }, { before: [A1], after: [A3] }]);
  });

  it('F5 a platform token with NO tenantId and NO userId: serialised the same way', async () => {
    const u = await newAdmin();
    const bare = () => token({ role: 'SUPER_ADMIN' });
    expect((await put(u, T, [A1], bare())).status).toBe(200);
    await hold(u, [A2], 'sleep', 1.5);
    try {
      const px = put(u, T, [A2], bare());
      await sleep(300);
      const py = put(u, T, [A3], bare());
      const waiters = await watchWaiters(900);
      const [x, y] = await Promise.all([px, py]);
      const aud = await auditsOf(u);
      note('F5', { x: x.status, y: y.status, advisoryWaitersSeen: waiters, final: short(await rows(u)), audits: aud.map((a) => [short(a.before), short(a.after)]) });
      expect([x.status, y.status]).toEqual([200, 200]);
      expect(waiters).toBeGreaterThanOrEqual(1);
      expect(await rows(u)).toEqual([A3]);
      expect(aud.map((a) => [a.before, a.after])).toEqual([[[], [A1]], [[A1], [A2]], [[A2], [A3]]]);
    } finally { await clearHolds(); }
  });

  it('F6 OBSERVE: what PR A\'s mint sees while a replace is held mid-transaction (READ COMMITTED)', async () => {
    const u = await newAdmin();
    expect((await put(u, T, [A1])).status).toBe(200);
    await hold(u, [A2], 'sleep', 2);
    const mid: Record<string, number | number> = {};
    let x: Res;
    try {
      const px = put(u, T, [A2]);
      await sleep(500);
      for (const [k, o] of [['A1', A1], ['A2', A2], ['A3', A3]] as const) { const m = await mint(u, o); mid[k] = m.status; mid[`${k}ms`] = m.at - m.t0; }
      x = await px;
    } finally { await clearHolds(); }
    const after: Record<string, number> = {};
    for (const [k, o] of [['A1', A1], ['A2', A2], ['A3', A3]] as const) after[k] = (await mint(u, o)).status;
    note('F6', { midReplace: mid, x: x!.status, afterCommit: after });
    expect({ A1: mid.A1, A2: mid.A2, A3: mid.A3 }).toEqual({ A1: 201, A2: 403, A3: 403 });
    expect(after).toEqual({ A1: 403, A2: 201, A3: 403 });
  });

  it('F7 try to deadlock: two users, two held PUTs, then opposite-order PUTs for the same two users', async () => {
    const u1 = await newAdmin(); const u2 = await newAdmin();
    await hold(u1, [A1], 'sleep', 1); await hold(u2, [A2], 'sleep', 1);
    try {
      const p = [put(u1, T, [A1]), put(u2, T, [A2])];
      await sleep(200);
      p.push(put(u2, T, [A3]), put(u1, T, [A4]));
      await sleep(10);
      p.push(put(u1, T, [A5]), put(u2, T, [A5]));
      const r = await Promise.all(p);
      note('F7', { statuses: r.map((x) => x.status), u1: short(await rows(u1)), u2: short(await rows(u2)), chainU1: chains(await auditsOf(u1), [], await rows(u1)), chainU2: chains(await auditsOf(u2), [], await rows(u2)) });
      expect(r.map((x) => x.status)).toEqual([200, 200, 200, 200, 200, 200]);
      expect(chains(await auditsOf(u1), [], await rows(u1))).toBe(true);
      expect(chains(await auditsOf(u2), [], await rows(u2))).toBe(true);
    } finally { await clearHolds(); }
  });
});

describe('F chain: the audit trail equals the stored state under heavy concurrency', () => {
  for (const round of [1, 2, 3]) {
    it(`F8 round ${round}: 20 concurrent writers, 5 organisations, random subsets, jittered inside the transaction`, async () => {
      const u = await newAdmin();
      const sets: string[][] = [];
      for (let i = 0; i < 20; i++) { const s = ORGS.filter(() => Math.random() < 0.5); sets.push(s.length ? s : [ORGS[i % 5]]); }
      // jitter every write of this user between 0 and 80 ms inside its transaction (after DELETE/INSERT)
      for (const s of new Set(sets.map((x) => JSON.stringify([...x].sort())))) await hold(u, JSON.parse(s), 'jitter' as any, 0.08);
      let r: Res[];
      try { r = await Promise.all(sets.map((s) => put(u, T, s))); } finally { await clearHolds(); }
      const final = await rows(u); const aud = await auditsOf(u);
      const ok = chains(aud, [], final);
      const unionWider = final.length > Math.max(...sets.map((s) => new Set(s).size));
      note(`F8.${round}`, { statuses: [...new Set(r!.map((x) => x.status))], n: aud.length, final: short(final), chainHolds: ok, finalWiderThanAnyRequest: unionWider });
      expect(r!.every((x) => x.status === 200)).toBe(true);
      expect(aud.length).toBe(20);
      expect(ok, 'one chain of before->after from [] that ends at the stored set').toBe(true);
    });
  }
});

describe('F m2: the status filter at the real route', () => {
  it('F9 every status value in the users_status_vocabulary CHECK, plus case spellings the CHECK admits', async () => {
    const out: Record<string, unknown> = {};
    for (const st of ['active', 'pending', 'suspended', 'deactivated', 'invited', 'inactive', 'deleted', 'ACTIVE', 'Active']) {
      const u = await newAdmin(st);
      const r = await put(u, T, [A1]);
      out[st] = { status: r.status, rows: (await rows(u)).length, audits: await auditCount(u) };
    }
    note('F9', out);
    expect(out.active).toEqual({ status: 200, rows: 1, audits: 1 });
    for (const st of ['pending', 'suspended', 'deactivated', 'invited', 'inactive', 'deleted']) expect(out[st], st).toEqual({ status: 404, rows: 0, audits: 0 });
  });

  it('F9b OBSERVE: a live ADMIN stored as status "ACTIVE" (legal per migration 046) can it be given a scope', async () => {
    const u = await newAdmin('ACTIVE');
    const r = await put(u, T, [A1]);
    note('F9b', { status: r.status, rows: (await rows(u)).length });
    expect([200, 404]).toContain(r.status);
  });

  it('F10 OBSERVE: target deleted WHILE its PUT is held inside the transaction (status is not re-read under the lock)', async () => {
    const u = await newAdmin();
    await hold(u, [A2], 'sleep', 1.5);
    let x: Res;
    try {
      const px = put(u, T, [A2]);
      await sleep(400);
      await su.query("UPDATE users SET status='deleted' WHERE id=$1::uuid", [u]);
      x = await px;
    } finally { await clearHolds(); }
    const after = await put(u, T, [A3]);
    note('F10', { heldPut: x!.status, rowsAfterHeldPut: short(await rows(u)), nextPutAfterDelete: after.status });
    expect([200, 404]).toContain(x!.status);
  });
});

describe('F collision: hashtext collisions serialise unrelated writers (throughput only)', () => {
  it('F11 two different ADMINs whose ids collide under hashtext: the second WAITS on the first, both end correct', async () => {
    const c = await su.query<{ a: string; b: string }>(`
      WITH g AS (SELECT gen_random_uuid()::text u FROM generate_series(1, 400000)),
           h AS (SELECT u, hashtext(u) k FROM g)
      SELECT min(u) a, max(u) b FROM h GROUP BY k HAVING count(*) = 2 LIMIT 1`);
    expect(c.rows.length, 'a colliding pair was found').toBe(1);
    const { a, b } = c.rows[0];
    const ha = (await su.query('SELECT hashtext($1) x, hashtext($2) y', [a, b])).rows[0];
    const u1 = await newAdmin('active', a); const u2 = await newAdmin('active', b);
    await hold(u1, [A2], 'sleep', 1.5);
    try {
      const px = put(u1, T, [A2]);
      await sleep(300);
      const py = put(u2, T, [A3]);
      const waiters = await watchWaiters(900);
      const [x, y] = await Promise.all([px, py]);
      note('F11', { pair: [a, b], hashtext: ha, x: x.status, y: y.status, yLatencyMs: y.at - y.t0, advisoryWaitersSeen: waiters, u1: short(await rows(u1)), u2: short(await rows(u2)) });
      expect(ha.x).toBe(ha.y);
      expect([x.status, y.status]).toEqual([200, 200]);
      expect(await rows(u1)).toEqual([A2]);
      expect(await rows(u2)).toEqual([A3]);
    } finally { await clearHolds(); }
  }, 60000);
});
