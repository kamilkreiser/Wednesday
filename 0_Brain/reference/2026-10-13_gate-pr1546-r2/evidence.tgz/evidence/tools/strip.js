// usage: node strip.js <file> -> prints TS transpiled with comments removed (code-only fingerprint)
const ts = require(process.env.TSPATH); const fs = require('fs');
const src = fs.readFileSync(process.argv[2], 'utf8');
const out = ts.transpileModule(src, { compilerOptions: { removeComments: true, target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.CommonJS } }).outputText;
process.stdout.write(out);
