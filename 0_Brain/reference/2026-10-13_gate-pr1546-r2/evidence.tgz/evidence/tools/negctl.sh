#!/bin/bash
# Negative control for merge-tree: a scratch commit (develop + an edit to a line the delta rewrites) in the
# gate's OWN scratch clone only.
G=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1546r2
E=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1546-r2/evidence
cd_free_git() { git --git-dir=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1546r2/repo/.git "$@"; }
cd_free_git show refs/gate/develop:Blockchain/Dev/.env.example \
  | sed 's/^# UNSET is valid and fail-OPEN by design: fail-closed would mean an$/# GATE-CONFLICT-CONTROL edited on develop side/' > $G/conflict_env
echo "planted lines: $(grep -c GATE-CONFLICT $G/conflict_env)"
BLOB=$(cd_free_git hash-object -w $G/conflict_env)
export GIT_INDEX_FILE=$G/ctl.index
cd_free_git read-tree refs/gate/develop
cd_free_git update-index --cacheinfo 100644,$BLOB,Blockchain/Dev/.env.example
TREE=$(cd_free_git write-tree)
C=$(echo ctl | GIT_AUTHOR_NAME=gate GIT_AUTHOR_EMAIL=gate@local GIT_COMMITTER_NAME=gate GIT_COMMITTER_EMAIL=gate@local cd_free_git commit-tree $TREE -p refs/gate/develop)
unset GIT_INDEX_FILE
{
  echo "NEGATIVE CONTROL: scratch commit $C = develop + edit to .env.example:329 (a line the delta rewrites)"
  cd_free_git merge-tree --write-tree $C refs/gate/head | tail -4
  echo "rc=${PIPESTATUS[0]}"
} | tee -a $E/overlap_mergetree.txt
