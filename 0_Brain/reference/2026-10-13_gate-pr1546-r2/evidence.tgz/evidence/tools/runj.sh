#!/bin/bash
# usage: runj.sh <worktree> <tag> <patterns...>  -> evidence/<tag>.json/.log, prints summary
W="$1"; T="$2"; shift 2
O="$W/Blockchain/Dev/services/originate"; E=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1546-r2/evidence
"$W/Blockchain/Dev/node_modules/.bin/jest" --config "$O/jest.config.js" --rootDir "$O" --json --outputFile="$E/$T.json" "$@" > "$E/$T.log" 2>&1
python3 -I - "$E/$T.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
print("TOTAL passed=%d failed=%d total=%d suites=%d/%d"%(d['numPassedTests'],d['numFailedTests'],d['numTotalTests'],d['numPassedTestSuites'],d['numTotalTestSuites']))
for s in d['testResults']:
  ar=s['assertionResults']; fn=s['name'].split('/')[-1]
  print(" ",fn, "%d/%d"%(sum(a['status']=='passed' for a in ar),len(ar)), ("LOADFAIL "+s.get('message','')[:300].replace('\n',' ')) if not ar else "")
  for a in ar:
    if a['status']!='passed': print("    RED:",a['title'][:110])
PY
