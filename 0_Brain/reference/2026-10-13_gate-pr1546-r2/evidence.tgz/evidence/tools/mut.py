#!/usr/bin/env python3
"""Gate PR1546 r2 mutation runner. Mutates files in g1546r2/wt_gate only; restores from g1546r2/pristine; asserts byte-identical."""
import json, subprocess, sys, shutil, filecmp
G = "/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad/g1546r2"
O = f"{G}/wt_gate/Blockchain/Dev/services/originate"; PR = f"{G}/pristine"
EV = "/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1546-r2/evidence"
JEST = f"{G}/wt_gate/Blockchain/Dev/node_modules/.bin/jest"
GP, RT, MT, IX = "src/utils/gatewayProvenance.ts", "src/utils/requestTenant.ts", "src/routes/metering.ts", "src/index.ts"
NB = "src/__tests__/ks1032-second-lines-hold-without-the-strip.test.ts"
M = [
 ("c0", "CONTROL comment-only", MT, "meteringRouter.use((req", "// r2 comment-only control\nmeteringRouter.use((req"),
 ("g2", "author-named: metering verdict read REMOVED", MT, "if (isGatewayVouched(req) && req.headers['x-user-role']", "void isGatewayVouched; if (req.headers['x-user-role']"),
 ("g5", "author-named: index.ts KS-458 wiring reverted to ungated inline read", IX, "  (req as any).tenantId = resolveRequestTenantId(req as never);", "  void resolveRequestTenantId;\n  (req as any).tenantId = (req as any).tenantId || (typeof req.headers['x-tenant-id'] === 'string' && req.headers['x-tenant-id']) || 'a0000000-0000-4000-8000-000000000001';"),
 ("g11", "metering shim accepts 'unconfigured' as vouched (local)", MT, "if (isGatewayVouched(req) && req.headers['x-user-role']", "if ((isGatewayVouched(req) || (req as any).gatewayProvenance === 'unconfigured') && req.headers['x-user-role']"),
 ("g12", "index.ts call site forces the verdict to 'vouched'", IX, "  (req as any).tenantId = resolveRequestTenantId(req as never);", "  (req as any).tenantId = resolveRequestTenantId({ headers: req.headers, tenantId: (req as any).tenantId, gatewayProvenance: 'vouched' } as never);"),
 ("x1", "TEST-SIDE: the no-strip wrapper ALSO restores the vouch header", NB, "if (!(k in req.headers) && k !== 'x-gateway-vouch') req.headers[k] = saved[k];", "if (!(k in req.headers)) req.headers[k] = saved[k];"),
 ("x2", "TEST-SIDE: the no-strip wrapper restores NOTHING (strip silently back)", NB, "if (!(k in req.headers) && k !== 'x-gateway-vouch') req.headers[k] = saved[k];", "void k; void saved;"),
 ("x3", "TEST-SIDE: wrapper restores, but fakes the verdict to 'vouched'", NB, "          next();\n        });\n      };", "          req.gatewayProvenance = 'vouched';\n          next();\n        });\n      };"),
]
FILES = ["ks1032-unconfigured", "ks1032-second-lines", "ks1041-gateway-provenance", "ks1041-provenance-mount", "gate1546-a", "gate1546-b", "gate1546-c"]
def run(tag):
    out = f"{EV}/mut_{tag}.json"
    p = subprocess.run([JEST, "--config", f"{O}/jest.config.js", "--rootDir", O, "--json", f"--outputFile={out}", *FILES], capture_output=True, text=True)
    open(f"{EV}/mut_{tag}.log", "w").write(p.stdout + p.stderr)
    d = json.load(open(out)); red = {"author": [], "gate": []}; lf = []
    for s in d["testResults"]:
        fn = s["name"].split("/")[-1]; grp = "gate" if fn.startswith("gate1546") else "author"
        if not s["assertionResults"]: lf.append(fn)
        for a in s["assertionResults"]:
            if a["status"] != "passed": red[grp].append(f"{fn.split('.')[0][:22]}::{a['title'][:34]}")
    return d["numPassedTests"], d["numFailedTests"], d["numTotalTests"], red, lf
only = sys.argv[1:]
b = run("baseline"); print("BASELINE", b[:3], b[4], flush=True); assert b[1] == 0 and not b[4] and b[2] == 71
for tag, desc, f, old, new in M:
    if only and tag not in only: continue
    path = f"{O}/{f}"; src = open(path).read(); n = src.count(old)
    if n != 1: print(f"{tag} APPLY-FAIL count={n}", flush=True); continue
    open(path, "w").write(src.replace(old, new))
    try: p, fl, t, red, lf = run(tag)
    finally:
        shutil.copyfile(f"{PR}/{f}", path); assert filecmp.cmp(f"{PR}/{f}", path, shallow=False)
    v = "LOADFAIL" if lf else ("KILLED" if fl else "SURVIVED")
    print(f"{tag:4} {v:8} failed={fl} passed={p} total={t} author_red={len(red['author'])} gate_red={len(red['gate'])} :: {desc}")
    print("      author:", red["author"]); print("      gate  :", red["gate"]); print("      loadfail:", lf, flush=True)
r = run("restored"); print("RESTORED", r[:3], r[4])
