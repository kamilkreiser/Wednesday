Refs KS-1032 — ticket: https://linear.app/secuura/issue/KS-1032

> This pull request **contributes to** KS-1032 and must NOT auto-close it: the ticket's nine (now eleven) trust-header reads span four services and this changes **originate's four only**; the rest stay with their own lanes. The branch name gave the Linear attachment a `closes` link on open, which this line is here to flip.

## BLUF

Two sites in originate treated request headers as authoritative, both justified in their own comments by "originate is internal-only ingress". **That premise is false and was measured false**: `originate:4000` is not published to the host but sits on one flat compose network, and from a peer container on the demo box a forged `x-user-role: connector` plus a tenant id answered **200**, while the same forged request through `api-gateway:8080` answered 401 (the table at `services/originate/src/utils/gatewayProvenance.ts:19-32`).

KS-1041 Step 2 had already built the control. It was **inert unless `GATEWAY_VOUCH_SECRET` is set**, and unset is the shipped default — `.env.example:332`, `env.example:469`, and `${GATEWAY_VOUCH_SECRET:-}` for both services at `docker-compose.yml:452` and `:610`. The only place it is wired to a value is `deployment/azure/services.bicep:686,826`, the Container Apps estate deleted 2026-07-31. So every box the templates produce honoured forged trust headers.

**Scope is Kam's ruling of 2026-10-13** on card `secuura-ks1032-fail-closed-when-vouch-secret-unset-1013`: *"Fail closed, deployed only after the secret is set"*. All three parts, and the condition is on **deploying**, not on merging.

## The census, run rather than inherited

`bash Blockchain/Dev/scripts/check-no-trust-header-reads.sh` at develop `405e33a1`, default mode `fail`, rc 1: **eleven** reads, not the ticket's nine. originate's four are `src/index.ts:251` (the ticket said `:230`), `src/routes/metering.ts:42`, `:43`, `:45`. The two `api-gateway/src/routes/proxy.ts` hits (`:682`, `:708`) are new since the ticket was written and are **not** originate's — they look like the gateway *forwarding* rather than *trusting*, but I have not read them closely and am not claiming it.

## What changed

1. **The verdict is recorded, not only acted on.** The provenance middleware sets `vouched` / `unvouched` / `unconfigured` on the request. Three values rather than a boolean: the last two are the same *decision* and a different *fact*, and a boolean throws that away.
2. **An unconfigured request is treated as unvouched** — the trust set is stripped. Fail closed, per the ruling.
3. **The two trusting sites consult the verdict, not the header.** `routes/metering.ts`'s connector shim fires only on a vouched request; the KS-458 tenant resolution reads `x-tenant-id` only on one. This is deliberate defence in depth: a site that trusts a header must not depend on an upstream strip still being there.
4. **The KS-458 resolution moved to `utils/requestTenant.ts`** so a cell can run the real code instead of a rebuilt copy — the defect class KS-1432 was filed for. The verdict is **declared on express's `Request`** (the pattern `packages/shared`'s `db/tenant-context.ts` already uses) rather than read through `(req as any)` — the KS-759 / KS-1593 class.

An upstream-attached `req.tenantId` is deliberately **not** gated, and gating it would break multi-tenancy. Mutant m5 is that mistake and cell C2 kills it.

> **⚠ CORRECTED in round 1 (gate finding m2).** This paragraph used to add "from a verified context, never from a caller's raw header". That is **false in multi-tenant mode**, and I verified it independently of the gate: every writer of `.tenantId` in `services/originate/src` and `packages/shared/src` is exactly **three** — `index.ts:251` (this resolution), `routes/metering.ts:65`, and `packages/shared/src/db/tenant-context.ts:91` — and the third assigns straight from the **raw** `req.headers['x-tenant-id']` it read at `tenant-context.ts:67`, ungated.
>
> So with `MULTI_TENANCY_ENABLED=true` the attached arm wins and carries an ungated header value: **part (c) is a real second line in SINGLE-tenant mode only**, and in multi-tenant mode the provenance **strip is the only line**. Not exploitable while the strip works — the gate's GA5, GB3 and GC7 found **0 forged-versus-bare differences across all 147 declared routes**. `MULTI_TENANCY_ENABLED` is `${MULTI_TENANCY_ENABLED:-false}` in `docker-compose.yml`; whether it is on for any live box is **UNMEASURED**.
>
> Gating `extractTenantContext`'s header read is **deliberately not done** in this pull request: it is a behaviour change outside Kam's ruling. It is recorded on **KS-1599** with the metering `req.user.tenantId` point.

**Two pre-existing KS-1041 cells are inverted, not deleted.** Their describe block was `unconfigured — fail-open, but LOUD` and its own comment asked for exactly this: *"This test exists so that a future change to fail-closed is a DECISION SOMEONE MAKES, not a silent regression."* Kam made it; the block is renamed and the ruling and card id are in the comment.

## Test Evidence

**Touched:** `services/originate` — `utils/gatewayProvenance.ts`, `utils/requestTenant.ts` (new), `index.ts`, `routes/metering.ts`, `__tests__/ks1032-unconfigured-vouch-fails-closed.test.ts` (new, 12 cells), `__tests__/ks1041-gateway-provenance.test.ts`.

**Ran:**
- originate unit suite **106/106 suites, 1333/1333 tests, rc 0** (baseline 105 suites / 1321 tests, plus this file's 12).
- `tsc --noEmit` over originate: **rc 0, 0 errors**.
- `ks1041-gateway-provenance` + `ks1041-provenance-mount-wiring`: **24/24**.
- **Red-first: 6 red / 6 green of 12, with both CONTROL cells GREEN.** Red: A1, A2, A3 (the forged-header refusals), A5 (the boot line), B1 (verdict + strip), C1 (the gated tenant arm). Green: both controls, A4 (the two by-design direct callers), B2, C2, C3 — the cells that assert nothing changed. A straight revert is a *compile break* here (the cells import a new module), and a compile break reds nothing, so the variant restores develop's **behaviour** with the new plumbing present.
- **Mutants 7/7 killed**, baseline green and restore green. Recorded honestly: A1-A3 **cannot** catch a verdict-reader mutant, because on an unconfigured request the strip has already removed the headers and the shim's header test is false whatever the verdict says. That is defence in depth working; A1-A3's red comes from the develop-behaviour variant instead. The expectations were corrected to match the cells, not the reverse.
- **Pre-push preflight, in-hook, PUSH_RC=0**, and quoted as it quotes itself: `PREFLIGHT INCOMPLETE — 13/16 legs ran, 3 SKIPPED. Nothing failed.` Legs 3, 4, 8 skipped — local stack not up. Leg 14 shell suites **88 passed / 0 failed / 0 skipped of 88**. Leg 15 21/21 guards, production-guard 23/23 services. Leg 16 auth 42 baselined / 0 new / 0 stale, api-gateway 35 / 0 / 0, vc-issuer 0 / 0 / 0. Read by **tallies, not a FAIL grep** — the suites legitimately print `ok … REFUSED` lines; the count of lines reporting a non-zero failed count is **zero**.

**NOT run, and the honest reason:** the four platform suites (Schemathesis, Akto, Playwright, k6) and preflight legs 3, 4 and 8 — the local stack is not up in this worktree and I did not start it. No spec surface changed, so `check:openapi` has nothing to see here beyond what leg 1 ran.

**Migrations + config:** no migration; no config file changed; no change to the served specification.

## ⚠ Deploy condition — this is the part that must not be missed

Read the effective `GATEWAY_VOUCH_SECRET` on Kintsugi and on demo, set it where empty, and check Platform-S metering end to end **before** this ships to either. It is on the deploy-blockers list.

> **⚠ CORRECTED in round 1 — the previous wording here named the wrong failure signature, and it was the gate's Major (M1).** It said "that box's Platform-S metering answers **401** … on a single-tenant deployment … the answers are unchanged". That is wrong except in one narrow case. These are the gate's measurements (cells GA1, GA2, GC5; verdict `34fb8ee6b4650ac6`), not re-measured by me:
>
> For an `sk_` key, api-gateway attaches **both** the trust headers **and** a connector Bearer JWT minted by auth `/internal/connector-token` carrying the key's `tenantId`. originate strips the headers, so the metering shim is skipped — but `authenticate()` then **accepts the Bearer**, and the handler scopes by `req.tenantId`, which the KS-458 block had set to `DEFAULT_TENANT_ID` because the header is gone. So, on a box whose secret is **unset or MISMATCHED**:
>
> | situation | answer |
> |---|---|
> | Bearer present (the normal gateway path) | **200, reading the DEFAULT tenant's usage** (GA1, GC5) |
> | Bearer absent — the gateway's token exchange failed | **401** — the only shape that gives 401 (GA2) |
> | `MULTI_TENANCY_ENABLED=true` + `NODE_ENV=production` | **400** on every request (`extractTenantContext`, "Missing tenant context") |
>
> **The failure on an unset box is a silent switch to the wrong tenant, not a refusal**, and a mismatched secret is indistinguishable from a missing one by status code alone. The real consequence is a partner reading **another tenant's** usage totals whenever Platform S's key tenant differs from DEFAULT. **Whether that is so on Kintsugi or demo is UNMEASURED.** "Single-tenant answers are unchanged" holds only where S's key tenant already equals DEFAULT.
>
> Consequently a deploy check that only asserts "metering answers 200" **cannot** detect a missing or mismatched secret. Wednesday has amended **DEPLOY-BLOCKERS step (3)**: the end-to-end check asserts that the response's `data.tenantId` equals Platform S's key tenant, not merely that it is 200.

- [x] Pre-merge acknowledged — Schemathesis: **NOT run** (local stack down), stated above rather than ticked as done.
- [x] Pre-merge acknowledged — Akto: **NOT run** (local stack down), stated above rather than ticked as done.

---

## Round 1 of 2 — answering the gate's NO GO (verdict `34fb8ee6b4650ac6`, head `ad366066`)

Commit **`234fe0b0b`**. **No behaviour changed in this round.** The Major and two of the three Minors were false statements; the third was operator documentation contradicting the shipped behaviour. The only code added is test cells.

| finding | what it was | answered by |
|---|---|---|
| **M1** (Major) | the deploy condition named the wrong failure signature, in this body and at `routes/metering.ts:55-59` | both texts rewritten from the gate's GA1/GA2/GC5; see the corrected block above |
| **m1** | mutants **g2** and **g5** survived all 36 cells — neither second line was pinned as *wired into the real app* | new file `ks1032-second-lines-hold-without-the-strip.test.ts`: **GB0** (control), **GB1**, **GB2**, **GB2b** |
| **m2** | "verified context, never a raw header" false in multi-tenant mode — 3 texts | `utils/requestTenant.ts`, the C2 cell comment, and this body |
| **m3** | five operator-facing texts still said unset is fail-**OPEN** | `.env.example`, `env.example`, `docs/ENVIRONMENT-VARIABLES.md` (table row + prose), `services/originate/src/index.ts` |
| item 5 | one follow-up ticket, facts only, no fix shape | **KS-1599** |

**Why GB0 exists.** GB1 and GB2 are only observable with the provenance **strip removed** — with it in place the headers are gone before either line runs, which is exactly why both mutants were invisible. The harness wraps the real middleware so it still records the verdict but restores the headers it deleted. **GB0 asserts the wrapper really removed the strip**; without it, GB1 and GB2 would pass just as happily against a strip that was still working, and would be pinning the strip rather than the second lines.

**Red-proof — each mutant kills exactly one cell and nothing else:**

| mutant | effect | result |
|---|---|---|
| **g2** — verdict read removed from the metering shim | the shim fires on headers alone | **GB1 only** red: expected 401, received 200 |
| **g5** — KS-458 block reverted to the ungated inline read | the forged header becomes the tenant | **GB2 only** red |
| restored | zero mutant markers | **16/16** across both KS-1032 files |

### Test Evidence — round 1

**Touched:** `services/originate/src/{index.ts,routes/metering.ts,utils/requestTenant.ts}` (comments only, plus the one-word `index.ts` boot comment), two `__tests__` files, `.env.example`, `env.example`, `docs/ENVIRONMENT-VARIABLES.md`.

**Ran, locally, by me:**
- `tsc --noEmit` on originate — **0 errors**.
- Full originate unit suite — **107/107 suites, 1337/1337 tests** (the new file is the 107th suite and its 4 cells the +4).
- The two mutant runs above, each restored and re-verified at 16/16.
- The pre-push hook, all 16 legs, **`PUSH_RC=0`**, no bypass. 86 suite tallies in the log and **none** with a non-zero failed count (the honest predicate — the suites print their own control assertions as `ok … REFUSED`, so a `FAIL|REFUSED` grep over-reports).

**NOT run, stated rather than ticked:**
- **Schemathesis, Akto, Playwright, k6** — the local stack is not up on `localhost:6882`. **Three preflight legs reported `SKIP — local stack not up`** for the same reason; that is the preflight's own word, in its log, not a suite I chose to skip.
- I did **not** re-measure the gate's GA1/GA2/GC5 myself. The corrected texts attribute those numbers to the gate. What I **did** verify independently is m2's writer enumeration (three writers, the third reading the raw header) and m3's five text sites.

**Migrations + config:** no migration. `.env.example`, `env.example` and `docs/ENVIRONMENT-VARIABLES.md` change **comment and documentation text only** — no key, default or value is added, removed or altered. No change to the served specification.

**Deploy:** unchanged — this ships only after `GATEWAY_VOUCH_SECRET` is set and DEPLOY-BLOCKERS step (3) passes **as amended** (assert `data.tenantId`). Nothing is deployed by this pull request.