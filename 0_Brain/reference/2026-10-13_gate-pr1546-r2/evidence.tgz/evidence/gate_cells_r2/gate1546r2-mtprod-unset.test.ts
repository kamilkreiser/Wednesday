// GATE PR1546 round 2 — the multi-tenant PRODUCTION 400 claim, run on the real app (scratch only).
// getTenantManager is mocked to a live-looking manager so the extractTenantContext block engages
// (in the plain harness it is null before initDb and the block is a pass-through).
import { boot, raw, T_CONN } from "./gatekit/harness";
const mockUsage = jest.fn(async (t: string) => ({ tenantId: t, from: null, to: null, byEventType: [], totals: { count: 0, adaTotal: 0, usdTotal: 0 } }));
jest.mock("../services/chargeEvents", () => ({ ...jest.requireActual("../services/chargeEvents"), getUsageSummary: (...a: unknown[]) => (mockUsage as any)(...a) }));
jest.mock("@secuura/shared/crypto/jwks", () => ({ ...jest.requireActual("@secuura/shared/crypto/jwks"), verifyJwtRs256: async (t: string) => require("./gatekit/mocks").fakeVerify(t) }));
const fakeMgr = { isEnabled: () => true, getTenantStatus: () => "active", getPool: () => ({ fake: true }) };
jest.mock("../db", () => ({ ...jest.requireActual("../db"), getTenantManager: () => fakeMgr, getRequestPrisma: () => ({}) }));
jest.setTimeout(120000);
let h: { base: string; close: () => Promise<void> };
const PS = { authorization: "Bearer gate-connector-jwt", "x-user-role": "connector", "x-tenant-id": T_CONN, "x-user-id": "connector:ps-gate" };
const MODE = process.env.GATE_MT_NODE_ENV || "production";
beforeAll(async () => { delete process.env.GATEWAY_VOUCH_SECRET; process.env.MULTI_TENANCY_ENABLED = "true"; process.env.NODE_ENV = MODE; process.env.REDIS_URL = "redis://127.0.0.1:1"; process.env.ANCHORING_SERVICE_URL = "http://127.0.0.1:1"; h = await boot(); }, 120000);
afterAll(async () => { process.env.NODE_ENV = "test"; delete process.env.MULTI_TENANCY_ENABLED; await h?.close(); });
describe("R2 multi-tenant, secret UNSET", () => {
  it("R2-MT1 Platform-S shape (Bearer + headers, no vouch) on /api/metering/usage", async () => {
    const r = await raw(h.base, "GET", "/api/metering/usage", PS);
    console.log("R2-MT1 NODE_ENV=" + MODE, r.status, r.body.slice(0, 160));
    expect(r.status).toBeGreaterThan(0);
  });
  it("R2-MT2 /health (mounted before? records whether 'every request' holds)", async () => {
    const r = await raw(h.base, "GET", "/health", {});
    console.log("R2-MT2 NODE_ENV=" + MODE, r.status, r.body.slice(0, 120));
    expect(r.status).toBeGreaterThan(0);
  });
  it("R2-MT3 GET /api (mounted at index.ts:~200, before the block)", async () => {
    const r = await raw(h.base, "GET", "/api", {});
    console.log("R2-MT3 NODE_ENV=" + MODE, r.status, r.body.slice(0, 120));
    expect(r.status).toBeGreaterThan(0);
  });
});
