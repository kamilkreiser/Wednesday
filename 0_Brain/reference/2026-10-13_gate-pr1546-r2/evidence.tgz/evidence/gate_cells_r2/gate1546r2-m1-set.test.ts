// GATE PR1546 round 2 — M1 re-measured, secret SET (scratch only).
import { boot, raw, T_CONN, DEFAULT_T } from "./gatekit/harness";
const mockUsage = jest.fn(async (t: string) => ({ tenantId: t, from: null, to: null, byEventType: [], totals: { count: 0, adaTotal: 0, usdTotal: 0 } }));
jest.mock("../services/chargeEvents", () => ({ ...jest.requireActual("../services/chargeEvents"), getUsageSummary: (...a: unknown[]) => (mockUsage as any)(...a) }));
jest.mock("@secuura/shared/crypto/jwks", () => ({ ...jest.requireActual("@secuura/shared/crypto/jwks"), verifyJwtRs256: async (t: string) => require("./gatekit/mocks").fakeVerify(t) }));
jest.setTimeout(120000);
const SECRET = "c".repeat(64);
let h: { base: string; close: () => Promise<void> };
const PS = { authorization: "Bearer gate-connector-jwt", "x-user-role": "connector", "x-tenant-id": T_CONN, "x-user-id": "connector:ps-gate" };
beforeAll(async () => { process.env.GATEWAY_VOUCH_SECRET = SECRET; h = await boot(); }, 120000);
afterAll(async () => { delete process.env.GATEWAY_VOUCH_SECRET; await h?.close(); });
const dt = (b: string) => { try { return JSON.parse(b)?.data?.tenantId ?? "ABSENT"; } catch { return "UNPARSEABLE"; } };
describe("R2 M1 — secret SET", () => {
  it("R2-GC1 CONTROL correct vouch + Bearer -> S's own tenant (the tenant check CAN tell the states apart)", async () => {
    const r = await raw(h.base, "GET", "/api/metering/usage", { ...PS, "x-gateway-vouch": SECRET });
    console.log("R2-GC1", r.status, "data.tenantId=" + dt(r.body));
    expect({ s: r.status, t: dt(r.body) }).toEqual({ s: 200, t: T_CONN });
  });
  it("R2-GC5 MISMATCHED vouch (same length) + Bearer", async () => {
    const r = await raw(h.base, "GET", "/api/metering/usage", { ...PS, "x-gateway-vouch": "d".repeat(64) });
    console.log("R2-GC5", r.status, "data.tenantId=" + dt(r.body));
    expect({ s: r.status, t: dt(r.body) }).toEqual({ s: 200, t: DEFAULT_T });
  });
  it("R2-GC5b gateway sends NO vouch while originate has one (gateway-side unset) + Bearer", async () => {
    const r = await raw(h.base, "GET", "/api/metering/usage", PS);
    console.log("R2-GC5b", r.status, "data.tenantId=" + dt(r.body));
    expect({ s: r.status, t: dt(r.body) }).toEqual({ s: 200, t: DEFAULT_T });
  });
  it("R2-GC5c MISMATCHED vouch, NO Bearer -> 401", async () => {
    const { authorization, ...nb } = PS; void authorization;
    const r = await raw(h.base, "GET", "/api/metering/usage", { ...nb, "x-gateway-vouch": "d".repeat(64) });
    console.log("R2-GC5c", r.status);
    expect(r.status).toBe(401);
  });
});
