// GATE PR1546 round 2 — M1 re-measured by the gate (scratch only, never committed).
// getUsageSummary is mocked to return the REAL function's shape { tenantId: <arg>, ... } (chargeEvents.ts:302),
// so data.tenantId in the HTTP response is what an operator's deploy check would read.
import { boot, raw, T_CONN, DEFAULT_T } from "./gatekit/harness";
const mockUsage = jest.fn(async (t: string) => ({ tenantId: t, from: null, to: null, byEventType: [], totals: { count: 0, adaTotal: 0, usdTotal: 0 } }));
jest.mock("../services/chargeEvents", () => ({ ...jest.requireActual("../services/chargeEvents"), getUsageSummary: (...a: unknown[]) => (mockUsage as any)(...a) }));
jest.mock("@secuura/shared/crypto/jwks", () => ({ ...jest.requireActual("@secuura/shared/crypto/jwks"), verifyJwtRs256: async (t: string) => require("./gatekit/mocks").fakeVerify(t) }));
jest.setTimeout(120000);
let h: { base: string; close: () => Promise<void> };
const PS = { authorization: "Bearer gate-connector-jwt", "x-user-role": "connector", "x-tenant-id": T_CONN, "x-user-id": "connector:ps-gate" };
beforeAll(async () => { delete process.env.GATEWAY_VOUCH_SECRET; h = await boot(); }, 120000);
afterAll(async () => { await h?.close(); });
const dt = (b: string) => { try { return JSON.parse(b)?.data?.tenantId ?? "ABSENT"; } catch { return "UNPARSEABLE"; } };
describe("R2 M1 — secret UNSET", () => {
  it("R2-0 CONTROL secret unset, NODE_ENV and MULTI_TENANCY as run", () => {
    console.log("R2-0 env", JSON.stringify({ secret: process.env.GATEWAY_VOUCH_SECRET ?? null, NODE_ENV: process.env.NODE_ENV, MT: process.env.MULTI_TENANCY_ENABLED ?? null }));
    expect(process.env.GATEWAY_VOUCH_SECRET).toBeUndefined();
  });
  it("R2-GA1 unset + Bearer + trust headers", async () => {
    mockUsage.mockClear();
    const r = await raw(h.base, "GET", "/api/metering/usage", PS);
    console.log("R2-GA1", r.status, "data.tenantId=" + dt(r.body), "calls=" + mockUsage.mock.calls.length);
    expect({ s: r.status, t: dt(r.body) }).toEqual({ s: 200, t: DEFAULT_T });
  });
  it("R2-GA2 unset, NO Bearer (exchange failed)", async () => {
    mockUsage.mockClear();
    const { authorization, ...nb } = PS; void authorization;
    const r = await raw(h.base, "GET", "/api/metering/usage", nb);
    console.log("R2-GA2", r.status, "calls=" + mockUsage.mock.calls.length, r.body.slice(0, 120));
    expect(r.status).toBe(401); expect(mockUsage).not.toHaveBeenCalled();
  });
  it("R2-GA6 unset, gateway-shaped HUMAN (JWT tenant T_HUMAN + gateway x-tenant-id T_HUMAN): which tenant?", async () => {
    const r = await raw(h.base, "GET", "/api/metering/usage", { authorization: "Bearer gate-human-jwt", "x-tenant-id": "44444444-4444-4444-8444-444444444444" });
    console.log("R2-GA6", r.status, "data.tenantId=" + dt(r.body));
    expect({ s: r.status, t: dt(r.body) }).toEqual({ s: 200, t: DEFAULT_T });
  });
  it("R2-GA7 unset, Platform-S shape with an INVALID Bearer (not an exchange failure)", async () => {
    mockUsage.mockClear();
    const r = await raw(h.base, "GET", "/api/metering/usage", { ...PS, authorization: "Bearer not-a-known-token" });
    console.log("R2-GA7", r.status, "calls=" + mockUsage.mock.calls.length);
    expect(r.status).toBe(401);
  });
});
