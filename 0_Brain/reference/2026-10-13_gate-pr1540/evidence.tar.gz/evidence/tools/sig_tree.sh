#!/bin/bash
# sig_tree.sh <gate> <workdir>: every signal (and an `exit 1` mid-check) during a TREE-MODE check; tree dir left? check group alive? sentinels kept?
set -u
GATE=$1; W=$2
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null npm_config_registry="http://127.0.0.1:9/"
rm -rf "$W"; mkdir -p "$W"
python3 - "$GATE" "$W/gate_exit1_midcheck.sh" <<'PY'
import sys; s=open(sys.argv[1]).read(); o='    _FG_CHK_PID=$!\n'; assert s.count(o)==1
open(sys.argv[2],'w').write(s.replace(o, o+'    [ -n "${EXIT1_MIDCHECK:-}" ] && { sleep 1; exit 1; }\n'))
PY
for sig in INT TERM HUP QUIT USR1 ALRM PIPE KILL EXIT1; do
  r=$W/$sig; d=$r/systemTest/p; mkdir -p $r/systemTest/scripts $d/src $d/node_modules/.bin
  if [ $sig = EXIT1 ]; then cp $W/gate_exit1_midcheck.sh $r/systemTest/scripts/check-package-format.sh; else cp "$GATE" $r/systemTest/scripts/check-package-format.sh; fi
  printf '{ "name": "p", "version": "0.0.0", "scripts": { "format:check": "bash hang.sh; true" } }\n' > $d/package.json
  printf 'echo $$ >> "$PIDF"\n( trap "" TERM; echo $BASHPID 2>/dev/null; exec sleep 300 ) &\necho $! >> "$PIDF"\nwhile :; do sleep 0.1; done\n' > $d/hang.sh
  echo good > $d/src/a.ts; printf '#!/bin/sh\nexit 0\n' > $d/node_modules/.bin/prettier; chmod +x $d/node_modules/.bin/prettier
  echo keep > $r/SENTINEL_root; echo keep > $d/SENTINEL_pkg; echo keep > $W/SENTINEL_outside_$sig
  printf 'node_modules/\n' > $r/.gitignore
  ( cd $r && git init -q -b main . && git add -A && git -c user.email=t@t.t -c user.name=t commit -qm i )
  sha=$(git -C $r rev-parse HEAD); export PIDF=$r/pids; : > $PIDF
  printf 'systemTest/p/src/a.ts\n' | EXIT1_MIDCHECK=$( [ $sig = EXIT1 ] && echo 1 ) FORMAT_GATE_TREE=$sha \
    perl -e '$SIG{INT}=$SIG{QUIT}="DEFAULT"; exec @ARGV' -- bash $r/systemTest/scripts/check-package-format.sh > $r/out 2>&1 &
  g=$!; for i in $(seq 1 100); do [ "$(wc -l < $PIDF)" -ge 2 ] && break; sleep 0.1; done; sleep 0.2
  pre_trees=$(ls -A $r/systemTest | grep -c format-gate-tree)
  [ $sig != EXIT1 ] && kill -$sig $g
  wait $g; rc=$?; sleep 0.5
  n=0; for p in $(cat $PIDF); do ps -p $p >/dev/null 2>&1 && n=$((n+1)); done
  printf '%-6s rc=%-4s tree_in_flight=%s trees_left=%s check_procs_alive=%s sentinels=%s%s%s\n' $sig $rc $pre_trees "$(ls -A $r/systemTest | grep -c format-gate-tree)" $n \
    "$( [ -f $r/SENTINEL_root ] && echo R)" "$( [ -f $d/SENTINEL_pkg ] && echo P)" "$( [ -f $W/SENTINEL_outside_$sig ] && echo O)"
  for p in $(cat $PIDF); do kill -KILL $p 2>/dev/null; done
done
echo "== the next run after SIGKILL sweeps the dead pid's tree dir:"
r=$W/KILL; sha=$(git -C $r rev-parse HEAD)
printf 'bash -c true\n' > /dev/null
printf '{ "name": "p", "version": "0.0.0", "scripts": { "format:check": "exit 0" } }\n' > $r/systemTest/p/package.json; git -C $r -c user.email=t@t.t -c user.name=t commit -qam quick; sha=$(git -C $r rev-parse HEAD)
before=$(ls -A $r/systemTest | grep -c format-gate-tree)
printf 'systemTest/p/src/a.ts\n' | FORMAT_GATE_TREE=$sha bash $r/systemTest/scripts/check-package-format.sh >/dev/null 2>&1; echo "  rc=$? trees before=$before after=$(ls -A $r/systemTest | grep -c format-gate-tree)"
