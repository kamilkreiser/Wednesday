#!/bin/bash
# perl.sh <gate> <workdir>: no-perl refusal (with control), and PATH spoofing of perl
set -u
GATE=$1; W=$2
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null npm_config_registry="http://127.0.0.1:9/"
rm -rf "$W"; mkdir -p "$W/noperl" "$W/withperl" "$W/stub"
for d in /usr/bin /bin /usr/sbin /sbin; do for f in $d/*; do b=${f##*/}; case $b in perl*) continue;; esac
  [ -e "$W/noperl/$b" ] || ln -s "$f" "$W/noperl/$b"; [ -e "$W/withperl/$b" ] || ln -s "$f" "$W/withperl/$b"; done; done
for b in node npm npx; do ln -sf "$(command -v $b)" "$W/noperl/$b"; ln -sf "$(command -v $b)" "$W/withperl/$b"; done
ln -sf /usr/bin/perl "$W/withperl/perl"
cat > $W/stub/npm <<'N'
#!/bin/bash
if [ "${1:-}" = ci ]; then echo "npm ci STARTED" >> "$NPMLOG"; mkdir -p node_modules/.bin; printf '#!/bin/sh\nexit 0\n' > node_modules/.bin/prettier; chmod +x node_modules/.bin/prettier; exit 0; fi
exec "$REAL_NPM" "$@"
N
chmod +x $W/stub/npm; export REAL_NPM=$(command -v npm)
mk() { local r=$W/$1; mkdir -p $r/systemTest/scripts $r/systemTest/p; cp "$GATE" $r/systemTest/scripts/check-package-format.sh
  printf '{ "name": "p", "version": "0.0.0", "scripts": { "format:check": "exit 0" } }\n' > $r/systemTest/p/package.json; echo $r; }
echo "CONTROL perl visible: noperl=$(PATH=$W/noperl command -v perl || echo none) withperl=$(PATH=$W/withperl command -v perl)"
for v in withperl noperl; do r=$(mk $v); export NPMLOG=$W/$v.npmlog
  out=$(printf 'systemTest/p/x\n' | PATH="$W/stub:$W/$v" bash $r/systemTest/scripts/check-package-format.sh 2>&1); rc=$?
  echo "[$v] normal: rc=$rc npm_ci_started=$(cat $NPMLOG 2>/dev/null | wc -l | tr -d ' ') names_perl=$(printf '%s' "$out" | grep -c 'perl was not found on PATH') INSTALLED=$(printf '%s' "$out" | grep -c INSTALLED) stages=$(ls -A $r/systemTest | grep -c format-gate-stage) nm=$( [ -e $r/systemTest/p/node_modules ] && echo yes || echo no)"
  printf '%s\n' "$out" | sed 's/^/    | /' | grep -i 'perl\|REFUSED\|fix' | head -4
  r=$(mk $v-all); out=$(PATH="$W/stub:$W/$v" bash $r/systemTest/scripts/check-package-format.sh --all </dev/null 2>&1); rc=$?
  echo "[$v] --all : rc=$rc names_perl=$(printf '%s' "$out" | grep -c 'perl was not found') NOTHING_CHECKED=$(printf '%s' "$out" | grep -c 'NOTHING CHECKED')"
done
echo "== spoof: a repo-controlled dir FIRST on PATH holding 'perl' (would need the developer to have put it on PATH)"
r=$(mk spoof); mkdir -p $r/evilbin
printf '#!/bin/sh\necho "SPOOFED perl ran: $*" >> %s/spoof.log\nshift 2 2>/dev/null; exec /usr/bin/perl "$@"\n' "$W" > $r/evilbin/perl
printf '#!/bin/sh\necho "SPOOFED npm ran" >> %s/spoof.log\nexec %s "$@"\n' "$W" "$W/stub/npm" > $r/evilbin/npm
chmod +x $r/evilbin/*; export NPMLOG=$W/spoof.npmlog
printf 'systemTest/p/x\n' | PATH="$r/evilbin:$W/withperl" bash $r/systemTest/scripts/check-package-format.sh >/dev/null 2>&1
echo "  spoof.log:"; sed 's/^/    /' $W/spoof.log 2>/dev/null | cut -c1-160
