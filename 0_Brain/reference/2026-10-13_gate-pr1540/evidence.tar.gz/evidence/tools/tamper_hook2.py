#!/usr/bin/env python3
"""Mutation proof for the item 2 hook. Copies of the hook run through the three hook-level suites via HOOK_SH.
A mutant is KILLED BY NAME only if every cell named in advance is among the FAIL lines of ANY of the suites."""
import datetime, os, re, subprocess, sys
HOOK, OUT = sys.argv[1], sys.argv[2]
D = os.path.dirname(HOOK) + "/../Blockchain/Dev/scripts/__tests__/"
SUITES = [D + "ks998_pre_push_judges_the_push.test.sh", D + "ks998_pre_push_stale_base_hint.test.sh", D + "pre_push_hook_base.test.sh"]
os.makedirs(OUT, exist_ok=True)
src = open(HOOK, encoding="utf-8").read()
now = lambda: datetime.datetime.now(datetime.timezone.utc).strftime("%H:%M:%SZ")
M = []
def mut(name, edits, kills, survive=None): M.append((name, edits, kills, survive))
TIPLINE = '''    _tip=$(git rev-parse --verify --quiet "${_jr_lsha}^{commit}" 2>/dev/null) || _tip=''\n'''
DELLINE = '''    [ "$_jr_lsha" = "$ZERO" ] && { _jr_skip=delete; return 0; }     # deleting a ref rewrites nothing and archives nothing\n'''
FC = '''    if [ -n "$changed" ] && [ "$_tip" != "$_head_c" ]; then\n'''
mut("h01_gate_judges_head_not_the_pushed_tip", [('FORMAT_GATE_TREE="$_tip" FORMAT_GATE_BASE_MAY_BE_STALE=', 'FORMAT_GATE_TREE="$_head_c" FORMAT_GATE_BASE_MAY_BE_STALE=')],
    ["SC2 pushing a branch that is NOT checked out: its red systemTest file is caught"])
mut("h02_no_fail_closed_refusal", [(FC, '    if false; then\n')],
    ["SC3 a pushed sha that is not HEAD and changes Blockchain/Dev is REFUSED", "SC11 HEAD plus a not-checked-out Blockchain/Dev ref: the whole push is refused"])
mut("h03_refuses_every_non_head_ref", [(FC, '    if [ "$_tip" != "$_head_c" ]; then\n')],
    ["...naming the pushed file"])
mut("h04_deleted_ref_archived", [(DELLINE, ''), (TIPLINE, '    _tip="$_jr_lsha"\n')],
    ["SC5 deleting a remote branch goes through"])
mut("h04b_delete_guard_dropped_ALONE", [(DELLINE, '')],
    ["...and no misleading 'not a commit' note for the all-zero sha"])
mut("h05_remote_sha_ignored_for_existing_branches", [('    if [ -n "$_jr_rsha" ] && [ "$_jr_rsha" != "$ZERO" ] && git cat-file -e "${_jr_rsha}^{commit}" 2>/dev/null; then', '    if false; then')],
    ["SC8 a docs-only push to an existing branch is NOT refused for the untouched pkgA"])
mut("h06_upstream_step_dropped", [('    if [ -n "$_jr_up" ]; then\n        all_changed=$(git diff --name-only "$_jr_up" "$_tip"', '    if false; then\n        all_changed=$(git diff --name-only "$_jr_up" "$_tip"')],
    ["trunk as upstream, pkgA not installable: REFUSED"])
mut("h07_tags_get_the_unconditional_rule", [('    case "$_jr_lref" in refs/tags/*)\n', '    case "$_jr_lref" in refs/tags-off/*)\n')],
    ["SC9a a tag on a commit already in origin/develop: lands, runs nothing"])
mut("h08_non_commit_objects_gated", [('    [ -n "$_tip" ] || { _jr_skip=notcommit; return 0; }              # a tag of a blob or a tree is not code\n', '')],
    ["SC9c a tag that points at a BLOB is not a commit: not gated, said so, and lands"])
mut("h09_blockchain_dev_change_not_accumulated", [('    _changed_all="${_changed_all}${changed}"\n', '')],
    ["SC4 HEAD:other-name with a Blockchain/Dev change runs the preflight and lands"])
mut("h10_stale_flag_inverted_for_upstreams", [('        if [ "${_jr_up#*/}" != "$_jr_brname" ]; then st_base_stale=1; fi', '        if [ "${_jr_up#*/}" = "$_jr_brname" ]; then st_base_stale=1; fi')],
    ["...WITH the stale-base hint (that upstream is not this branch's own counterpart)"])
mut("h11_stale_flag_not_set_for_new_branches", [('    st_base_stale=1   # KS-998 item 1: a merge-base with origin/develop is only as fresh as the last fetch\n', '')],
    ["...and the hint: your origin/develop may be stale"])
mut("h12_gate_failure_does_not_refuse", [('    echo "           (bypass, sparingly: git push --no-verify)" >&2\n    exit 1\n}', '    echo "           (bypass, sparingly: git push --no-verify)" >&2\n}')],
    ["SC1 red at the pushed sha, fix uncommitted: the push is REFUSED"])
mut("h13_failing_ref_not_named", [('    echo "           ref: ${_lr} -> ${_rr} (commit $(_short "$_tip"))" >&2\n', '')],
    ["...the failing ref is named"])
mut("h14_force_push_judged_from_the_remote_tip", [('''        if git merge-base --is-ancestor "$_jr_rsha" "$_tip" 2>/dev/null; then
            _jr_b="$_jr_rsha"
        else
            _jr_b=$(git merge-base "$_jr_rsha" "$_tip" 2>/dev/null) || _jr_b=''      # a deliberate force push
        fi''', '        _jr_b="$_jr_rsha"')],
    ["SC12 ALLOW_FORCE=1: the rewrite goes through (docs only; pkgA's removal is not 'in this push')"])
mut("h15_tip_is_always_head", [(TIPLINE, '    _tip=$(git rev-parse HEAD 2>/dev/null)\n')],
    ["SC2 pushing a branch that is NOT checked out: its red systemTest file is caught", "SC3 a pushed sha that is not HEAD and changes Blockchain/Dev is REFUSED"])
mut("h16_all_mode_gate_runs_in_the_working_tree", [('FORMAT_GATE_TREE="$_tip" bash "$_fmt_gate" --all </dev/null', 'bash "$_fmt_gate" --all </dev/null')],
    ["SC13 --all (no base): the PUSHED red commit is refused though the working tree is fixed"])
mut("h17_tag_skip_applies_to_branches_too", [('    case "$_jr_lref" in refs/tags/*)\n', '    case "$_jr_lref" in refs/*)\n')],
    ["SC13 --all (no base): the PUSHED red commit is refused though the working tree is fixed"])
mut("h18_ref_lines_not_kept_for_judging", [('done <<EOF\n$_ref_lines\nEOF\nchanged="$_changed_all"', 'done </dev/null\nchanged="$_changed_all"')],
    ["SC1 red at the pushed sha, fix uncommitted: the push is REFUSED"])
def run(path, tag):
    fails = []; tallies = []
    for su in SUITES:
        p = subprocess.run(["/bin/bash", su], capture_output=True, text=True, env=dict(os.environ, HOOK_SH=path), timeout=400)
        open(f"{OUT}/{tag}.{os.path.basename(su)}.out", "w").write(p.stdout)
        m = re.findall(r"(\d+) passed, (\d+) failed", p.stdout); tallies.append((int(m[-1][0]), int(m[-1][1])) if m else (0, 0))
        fails += [l.strip()[5:] for l in p.stdout.splitlines() if l.strip().startswith("FAIL ")]
    return tallies, fails
t, f = run(HOOK, "00_control")
ok = all(b == 0 and a > 0 for a, b in t)
print(f"[{now()}] CONTROL unmutated hook: {t} -> {'GREEN' if ok else 'NOT GREEN - ABORT'}", flush=True)
if not ok: sys.exit(3)
res = {}
for name, edits, kills, survive in M:
    s = src; bad = None
    for old, new in edits:
        if s.count(old) != 1: bad = f"anchor found {s.count(old)}x: {old[:70]!r}"; break
        s = s.replace(old, new, 1)
    if bad: print(f"[{now()}] {name}: ANCHOR-ERROR {bad}", flush=True); res[name] = "ANCHOR-ERROR"; continue
    path = f"{OUT}/{name}.sh"; open(path, "w", encoding="utf-8").write(s)
    if subprocess.run(["/bin/sh", "-n", path], capture_output=True).returncode: print(f"[{now()}] {name}: DOES-NOT-PARSE", flush=True); res[name] = "LOADFAIL"; continue
    t, fails = run(path, name)
    if all(a == 0 and b == 0 for a, b in t): v = "LOADFAIL"
    elif sum(b for _, b in t) == 0: v = "SURVIVED-BY-DESIGN" if survive else "SURVIVED"
    else:
        miss = [k for k in kills if not any(k in x for x in fails)]
        v = "KILLED-BY-NAME" if kills and not miss else ("KILLED-BUT-NOT-BY-THE-NAMED-CELL" if kills else "KILLED (no name)")
    res[name] = v
    print(f"[{now()}] {name}: {v}  {t}" + (f"  MISSING {miss}" if v.startswith("KILLED-BUT") else "") + ("" if v.startswith("KILLED") else f"  first fails: {fails[:2]}"), flush=True)
import collections, json
print(f"[{now()}] DONE", dict(collections.Counter(res.values())), flush=True)
json.dump(res, open(f"{OUT}/results.json", "w"), indent=1)
