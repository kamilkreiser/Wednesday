#!/bin/bash
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad/g1540
E=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1540/evidence
until grep -q 'ALL DONE' $E/logs/SUMMARY_suites.txt 2>/dev/null; do sleep 5; done
mkdir -p $S/tmpA $S/tmpB $S/tmpH $S/tmpM
( TMPDIR=$S/tmpA python3 $S/tools/tamper_gate2.py $S/head/systemTest/scripts/check-package-format.sh $S/head/systemTest/__tests__/package_format_gate.test.sh $S/mutA $(cat $S/tools/shardA.txt) > $E/mutants/gate_shardA.log 2>&1 ) &
sleep 20
( TMPDIR=$S/tmpB python3 $S/tools/tamper_gate2.py $S/head/systemTest/scripts/check-package-format.sh $S/head/systemTest/__tests__/package_format_gate.test.sh $S/mutB $(cat $S/tools/shardB.txt) > $E/mutants/gate_shardB.log 2>&1 ) &
wait
( TMPDIR=$S/tmpH python3 $S/tools/tamper_hook2.py $S/head/.githooks/pre-push $S/mutH > $E/mutants/hook.log 2>&1 ) &
( TMPDIR=$S/tmpM python3 $S/tools/my_mutants.py $S/head $S/mutM > $E/mutants/mine.log 2>&1 ) &
wait
echo "MUTANTS ALL DONE $(date +%H:%M:%S)" >> $E/mutants/hook.log
