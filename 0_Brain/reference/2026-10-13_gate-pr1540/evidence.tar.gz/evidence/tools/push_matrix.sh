#!/bin/bash
# push_matrix.sh <hook> <gate> <workdir> : real `git push` to a bare remote, one scenario per row.
# Prints: ROW | rc | landed? | preflight ran? | refused-not-HEAD? | gate FAILED? | format-gate lines
set -u
HOOK=$1; GATE=$2; W=$3
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
export npm_config_cache="$W/npm-cache" npm_config_registry="http://127.0.0.1:9/"
rm -rf "$W"; mkdir -p "$W" "$W/npm-cache"
build() {
  local r=$W/$1
  (
  set -e
  mkdir -p $r; git init -q --bare -b main $r/origin.git
  git init -q -b main $r/seed; cd $r/seed
  git config user.email t@t.t; git config user.name t
  mkdir -p Blockchain/Dev/scripts/preflight systemTest/scripts "systemTest/pkgB/src" docs
  echo base > Blockchain/Dev/file.txt; echo docs > docs/readme.md
  printf '#!/usr/bin/env bash\necho "[preflight] ran in $(git rev-parse --short HEAD)"\nexit 0\n' > Blockchain/Dev/scripts/preflight/preflight.sh
  : > systemTest/slot-target.sh
  cp "$GATE" systemTest/scripts/check-package-format.sh
  printf 'node_modules/\nsystemTest/.format-gate-stage.*/\nsystemTest/.format-gate-tree.*/\n' > .gitignore
  printf '{ "name": "fixture-pkgB", "version": "0.0.0", "scripts": { "format:check": "sh check.sh" } }\n' > systemTest/pkgB/package.json
  # green only if every file under src (recursively, any name) says "good"
  cat > systemTest/pkgB/check.sh <<'SH'
rc=0
find src -type f -o -type l | while IFS= read -r f; do c=$(cat "$f" 2>/dev/null); [ "$c" = good ] || { echo "[warn] $f"; echo x > "${TMPDIR:-/tmp}/.pmx.$$"; }; done
[ -e "${TMPDIR:-/tmp}/.pmx.$$" ] && { rm -f "${TMPDIR:-/tmp}/.pmx.$$"; exit 1; }
exit 0
SH
  echo good > systemTest/pkgB/src/b.ts
  git add -A; git commit -qm init; git branch develop
  git remote add origin $r/origin.git; git push -q origin main develop
  cd $r; git clone -q $r/origin.git fresh; cd fresh
  git config user.email t@t.t; git config user.name t
  mkdir -p .githooks; cp "$HOOK" .githooks/pre-push; chmod +x .githooks/pre-push
  git config core.hooksPath .githooks; echo '.githooks/' >> .git/info/exclude
  mkdir -p systemTest/pkgB/node_modules/.bin
  printf '#!/bin/sh\nexit 0\n' > systemTest/pkgB/node_modules/.bin/prettier; chmod +x systemTest/pkgB/node_modules/.bin/prettier
  ) >/dev/null 2>&1 || { echo "BUILD FAIL $1"; exit 2; }
  cd $r/fresh
}
c() { mkdir -p "$(dirname "$1")"; printf '%s\n' "$2" > "$1"; git add -- "$1"; git commit -qm "touch $1"; }
has() { git ls-remote origin "$1" | wc -l | tr -d ' '; }
row() { # row <name> <ref-to-check-landed> <git push args...>
  local name=$1 ref=$2; shift 2
  local out rc
  out=$(git push "$@" 2>&1); rc=$?
  printf '%-58s rc=%-3s landed=%s preflight=%s notHEADrefusal=%s gateFAILED=%s fg=%s\n' "$name" "$rc" "$( [ "$ref" = - ] && echo - || has "$ref")" \
    "$(printf '%s' "$out" | grep -c '\[preflight\] ran')" "$(printf '%s' "$out" | grep -c 'REFUSED — this push sends')" \
    "$(printf '%s' "$out" | grep -c 'formatting gate FAILED')" "$(printf '%s' "$out" | grep -c '^\[format-gate\]')"
  printf '%s\n' "$out" | sed 's/^/      | /' >> $W/full.log
  echo "=== $name" >> $W/full.log
}

# R1 new branch from HEAD, systemTest-only green
build r1; git checkout -q -b f1 --no-track origin/develop; c systemTest/pkgB/src/n.ts good
row "R1 new branch = HEAD, systemTest green" refs/heads/f1 origin f1
# R2 existing branch, fast-forward, systemTest red
c systemTest/pkgB/src/n.ts bad
row "R2 existing branch ff, systemTest RED (HEAD)" - origin f1
git reset -q --hard HEAD~1
# R3 deletion
row "R3 delete existing branch" refs/heads/f1 origin :f1
# R4 tag on non-HEAD, non-trunk commit with Blockchain/Dev change
build r4; git checkout -q -b f4 --no-track origin/develop; c Blockchain/Dev/file.txt x; git push -q --no-verify origin f4; git tag t4; git checkout -q main
row "R4 tag on ALREADY-PUSHED feature commit, HEAD=main" refs/tags/t4 origin t4
git checkout -q f4
row "R4b same tag, HEAD = that commit" refs/tags/t4 origin t4
# R5 non-HEAD sha changes Blockchain/Dev -> must refuse
build r5; git checkout -q -b f5 --no-track origin/develop; c Blockchain/Dev/file.txt y; git checkout -q main
row "R5 non-HEAD branch changes Blockchain/Dev" refs/heads/f5 origin f5
# R6 non-HEAD sha docs only -> must pass
git checkout -q -b f6 --no-track origin/develop; c docs/readme.md z; git checkout -q main
row "R6 non-HEAD branch docs only" refs/heads/f6 origin f6
# R7 several refs, one bad (systemTest red, non-HEAD)
git checkout -q -b g7 --no-track origin/develop; c systemTest/pkgB/src/g.ts good
git checkout -q -b b7 --no-track origin/develop; c systemTest/pkgB/src/g.ts bad
git checkout -q main
row "R7 three refs: f6(docs) g7(green) b7(RED)" refs/heads/g7 origin f6 g7 b7
# R8 src:dst refspec, dst existing at remote (fast-forward develop by a feature) systemTest red
build r8; git checkout -q -b f8 --no-track origin/develop; c systemTest/pkgB/src/d.ts bad; git checkout -q main
row "R8 f8:develop (dst exists, ff), RED, non-HEAD" - origin f8:develop
git checkout -q f8; printf 'good\n' > systemTest/pkgB/src/d.ts; git commit -qam fix
git checkout -q main
row "R8b f8:develop after fix commit, non-HEAD" refs/heads/develop origin f8:develop
# R9 detached HEAD with Blockchain/Dev change
build r9; git checkout -q --detach origin/develop; c Blockchain/Dev/file.txt det
row "R9 detached HEAD:refs/heads/det (Blockchain/Dev)" refs/heads/det origin HEAD:refs/heads/det
# R10 dirty tree: commit GREEN, working tree RED -> must PASS
build r10; git checkout -q -b f10 --no-track origin/develop; c systemTest/pkgB/src/w.ts good; echo bad > systemTest/pkgB/src/w.ts; echo bad > systemTest/pkgB/src/untracked.ts
row "R10 commit GREEN, working tree RED + untracked red" refs/heads/f10 origin f10
git checkout -q -- .; rm -f systemTest/pkgB/src/untracked.ts
# R11 dirty tree: commit RED, working tree GREEN -> must refuse
c systemTest/pkgB/src/w.ts bad; echo good > systemTest/pkgB/src/w.ts
row "R11 commit RED, working tree GREEN" - origin f10
git checkout -q -- .
# R12 new branch at a trunk commit while HEAD elsewhere (nothing new lands)
build r12; git checkout -q -b f12 --no-track origin/develop; c docs/readme.md q
git branch rel origin/develop
row "R12 new branch 'rel' AT origin/develop, HEAD=f12" refs/heads/rel origin rel
row "R12b raw ref origin/develop:refs/heads/rel2" refs/heads/rel2 origin origin/develop:refs/heads/rel2
# R13 raw sha refspec, systemTest red, non-HEAD
git checkout -q -b f13 --no-track origin/develop; c systemTest/pkgB/src/s.ts bad; SHA=$(git rev-parse HEAD); git checkout -q f12
row "R13 <sha>:refs/heads/x13 RED non-HEAD" refs/heads/x13 origin $SHA:refs/heads/x13
# R14 force push (ALLOW_FORCE) of a RED rewrite, non-HEAD
build r14; git checkout -q -b f14 --no-track origin/develop; c systemTest/pkgB/src/f.ts good; git push -q --no-verify origin f14
git checkout -q -B f14 origin/develop; c systemTest/pkgB/src/f.ts bad; git checkout -q main
ALLOW_FORCE=1 row "R14 ALLOW_FORCE rewrite to RED, non-HEAD" - origin +f14
# R15 unborn HEAD (orphan, no commit) pushing a branch with Blockchain/Dev change
build r15; git checkout -q -b f15 --no-track origin/develop; c Blockchain/Dev/file.txt u; git checkout -q --orphan unborn; git rm -rq --cached . >/dev/null
row "R15 HEAD unborn, push f15 (Blockchain/Dev)" refs/heads/f15 origin f15
# R16 push develop (ff merge of a feature that touches Blockchain/Dev) while on the feature branch
build r16; git checkout -q -b f16 --no-track origin/develop; c Blockchain/Dev/file.txt m; git branch -f develop f16; git checkout -q -b f16b; c docs/readme.md after
row "R16 develop (ff, Blockchain/Dev) while HEAD=f16b" refs/heads/develop origin develop
# R17 file DELETED in the push (pkgB src file removed), red elsewhere absent -> pass; and package removed entirely
build r17; git checkout -q -b f17 --no-track origin/develop; git rm -q systemTest/pkgB/src/b.ts; c systemTest/pkgB/src/keep.ts good
row "R17 a file deleted in the push" refs/heads/f17 origin f17
git checkout -q -b f17b --no-track origin/develop; git rm -rq systemTest/pkgB; git commit -qm rmpkg
row "R17b the whole package removed in the push" refs/heads/f17b origin f17b
echo DONE
