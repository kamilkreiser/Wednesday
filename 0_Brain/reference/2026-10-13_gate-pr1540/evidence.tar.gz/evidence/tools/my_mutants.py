#!/usr/bin/env python3
"""Gate-1540 reviewer's own mutants. Each is a copy of the gate or the hook with exact-once edits.
Gate mutants run the gate suite AND the hook suite (PACKAGE_FORMAT_GATE_SH); hook mutants run the three hook suites
(HOOK_SH). Reports every FAIL line by cell name. A comment-only control must redden nothing."""
import os, re, subprocess, sys, json, time
HEAD, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
GATE = HEAD + "/systemTest/scripts/check-package-format.sh"; HOOK = HEAD + "/.githooks/pre-push"
GS = HEAD + "/systemTest/__tests__/package_format_gate.test.sh"
T = HEAD + "/Blockchain/Dev/scripts/__tests__/"
HS = [T + "ks998_pre_push_judges_the_push.test.sh", T + "ks998_pre_push_stale_base_hint.test.sh", T + "pre_push_hook_base.test.sh"]
gsrc = open(GATE).read(); hsrc = open(HOOK).read()
M = []
def g(name, edits): M.append(("gate", name, edits))
def h(name, edits): M.append(("hook", name, edits))
# controls
g("X00_gate_comment_only_CONTROL", [("# The ONLY place this script deletes a directory", "# (mutated comment) The ONLY place this script deletes a directory")])
h("X00_hook_comment_only_CONTROL", [("# KS-998 item 2 / KS-1483 - JUDGE EACH PUSHED REF, NOT HEAD.", "# (mutated comment) KS-998 item 2 / KS-1483 - JUDGE EACH PUSHED REF, NOT HEAD.")])
FC = '    if [ -n "$changed" ] && [ "$_tip" != "$_head_c" ]; then\n'
h("X01_not_HEAD_refusal_inverted", [(FC, '    if [ -n "$changed" ] && [ "$_tip" = "$_head_c" ]; then\n')])
h("X02_refusal_skipped_for_tags", [(FC, '    if [ -n "$changed" ] && [ "$_tip" != "$_head_c" ] && case "$_lr" in refs/tags/*) false ;; *) true ;; esac; then\n')])
h("X03_stale_flag_never_passed", [('FORMAT_GATE_BASE_MAY_BE_STALE="$st_base_stale" bash', 'FORMAT_GATE_BASE_MAY_BE_STALE=0 bash')])
h("X04_head_c_is_the_upstream", [('_head_c=$(git rev-parse HEAD 2>/dev/null || true)', "_head_c=$(git rev-parse '@{upstream}' 2>/dev/null || git rev-parse HEAD)")])
ARCH = '''        out="could not archive systemTest/$p at ${TREE_SHA}: $(cat "$tree/.archive.err" 2>/dev/null)"; rc=125\n'''
g("X05_archive_error_falls_back_to_working_tree", [(ARCH, '''        out="$(cd "$dir" && npm run --silent format:check < /dev/null 2>&1)"; rc=$?\n''')])
g("X06_archive_HEAD_not_the_pushed_commit", [('git -C "$REPO_ROOT" archive "$TREE_SHA" -- "systemTest/$p" $anc', 'git -C "$REPO_ROOT" archive HEAD -- "systemTest/$p" $anc')])
g("X07_discovery_from_HEAD_tree", [('done < <(git -C "$REPO_ROOT" ls-tree --name-only "$TREE_SHA" systemTest/ 2>/dev/null)', 'done < <(git -C "$REPO_ROOT" ls-tree --name-only HEAD systemTest/ 2>/dev/null)')])
g("X08_quit_trap_exits_0", [("trap '_fg_cleanup; exit 131' QUIT", "trap '_fg_cleanup; exit 0' QUIT")])
g("X09_int_trap_exits_0", [("trap '_fg_cleanup; exit 130' INT", "trap '_fg_cleanup; exit 0' INT")])
g("X10_hup_trap_exits_0", [("trap '_fg_cleanup; exit 129' HUP", "trap '_fg_cleanup; exit 0' HUP")])
g("X11_no_perl_silent_pid_only_fallback", [('    if [ "$HAVE_PERL" -ne 1 ]; then\n        INST_STATE="nopgrp"; INST_RC=1; return 0', '    if false; then\n        INST_STATE="nopgrp"; INST_RC=1; return 0')])
g("X12_marker_check_reads_wrong_name", [('        elif [ ! -f "$dir/node_modules/$tag" ]; then', '        elif [ ! -f "$dir/node_modules/.format-gate-moved.0" ]; then')])
g("X13_tree_check_rc_ignored", [('    wait "$_FG_CHK_PID" 2>/dev/null; rc=$?', '    wait "$_FG_CHK_PID" 2>/dev/null; rc=0')])
g("X14_ancestor_config_from_working_tree_HEAD", [('    anc="$(git -C "$REPO_ROOT" ls-tree --name-only "$TREE_SHA" -- $ANC_CANDIDATES 2>/dev/null)"', '    anc="$(git -C "$REPO_ROOT" ls-tree --name-only HEAD -- $ANC_CANDIDATES 2>/dev/null)"')])
g("X15_notintree_remedy_is_npm_ci", [('        if [ "${INST_STATE:-}" = "notintree" ]; then', '        if false; then')])
g("X16_move_back_ignores_rename_failure", [('            if [ "$rrc" -eq 0 ]; then INST_STATE="mvbroken"; else INST_STATE="mvstuck"; fi', '            INST_STATE="mvbroken"; rm -rf "$dir/node_modules"')])

def tally(out):
    m = re.findall(r"(\d+) passed, (\d+) failed", out); return (int(m[-1][0]), int(m[-1][1])) if m else (0, 0)
def run(env_extra, suites, tag):
    res = []; fails = []
    for su in suites:
        p = subprocess.run(["/bin/bash", su], capture_output=True, text=True, env=dict(os.environ, **env_extra), timeout=1500)
        open(f"{OUT}/{tag}.{os.path.basename(su)}.out", "w").write(p.stdout + "\n--- stderr ---\n" + p.stderr[-4000:])
        res.append((os.path.basename(su).replace(".test.sh", ""),) + tally(p.stdout))
        fails += [os.path.basename(su).split(".")[0] + ": " + l.strip()[5:].strip() for l in p.stdout.splitlines() if l.strip().startswith("FAIL ")]
    return res, fails
only = set(sys.argv[3:])
results = {}
for kind, name, edits in M:
    if only and name not in only: continue
    s = gsrc if kind == "gate" else hsrc
    for o, n in edits:
        assert s.count(o) == 1, f"{name}: anchor x{s.count(o)}: {o[:70]!r}"
        s = s.replace(o, n, 1)
    path = f"{OUT}/{name}.sh"; open(path, "w").write(s)
    sh = "/bin/bash" if kind == "gate" else "/bin/sh"
    if subprocess.run([sh, "-n", path], capture_output=True).returncode: print(name, "DOES NOT PARSE", flush=True); continue
    t = time.time()
    if kind == "gate": r, f = run({"PACKAGE_FORMAT_GATE_SH": path}, [GS, HS[0]], name)
    else: r, f = run({"HOOK_SH": path}, HS, name)
    v = "SURVIVED" if not f and all(a > 0 for _, a, _ in r) else ("LOADFAIL" if not f else f"KILLED({len(f)})")
    results[name] = dict(verdict=v, tallies=r, fails=f, secs=round(time.time() - t))
    print(f"{time.strftime('%H:%M:%S')} {name}: {v} {r} first: {f[:3]}", flush=True)
json.dump(results, open(f"{OUT}/my_results.json", "w"), indent=1)
