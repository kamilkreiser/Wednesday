#!/bin/bash
# pgroup.sh <gate> <workdir> <label>: process-group behaviour of the install (stub npm with a TERM-handling GRANDCHILD)
# Distinguishes "the grandchild got TERM (graceful)" from "only the final group KILL reached it" and counts survivors.
set -u
GATE=$1; W=$2; L=$3
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null npm_config_registry="http://127.0.0.1:9/"
rm -rf "$W"; mkdir -p "$W/bin" "$W/pids"
REAL_NPM=$(command -v npm)
cat > "$W/grand.sh" <<'G'
#!/bin/bash
# grandchild of npm: records its pid, records TERM if it gets one, optionally ignores TERM
echo $$ >> "$PIDDIR/grand.pids"
if [ "${GRAND_MODE:-graceful}" = deaf ]; then trap '' TERM; else trap 'echo $$ >> "$PIDDIR/grand.gotterm"; exit 0' TERM; fi
while :; do sleep 0.1; done
G
cat > "$W/bin/npm" <<'N'
#!/bin/bash
if [ "${1:-}" = ci ]; then
  echo $$ > "$PIDDIR/npm.pid"
  bash "$GRAND" &          # a grandchild of the gate (child of this npm), same process group as npm
  wait                     # npm dies on TERM (default disposition), leaving the grandchild
  exit 1
fi
exec "$REAL_NPM" "$@"
N
chmod +x "$W/bin/npm" "$W/grand.sh"
export GRAND="$W/grand.sh" REAL_NPM
mk() { local r=$W/$1; mkdir -p $r/systemTest/scripts $r/systemTest/p; cp "$GATE" $r/systemTest/scripts/check-package-format.sh
  printf '{ "name": "p", "version": "0.0.0", "scripts": { "format:check": "exit 0" } }\n' > $r/systemTest/p/package.json
  ( cd $r && git init -q -b main . && git add -A && git -c user.email=t@t.t -c user.name=t commit -qm i ); echo $r; }
alive() { local n=0 p; for p in $(cat "$PIDDIR/grand.pids" 2>/dev/null); do ps -p $p >/dev/null 2>&1 && n=$((n+1)); done; echo $n; }
reap() { for p in $(cat "$PIDDIR/grand.pids" 2>/dev/null); do kill -KILL $p 2>/dev/null; done; pkill -KILL -f "$W/grand.sh" 2>/dev/null; }
for mode in graceful deaf; do
  # A) watchdog path
  export PIDDIR=$W/pids/wd-$mode; mkdir -p $PIDDIR; R=$(mk wd-$mode)
  t0=$(python3 -c 'import time;print(int(time.time()*1000))')
  out=$(printf 'systemTest/p/x\n' | PATH="$W/bin:$PATH" GRAND_MODE=$mode FORMAT_GATE_INSTALL_TIMEOUT=2 bash $R/systemTest/scripts/check-package-format.sh 2>&1); rc=$?
  t1=$(python3 -c 'import time;print(int(time.time()*1000))'); sleep 0.3
  echo "$L watchdog  [$mode] rc=$rc $((t1-t0))ms timeout-line=$(printf '%s' "$out" | grep -c 'timed out after 2s') grandchild_got_TERM=$(cat $PIDDIR/grand.gotterm 2>/dev/null | wc -l | tr -d ' ') survivors=$(alive) stages=$(ls -A $R/systemTest | grep -c format-gate-stage)"
  reap
  # B) SIGTERM to the gate mid-install (cleanup path)
  export PIDDIR=$W/pids/term-$mode; mkdir -p $PIDDIR; R=$(mk term-$mode)
  printf 'systemTest/p/x\n' | PATH="$W/bin:$PATH" GRAND_MODE=$mode FORMAT_GATE_INSTALL_TIMEOUT=60 bash $R/systemTest/scripts/check-package-format.sh > $W/out.$mode 2>&1 &
  g=$!; for i in $(seq 1 100); do [ -s $PIDDIR/grand.pids ] && break; sleep 0.1; done; sleep 0.3
  pre=$(alive); kill -TERM $g; wait $g; rc=$?; sleep 0.3
  echo "$L SIGTERM   [$mode] rc=$rc in-flight-before=$pre grandchild_got_TERM=$(cat $PIDDIR/grand.gotterm 2>/dev/null | wc -l | tr -d ' ') survivors=$(alive) stages=$(ls -A $R/systemTest | grep -c format-gate-stage)"
  reap
done
