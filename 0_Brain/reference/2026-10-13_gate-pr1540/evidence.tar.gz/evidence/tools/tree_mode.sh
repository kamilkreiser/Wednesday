#!/bin/bash
# tree_mode.sh <gate> <workdir>: FORMAT_GATE_TREE attacks on a fixture repo (gate run directly, stdin = changed paths)
set -u
GATE=$1; W=$2
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null npm_config_registry="http://127.0.0.1:9/"
rm -rf "$W"; mkdir -p "$W"
mk() { # mk <name>: fresh repo with pkgB (check.sh: every file under src must say good), deps present (stub prettier)
  local r=$W/$1; mkdir -p $r; cd $r; git init -q -b main .; git config user.email t@t.t; git config user.name t
  mkdir -p systemTest/scripts systemTest/pkgB/src; cp "$GATE" systemTest/scripts/check-package-format.sh
  printf 'node_modules/\nsystemTest/.format-gate-stage.*/\nsystemTest/.format-gate-tree.*/\n' > .gitignore
  printf '{ "name": "p", "version": "0.0.0", "scripts": { "format:check": "sh check.sh" } }\n' > systemTest/pkgB/package.json
  cat > systemTest/pkgB/check.sh <<'SH'
n=0; bad=0
while IFS= read -r -d '' f; do n=$((n+1)); [ "$(cat "$f" 2>/dev/null)" = good ] || { echo "[warn] ${f#./}"; bad=1; }; done < <(find src \( -type f -o -type l \) -print0)
echo "checked $n file(s)" >&2
exit $bad
SH
  sed -i '' '1i\
#!/bin/bash
' systemTest/pkgB/check.sh
  printf '{ "name": "p", "version": "0.0.0", "scripts": { "format:check": "bash check.sh" } }\n' > systemTest/pkgB/package.json
  echo good > systemTest/pkgB/src/a.ts
  git add -A; git commit -qm init
  mkdir -p systemTest/pkgB/node_modules/.bin; printf '#!/bin/sh\nexit 0\n' > systemTest/pkgB/node_modules/.bin/prettier; chmod +x systemTest/pkgB/node_modules/.bin/prettier
}
gate() { # gate <label> <sha> <paths...>
  local label=$1 sha=$2; shift 2
  local out rc
  out=$(printf '%s\n' "$@" | FORMAT_GATE_TREE=$sha bash systemTest/scripts/check-package-format.sh 2>&1); rc=$?
  printf '%-70s rc=%s  trees_left=%s  | %s\n' "$label" "$rc" "$(ls -A systemTest | grep -c '^\.format-gate-tree')" "$(printf '%s' "$out" | grep -E 'FAILED|OK|REFUSED|checked [0-9]|could not|SKIP' | tr '\n' ' ' | cut -c1-200)"
}

echo "== T3a export-ignore in the PUSHED commit's .gitattributes hides a red file (working tree mode as control)"
mk t3a; echo bad > systemTest/pkgB/src/red.ts; printf 'src/red.ts export-ignore\n' > systemTest/pkgB/.gitattributes; git add -A; git commit -qm red
gate "T3a tree mode, red.ts export-ignore'd by the pushed .gitattributes" HEAD systemTest/pkgB/src/red.ts systemTest/pkgB/.gitattributes
out=$(printf 'systemTest/pkgB/src/red.ts\n' | bash systemTest/scripts/check-package-format.sh 2>&1); echo "   CONTROL working-tree mode same commit: rc=$? $(printf '%s' "$out" | grep -E 'FAILED|OK' | tr '\n' ' ')"
echo "== T3b export-ignore from .git/info/attributes (developer-local, not in any commit)"
mk t3b; echo bad > systemTest/pkgB/src/red.ts; git add -A; git commit -qm red
gate "T3b CONTROL no attributes: red is caught" HEAD systemTest/pkgB/src/red.ts
printf '*.ts export-ignore\n' > .git/info/attributes
gate "T3b info/attributes '*.ts export-ignore'" HEAD systemTest/pkgB/src/red.ts
echo "== T3c export-subst rewrites content"
mk t3c; printf 'good$Format:%%H$\n' > systemTest/pkgB/src/s.ts; printf 'src/s.ts export-subst\n' > systemTest/pkgB/.gitattributes; git add -A; git commit -qm s
gate "T3c export-subst (file says good\$Format\$ - red in WT, archive expands)" HEAD systemTest/pkgB/src/s.ts
echo "== T3d a file only in the WORKING TREE (untracked red) does not change the verdict; only in the COMMIT (deleted in WT) does"
mk t3d; echo bad > systemTest/pkgB/src/untracked.ts
gate "T3d untracked red file in WT, commit green" HEAD systemTest/pkgB/src/a.ts
rm -f systemTest/pkgB/src/untracked.ts; echo bad > systemTest/pkgB/src/c.ts; git add -A; git commit -qm c; rm systemTest/pkgB/src/c.ts
gate "T3d red file in commit, deleted from WT" HEAD systemTest/pkgB/src/c.ts
echo "== T3e symlink in the pushed commit pointing OUTSIDE the tree / dangling"
mk t3e; echo bad > $W/outside_red.txt; ln -s $W/outside_red.txt systemTest/pkgB/src/link.ts; git add -A; git commit -qm link
gate "T3e src/link.ts -> absolute outside file (red)" HEAD systemTest/pkgB/src/link.ts
ln -s ../../../../nonexistent systemTest/pkgB/src/dang.ts; git rm -q --cached systemTest/pkgB/src/link.ts; rm systemTest/pkgB/src/link.ts; git add -A; git commit -qm dang
gate "T3e dangling symlink" HEAD systemTest/pkgB/src/dang.ts
echo "== T3f paths with spaces / newline / glob chars"
mk t3f; printf 'bad\n' > "systemTest/pkgB/src/sp ace [x]*.ts"; printf 'bad\n' > "systemTest/pkgB/src/nl
ine.ts"; git add -A; git commit -qm weird
gate "T3f red files 'sp ace [x]*.ts' and 'nl<LF>ine.ts'" HEAD "systemTest/pkgB/src/sp ace [x]*.ts"
echo "== T3g rename (git mv) of a red file"
mk t3g; echo bad > systemTest/pkgB/src/r.ts; git add -A; git commit -qm r; git mv systemTest/pkgB/src/r.ts systemTest/pkgB/src/r2.ts; git commit -qm mv
gate "T3g renamed red file (only the new path in the push)" HEAD systemTest/pkgB/src/r2.ts systemTest/pkgB/src/r.ts
echo "== T3h submodule under the package"
mk t3h; git init -q $W/sub; git -C $W/sub -c user.email=t@t.t -c user.name=t commit -q --allow-empty -m s; echo bad > $W/sub/x.ts; git -C $W/sub add x.ts; git -C $W/sub -c user.email=t@t.t -c user.name=t commit -qm x
git -c protocol.file.allow=always submodule -q add $W/sub systemTest/pkgB/src/sub 2>/dev/null; git commit -qm sub
gate "T3h submodule with a red file (WT has it checked out)" HEAD systemTest/pkgB/src/sub
out=$(printf 'systemTest/pkgB/src/sub\n' | bash systemTest/scripts/check-package-format.sh 2>&1); echo "   CONTROL working-tree mode: rc=$? $(printf '%s' "$out" | grep -E 'FAILED|OK' | tr '\n' ' ')"
echo "== T3i non-ASCII package name (core.quotePath)"
mk t3i; mkdir -p "systemTest/pkgé/src"; cp systemTest/pkgB/package.json systemTest/pkgB/check.sh "systemTest/pkgé/"; echo bad > "systemTest/pkgé/src/x.ts"; cp -R systemTest/pkgB/node_modules "systemTest/pkgé/"; git add -A; git commit -qm nonascii
gate "T3i red file in systemTest/pkgé (tree mode)" HEAD "systemTest/pkgé/src/x.ts"
out=$(printf 'systemTest/pkgé/src/x.ts\n' | bash systemTest/scripts/check-package-format.sh 2>&1); echo "   CONTROL working-tree mode: rc=$? $(printf '%s' "$out" | grep -E 'FAILED|OK' | tr '\n' ' ')"
echo "== T3j huge diff: 20000 files in the push"
mk t3j; for i in $(seq 1 20000); do echo good > systemTest/pkgB/src/f$i.ts; done; echo bad > systemTest/pkgB/src/f19999.ts; git add -A; git commit -qm huge
t0=$(date +%s); gate "T3j 20000 files, one red" HEAD $(git diff --name-only HEAD~1 HEAD | head -3); echo "   wall $(( $(date +%s)-t0 ))s"
echo "== T3k committed node_modules/.bin/prettier and package.json script in the PUSHED commit run (what the gate EXECUTES)"
mk t3k; git checkout -q -b evil; SENT=$W/SENTINEL_pushed_script_ran
printf '{ "name": "p", "version": "0.0.0", "scripts": { "format:check": "touch %s; bash check.sh" } }\n' "$SENT" > systemTest/pkgB/package.json; git add -A; git commit -qm evil; EV=$(git rev-parse HEAD); git checkout -q main
rm -f $SENT; gate "T3k pushed commit (NOT checked out) changes format:check script" $EV systemTest/pkgB/package.json; echo "   sentinel written by the pushed commit's script: $( [ -e $SENT ] && echo YES || echo no)"
rm -f $SENT; out=$(printf 'systemTest/pkgB/package.json\n' | bash systemTest/scripts/check-package-format.sh 2>&1); echo "   CONTROL working-tree mode (main checked out): sentinel $( [ -e $SENT ] && echo YES || echo no)"
git checkout -q evil; printf 'node-options=--require %s/evil.js\n' "$W" > systemTest/pkgB/.npmrc; printf 'require("fs").writeFileSync("%s.npmrc","x")\n' "$SENT" > $W/evil.js
printf '{ "name": "p", "version": "0.0.0", "scripts": { "format:check": "bash check.sh" } }\n' > systemTest/pkgB/package.json; git add -A; git commit -qm npmrc; EV2=$(git rev-parse HEAD); git checkout -q main
rm -f $SENT.npmrc; gate "T3k2 pushed commit adds a package .npmrc node-options --require" $EV2 systemTest/pkgB/.npmrc; echo "   sentinel via pushed .npmrc: $( [ -e $SENT.npmrc ] && echo YES || echo no)"
echo DONE
