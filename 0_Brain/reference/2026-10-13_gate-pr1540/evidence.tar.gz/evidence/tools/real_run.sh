#!/bin/bash
# real_run.sh: the head gate on the four REAL packages, tree mode, real registry, EMPTY npm cache, in a scratch worktree
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad/g1540
R=$S/real
git -C $S/repo worktree add --detach $R c6d103ffc4692cb075287eb8143715989abeafab >/dev/null 2>&1
git -C $R rev-parse HEAD
export npm_config_cache=$S/real_cache; mkdir -p $npm_config_cache
echo "CONTROL before: status lines=$(git -C $R status --porcelain | wc -l | tr -d ' ') node_modules present: $(ls -d $R/systemTest/*/node_modules 2>/dev/null | wc -l | tr -d ' ') cache entries: $(find $npm_config_cache -type f | wc -l | tr -d ' ')"
for p in akto api-explorer performance playwright; do shasum -a 256 $R/systemTest/$p/package-lock.json; done > $S/real_locks_before.txt
PATHS=$(for p in akto api-explorer performance playwright; do git -C $R ls-files systemTest/$p | grep -v package | head -1; done)
echo "$PATHS"
t0=$(python3 -c 'import time;print(time.time())')
printf '%s\n' "$PATHS" | FORMAT_GATE_TREE=$(git -C $R rev-parse HEAD) bash $R/systemTest/scripts/check-package-format.sh; rc=$?
t1=$(python3 -c 'import time;print(time.time())')
echo "rc=$rc wall=$(python3 -c "print(round($t1-$t0,1))")s"
echo "after: status lines=$(git -C $R status --porcelain | wc -l | tr -d ' ') stage/tree dirs=$(ls -A $R/systemTest | grep -c '^\.format-gate-')"
for p in akto api-explorer performance playwright; do echo "  $p: prettier_x=$([ -x $R/systemTest/$p/node_modules/.bin/prettier ] && echo yes || echo NO) markers=$(ls -A $R/systemTest/$p/node_modules | grep -c format-gate-moved) size=$(du -sm $R/systemTest/$p/node_modules | cut -f1)MB"; done
for p in akto api-explorer performance playwright; do shasum -a 256 $R/systemTest/$p/package-lock.json; done | diff - $S/real_locks_before.txt && echo "lockfiles byte-identical"
echo "== second run (installed): tree mode vs working-tree mode"
t0=$(python3 -c 'import time;print(time.time())'); printf '%s\n' "$PATHS" | FORMAT_GATE_TREE=HEAD bash $R/systemTest/scripts/check-package-format.sh >/dev/null 2>&1; rc=$?; t1=$(python3 -c 'import time;print(time.time())'); echo "tree mode rc=$rc $(python3 -c "print(round($t1-$t0,1))")s"
t0=$(python3 -c 'import time;print(time.time())'); printf '%s\n' "$PATHS" | bash $R/systemTest/scripts/check-package-format.sh >/dev/null 2>&1; rc=$?; t1=$(python3 -c 'import time;print(time.time())'); echo "working-tree mode rc=$rc $(python3 -c "print(round($t1-$t0,1))")s"
echo "== CONTROL the real gate CAN fail in tree mode: a committed misformatted file in playwright (scratch commit in the scratch worktree)"
f=$(git -C $R ls-files systemTest/playwright | grep -E '\.ts$' | head -1); printf 'const   x    =1\n' >> $R/$f
git -C $R -c user.email=t@t.t -c user.name=t commit -qam "scratch red" ; red=$(git -C $R rev-parse HEAD)
git -C $R checkout -q HEAD~1 -- $f   # working tree back to green, commit stays red
printf '%s\n' "$f" | FORMAT_GATE_TREE=$red bash $R/systemTest/scripts/check-package-format.sh 2>&1 | tail -6; echo "rc=${PIPESTATUS[1]}"
