#!/bin/bash
# Gate 1540 baseline suite runner (head + develop red/green, controls, nohup shape, dash, bash 3.2)
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad/g1540
E=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1540/evidence/logs
H=$S/head; D=$S/dev; GT=$S/gates
export TMPDIR=$S/tmp; mkdir -p $TMPDIR
GS=$H/systemTest/__tests__/package_format_gate.test.sh
HS=$H/Blockchain/Dev/scripts/__tests__/ks998_pre_push_judges_the_push.test.sh
sum() { grep -E '[0-9]+ passed, [0-9]+ failed' "$1" | tail -1; }
run() { # run <tag> <cmd...>
  local tag=$1; shift; local t0=$(date +%s)
  "$@" > $E/$tag.log 2>&1; local rc=$?
  echo "$(date +%H:%M:%S) $tag rc=$rc $(( $(date +%s)-t0 ))s :: $(sum $E/$tag.log)" | tee -a $E/SUMMARY_suites.txt
}
# controls
sed '2i\
exit 0' $GT/gate_c6d103ffc.sh > $GT/C1_gate_exit0.sh
sed '2i\
exit 0' $GT/hook_c6d103ffc.sh > $GT/C3_hook_exit0.sh
sed '1s|.*|#!/bin/dash|' $GT/hook_c6d103ffc.sh > $GT/hook_dash.sh
sed '1s|.*|#!/bin/bash|' $GT/hook_c6d103ffc.sh > $GT/hook_bash32.sh
# dash control: a bashism ([[ ]]) inside _judge_ref must redden under dash
awk '{print} /^_judge_ref\(\) \{/{print "    [[ x == x ]] || { _jr_skip=empty; return 0; }"}' $GT/hook_dash.sh > $GT/hook_dash_bashism.sh
chmod +x $GT/*.sh

for i in 1 2; do run G_head_$i /bin/bash $GS; done
for i in 1 2; do run G_red_develop_$i env PACKAGE_FORMAT_GATE_SH=$GT/gate_a7cffc8d9.sh /bin/bash $GS; done
run G_red_3d14856c3 env PACKAGE_FORMAT_GATE_SH=$GT/gate_3d14856c3.sh /bin/bash $GS
run G_C1_exit0 env PACKAGE_FORMAT_GATE_SH=$GT/C1_gate_exit0.sh /bin/bash $GS
run G_head_nohup_QUIT_INT_ignored /bin/bash -c "trap '' QUIT INT; exec /bin/bash $GS"

for i in 1 2; do run H_head_$i /bin/bash $HS; done
for i in 1 2; do run H_red_develop_$i env HOOK_SH=$GT/hook_a7cffc8d9.sh PACKAGE_FORMAT_GATE_SH=$GT/gate_a7cffc8d9.sh /bin/bash $HS; done
run H_head_dash env HOOK_SH=$GT/hook_dash.sh /bin/bash $HS
run H_head_bash32 env HOOK_SH=$GT/hook_bash32.sh /bin/bash $HS
run H_C_dash_bashism env HOOK_SH=$GT/hook_dash_bashism.sh /bin/bash $HS
run H_C3_exit0 env HOOK_SH=$GT/C3_hook_exit0.sh /bin/bash $HS

for su in ks998_pre_push_stale_base_hint pre_push_hook_base pre_push_hook_base_fixture_guard pre_push_hook_current_develop ks884_pre_push_tag_named_develop pre_push_hook_base_leg_comment pre_push_stack_legs_comment; do
  for i in 1 2; do run O_head_${su}_$i /bin/bash $H/Blockchain/Dev/scripts/__tests__/$su.test.sh; done
  run O_develop_${su} /bin/bash $D/Blockchain/Dev/scripts/__tests__/$su.test.sh
  case $su in pre_push_hook_base_leg_comment|pre_push_stack_legs_comment) ;; *)
    run O_C3_${su} env HOOK_SH=$GT/C3_hook_exit0.sh /bin/bash $H/Blockchain/Dev/scripts/__tests__/$su.test.sh ;; esac
done
echo "$(date +%H:%M:%S) ALL DONE" | tee -a $E/SUMMARY_suites.txt
