#!/bin/bash
# rm_stage.sh <gate> <workdir>: _rm_stage extracted verbatim from the gate and attacked (stage AND tree prefixes)
set -u
GATE=$1; W=$2; rm -rf "$W"; mkdir -p "$W/repo/systemTest/pkg" "$W/outside"
REPO_ROOT=$W/repo
STAGE_PREFIX="$REPO_ROOT/systemTest/.format-gate-stage."
TREE_PREFIX="$REPO_ROOT/systemTest/.format-gate-tree."
eval "$(awk '/^_rm_stage\(\) \{/,/^\}/' "$GATE")"
type _rm_stage >/dev/null || { echo "could not extract"; exit 2; }
sent() { echo keep > $REPO_ROOT/SENT_root; echo keep > $REPO_ROOT/systemTest/SENT_st; echo keep > $REPO_ROOT/systemTest/pkg/SENT_pkg; echo keep > $W/outside/SENT_out; }
check() { echo "$( [ -f $REPO_ROOT/SENT_root ] && echo R)$( [ -f $REPO_ROOT/systemTest/SENT_st ] && echo S)$( [ -f $REPO_ROOT/systemTest/pkg/SENT_pkg ] && echo P)$( [ -f $W/outside/SENT_out ] && echo O)"; }
t() { local label=$1 arg=$2; sent; _rm_stage "$arg"; local rc=$?; printf '%-62s rc=%s sentinels=%s target_exists=%s\n' "$label" $rc "$(check)" "$( [ -e "$arg" ] || [ -L "$arg" ] && echo yes || echo no)"; }
for P in STAGE TREE; do eval "PFX=\$${P}_PREFIX"
  echo "== $P prefix"
  t "empty arg" ""
  t "bare prefix (rest empty)" "$PFX"
  t "prefix + '..' (rest '..')" "$PFX.."
  t "prefix..'/../pkg'" "$PFX../pkg"
  mkdir -p "${PFX}x"; t "prefixx/../pkg (multi-component)" "${PFX}x/../pkg"
  t "prefix + '1/..' " "${PFX}1/.."
  ln -s $W/outside "${PFX}link.1"; t "symlink stage -> outside dir" "${PFX}link.1"
  ln -s $W/nonexistent "${PFX}dang.1"; t "dangling symlink stage" "${PFX}dang.1"
  : > "${PFX}file.1"; t "regular file named like a stage" "${PFX}file.1"
  mkdir -p "${PFX}real.1"; ln -s $W/outside "${PFX}real.1/l"; ln -s $REPO_ROOT/systemTest/pkg "${PFX}real.1/p"; t "real stage containing symlinks to outside and pkg" "${PFX}real.1"
  mkdir -p "${PFX}sp ace
nl.1"; t "real stage with space+newline in the name" "${PFX}sp ace
nl.1"
  t "relative path that LOOKS like the prefix" "systemTest/.format-gate-tree.1"
  t "repo root" "$REPO_ROOT"
done
echo "== empty prefixes (unreachable: both are assigned once from REPO_ROOT, never empty) - defence-in-depth probe"
STAGE_PREFIX=""; TREE_PREFIX=""; mkdir -p $W/cwd/victim; echo keep > $W/cwd/victim/f
( cd $W/cwd && _rm_stage victim; echo "  _rm_stage victim with both prefixes empty: rc=$? victim_exists=$( [ -d victim ] && echo yes || echo NO)" )
