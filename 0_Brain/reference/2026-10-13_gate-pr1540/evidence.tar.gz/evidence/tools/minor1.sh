#!/bin/bash
# minor1.sh <gate> <workdir>: rename + marker attacks
set -u
GATE=$1; W=$2
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
rm -rf "$W"; mkdir -p "$W"
REAL_NODE=$(command -v node); REAL_NPM=$(command -v npm)
echo "== M1a errno of rename(2) onto a NON-EMPTY dir / EMPTY dir / symlink / file on this filesystem ($(df -T apfs $W >/dev/null 2>&1 && echo apfs || mount | grep ' / ' ))"
mkdir -p $W/e/src $W/e/full $W/e/empty $W/e/linktarget; : > $W/e/full/x; ln -s $W/e/linktarget $W/e/link; : > $W/e/file
for t in full empty link file; do mkdir -p $W/e/src; : > $W/e/src/ours
  printf '  onto %-6s -> ' $t; node -e 'try{require("fs").renameSync(process.argv[1],process.argv[2]);console.log("OK (replaced)")}catch(e){console.log(e.code)}' $W/e/src $W/e/$t; done
echo "== M1b the look->rename window: wall time of the node process that performs rename(2) (fork+exec+boot), 30 runs"
python3 - "$REAL_NODE" <<'PY'
import subprocess,sys,time,statistics,os,tempfile
d=tempfile.mkdtemp(); ts=[]
for i in range(30):
    a=os.path.join(d,'a%d'%i); os.mkdir(a); b=os.path.join(d,'b%d'%i)
    t=time.perf_counter(); subprocess.run([sys.argv[1],'-e','try { require("fs").renameSync(process.argv[1], process.argv[2]); } catch (e) { process.stdout.write(String(e.code || "EUNKNOWN")); process.exit(1); }',a,b]); ts.append((time.perf_counter()-t)*1000)
print("  node rename process wall ms: min %.1f median %.1f max %.1f  (CONTROL /bin/mv same op: see next line)"%(min(ts),statistics.median(ts),max(ts)))
ts=[]
for i in range(30):
    a=os.path.join(d,'c%d'%i); os.mkdir(a); b=os.path.join(d,'e%d'%i)
    t=time.perf_counter(); subprocess.run(['/bin/mv',a,b]); ts.append((time.perf_counter()-t)*1000)
print("  /bin/mv process wall ms:       min %.1f median %.1f max %.1f"%(min(ts),statistics.median(ts),max(ts)))
PY
echo "== M1c the move-BACK window: marker check -> rename back. A FOREIGN NON-EMPTY tree swapped in during it (needs an install that embeds its stage path)"
mkdir -p $W/bin
cat > $W/bin/npm <<'N'
#!/bin/bash
if [ "${1:-}" = ci ]; then   # 'embed': prettier is an ABSOLUTE symlink into the stage, so it breaks on the move
  mkdir -p node_modules/.bin node_modules/real; printf '#!/bin/sh\nexit 0\n' > node_modules/real/p; chmod +x node_modules/real/p
  ln -s "$PWD/node_modules/real/p" node_modules/.bin/prettier; exit 0
fi
exec "$REAL_NPM" "$@"
N
cat > $W/bin/node <<'N'
#!/bin/bash
# shim: on the BACK rename (package -> stage), another actor replaces the package's node_modules with ITS tree first
case "${2:-}" in *renameSync*)
  case "${3:-}" in */systemTest/p/node_modules)
    if [ "${SWAP:-0}" = 1 ]; then rm -rf "$3"; mkdir -p "$3"; echo precious > "$3/FOREIGN_DEVELOPER_TREE"; fi ;;
  esac ;;
esac
exec "$REAL_NODE" "$@"
N
chmod +x $W/bin/*
export REAL_NODE REAL_NPM
for swap in 0 1; do
  r=$W/m1c-$swap; mkdir -p $r/systemTest/scripts $r/systemTest/p; cp "$GATE" $r/systemTest/scripts/check-package-format.sh
  printf '{ "name": "p", "version": "0.0.0", "scripts": { "format:check": "exit 0" } }\n' > $r/systemTest/p/package.json
  out=$(printf 'systemTest/p/x\n' | PATH="$W/bin:$PATH" SWAP=$swap bash $r/systemTest/scripts/check-package-format.sh 2>&1); rc=$?
  echo "  SWAP=$swap rc=$rc state='$(printf '%s' "$out" | grep -o 'embeds its staging path[^)]*' | head -1)' foreign_tree_survives=$( [ -e $r/systemTest/p/node_modules/FOREIGN_DEVELOPER_TREE ] && echo yes || echo NO) pkg_node_modules=$( [ -e $r/systemTest/p/node_modules ] && echo present || echo absent) stages=$(ls -A $r/systemTest | grep -c format-gate-stage)"
done
echo "== M1d two REAL gate processes, one package, real npm, offline tarball with a 1.x s postinstall (5 trials)"
T=$W/tools; mkdir -p $T/src
cat > $T/src/package.json <<'J'
{ "name": "fake-prettier", "version": "1.0.0", "bin": { "prettier": "bin.js" }, "scripts": { "postinstall": "sleep 1.$((RANDOM%9))" } }
J
printf '#!/usr/bin/env node\nprocess.exit(0)\n' > $T/src/bin.js; chmod +x $T/src/bin.js
( cd $T/src && npm pack --pack-destination $T --cache=$W/cache --silent ) >/dev/null 2>&1
TGZ=$T/fake-prettier-1.0.0.tgz; INTEG="sha512-$(openssl dgst -sha512 -binary $TGZ | base64 | tr -d '\n')"
for trial in 1 2 3 4 5; do
  r=$W/m1d-$trial; d=$r/systemTest/p; mkdir -p $r/systemTest/scripts $d; cp "$GATE" $r/systemTest/scripts/check-package-format.sh
  cat > $d/package.json <<J
{ "name": "p", "version": "0.0.0", "private": true, "scripts": { "format:check": "prettier --version >/dev/null" }, "devDependencies": { "fake-prettier": "file:$TGZ" } }
J
  cat > $d/package-lock.json <<J
{ "name": "p", "version": "0.0.0", "lockfileVersion": 3, "requires": true, "packages": {
  "": { "name": "p", "version": "0.0.0", "devDependencies": { "fake-prettier": "file:$TGZ" } },
  "node_modules/fake-prettier": { "version": "1.0.0", "resolved": "file:$TGZ", "integrity": "$INTEG", "dev": true, "hasInstallScript": true, "bin": { "prettier": "bin.js" } } } }
J
  echo 'x' > $d/x.ts
  for g in A B; do ( printf 'systemTest/p/x.ts\n' | npm_config_cache=$W/cache-$trial-$g npm_config_registry=http://127.0.0.1:9/ bash $r/systemTest/scripts/check-package-format.sh > $r/$g.out 2>&1; echo $? > $r/$g.rc ) & done; wait
  echo "  trial $trial: A rc=$(cat $r/A.rc) [$(grep -oE 'INSTALLED|appeared during the install|REFUSED[^:]*: [^,]*' $r/A.out | head -2 | tr '\n' ';')]  B rc=$(cat $r/B.rc) [$(grep -oE 'INSTALLED|appeared during the install|REFUSED[^:]*: [^,]*' $r/B.out | head -2 | tr '\n' ';')]  nested=$( [ -e $d/node_modules/node_modules ] && echo YES || echo no) markers_left=$(ls -A $d/node_modules 2>/dev/null | grep -c format-gate-moved) stages=$(ls -A $r/systemTest | grep -c format-gate-stage) prettier_x=$( [ -x $d/node_modules/.bin/prettier ] && echo yes || echo NO)"
done
