#!/bin/bash
# wait until the suites log contains the final no-db control line, max ~9 min
L=/private/tmp/claude-501/gate1549r2-170549/ev/suites_run.log
for i in $(seq 1 108); do
  grep -q "refusing-lines=" $L && break
  sleep 5
done
tail -9 $L
