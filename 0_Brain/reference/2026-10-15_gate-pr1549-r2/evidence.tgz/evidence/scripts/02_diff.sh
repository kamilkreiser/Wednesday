#!/bin/bash
set -u
R=/private/tmp/claude-501/gate1549r2-170549/repo
E=/private/tmp/claude-501/gate1549r2-170549/ev
echo "== first-parent log b1801721..80daaa78"
git -C $R log --first-parent --format='%H %P | %an | %s' b1801721d56b35d7982cbe5b103c740113aa70b9..80daaa78a2c7adf7196a41cdf240376d8c2bf75a
echo "== full log aca6efb0..b1801721 (round-1 fix)"
git -C $R log --format='%H %P | %s' aca6efb0864b11360eca90d1217d72ccd24e10ac..b1801721d56b35d7982cbe5b103c740113aa70b9
for c in ea799fd4 12b87963 80daaa78; do
  echo "== $c parents and per-parent stats"
  P=$(git -C $R rev-parse $c^@)
  for p in $P; do echo "-- vs parent $p"; git -C $R diff --stat $p $c | tail -40; done
done
echo "== merge purity: for each merge M=(P1,P2), is diff(P2..M) == diff(base(P1,P2)..P1)? i.e. M tree == merge-tree(P1,P2)"
for c in ea799fd4 80daaa78; do
  P1=$(git -C $R rev-parse $c^1); P2=$(git -C $R rev-parse $c^2)
  MT=$(git -C $R merge-tree --write-tree $P1 $P2 | head -1)
  T=$(git -C $R rev-parse $c^{tree})
  echo "$c tree=$T merge-tree(P1,P2)=$MT $( [ "$T" = "$MT" ] && echo EQUAL || echo DIFFER)"
done
echo "== control: merge-tree of 12b87963's parent with develop 53b429ed vs 80daaa78 tree should be equal; a planted tree differs"
