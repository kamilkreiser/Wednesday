#!/bin/bash
R=/private/tmp/claude-501/gate1549r2-170549/repo
E=/private/tmp/claude-501/gate1549r2-170549/ev
git -C $R show 12b87963 > $E/diff_12b87963.patch
git -C $R diff aca6efb0 b1801721 > $E/diff_round1_fix.patch
git -C $R diff e67e0dc1 53b429ed > $E/dev_e67_53b.patch
git -C $R diff 12b87963 80daaa78 > $E/pr_12b_80d.patch
git -C $R diff --stat e67e0dc1 53b429ed
if cmp -s $E/dev_e67_53b.patch $E/pr_12b_80d.patch; then echo "80daaa78 first-parent delta == develop e67e0dc1..53b429ed: IDENTICAL"; else echo "DIFFER"; fi
# ea799fd4: develop side delta vs first-parent delta: files touched by first-parent delta must equal files of develop b1801721-mergebase..e67e0dc1
MB=$(git -C $R merge-base b1801721 e67e0dc1)
echo "merge-base(b1801721,e67e0dc1)=$MB"
git -C $R diff --name-only $MB e67e0dc1 | sort > $E/ea_dev_files.txt
git -C $R diff --name-only b1801721 ea799fd4 | sort > $E/ea_fp_files.txt
git -C $R diff --name-only $MB b1801721 | sort > $E/ea_pr_files.txt
echo "dev files: $(wc -l < $E/ea_dev_files.txt)  fp files: $(wc -l < $E/ea_fp_files.txt)  pr-side files: $(wc -l < $E/ea_pr_files.txt)"
echo "fp files not in dev files:"; comm -23 $E/ea_fp_files.txt $E/ea_dev_files.txt
echo "overlap pr-side x dev:"; comm -12 $E/ea_pr_files.txt $E/ea_dev_files.txt
# for overlap-free merges, fp diff per file should equal dev diff per file
git -C $R diff $MB e67e0dc1 > $E/ea_dev.patch
git -C $R diff b1801721 ea799fd4 > $E/ea_fp.patch
if cmp -s $E/ea_dev.patch $E/ea_fp.patch; then echo "ea799fd4 first-parent delta == develop's own delta: IDENTICAL"; else echo "ea799fd4 fp vs dev patch DIFFER"; fi
wc -l $E/diff_12b87963.patch $E/diff_round1_fix.patch
