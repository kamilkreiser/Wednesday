#!/bin/bash
V=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-15_gate-pr1549-r2/verdict.md
H=$(sed '2d' $V | shasum -a 256 | cut -c1-16)
sed -i '' -e "2s/.*/REPORT-SHA256\/16: $H/" $V
echo "line2: $(sed -n 2p $V)"
echo "recomputed: $(sed '2d' $V | shasum -a 256 | cut -c1-16)"
echo "one-byte control: $( (sed '2d' $V; printf x) | shasum -a 256 | cut -c1-16)"
echo "hash lines: $(grep -c '^REPORT-SHA256/16:' $V)"
