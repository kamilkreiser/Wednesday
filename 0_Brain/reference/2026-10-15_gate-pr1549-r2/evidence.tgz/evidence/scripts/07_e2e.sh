#!/bin/bash
# usage: 07_e2e.sh <worktree> <port> <tag>
set -u
G=/private/tmp/claude-501/gate1549r2-170549
W="$1"; PORT="$2"; TAG="$3"
D=$W/Blockchain/Dev
if lsof -nP -iTCP:$PORT -sTCP:LISTEN >/dev/null 2>&1; then echo "PORT $PORT BUSY"; exit 2; fi
export PORT
export DATABASE_URL="postgresql://secuura_app:app@127.0.0.1:55621/secuura"
export JWT_PUBLIC_KEY="$(base64 < $G/keys/gate.pub | tr -d '\n')"
export NODE_ENV=development
export PII_ENCRYPTION_KEY="$(openssl rand -hex 32)"
unset BLOCKFROST_API_KEY PLATFORM_WALLET_MNEMONIC JWT_JWKS_URL AUTH_SERVICE_URL
$D/node_modules/.bin/tsx $D/services/anchoring/src/index.ts > $G/ev/anchoring_boot_$TAG.log 2>&1 &
SVC=$!
for i in $(seq 1 60); do
  curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$PORT/health 2>/dev/null | grep -q 200 && break
  sleep 1
done
echo "health: $(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$PORT/health)"
$D/node_modules/.bin/tsx $G/cells/e2e_custody.ts http://127.0.0.1:$PORT $G/keys/gate.pem $G/keys/forger.pem "postgresql://secuura:secuura@127.0.0.1:55621/secuura" $W > $G/ev/e2e_custody_$TAG.log 2>&1
echo "cell rc=$?"
sleep 2
kill $SVC
wait $SVC 2>/dev/null
cat $G/ev/e2e_custody_$TAG.log
echo "--- guard log lines (kept-payload warnings) in the service log:"
grep -c "kept the stored anchor metadata" $G/ev/anchoring_boot_$TAG.log
grep "kept the stored anchor metadata" $G/ev/anchoring_boot_$TAG.log | python3 -I -c "
import sys,json
for l in sys.stdin:
    try: d=json.loads(l); print(d.get('reason'), d.get('documentId'))
    except Exception: pass"
echo "--- 401 count in service log: $(grep -c '"statusCode":401' $G/ev/anchoring_boot_$TAG.log)"
