#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1549r2-170549
SRC="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files"
export GIT_SSH_COMMAND='ssh -i "/Volumes/DevMASTER/!CODING/Secuura/Blockchain/3_Access_Keys/github_deploy_rw" -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new -o ServerAliveInterval=15'
mkdir -p $G/ev
date -u +%FT%TZ > $G/ev/receipts_lsremote_1.txt
git -C "$SRC" ls-remote origin refs/pull/1549/head refs/heads/develop >> $G/ev/receipts_lsremote_1.txt 2>&1
cat $G/ev/receipts_lsremote_1.txt
git clone --shared --no-checkout "$SRC" $G/repo 2>&1 | tail -2
git -C $G/repo remote set-url origin git@github.com:Secuura/Distributed_Secuura.git
git -C $G/repo fetch origin refs/pull/1549/head:refs/gate/head refs/heads/develop:refs/gate/develop 2>&1 | tail -3
for c in aca6efb0864b11360eca90d1217d72ccd24e10ac b1801721d56b35d7982cbe5b103c740113aa70b9 80daaa78a2c7adf7196a41cdf240376d8c2bf75a 53b429ed6b4bf4d23c0721bf573b9df1c858bc06; do
  git -C $G/repo cat-file -t $c || echo "MISSING $c"
done
git -C $G/repo rev-parse refs/gate/head refs/gate/develop
