#!/bin/bash
# usage: 06_itest.sh <worktree> <outname> [vitest file filter...]
set -u
G=/private/tmp/claude-501/gate1549r2-170549
W="$1"; O="$2"; shift 2
A=$W/Blockchain/Dev/services/anchoring
export TEST_DATABASE_URL="postgresql://secuura:secuura@127.0.0.1:55621/secuura"
export TEST_APP_DATABASE_URL="postgresql://secuura_app:app@127.0.0.1:55621/secuura"
export DATABASE_URL="$TEST_DATABASE_URL"
VT=$W/Blockchain/Dev/node_modules/.bin/vitest
$VT run --root $A --config $A/vitest.integration.config.ts --reporter=json --outputFile=$G/ev/$O.json "$@" > $G/ev/$O.log 2>&1
rc=$?
python3 -I - "$G/ev/$O.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
print("files",d.get("numTotalTestSuites"),"tests",d["numTotalTests"],"passed",d["numPassedTests"],"failed",d["numFailedTests"],"failedSuites",d.get("numFailedTestSuites"))
for f in d["testResults"]:
    for a in f["assertionResults"]:
        if a["status"]!="passed":
            print("  FAIL", a["fullName"][:150], "|", (a.get("failureMessages") or [""])[0].splitlines()[0][:200])
    if f.get("status")=="failed" and not f["assertionResults"]:
        print("  SUITE-FAIL", f["name"], f.get("message","")[:300])
PY
echo "rc=$rc"
