#!/bin/bash
G=/private/tmp/claude-501/gate1549r2-170549
python3 -I $G/s/mutants.py i2-MAJ2-hash-equality-dropped i3-MIN3-anchor-type-equality-dropped i5-guard-decision-not-bound s1-MIN1-CAS-where-dropped > $G/ev/mutants_run2.log 2>&1
D=$G/wt/head/Blockchain/Dev
echo "== tsc anchoring"; $D/node_modules/.bin/tsc --noEmit -p $D/services/anchoring/tsconfig.json > $G/ev/tsc_anchoring.log 2>&1; echo "rc=$? errors=$(grep -c 'error TS' $G/ev/tsc_anchoring.log)"
echo "== tsc originate"; $D/node_modules/.bin/tsc --noEmit -p $D/services/originate/tsconfig.json > $G/ev/tsc_originate.log 2>&1; echo "rc=$? errors=$(grep -c 'error TS' $G/ev/tsc_originate.log)"
# planted type error control, in the mut worktree
M=$G/wt/mut/Blockchain/Dev
printf '\nexport const __gatePlanted: number = "not a number";\n' >> $M/services/anchoring/src/anchorOverwriteGuard.ts
$M/node_modules/.bin/tsc --noEmit -p $M/services/anchoring/tsconfig.json > $G/ev/tsc_planted.log 2>&1; echo "planted control tsc rc=$? errors=$(grep -c 'error TS' $G/ev/tsc_planted.log)"
git -C $G/wt/mut checkout -- Blockchain/Dev/services/anchoring/src/anchorOverwriteGuard.ts
echo "mut clean: $(git -C $G/wt/mut status --porcelain --untracked-files=no | wc -l)"
echo "== eslint on the PR's 17 files"
FILES=$(git -C $G/repo diff --name-only 53b429ed 80daaa78 | grep -E '\.(ts|js)$' | sed "s#^#$G/wt/head/#")
$D/node_modules/.bin/eslint --no-warn-ignored $FILES > $G/ev/eslint_head.log 2>&1; echo "rc=$? problems-line: $(grep -E 'problem' $G/ev/eslint_head.log)"
printf '\nvar __gate_unused = 1\n' >> $M/services/anchoring/src/anchorOverwriteGuard.ts
$M/node_modules/.bin/eslint --no-warn-ignored $M/services/anchoring/src/anchorOverwriteGuard.ts > $G/ev/eslint_planted.log 2>&1; echo "planted eslint rc=$? $(grep -E 'problem' $G/ev/eslint_planted.log)"
git -C $G/wt/mut checkout -- Blockchain/Dev/services/anchoring/src/anchorOverwriteGuard.ts
echo "== originate full jest (default config)"
$D/node_modules/.bin/jest --config $D/services/originate/jest.config.js --rootDir $D/services/originate --ci --silent --json --outputFile $G/ev/originate_full.json > $G/ev/originate_full.log 2>&1
python3 -I -c "
import json;d=json.load(open('$G/ev/originate_full.json'))
print('suites',d['numPassedTestSuites'],'/',d['numTotalTestSuites'],'tests',d['numPassedTests'],'/',d['numTotalTests'],'failed',d['numFailedTests'])"
echo "== anchoring default lane"
$D/node_modules/.bin/vitest run --root $D/services/anchoring --reporter=json --outputFile=$G/ev/anchoring_default.json > $G/ev/anchoring_default.log 2>&1
python3 -I -c "
import json;d=json.load(open('$G/ev/anchoring_default.json'))
print('tests',d['numPassedTests'],'/',d['numTotalTests'],'failed',d['numFailedTests'])
[print('  FAIL',f['name'].split('/')[-1],a['title'][:80]) for f in d['testResults'] for a in f['assertionResults'] if a['status']=='failed']"
echo "== integration lane with NO database URL (control: must refuse)"
( unset TEST_DATABASE_URL TEST_APP_DATABASE_URL DATABASE_URL; $D/node_modules/.bin/vitest run --root $D/services/anchoring --config $D/services/anchoring/vitest.integration.config.ts > $G/ev/itest_nodb.log 2>&1; echo "rc=$? refusing-lines=$(grep -c 'refusing to pass' $G/ev/itest_nodb.log)" )
