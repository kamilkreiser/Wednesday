#!/bin/bash
G=/private/tmp/claude-501/gate1549r2-170549
E=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-15_gate-pr1549-r2/evidence
mkdir -p $E/logs $E/cells $E/scripts $E/logs/mutants
for f in $G/ev/*; do
  b=$(basename $f)
  [ -d "$f" ] && continue
  case "$b" in originate_full.json) continue;; esac
  if grep -q -i "BEGIN.*PRIVATE" "$f"; then echo "skipped (contains a key block): $b"; continue; fi
  cp "$f" $E/logs/
done
cp $G/ev/mutants/* $E/logs/mutants/
cp $G/cells/* $E/cells/
cp $G/s/* $E/scripts/
python3 -I -c "
import json;d=json.load(open('$G/ev/originate_full.json'))
print('suites',d['numPassedTestSuites'],'/',d['numTotalTestSuites'],'tests',d['numPassedTests'],'/',d['numTotalTests'],'failed',d['numFailedTests'])" > $E/logs/originate_full.summary.txt
du -sh $E; ls $E/logs | wc -l
