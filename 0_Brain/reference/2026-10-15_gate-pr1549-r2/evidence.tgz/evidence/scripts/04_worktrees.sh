#!/bin/bash
# usage: 04_worktrees.sh <name> <commit>   -> creates worktree G/wt/<name>, links node_modules, builds shared dist
set -u
G=/private/tmp/claude-501/gate1549r2-170549
R=$G/repo
N="$1"; C="$2"
W=$G/wt/$N
mkdir -p $G/wt
git -C $R worktree add --detach $W $C 2>&1 | tail -1
/bin/bash /Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1549/evidence/cells/setup_nm.sh $W
cd_free_build() {
  ( "$W/Blockchain/Dev/node_modules/.bin/tsc" -p "$W/Blockchain/Dev/packages/shared/tsconfig.json" ) > $G/ev/build_shared_$N.log 2>&1
  echo "shared build rc=$? (log ev/build_shared_$N.log)"
}
cd_free_build
ls $W/Blockchain/Dev/packages/shared/dist | head -3
git -C $W status --porcelain | head -5
echo "HEAD=$(git -C $W rev-parse HEAD)"
