#!/usr/bin/env python3
"""Gate 1549 r2 mutation runner (own instrument). Each mutant: exact-once string replacement in the
mut worktree; run originate jest on the two ks1385 suites (--json) and the anchoring integration lane
(vitest json) against my Postgres :55621; record NAMED failing cells + cell totals; restore with
`git checkout -- <file>`; assert the worktree is clean at the end.
KILL = >=1 named cell failed with a non-empty message AND totals equal the control AND no suite load failure."""
import json, os, subprocess, sys, pathlib

G = '/private/tmp/claude-501/gate1549r2-170549'
W = G + '/wt/mut'
D = W + '/Blockchain/Dev'
O = D + '/services/originate'
A = D + '/services/anchoring'
EV = G + '/ev/mutants'
os.makedirs(EV, exist_ok=True)
DOCS = 'Blockchain/Dev/services/originate/src/routes/documents.ts'
GUARD = 'Blockchain/Dev/services/anchoring/src/anchorOverwriteGuard.ts'
IDX = 'Blockchain/Dev/services/anchoring/src/index.ts'

C_COND = "  if (custodyOption === 'c' && sameUuid(doc.ownerOrganizationId, caller.organizationId)) {"
NULLISS = "  if (doc.issuerOrganizationId === null || doc.issuerOrganizationId.trim().length === 0) {"
def call(evt):
    return f"        eventType: '{evt}',\n        identity: (req.body as any)?.identity,"

M = {
  'CTRL-none': [],
  'CTRL-comment-only': [(GUARD, "export const CUSTODY_OPTION: CustodyOption = 'c';", "// gate r2 comment-only control\nexport const CUSTODY_OPTION: CustodyOption = 'c';")],
  # red-first: round 1's option (a) restored (== the author's g8a)
  'RED-a': [(GUARD, "export const CUSTODY_OPTION: CustodyOption = 'c';", "export const CUSTODY_OPTION: CustodyOption = 'a';")],
  # the author's named mutants, re-run with the author's exact text
  'g4-null-issuer-branch-removed': [(GUARD, NULLISS, "  if (false) {")],
  'g8b-ship-b': [(GUARD, "export const CUSTODY_OPTION: CustodyOption = 'c';", "export const CUSTODY_OPTION: CustodyOption = 'b';")],
  'g12-c-compares-custodian-user': [(GUARD, C_COND, "  if (custodyOption === 'c' && sameUuid(doc.ownerUserId, caller.userId)) {")],
  'g13-c-fires-under-b-too': [(GUARD, C_COND, "  if (custodyOption !== 'a' && sameUuid(doc.ownerOrganizationId, caller.organizationId)) {")],
  # my own, on the constant/branch
  'm1-c-fails-open-on-null-custodian-org': [(GUARD, C_COND, "  if (custodyOption === 'c' && (doc.ownerOrganizationId === null || sameUuid(doc.ownerOrganizationId, caller.organizationId))) {")],
  'm2-c-widened-to-null-issuer-rows': [(GUARD, NULLISS, "  if (custodyOption !== 'c' && (doc.issuerOrganizationId === null || doc.issuerOrganizationId.trim().length === 0)) {")],
  'm3-custodian-join-any-user-in-tenant': [(GUARD, "                ON u.id = d.owner_user_id\n", "                ON u.organization_id IS NOT NULL\n")],
  'm4-c-ignores-the-option-and-always-fires': [(GUARD, C_COND, "  if (sameUuid(doc.ownerOrganizationId, caller.organizationId)) {")],
  # round-1 MIN-2 survivors, exact round-1 text
  'k04-transfer-custody-identity-dropped': [(DOCS, call('transfer-custody'), "        eventType: 'transfer-custody',")],
  'k05-share-identity-dropped': [(DOCS, call('share'), "        eventType: 'share',")],
  'k06-revoke-identity-dropped': [(DOCS, call('revoke'), "        eventType: 'revoke',")],
  'g08-share-forwards-caller-jwt': [(DOCS, call('share'), "        eventType: 'share',\n        identity: (req as any).user,")],
  # round-1 Major/Minor closures, my own instrument
  'i2-MAJ2-hash-equality-dropped': [(IDX, 'AND anchor_store.content_hash = EXCLUDED.content_hash', 'AND true')],
  'i3-MIN3-anchor-type-equality-dropped': [(IDX, 'AND anchor_store.anchor_type  = EXCLUDED.anchor_type', 'AND true')],
  'i5-guard-decision-not-bound': [(IDX, '        overwrite.allow,', '        true,')],
  's1-MIN1-CAS-where-dropped': [('Blockchain/Dev/services/anchoring/src/anchorStatusUpdate.ts', "    where.push(`metadata_payload = $${idx++}::jsonb`);", '    // gate: no CAS')],
}
ORIG_TESTS = ['ks1385-create-anchor-carries-the-identity-block.test.ts', 'ks1385-certification-anchors-carry-the-identity-block.test.ts']

def parse(out):
    j = json.load(open(out))
    cells, fails, loadfail = 0, [], []
    for s in j['testResults']:
        if s.get('status') == 'failed' and not s.get('assertionResults'):
            loadfail.append((os.path.basename(s['name']), (s.get('message') or '')[:300]))
        for a in s.get('assertionResults', []):
            cells += 1
            if a['status'] == 'failed':
                fails.append((a['title'][:70], ' '.join(m[:200] for m in a.get('failureMessages', [])).replace('\n', ' ')))
    return cells, fails, loadfail

def run_originate(tag):
    out = f'{EV}/{tag}.originate.json'
    pat = '|'.join(t.replace('.', '\\.') for t in ORIG_TESTS)
    subprocess.run([D + '/node_modules/.bin/jest', '--config', O + '/jest.config.js', '--rootDir', O, '--ci', '--silent',
                    '--json', '--outputFile', out, '--testPathPattern', pat], capture_output=True, text=True)
    return parse(out)

def run_anchoring(tag):
    out = f'{EV}/{tag}.anchoring.json'
    env = dict(os.environ, TEST_DATABASE_URL='postgresql://secuura:secuura@127.0.0.1:55621/secuura',
               TEST_APP_DATABASE_URL='postgresql://secuura_app:app@127.0.0.1:55621/secuura')
    env['DATABASE_URL'] = env['TEST_DATABASE_URL']
    subprocess.run([D + '/node_modules/.bin/vitest', 'run', '--root', A, '--config', A + '/vitest.integration.config.ts',
                    '--reporter=json', '--outputFile=' + out], capture_output=True, text=True, env=env)
    return parse(out)

def main(names):
    for name in names:
        touched, ok = set(), True
        for f, old, new in M[name]:
            p = pathlib.Path(W) / f
            t = p.read_text()
            if t.count(old) != 1:
                print(json.dumps({name: f'anchor matched {t.count(old)} times in {f}: NOT APPLIED, NOT SCORED'})); ok = False; break
            p.write_text(t.replace(old, new, 1)); touched.add(f)
        if ok:
            diff = subprocess.run(['git', '-C', W, 'diff', '--shortstat'], capture_output=True, text=True).stdout.strip()
            oc, of, ol = run_originate(name)
            ac, af, al = run_anchoring(name)
            allf = of + af
            killed = len(allf) > 0 and all(m.strip() for _, m in allf) and not ol and not al
            v = 'KILLED' if killed else ('LOAD-FAIL (not scored)' if (ol or al) else 'SURVIVED')
            print(json.dumps({name: dict(applied=diff or 'NO DIFF', originate_cells=oc, anchoring_cells=ac, verdict=v,
                                         failed=[t for t, _ in allf], first_msg=allf[0][1][:220] if allf else '', load_failures=ol + al)}))
            sys.stdout.flush()
        for f in touched:
            subprocess.run(['git', '-C', W, 'checkout', '--', f], check=True)
    st = subprocess.run(['git', '-C', W, 'status', '--porcelain', '--untracked-files=no'], capture_output=True, text=True).stdout
    print('worktree clean after run:', st.strip() == '')

if __name__ == '__main__':
    main(sys.argv[1:] or list(M))
