#!/bin/bash
G=/private/tmp/claude-501/gate1549r2-170549
/bin/bash $G/s/04_worktrees.sh dev 53b429ed6b4bf4d23c0721bf573b9df1c858bc06
/bin/bash $G/s/04_worktrees.sh r1 aca6efb0864b11360eca90d1217d72ccd24e10ac
/bin/bash $G/s/07_e2e.sh $G/wt/dev 55623 dev
/bin/bash $G/s/07_e2e.sh $G/wt/r1 55624 r1gated
