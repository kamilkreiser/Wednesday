#!/bin/bash
set -u
G=/private/tmp/claude-501/gate1549r2-170549
R=$G/repo
SRC="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files"
export GIT_SSH_COMMAND='ssh -i "/Volumes/DevMASTER/!CODING/Secuura/Blockchain/3_Access_Keys/github_deploy_rw" -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new -o ServerAliveInterval=15'
echo "ls-remote at $(date -u +%FT%TZ):"
git -C "$SRC" ls-remote origin refs/pull/1549/head refs/heads/develop
git -C $R fetch -q origin refs/heads/develop:refs/gate/develop2 refs/pull/1549/head:refs/gate/head2
DEV=$(git -C $R rev-parse refs/gate/develop2); HEAD=$(git -C $R rev-parse refs/gate/head2)
echo "develop=$DEV head=$HEAD"
echo "is develop an ancestor of head: $(git -C $R merge-base --is-ancestor $DEV $HEAD && echo yes || echo no)"
MB=$(git -C $R merge-base $DEV $HEAD); echo "merge-base=$MB"
git -C $R diff --name-only $MB $HEAD | sort > $G/ev/m_pr_files.txt
git -C $R diff --name-only $MB $DEV | sort > $G/ev/m_dev_files.txt
echo "pr files since mb: $(wc -l < $G/ev/m_pr_files.txt); develop files since mb: $(wc -l < $G/ev/m_dev_files.txt); overlap: $(comm -12 $G/ev/m_pr_files.txt $G/ev/m_dev_files.txt | wc -l)"
( cat $G/ev/m_dev_files.txt; echo Blockchain/Dev/services/anchoring/src/anchorOverwriteGuard.ts ) | sort > $G/ev/m_dev_files_planted.txt
echo "planted overlap control: $(comm -12 $G/ev/m_pr_files.txt $G/ev/m_dev_files_planted.txt | wc -l)"
MT=$(git -C $R merge-tree --write-tree $DEV $HEAD); rc=$?
echo "merge-tree(develop, head) rc=$rc tree=$(echo "$MT" | head -1); head tree=$(git -C $R rev-parse $HEAD^{tree})"
echo "squash diff develop..predicted tree (files): $(git -C $R diff --name-only $DEV $(echo "$MT"|head -1) | wc -l); PR diff develop..head files: $(git -C $R diff --name-only $DEV $HEAD | wc -l)"
# planted conflict: a commit on develop editing the CUSTODY_OPTION line differently
W=$G/wt/plant; git -C $R worktree add -q --detach $W $DEV
sed -i '' -e 's/^export const CUSTODY_OPTION: CustodyOption = .*/export const CUSTODY_OPTION: CustodyOption = "a"; \/\/ planted/' $W/Blockchain/Dev/services/anchoring/src/anchorOverwriteGuard.ts 2>/dev/null
if [ ! -f $W/Blockchain/Dev/services/anchoring/src/anchorOverwriteGuard.ts ]; then
  mkdir -p $W/Blockchain/Dev/services/anchoring/src
  echo 'export const CUSTODY_OPTION = "planted";' > $W/Blockchain/Dev/services/anchoring/src/anchorOverwriteGuard.ts
fi
git -C $W add -A Blockchain/Dev/services/anchoring/src/anchorOverwriteGuard.ts
git -C $W -c user.name=gate -c user.email=gate@invalid commit -q -m "planted conflicting control"
P=$(git -C $W rev-parse HEAD)
git -C $R merge-tree --write-tree $P $HEAD > $G/ev/m_planted.txt 2>&1; echo "planted control merge-tree rc=$? : $(grep -c CONFLICT $G/ev/m_planted.txt) CONFLICT line(s)"; grep CONFLICT $G/ev/m_planted.txt
