// Gate r2 cell: against a BOOTED anchoring service at head (real index.ts, real guard, real Postgres as
// secuura_app, mock chain, RS256 tokens), which callers may REPLACE a stored attestation under (c)?
// argv: baseUrl privKeyPath forgerKeyPath ownerDbUrl tree
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import { createRequire } from 'module';
const [base, keyPath, forgerPath, ownerUrl, tree] = process.argv.slice(2);
const req = createRequire(path.join(tree, 'Blockchain/Dev/services/anchoring/package.json'));
const jwt = req('jsonwebtoken');
const { Client } = req('pg');
const key = fs.readFileSync(keyPath, 'utf8');
const forger = fs.readFileSync(forgerPath, 'utf8');
const u = () => crypto.randomUUID();
const TA = u(), TB = u();
const ORG_I = u(), ORG_C = u(), ORG_T = u(), ORG_N = u(), ORG_TB = u();
const U_ISS = u(), U_CUST = u(), U_COLL = u(), U_THIRD = u(), U_TB = u();
const HASH = 'e7'.repeat(32);
const tok = (userId: string, tenantId: string, organizationId: string, signer = key, extra: object = {}) =>
  jwt.sign({ userId, email: `${userId}@x.invalid`, role: 'ISSUER_ADMIN', verificationLevel: 'BASIC', tenantId, organizationId, ...extra }, signer, { algorithm: 'RS256', expiresIn: '10m' });
const db = new Client({ connectionString: ownerUrl });
async function post(token: string, documentId: string, actor: string) {
  const r = await fetch(`${base}/api/anchors`, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
    body: JSON.stringify({ documentId, contentHash: HASH, identity: { actorDid: actor, actorLevel: 2, actorSource: 'platform' } }) });
  return r.status;
}
async function stored(documentId: string) {
  const r = await db.query('SELECT metadata_payload FROM anchor_store WHERE document_id = $1', [documentId]);
  return { rows: r.rowCount, actor: r.rows[0]?.metadata_payload?.secuura?.actorDid ?? null };
}
async function doc(opts: { issuer: string | null; owner: string | null; externalId?: string; tenant?: string }) {
  const id = u();
  await db.query(`INSERT INTO documents (id, external_id, title, document_type, content_hash, tenant_id, issuer_organization_id, owner_user_id)
                  VALUES ($1::uuid, $2, 'gate r2', 'invoice', $3, $4::uuid, $5::uuid, $6::uuid)`,
    [id, opts.externalId ?? null, HASH, opts.tenant ?? TA, opts.issuer, opts.owner]);
  return id;
}
let n = 0;
async function cell(name: string, documentId: string, second: string, expectReplace: boolean) {
  n += 1;
  const s1 = await post(tok(U_ISS, TA, ORG_I), documentId, `did:key:zFIRST${n}`);
  const s2 = await post(second, documentId, `did:key:zSECOND${n}`);
  const st = await stored(documentId);
  const replaced = st.actor === `did:key:zSECOND${n}`;
  const ok = replaced === expectReplace && st.rows === 1;
  console.log(JSON.stringify({ cell: name, firstStatus: s1, secondStatus: s2, rows: st.rows, storedActor: st.actor, replaced, expected: expectReplace ? 'REPLACE' : 'KEEP', result: ok ? 'AS-EXPECTED' : 'UNEXPECTED' }));
}
(async () => {
  await db.connect();
  for (const [id, org, t] of [[U_ISS, ORG_I, TA], [U_CUST, ORG_C, TA], [U_COLL, ORG_C, TA], [U_THIRD, ORG_T, TA], [U_TB, ORG_TB, TB]] as const) {
    await db.query('INSERT INTO users (id, email, organization_id, tenant_id) VALUES ($1::uuid, $2, $3::uuid, $4::uuid)', [id, `${id}@x.invalid`, org, t]);
  }
  // ---- the ruled set, documentId = documents.id (the key the guard reads) ----
  await cell('P0 control: issuer org, no custodian', await doc({ issuer: ORG_I, owner: null }), tok(U_ISS, TA, ORG_I), true);
  await cell('P1 issuer org after transfer (custodian in C)', await doc({ issuer: ORG_I, owner: U_CUST }), tok(U_ISS, TA, ORG_I), true);
  await cell('P2 the custodian user himself (org C)', await doc({ issuer: ORG_I, owner: U_CUST }), tok(U_CUST, TA, ORG_C), true);
  await cell('P3 colleague in the custodian org C (not the custodian)', await doc({ issuer: ORG_I, owner: U_CUST }), tok(U_COLL, TA, ORG_C), true);
  await cell('P4 third org T, same tenant', await doc({ issuer: ORG_I, owner: U_CUST }), tok(U_THIRD, TA, ORG_T), false);
  await cell('P5 other tenant B', await doc({ issuer: ORG_I, owner: U_CUST }), tok(U_TB, TB, ORG_TB), false);
  await cell('P5b other tenant B claiming org C (the custodian org id)', await doc({ issuer: ORG_I, owner: U_CUST }), tok(U_TB, TB, ORG_C), false);
  await cell('P6 NULL issuer, colleague in custodian org C (known limit)', await doc({ issuer: null, owner: U_CUST }), tok(U_COLL, TA, ORG_C), false);
  // custodian's organisation changes AFTER the transfer: (c) reads the CURRENT users.organization_id
  const dMove = await doc({ issuer: ORG_I, owner: U_CUST });
  await db.query('UPDATE users SET organization_id = $1::uuid WHERE id = $2::uuid', [ORG_N, U_CUST]);
  await cell('P7a custodian moved C->N: old colleague in C', dMove, tok(U_COLL, TA, ORG_C), false);
  const dMove2 = await doc({ issuer: ORG_I, owner: U_CUST });
  await cell('P7b custodian moved C->N: a caller claiming N', dMove2, tok(U_THIRD, TA, ORG_N), true);
  await db.query('UPDATE users SET organization_id = $1::uuid WHERE id = $2::uuid', [ORG_C, U_CUST]);
  // the CALLER's own org claim is not checked against users: U_THIRD is in T per users, token says C
  await cell('P8 stale/mismatched claim: user row says T, signed token says C', await doc({ issuer: ORG_I, owner: U_CUST }), tok(U_THIRD, TA, ORG_C), true);
  // forged claims never reach the guard
  await cell('P9 forged: token signed by a foreign key claiming org C', await doc({ issuer: ORG_I, owner: U_CUST }), tok(U_COLL, TA, ORG_C, forger), false);
  const none = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url') + '.' + Buffer.from(JSON.stringify({ userId: U_COLL, tenantId: TA, organizationId: ORG_C, role: 'ISSUER_ADMIN' })).toString('base64url') + '.';
  await cell('P10 forged: alg none claiming org C', await doc({ issuer: ORG_I, owner: U_CUST }), none, false);
  // ---- the key originate actually sends: documents.external_id, never documents.id ----
  const ext = `doc-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
  await doc({ issuer: ORG_I, owner: U_CUST, externalId: ext });
  await cell('X1 product-minted external id doc-<ts>-<rand>, issuer org (Kam ruling b case)', ext, tok(U_ISS, TA, ORG_I), true);
  const sUuid = u();
  await doc({ issuer: ORG_I, owner: U_CUST, externalId: sUuid });
  await cell('X2 S-supplied documentUuid as external id, issuer org', sUuid, tok(U_ISS, TA, ORG_I), true);
  const sUuid2 = u();
  await doc({ issuer: ORG_I, owner: U_CUST, externalId: sUuid2 });
  await cell('X3 S-supplied documentUuid, colleague in custodian org C (Kam ruling c case)', sUuid2, tok(U_COLL, TA, ORG_C), true);
  await db.end();
})().catch((e) => { console.error(e); process.exit(1); });
