#!/usr/bin/env python3
"""GATE PR1546 mutation runner. Mutates files inside the scratch worktree wt_gate only, restores
from the pristine wt_head copy after every mutant, asserts restoration byte-identical."""
import json, subprocess, sys, shutil, filecmp, os
S = "/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/2c8a1d0c-987e-41d3-84e7-d1d64d228275/scratchpad"
O = f"{S}/wt_gate/Blockchain/Dev/services/originate"
PRISTINE = f"{S}/wt_head/Blockchain/Dev/services/originate"
EV = "/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-13_gate-pr1546/evidence"
JEST = f"{S}/wt_gate/Blockchain/Dev/node_modules/.bin/jest"
GP, RT, MT, IX = "src/utils/gatewayProvenance.ts", "src/utils/requestTenant.ts", "src/routes/metering.ts", "src/index.ts"
M = [
 ("c0", "CONTROL comment-only edit", GP, "export const VOUCH_HEADER = 'x-gateway-vouch';", "// gate1546 comment-only control\nexport const VOUCH_HEADER = 'x-gateway-vouch';"),
 ("m1", "author: isGatewayVouched trusts 'unconfigured' too", GP, "return req.gatewayProvenance === 'vouched';", "return req.gatewayProvenance === 'vouched' || req.gatewayProvenance === 'unconfigured';"),
 ("m2", "author: isGatewayVouched is a NOT-unvouched test", GP, "return req.gatewayProvenance === 'vouched';", "return req.gatewayProvenance !== 'unvouched';"),
 ("m3", "author: unconfigured records but does NOT strip", GP, "      record('unconfigured');\n      strip();", "      record('unconfigured');"),
 ("m4", "author: unconfigured strips but records nothing", GP, "      record('unconfigured');\n      strip();", "      strip();"),
 ("m5", "author: resolver gates the upstream-attached tenant", RT, "const attached = nonEmpty(req.tenantId);", "const attached = isGatewayVouched(req) ? nonEmpty(req.tenantId) : undefined;"),
 ("m6", "author: resolver treats ABSENT verdict as vouched", RT, "const header = isGatewayVouched(req) ?", "const header = (isGatewayVouched(req) || req.gatewayProvenance === undefined) ?"),
 ("m7", "author: vouch left on the request after a match", GP, "      delete req.headers[VOUCH_HEADER];\n      record('vouched');", "      record('vouched');"),
 ("g1", "unset branch fail-open again (develop exactly: no record, no strip)", GP, "    if (!secret) {\n      record('unconfigured');\n      strip();\n      return next();\n    }", "    if (!secret) return next();"),
 ("g2", "metering verdict read REMOVED (header alone again)", MT, "if (isGatewayVouched(req) && req.headers['x-user-role']", "void isGatewayVouched; if (req.headers['x-user-role']"),
 ("g3", "metering verdict read INVERTED", MT, "if (isGatewayVouched(req) && req.headers['x-user-role']", "if (!isGatewayVouched(req) && req.headers['x-user-role']"),
 ("g4", "isGatewayVouched INVERTED", GP, "return req.gatewayProvenance === 'vouched';", "return req.gatewayProvenance !== 'vouched';"),
 ("g5", "index.ts KS-458 wiring reverted to the ungated inline header read", IX, "  (req as any).tenantId = resolveRequestTenantId(req as never);", "  void resolveRequestTenantId;\n  (req as any).tenantId = (req as any).tenantId || (typeof req.headers['x-tenant-id'] === 'string' && req.headers['x-tenant-id']) || 'a0000000-0000-4000-8000-000000000001';"),
 ("g6", "the strip REMOVED for both unvouched and unconfigured", GP, "        if (UNVOUCHED_STRIP_PATTERN.test(header)) {\n          delete req.headers[header];\n        }", "        void header;"),
 ("g7", "vouch compared with === instead of timingSafeEqual (equivalent; timing only)", GP, "  return crypto.timingSafeEqual(a, b);", "  void a; void b; void crypto; return presented === secret;"),
 ("g8", "tenant fallback changed to another tenant", RT, "export const DEFAULT_TENANT_ID = 'a0000000-0000-4000-8000-000000000001';", "export const DEFAULT_TENANT_ID = 'b0000000-0000-4000-8000-000000000001';"),
 ("g9", "strip pattern loses `tenant`", GP, "/^x-(user|tenant|organization|", "/^x-(user|organization|"),
 ("g10", "vouchMatches accepts an empty secret vs empty presented (drops both guards)", GP, "  if (!secret) return false;\n  if (typeof presented !== 'string' || presented.length === 0) return false;", "  if (typeof presented !== 'string') return false;"),
]
FILES = ["ks1032-unconfigured", "ks1041-gateway-provenance", "ks1041-provenance-mount", "gate1546-a", "gate1546-b", "gate1546-c"]
def run(tag):
    out = f"{EV}/mut_{tag}.json"
    p = subprocess.run([JEST, "--config", f"{O}/jest.config.js", "--rootDir", O, "--json", f"--outputFile={out}", *FILES],
                       capture_output=True, text=True)
    open(f"{EV}/mut_{tag}.log", "w").write(p.stdout + p.stderr)
    d = json.load(open(out))
    red = {"author": [], "gate": []}; loadfail = []
    for s in d["testResults"]:
        fn = s["name"].split("/")[-1]
        grp = "gate" if fn.startswith("gate1546") else "author"
        if not s["assertionResults"]: loadfail.append(fn)
        for a in s["assertionResults"]:
            if a["status"] != "passed":
                red[grp].append(f"{fn.split('.')[0][:14]}::{a['title'][:40]}")
    return d["numPassedTests"], d["numFailedTests"], d["numTotalTests"], red, loadfail
only = sys.argv[1:]
res = []
b = run("baseline"); print("BASELINE", b[:3], b[4]); assert b[1] == 0 and not b[4], "baseline not green"
for tag, desc, f, old, new in M:
    if only and tag not in only: continue
    path = f"{O}/{f}"; src = open(path).read()
    n = src.count(old)
    if n != 1: print(f"{tag} APPLY-FAIL count={n}"); res.append((tag, desc, "APPLY-FAIL")); continue
    open(path, "w").write(src.replace(old, new))
    try:
        p, fl, t, red, lf = run(tag)
    finally:
        shutil.copyfile(f"{PRISTINE}/{f}", path)
        assert filecmp.cmp(f"{PRISTINE}/{f}", path, shallow=False)
    verdict = "LOADFAIL" if lf else ("KILLED" if fl else "SURVIVED")
    line = f"{tag:4} {verdict:8} failed={fl} passed={p} total={t} author_red={len(red['author'])} gate_red={len(red['gate'])} :: {desc}"
    print(line, flush=True); print("      author:", red["author"]); print("      gate  :", red["gate"]); print("      loadfail:", lf, flush=True)
r = run("restored"); print("RESTORED", r[:3], r[4])
