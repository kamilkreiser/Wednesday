import { boot, raw, diffForgedVsBare, T_CONN, T_HUMAN, T_FORGED, DEFAULT_T } from "./gatekit/harness";
const mockUsage = jest.fn(async (..._a: unknown[]) => ({ marker: "gate1546-handler-ran" }));
jest.mock("../services/chargeEvents", () => ({ ...jest.requireActual("../services/chargeEvents"), getUsageSummary: (...a: unknown[]) => mockUsage(...a) }));
jest.mock("@secuura/shared/crypto/jwks", () => ({ ...jest.requireActual("@secuura/shared/crypto/jwks"), verifyJwtRs256: async (t: string) => require("./gatekit/mocks").fakeVerify(t) }));
jest.setTimeout(600000);
void T_HUMAN; void T_CONN;
let h: { base: string; close: () => Promise<void> };
const PS = { authorization: "Bearer gate-connector-jwt", "x-user-role": "connector", "x-tenant-id": T_CONN, "x-user-id": "connector:ps-gate" };
const tenantOfLastCall = () => (mockUsage.mock.calls.length ? mockUsage.mock.calls[mockUsage.mock.calls.length - 1][0] : "NOT-CALLED");

beforeAll(async () => { delete process.env.GATEWAY_VOUCH_SECRET; h = await boot(); }, 120000);
afterAll(async () => { await h?.close(); });

describe("GATE A — secret UNSET, real strip", () => {
  it("GA0 CONTROL secret unset", () => { expect(process.env.GATEWAY_VOUCH_SECRET).toBeUndefined(); });
  it("GA1 Platform-S as the gateway sends it (connector Bearer + trust headers, no vouch)", async () => {
    mockUsage.mockClear();
    const r = await raw(h.base, "GET", "/api/metering/usage", PS);
    console.log("GA1 status", r.status, "tenantArg", tenantOfLastCall(), r.body.slice(0, 160));
    expect({ status: r.status, tenant: tenantOfLastCall() }).toEqual({ status: 200, tenant: DEFAULT_T });
  });
  it("GA2 Platform-S when the gateway's connector-token exchange FAILED (no Bearer)", async () => {
    mockUsage.mockClear();
    const noBearer: Record<string, string> = { ...PS }; delete (noBearer as any).authorization;
    const r = await raw(h.base, "GET", "/api/metering/usage", noBearer);
    expect(r.status).toBe(401); expect(mockUsage).not.toHaveBeenCalled();
  });
  it("GA3 human JWT + forged x-tenant-id: tenant is the default, never the forged one", async () => {
    mockUsage.mockClear();
    const r = await raw(h.base, "GET", "/api/metering/usage", { authorization: "Bearer gate-human-jwt", "x-tenant-id": T_FORGED, "x-tenant-override": T_FORGED });
    console.log("GA3", r.status, tenantOfLastCall());
    expect(r.status).toBe(200); expect(tenantOfLastCall()).toBe(DEFAULT_T);
  });
  const variants: Array<[string, Record<string, string | string[]>]> = [
    ["upper-case names", { "X-USER-ROLE": "connector", "X-TENANT-ID": T_FORGED, "X-User-Id": "a" }],
    ["duplicate role header", { "x-user-role": ["connector", "connector"], "x-tenant-id": T_FORGED }],
    ["duplicate tenant header", { "x-user-role": "connector", "x-tenant-id": [T_FORGED, T_FORGED] }],
    ["whitespace vouch", { "x-user-role": "connector", "x-tenant-id": T_FORGED, "x-gateway-vouch": " " }],
    ["empty vouch", { "x-user-role": "connector", "x-tenant-id": T_FORGED, "x-gateway-vouch": "" }],
    ["duplicate vouch", { "x-user-role": "connector", "x-tenant-id": T_FORGED, "x-gateway-vouch": ["a", "a"] }],
    ["role with padding", { "x-user-role": " connector", "x-tenant-id": T_FORGED }],
    ["header present, no vouch", { "x-user-role": "connector", "x-tenant-id": T_FORGED }],
  ];
  for (const [name, hd] of variants) {
    it("GA4 forged variant refused: " + name, async () => {
      mockUsage.mockClear();
      const r = await raw(h.base, "GET", "/api/metering/usage", hd);
      expect(r.status).toBe(401); expect(mockUsage).not.toHaveBeenCalled();
    });
  }
  it("GA5 ENUMERATED: on every declared route, forged trust headers change nothing vs a bare request", async () => {
    const { total, diffs, timeouts } = (await diffForgedVsBare(h.base)) as any;
    console.log("GA5 routes", total, "diffs", diffs.length, "bareTimeouts", timeouts.length, JSON.stringify({ diffs, timeouts }, null, 1));
    expect(total).toBeGreaterThan(50);
    expect(diffs).toEqual([]);
  });
});
