// GATE (PR 1546) harness — scratch only, never committed.
import express from 'express';
import http from 'http';
import type { AddressInfo } from 'net';

export const T_CONN = '22222222-2222-4222-8222-222222222222';
export const T_HUMAN = '44444444-4444-4444-8444-444444444444';
export const T_FORGED = '66666666-6666-4666-8666-666666666666';
export const DEFAULT_T = 'a0000000-0000-4000-8000-000000000001';

const PROCESS_EVENTS = ['unhandledRejection', 'uncaughtException', 'SIGTERM', 'SIGINT'] as const;
export async function boot(): Promise<{ base: string; mod: any; close: () => Promise<void> }> {
  process.env.DATABASE_URL = 'postgresql://gate1546:never-connected@127.0.0.1:1/gate1546';
  const before = new Map(PROCESS_EVENTS.map((e) => [e, process.listeners(e as any).slice()]));
  const notBound = { keepAliveTimeout: 0, headersTimeout: 0, close: (cb?: () => void) => cb?.() };
  const spy = jest.spyOn(express.application, 'listen').mockImplementation((() => notBound) as any);
  const mod = await import('../../index');
  const added: Array<[string, any]> = [];
  for (const e of PROCESS_EVENTS) for (const l of process.listeners(e as any)) if (!before.get(e)!.includes(l)) added.push([e, l]);
  const server = http.createServer(mod.default);
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => r()));
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  return {
    base, mod,
    close: async () => {
      await new Promise<void>((r) => server.close(() => r()));
      for (const [e, l] of added) process.removeListener(e as any, l);
      const { stopOverloadMonitor } = await import('@secuura/shared');
      stopOverloadMonitor();
      spy.mockRestore();
    },
  };
}

/** raw http so header case and duplicates reach the wire exactly as given */
export function raw(base: string, method: string, path: string, headers: Record<string, string | string[]>, body?: string)
  : Promise<{ status: number; body: string }> {
  const u = new URL(base + path);
  return new Promise((resolve, reject) => {
    const req = http.request({ host: u.hostname, port: u.port, path: u.pathname + u.search, method }, (res) => {
      let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => resolve({ status: res.statusCode || 0, body: b }));
    });
    req.setTimeout(4000, () => { req.destroy(); resolve({ status: -1, body: 'TIMEOUT' }); });
    req.on('error', (e) => (String(e).includes('socket hang up') ? resolve({ status: -1, body: 'TIMEOUT' }) : reject(e)));
    for (const [k, v] of Object.entries(headers)) req.setHeader(k, v as any);
    if (body !== undefined) { req.setHeader('content-type', 'application/json'); req.write(body); }
    req.end();
  });
}

const MOUNTS: Array<[string, string]> = [
  ['/health', 'routes/health:healthRouter'],
  ['/api/certifications', 'routes/certifications:certificationsRouter'],
  ['/api/documents', 'routes/documents:publicDocumentsRouter'],
  ['/api/documents', 'routes/documents:documentsRouter'],
  ['/api/verification', 'routes/verification:verificationRouter'],
  ['/api/v2/verification', 'routes/verificationV2:verificationV2Router'],
  ['/api/anchors', 'routes/anchors:anchorsRouter'],
  ['/api/anchoring', 'routes/anchors:anchorsRouter'],
  ['/api/metering', 'routes/metering:meteringRouter'],
  ['/api/gdpr', 'routes/gdpr:gdprRouter'],
  ['/api/platform/organizations', 'routes/platformOrganizations:platformOrganizationsRouter'],
  ['/api/system-errors', 'routes/systemErrors:systemErrorsRouter'],
  ['/api/client-errors', 'routes/systemErrors:systemErrorsRouter'],
  ['/api/admin', 'routes/adminConfig:adminConfigRouter'],
  ['/api/signatories', 'routes/signatories:signatoriesRouter'],
  ['/api/third-party-verifiers', 'routes/thirdPartyVerifiers:thirdPartyVerifiersRouter'],
  ['/api/webhooks', 'routes/webhooks:webhooksRouter'],
];

/** every (method, concrete path) the routers declare — enumerated from the router stacks, not sampled */
export async function enumerateRoutes(): Promise<Array<{ method: string; path: string }>> {
  const out: Array<{ method: string; path: string }> = [{ method: 'GET', path: '/api' }];
  for (const [prefix, spec] of MOUNTS) {
    const [file, name] = spec.split(':');
    const m = await import(`../../${file}`);
    const router = m[name];
    if (!router?.stack) throw new Error(`no router ${spec}`);
    for (const layer of router.stack) {
      if (!layer.route) continue;
      const p = String(layer.route.path).replace(/:([A-Za-z0-9_]+)\??/g, 'gate1546-$1');
      for (const meth of Object.keys(layer.route.methods)) out.push({ method: meth.toUpperCase(), path: prefix + (p === '/' ? '' : p) });
    }
  }
  return out;
}

export function norm(b: string): string {
  return b.replace(/\d{4}-\d{2}-\d{2}T[0-9:.]+Z/g, 'TS').replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, 'UUID').replace(/"(requestId|timestamp|correlationId)":"[^"]*"/g, '"$1":"X"').replace(/"latencyMs":\d+/g, '"latencyMs":N');
}

export const FORGED_SETS: Record<string, Record<string, string>> = {
  connector: { 'x-user-role': 'connector', 'x-tenant-id': T_FORGED, 'x-user-id': 'attacker', 'x-organization-id': T_FORGED },
  admin: { 'x-user-role': 'SYSTEM_ADMIN', 'x-user-id': 'attacker', 'x-tenant-id': T_FORGED, 'x-tenant-override': T_FORGED,
    'x-roles': 'SYSTEM_ADMIN', 'x-auth-user': 'attacker', 'x-org-id': T_FORGED, 'x-user-email': 'a@x' },
};

export async function diffForgedVsBare(base: string): Promise<{ total: number; diffs: string[] }> {
  const routes = await enumerateRoutes();
  const diffs: string[] = [];
  const timeouts: string[] = [];
  for (const r of routes) {
    const body = r.method === 'GET' || r.method === 'DELETE' ? undefined : '{}';
    const bare = await raw(base, r.method, r.path, {}, body);
    if (bare.status === -1) timeouts.push(r.method + ' ' + r.path);
    for (const [name, h] of Object.entries(FORGED_SETS)) {
      const f = await raw(base, r.method, r.path, h, body);
      if (f.status !== bare.status || norm(f.body) !== norm(bare.body)) {
        diffs.push(`${r.method} ${r.path} [${name}] bare=${bare.status} forged=${f.status} ${norm(f.body).slice(0, 120)}`);
      }
    }
  }
  return { total: routes.length, diffs, timeouts } as any;
}
