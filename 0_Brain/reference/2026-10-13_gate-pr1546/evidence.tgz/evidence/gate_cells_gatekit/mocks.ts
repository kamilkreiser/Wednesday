// Shared mock bodies (each test file still declares jest.mock itself; these are plain helpers).
export const T_CONN = '22222222-2222-4222-8222-222222222222';
export const T_HUMAN = '44444444-4444-4444-8444-444444444444';
export function fakeVerify(token: string): any {
  if (token === 'gate-connector-jwt') return { userId: 'connector:ps-gate', role: 'connector', tenantId: T_CONN, type: 'connector' };
  if (token === 'gate-human-jwt') return { userId: '55555555-5555-4555-8555-555555555555', role: 'OWNER', tenantId: T_HUMAN };
  const e: any = new Error('invalid'); e.name = 'JsonWebTokenError'; throw e;
}
