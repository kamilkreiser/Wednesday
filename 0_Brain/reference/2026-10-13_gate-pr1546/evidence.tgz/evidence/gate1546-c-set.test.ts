import { boot, raw, diffForgedVsBare, T_CONN, T_HUMAN, T_FORGED, DEFAULT_T } from "./gatekit/harness";
const mockUsage = jest.fn(async (..._a: unknown[]) => ({ marker: "gate1546-handler-ran" }));
jest.mock("../services/chargeEvents", () => ({ ...jest.requireActual("../services/chargeEvents"), getUsageSummary: (...a: unknown[]) => mockUsage(...a) }));
jest.mock("@secuura/shared/crypto/jwks", () => ({ ...jest.requireActual("@secuura/shared/crypto/jwks"), verifyJwtRs256: async (t: string) => require("./gatekit/mocks").fakeVerify(t) }));
jest.setTimeout(600000);
void T_HUMAN; void T_CONN; void T_FORGED; void DEFAULT_T; void diffForgedVsBare;
let h: { base: string; close: () => Promise<void> };
const PS = { authorization: "Bearer gate-connector-jwt", "x-user-role": "connector", "x-tenant-id": T_CONN, "x-user-id": "connector:ps-gate" };
const tenantOfLastCall = () => (mockUsage.mock.calls.length ? mockUsage.mock.calls[mockUsage.mock.calls.length - 1][0] : "NOT-CALLED");
const SECRET = "gate1546-synthetic-secret".padEnd(64, "9");
beforeAll(async () => { process.env.GATEWAY_VOUCH_SECRET = SECRET; h = await boot(); }, 120000);
afterAll(async () => { await h?.close(); delete process.env.GATEWAY_VOUCH_SECRET; });
describe("GATE C — secret SET", () => {
  it("GC0 CONTROL secret set", () => { expect(process.env.GATEWAY_VOUCH_SECRET).toBe(SECRET); });
  it("GC1 legit vouched Platform-S call: 200 and ITS tenant (not refused, not defaulted)", async () => {
    mockUsage.mockClear();
    const r = await raw(h.base, "GET", "/api/metering/usage", { ...PS, "x-gateway-vouch": SECRET });
    expect(r.status).toBe(200); expect(tenantOfLastCall()).toBe(T_CONN);
  });
  it("GC2 legit vouched Platform-S call WITHOUT Bearer (exchange failed) still served by the shim", async () => {
    mockUsage.mockClear();
    const r = await raw(h.base, "GET", "/api/metering/usage", { "x-user-role": "connector", "x-tenant-id": T_CONN, "x-gateway-vouch": SECRET });
    expect(r.status).toBe(200); expect(tenantOfLastCall()).toBe(T_CONN);
  });
  it("GC3 legit vouched human: tenant from the gateway header", async () => {
    mockUsage.mockClear();
    const r = await raw(h.base, "GET", "/api/metering/usage", { authorization: "Bearer gate-human-jwt", "x-tenant-id": T_HUMAN, "x-gateway-vouch": SECRET });
    expect(r.status).toBe(200); expect(tenantOfLastCall()).toBe(T_HUMAN);
  });
  const bad: Array<[string, string | string[]]> = [
    ["wrong same-length", "x".repeat(64)], ["prefix (subset)", SECRET.slice(0, 32)], ["upper-cased", SECRET.toUpperCase()], ["duplicated header", [SECRET, SECRET]], ["empty", ""], ["superset", SECRET + "0"],
  ];
  for (const [name, v] of bad) {
    it("GC4 bad vouch refused (no Bearer): " + name, async () => {
      mockUsage.mockClear();
      const r = await raw(h.base, "GET", "/api/metering/usage", { "x-user-role": "connector", "x-tenant-id": T_FORGED, "x-gateway-vouch": v });
      expect(r.status).toBe(401); expect(mockUsage).not.toHaveBeenCalled();
    });
  }
  it("GC4b trailing whitespace is HTTP optional-whitespace: trimmed by the parser, so it IS the secret on the wire (expected 200)", async () => {
    mockUsage.mockClear();
    const r = await raw(h.base, "GET", "/api/metering/usage", { "x-user-role": "connector", "x-tenant-id": T_CONN, "x-gateway-vouch": SECRET + "  " });
    expect(r.status).toBe(200);
  });
  it("GC5 Platform-S with a WRONG vouch but a valid Bearer: 200 on the DEFAULT tenant (same shape as unset)", async () => {
    mockUsage.mockClear();
    const r = await raw(h.base, "GET", "/api/metering/usage", { ...PS, "x-gateway-vouch": "x".repeat(64) });
    console.log("GC5", r.status, tenantOfLastCall());
    expect({ status: r.status, tenant: tenantOfLastCall() }).toEqual({ status: 200, tenant: DEFAULT_T });
  });
  it("GC6 BY DESIGN (KS-1041): the vouch is a static bearer secret, not bound to the request — any holder can replay it", async () => {
    mockUsage.mockClear();
    const r = await raw(h.base, "GET", "/api/metering/usage", { "x-user-role": "connector", "x-tenant-id": T_FORGED, "x-gateway-vouch": SECRET });
    expect(r.status).toBe(200); expect(tenantOfLastCall()).toBe(T_FORGED);
  });
  it("GC7 ENUMERATED with the secret set and no vouch: forged headers change nothing", async () => {
    const { total, diffs, timeouts } = (await diffForgedVsBare(h.base)) as any;
    console.log("GC7 routes", total, "diffs", diffs.length, "bareTimeouts", timeouts.length, JSON.stringify({ diffs, timeouts }, null, 1));
    expect(diffs).toEqual([]);
  });
});
