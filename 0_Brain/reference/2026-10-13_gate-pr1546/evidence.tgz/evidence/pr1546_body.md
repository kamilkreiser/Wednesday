Refs KS-1032 — ticket: https://linear.app/secuura/issue/KS-1032

> This pull request **contributes to** KS-1032 and must NOT auto-close it: the ticket's nine (now eleven) trust-header reads span four services and this changes **originate's four only**; the rest stay with their own lanes. The branch name gave the Linear attachment a `closes` link on open, which this line is here to flip.

## BLUF

Two sites in originate treated request headers as authoritative, both justified in their own comments by "originate is internal-only ingress". **That premise is false and was measured false**: `originate:4000` is not published to the host but sits on one flat compose network, and from a peer container on the demo box a forged `x-user-role: connector` plus a tenant id answered **200**, while the same forged request through `api-gateway:8080` answered 401 (the table at `services/originate/src/utils/gatewayProvenance.ts:19-32`).

KS-1041 Step 2 had already built the control. It was **inert unless `GATEWAY_VOUCH_SECRET` is set**, and unset is the shipped default — `.env.example:332`, `env.example:469`, and `${GATEWAY_VOUCH_SECRET:-}` for both services at `docker-compose.yml:452` and `:610`. The only place it is wired to a value is `deployment/azure/services.bicep:686,826`, the Container Apps estate deleted 2026-07-31. So every box the templates produce honoured forged trust headers.

**Scope is Kam's ruling of 2026-10-13** on card `secuura-ks1032-fail-closed-when-vouch-secret-unset-1013`: *"Fail closed, deployed only after the secret is set"*. All three parts, and the condition is on **deploying**, not on merging.

## The census, run rather than inherited

`bash Blockchain/Dev/scripts/check-no-trust-header-reads.sh` at develop `405e33a1`, default mode `fail`, rc 1: **eleven** reads, not the ticket's nine. originate's four are `src/index.ts:251` (the ticket said `:230`), `src/routes/metering.ts:42`, `:43`, `:45`. The two `api-gateway/src/routes/proxy.ts` hits (`:682`, `:708`) are new since the ticket was written and are **not** originate's — they look like the gateway *forwarding* rather than *trusting*, but I have not read them closely and am not claiming it.

## What changed

1. **The verdict is recorded, not only acted on.** The provenance middleware sets `vouched` / `unvouched` / `unconfigured` on the request. Three values rather than a boolean: the last two are the same *decision* and a different *fact*, and a boolean throws that away.
2. **An unconfigured request is treated as unvouched** — the trust set is stripped. Fail closed, per the ruling.
3. **The two trusting sites consult the verdict, not the header.** `routes/metering.ts`'s connector shim fires only on a vouched request; the KS-458 tenant resolution reads `x-tenant-id` only on one. This is deliberate defence in depth: a site that trusts a header must not depend on an upstream strip still being there.
4. **The KS-458 resolution moved to `utils/requestTenant.ts`** so a cell can run the real code instead of a rebuilt copy — the defect class KS-1432 was filed for. The verdict is **declared on express's `Request`** (the pattern `packages/shared`'s `db/tenant-context.ts` already uses) rather than read through `(req as any)` — the KS-759 / KS-1593 class.

An upstream-attached `req.tenantId` is deliberately **not** gated: it is set by `extractTenantContext` / the `X-Tenant-Override` path from a verified context, never from a caller's raw header, and gating it would break multi-tenancy for no gain. Mutant m5 is that mistake and cell C2 kills it.

**Two pre-existing KS-1041 cells are inverted, not deleted.** Their describe block was `unconfigured — fail-open, but LOUD` and its own comment asked for exactly this: *"This test exists so that a future change to fail-closed is a DECISION SOMEONE MAKES, not a silent regression."* Kam made it; the block is renamed and the ruling and card id are in the comment.

## Test Evidence

**Touched:** `services/originate` — `utils/gatewayProvenance.ts`, `utils/requestTenant.ts` (new), `index.ts`, `routes/metering.ts`, `__tests__/ks1032-unconfigured-vouch-fails-closed.test.ts` (new, 12 cells), `__tests__/ks1041-gateway-provenance.test.ts`.

**Ran:**
- originate unit suite **106/106 suites, 1333/1333 tests, rc 0** (baseline 105 suites / 1321 tests, plus this file's 12).
- `tsc --noEmit` over originate: **rc 0, 0 errors**.
- `ks1041-gateway-provenance` + `ks1041-provenance-mount-wiring`: **24/24**.
- **Red-first: 6 red / 6 green of 12, with both CONTROL cells GREEN.** Red: A1, A2, A3 (the forged-header refusals), A5 (the boot line), B1 (verdict + strip), C1 (the gated tenant arm). Green: both controls, A4 (the two by-design direct callers), B2, C2, C3 — the cells that assert nothing changed. A straight revert is a *compile break* here (the cells import a new module), and a compile break reds nothing, so the variant restores develop's **behaviour** with the new plumbing present.
- **Mutants 7/7 killed**, baseline green and restore green. Recorded honestly: A1-A3 **cannot** catch a verdict-reader mutant, because on an unconfigured request the strip has already removed the headers and the shim's header test is false whatever the verdict says. That is defence in depth working; A1-A3's red comes from the develop-behaviour variant instead. The expectations were corrected to match the cells, not the reverse.
- **Pre-push preflight, in-hook, PUSH_RC=0**, and quoted as it quotes itself: `PREFLIGHT INCOMPLETE — 13/16 legs ran, 3 SKIPPED. Nothing failed.` Legs 3, 4, 8 skipped — local stack not up. Leg 14 shell suites **88 passed / 0 failed / 0 skipped of 88**. Leg 15 21/21 guards, production-guard 23/23 services. Leg 16 auth 42 baselined / 0 new / 0 stale, api-gateway 35 / 0 / 0, vc-issuer 0 / 0 / 0. Read by **tallies, not a FAIL grep** — the suites legitimately print `ok … REFUSED` lines; the count of lines reporting a non-zero failed count is **zero**.

**NOT run, and the honest reason:** the four platform suites (Schemathesis, Akto, Playwright, k6) and preflight legs 3, 4 and 8 — the local stack is not up in this worktree and I did not start it. No spec surface changed, so `check:openapi` has nothing to see here beyond what leg 1 ran.

**Migrations + config:** no migration; no config file changed; no change to the served specification.

## ⚠ Deploy condition — this is the part that must not be missed

Read the effective `GATEWAY_VOUCH_SECRET` on Kintsugi and on demo, set it where empty, and check Platform-S metering end to end **before** this ships to either. Until the secret is set on a box: that box's Platform-S metering answers **401**, and a multi-tenant deployment loses its tenant on every request. On a single-tenant deployment the fallback is `DEFAULT_TENANT_ID`, which is the tenant migration 039 backfilled every row into, so the answers are unchanged. It is on the deploy-blockers list.

- [x] Pre-merge acknowledged — Schemathesis: **NOT run** (local stack down), stated above rather than ticked as done.
- [x] Pre-merge acknowledged — Akto: **NOT run** (local stack down), stated above rather than ticked as done.
