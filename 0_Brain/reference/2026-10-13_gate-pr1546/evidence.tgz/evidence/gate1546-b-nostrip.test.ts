import { boot, raw, diffForgedVsBare, T_CONN, T_HUMAN, T_FORGED, DEFAULT_T } from "./gatekit/harness";
const mockUsage = jest.fn(async (..._a: unknown[]) => ({ marker: "gate1546-handler-ran" }));
jest.mock("../services/chargeEvents", () => ({ ...jest.requireActual("../services/chargeEvents"), getUsageSummary: (...a: unknown[]) => mockUsage(...a) }));
jest.mock("@secuura/shared/crypto/jwks", () => ({ ...jest.requireActual("@secuura/shared/crypto/jwks"), verifyJwtRs256: async (t: string) => require("./gatekit/mocks").fakeVerify(t) }));
jest.setTimeout(600000);
void T_HUMAN; void T_CONN; void T_FORGED; void DEFAULT_T; void diffForgedVsBare;
let h: { base: string; close: () => Promise<void> };
const PS = { authorization: "Bearer gate-connector-jwt", "x-user-role": "connector", "x-tenant-id": T_CONN, "x-user-id": "connector:ps-gate" };
const tenantOfLastCall = () => (mockUsage.mock.calls.length ? mockUsage.mock.calls[mockUsage.mock.calls.length - 1][0] : "NOT-CALLED");
// THE STRIP REMOVED, the verdict still recorded: the state part (c) and the metering verdict read
// exist for. Simulated by restoring every header the real middleware deleted (except the vouch).
jest.mock("../utils/gatewayProvenance", () => {
  const actual = jest.requireActual("../utils/gatewayProvenance");
  return { ...actual, createGatewayProvenanceMiddleware: (secret: string) => {
    const real = actual.createGatewayProvenanceMiddleware(secret);
    return (req: any, res: any, next: any) => {
      const saved = { ...req.headers };
      real(req, res, () => { for (const k of Object.keys(saved)) if (!(k in req.headers) && k !== "x-gateway-vouch") req.headers[k] = saved[k]; next(); });
    };
  } };
});
beforeAll(async () => { delete process.env.GATEWAY_VOUCH_SECRET; h = await boot(); }, 120000);
afterAll(async () => { await h?.close(); });
describe("GATE B — secret UNSET, strip REMOVED (second lines only)", () => {
  it("GB0 CONTROL the mock really removed the strip: a forged header survives to the route layer", async () => {
    const { createGatewayProvenanceMiddleware } = await import("../utils/gatewayProvenance");
    const req: any = { headers: { "x-tenant-id": T_FORGED } };
    createGatewayProvenanceMiddleware("")(req, {} as any, () => undefined);
    expect(req.headers["x-tenant-id"]).toBe(T_FORGED); expect(req.gatewayProvenance).toBe("unconfigured");
  });
  it("GB1 metering verdict read: forged connector headers with no Bearer are refused", async () => {
    mockUsage.mockClear();
    const r = await raw(h.base, "GET", "/api/metering/usage", { "x-user-role": "connector", "x-tenant-id": T_FORGED, "x-user-id": "a" });
    expect(r.status).toBe(401); expect(mockUsage).not.toHaveBeenCalled();
  });
  it("GB2 index.ts KS-458 wiring: human JWT + forged x-tenant-id resolves to the default tenant", async () => {
    mockUsage.mockClear();
    const r = await raw(h.base, "GET", "/api/metering/usage", { authorization: "Bearer gate-human-jwt", "x-tenant-id": T_FORGED });
    expect(r.status).toBe(200); expect(tenantOfLastCall()).toBe(DEFAULT_T);
  });
  it("GB3 ENUMERATED with the strip removed: forged headers change nothing on any declared route", async () => {
    const { total, diffs, timeouts } = (await diffForgedVsBare(h.base)) as any;
    console.log("GB3 routes", total, "diffs", diffs.length, "bareTimeouts", timeouts.length, JSON.stringify({ diffs, timeouts }, null, 1));
    expect(total).toBeGreaterThan(50); expect(diffs).toEqual([]);
  });
});

void PS;
