#!/bin/bash
# usage: run.sh <variant: head|dev|path-to-ts> <MT: true|false> <layout: L1|L2|L1noplat> <label> [jest pattern...]
# Installs the variant's verification.ts into the scratch worktree, runs jest integration, restores head.
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad
O=$S/wt/Blockchain/Dev/services/originate
V="$1"; MTV="$2"; LAY="$3"; LABEL="$4"; shift 4
PAT="${@:-ks1119-verify-never-claims}"
case "$V" in
  head) SRC=$S/src/verification.head.ts ;;
  dev)  SRC=$S/src/verification.dev.ts ;;
  *)    SRC="$V" ;;
esac
cp "$SRC" $O/src/routes/verification.ts
PORT=55414
case "$LAY" in
  L1) TDB=secuura; PDB=secuura_platform ;;
  L2) TDB=secuura_one; PDB=secuura_one ;;
  L1noplat) TDB=secuura; PDB= ;;
  L1fallback) TDB=secuura; PDB=; SPDB=secuura_platform ;;
esac
mkdir -p $S/ev/runs
LOG=$S/ev/runs/$LABEL.log
{
  echo "# variant=$V sha256=$(shasum -a 256 $O/src/routes/verification.ts | cut -c1-16) MT=$MTV layout=$LAY pattern=$PAT"
  env -i PATH=$PATH HOME=$HOME \
    MULTI_TENANCY_ENABLED=$MTV \
    TEST_DATABASE_URL=postgresql://secuura@127.0.0.1:$PORT/$TDB \
    TEST_APP_DATABASE_URL=postgresql://secuura_app:appsecret@127.0.0.1:$PORT/$TDB \
    ${PDB:+TEST_PLATFORM_DATABASE_URL=postgresql://secuura_app:appsecret@127.0.0.1:$PORT/$PDB} \
    ${PDB:+TEST_SUPER_PLATFORM_DATABASE_URL=postgresql://secuura@127.0.0.1:$PORT/$PDB} \
    ${PDB:+PLATFORM_DATABASE_URL=postgresql://secuura_app:appsecret@127.0.0.1:$PORT/$PDB} \
    ${SPDB:+TEST_SUPER_PLATFORM_DATABASE_URL=postgresql://secuura@127.0.0.1:$PORT/$SPDB} \
    DATABASE_URL=postgresql://secuura_app:appsecret@127.0.0.1:$PORT/$TDB \
    NODE_ENV=test \
    $O/../../node_modules/.bin/jest --rootDir $O --config $O/jest.integration.config.js --runInBand --verbose $PAT 2>&1
  echo "# jest rc=$?"
} > $LOG
cp $S/src/verification.head.ts $O/src/routes/verification.ts
grep -E "^Tests:|# jest rc|falling back to single-tenant|Multi-tenancy enabled" $LOG | sed "s/^/[$LABEL] /"
