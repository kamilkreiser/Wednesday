#!/bin/bash
# usage: probe_all.sh <run> <svc...>   (svc = gate_svc_dev gate_svc_head gate_svc_M2 ...)
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad
RUN=$1; shift
LAYOUTS=${LAYOUTS:-"L1 L2"}; MODES=${MODES:-"true false"}
HP=47111
mkdir -p $S/ev/probe
for svc in "$@"; do for l in $LAYOUTS; do for m in $MODES; do
  lab=${svc}_${l}_mt${m}
  bash $S/tools/svc.sh start $svc $m $l $HP $lab
  node $S/tools/probe.mjs probe $l $RUN $HP $S/ev/probe/$lab.json
  bash $S/tools/svc.sh stop $lab
done; done; done
