import sys, hashlib, json
S = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad'
src = open(f'{S}/src/verification.head.ts').read()
GATE = "if ((!docRows || docRows.rows.length === 0) && !hashToVerify) {"
GUARD = "if (!docRows || docRows.rows.length === 0) return null;"
FLAG = "const hashMatch = typeof docRow.content_hash === 'string' && normaliseHash(docRow.content_hash) === hashNorm;"
HQ = "[hashToVerify, searchHash, `sha256:${searchHash}`],\n      ));\n    }\n    // KS-1119"
for s in (GATE, GUARD, FLAG, HQ):
    assert src.count(s) == 1, s
M = {
 'M1_drop_gate': [(GATE, "if (!docRows || docRows.rows.length === 0) {")],
 'M2_flag_true': [(FLAG, "const hashMatch = true;")],
 'M1M2_both': [(GATE, "if (!docRows || docRows.rows.length === 0) {"), (FLAG, "const hashMatch = true;")],
 'M3_row_side_unnormalised': [(FLAG, "const hashMatch = typeof docRow.content_hash === 'string' && docRow.content_hash === hashNorm;")],
 'M4_gate_inverted': [(GATE, "if ((!docRows || docRows.rows.length === 0) && hashToVerify) {")],
 'M5_comment_only': [(FLAG, FLAG + " // gate1542 comment-only control")],
 'M6_gate_on_documentId': [(GATE, "if ((!docRows || docRows.rows.length === 0) && !documentId) {")],
 'M7_guard_removed': [(GUARD, "if (docRows.rows.length === 0) return null;")],
 'M8_sent_side_unnormalised': [(FLAG, "const hashMatch = typeof docRow.content_hash === 'string' && normaliseHash(docRow.content_hash) === computedHash;")],
 'M9_flag_from_documentId': [(FLAG, "const hashMatch = !documentId || docRow.external_id === documentId || docRow.id === documentId;")],
 'M10_fallback_for_empty_docid': [(GATE, "if ((!docRows || docRows.rows.length === 0) && (!hashToVerify || documentId === '')) {")],
 'M11_hashquery_drops_prefixed_form': [(HQ, HQ.replace("`sha256:${searchHash}`", "searchHash"))],
}
out = {}
for name, edits in M.items():
    t = src
    for a, b in edits:
        assert t.count(a) == 1, (name, a)
        t = t.replace(a, b)
    p = f'{S}/src/mut_{name}.ts'
    open(p, 'w').write(t)
    out[name] = hashlib.sha256(t.encode()).hexdigest()[:16]
print(json.dumps(out, indent=1))
