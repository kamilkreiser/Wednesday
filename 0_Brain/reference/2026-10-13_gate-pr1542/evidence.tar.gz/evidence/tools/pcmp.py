import json, sys, collections
# usage: pcmp.py a.json b.json [filterprefix]  -> differences in claim fields per (cell, caller)
K = ('status', 'verified', 'hashValid', 'integ', 'exists', 'documentId', 'storedHandedBack')
def load(p):
    rows = [json.loads(l.rstrip(',\n').lstrip('[').rstrip(']')) for l in open(p) if l.strip() not in ('', '[', ']')]
    return {(r['cell'], r['caller']): r for r in rows}
a, b = load(sys.argv[1]), load(sys.argv[2])
pref = sys.argv[3] if len(sys.argv) > 3 else ''
n = 0
for k in sorted(set(a) | set(b)):
    if not k[0].startswith(pref): continue
    x, y = a.get(k, {}), b.get(k, {})
    dx = {f: x.get(f) for f in K}; dy = {f: y.get(f) for f in K}
    if dx != dy:
        n += 1
        ch = {f: (dx[f], dy[f]) for f in K if dx[f] != dy[f]}
        print(f'  {k[0]} [{k[1]}] ' + ' '.join(f'{f}:{v[0]}->{v[1]}' for f, v in ch.items()))
print(f'  {n} differing of {len(set(a)|set(b))}')
