#!/bin/bash
# usage: svc.sh start <svcdir-name> <MT true|false> <L1|L2> <httpport> <label> [NODE_ENV]   |  svc.sh stop <label>
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad
D=$S/wt/Blockchain/Dev
PGP=55414
mkdir -p $S/ev/svc $S/run
if [ "$1" = stop ]; then
  pid=$(cat $S/run/$2.pid 2>/dev/null); [ -n "$pid" ] && { pkill -P $pid 2>/dev/null; kill $pid 2>/dev/null; }
  sleep 1; echo "stopped $2"; exit 0
fi
SVC=$2; MTV=$3; LAY=$4; HP=$5; LABEL=$6; NE=${7:-development}
case "$LAY" in L1) TDB=secuura; PDB=secuura_platform ;; L2) TDB=secuura_one; PDB=secuura_one ;; esac
env -i PATH=$PATH HOME=$HOME \
  NODE_ENV=$NE PORT=$HP MULTI_TENANCY_ENABLED=$MTV \
  DATABASE_URL=postgresql://secuura_app:appsecret@127.0.0.1:$PGP/$TDB \
  PLATFORM_DATABASE_URL=postgresql://secuura_app:appsecret@127.0.0.1:$PGP/$PDB \
  ANCHORING_SERVICE_URL=http://127.0.0.1:2 SIMULATE_ANCHORING=true \
  AUTH_SERVICE_URL=http://gate1542-auth.invalid JWT_SECRET=gate1542-secret-gate1542-secret-0123456789 \
  PII_ENCRYPTION_KEY=$(openssl rand -hex 32) PII_LOOKUP_HMAC_KEY=$(openssl rand -hex 32) \
  REDIS_URL=redis://127.0.0.1:1 \
  $D/node_modules/.bin/tsx $D/services/$SVC/src/index.ts > $S/ev/svc/$LABEL.log 2>&1 &
echo $! > $S/run/$LABEL.pid
for i in $(seq 1 60); do
  curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$HP/health 2>/dev/null | grep -q 200 && break
  sleep 1
done
echo "[$LABEL] svc=$SVC sha=$(shasum -a 256 $D/services/$SVC/src/routes/verification.ts | cut -c1-16) MT=$MTV layout=$LAY port=$HP health=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$HP/health)"
grep -E "falling back to single-tenant|Multi-tenancy enabled|TenantPoolManager\] Initialized" $S/ev/svc/$LABEL.log | sed "s/^/[$LABEL] /"
