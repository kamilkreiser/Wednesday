import sys, re
# usage: jcmp.py a.log b.log  -> per-test outcome differences (by suite + test title)
def parse(p):
    res = {}; suite = None
    for line in open(p, errors='replace'):
        m = re.match(r'^(PASS|FAIL) .*/__tests__/(\S+)', line)
        if m: suite = m.group(2); continue
        m = re.match(r'^\s+(✓|✕|○)\s+(.*?)(\s\(\d+(\.\d+)? m?s\))?$', line.rstrip('\n'))
        if m and suite: res[(suite, m.group(2))] = m.group(1)
    return res
a, b = parse(sys.argv[1]), parse(sys.argv[2])
print(f'{sys.argv[1].split("/")[-1]}: {len(a)} tests, {sum(v=="✕" for v in a.values())} failed | {sys.argv[2].split("/")[-1]}: {len(b)} tests, {sum(v=="✕" for v in b.values())} failed')
diff = [(k, a.get(k), b.get(k)) for k in sorted(set(a) | set(b)) if a.get(k) != b.get(k)]
for (s, t), x, y in diff: print(f'  DIFF {s} :: {t[:110]} : {x} -> {y}')
print(f'  {len(diff)} differing')
