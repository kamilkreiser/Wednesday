import json, sys, collections, glob, os
# Mutant verdicts from the gate's own probe: each mutant vs head, same layout+mode. A mutant is KILLED by a probe
# cell when any claim field (status, verified, hashValid, integrityVerified, documentExists, documentId, stored-hash-returned)
# differs from head's reading of the same (cell, caller).
P = sys.argv[1]
K = ('status', 'verified', 'hashValid', 'integ', 'exists', 'documentId', 'storedHandedBack')
def load(p):
    rows = [json.loads(l.rstrip(',\n').lstrip('[').rstrip(']')) for l in open(p) if l.strip() not in ('', '[', ']')]
    return {(r['cell'], r['caller']): tuple(r.get(f) for f in K) for r in rows}
for mode in ('true', 'false'):
    head = load(f'{P}/gate_svc_head_L1_mt{mode}.json')
    print(f'=== MT={mode} (vs head, {len(head)} cells)')
    for f in sorted(glob.glob(f'{P}/gate_svc_*_L1_mt{mode}.json')):
        name = os.path.basename(f).replace('gate_svc_', '').replace(f'_L1_mt{mode}.json', '')
        if name == 'head': continue
        m = load(f)
        diff = sorted(k for k in head if head[k] != m.get(k))
        groups = collections.Counter('.'.join(k[0].split('.')[:3]) for k in diff)
        verdict = 'KILLED' if diff else 'survives'
        print(f'  {name:36s} {verdict:8s} {len(diff):4d} cells  ' + '; '.join(f'{g} x{n}' for g, n in sorted(groups.items())[:12]))
