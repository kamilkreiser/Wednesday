const fs=require('fs');
const [a,b]=process.argv.slice(2);
const A=JSON.parse(fs.readFileSync(a)).packages,B=JSON.parse(fs.readFileSync(b)).packages;
const ka=Object.keys(A),kb=Object.keys(B);
console.log('entries before/after',ka.length,kb.length);
console.log('added',kb.filter(k=>!(k in A)));
console.log('removed',ka.filter(k=>!(k in B)));
const F=['dev','optional','devOptional','peer'],V=['version','resolved','integrity'];
let vc=0,fc=0,other=[];
for(const k of ka){ if(!(k in B))continue;
 for(const f of V) if(A[k][f]!==B[k][f]){vc++;console.log('VCHANGE',k,f,A[k][f],'->',B[k][f]);}
 for(const f of F) if(A[k][f]!==B[k][f]){fc++;console.log('FLAG',k,f,A[k][f],'->',B[k][f]);}
 const strip=o=>{const c={...o};[...F,...V].forEach(x=>delete c[x]);return JSON.stringify(c)};
 if(strip(A[k])!==strip(B[k])) other.push(k);
}
console.log('version/resolved/integrity changes',vc,'flag changes',fc);
console.log('other-field changes in entries:',other);
for(const k of other){const x=A[k],y=B[k];for(const f of new Set([...Object.keys(x),...Object.keys(y)])){if(JSON.stringify(x[f])!==JSON.stringify(y[f])&&![...F,...V].includes(f))console.log('  ',k,f,JSON.stringify(x[f]),'->',JSON.stringify(y[f]));}}
