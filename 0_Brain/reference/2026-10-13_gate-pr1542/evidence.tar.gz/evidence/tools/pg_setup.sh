#!/bin/bash
# Gate PR1542: throwaway PG15 on 55414, three DBs.
#  L1 split : secuura (tenant tables) + secuura_platform (platform tables)
#  L2 single: secuura_one (tenant tables + platform tables in the same DB)
set -u
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad
D=$S/wt/Blockchain/Dev
PGB=/opt/homebrew/opt/postgresql@15/bin
PORT=55414
export PATH=$PGB:$PATH
mkdir -p $S/pg $S/sock
if [ ! -d $S/pg/data ]; then
  initdb -U secuura -A trust -D $S/pg/data --no-locale -E UTF8 >/dev/null || exit 1
fi
pg_ctl -D $S/pg/data -l $S/pg/server.log -o "-p $PORT -k \"\" -c listen_addresses=127.0.0.1 -c fsync=off -c timezone=UTC" -w start || exit 1
P="psql -h 127.0.0.1 -p $PORT -U secuura -v ON_ERROR_STOP=1 -q"
$P -d postgres -tAc "select version()"
for db in secuura secuura_platform secuura_one; do $P -d postgres -c "CREATE DATABASE $db" ; done
$P -d postgres -c "CREATE ROLE secuura_app LOGIN PASSWORD 'appsecret' NOSUPERUSER NOBYPASSRLS"
for tdb in secuura secuura_one; do
  echo "---- docker/init/*.sql into $tdb"
  for f in $D/docker/init/*.sql; do
    b=$(basename $f); [ "$b" = "00-create-platform-db.sql" ] && { echo "  SKIP $b (dblink)"; continue; }
    if $P -d $tdb -f $f >/dev/null 2>$S/pg/err.txt; then echo "  $b OK"; else echo "  $b FAIL"; tail -3 $S/pg/err.txt; fi
  done
done
for pdb in secuura_platform secuura_one; do
  echo "---- docker/init-platform/*.sql into $pdb"
  for f in $D/docker/init-platform/*.sql; do
    b=$(basename $f)
    if $P -d $pdb -f $f >/dev/null 2>$S/pg/err.txt; then echo "  $b OK"; else echo "  $b FAIL"; tail -3 $S/pg/err.txt; fi
  done
done
echo "---- run-migrations L1"
( cd $D && DATABASE_URL=postgresql://secuura@127.0.0.1:$PORT/secuura PLATFORM_DATABASE_URL=postgresql://secuura@127.0.0.1:$PORT/secuura_platform sh scripts/run-migrations.sh 2>&1 | grep -E "Summary|FAILED|finished|ERROR" ; echo "rc=${PIPESTATUS[0]}")
echo "---- run-migrations L2"
( cd $D && DATABASE_URL=postgresql://secuura@127.0.0.1:$PORT/secuura_one PLATFORM_DATABASE_URL=postgresql://secuura@127.0.0.1:$PORT/secuura_one sh scripts/run-migrations.sh 2>&1 | grep -E "Summary|FAILED|finished|ERROR" ; echo "rc=${PIPESTATUS[0]}")
for db in secuura secuura_platform secuura_one; do
  $P -d $db -c "GRANT CONNECT ON DATABASE $db TO secuura_app; GRANT USAGE ON SCHEMA public TO secuura_app; GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO secuura_app; GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO secuura_app;"
  echo "$db tables: $($P -d $db -tAc "select count(*) from pg_tables where schemaname='public'")  registry? $($P -d $db -tAc "select to_regclass('public.platform_document_registry') is not null") documents? $($P -d $db -tAc "select to_regclass('public.documents') is not null") documents RLS forced: $($P -d $db -tAc "select relrowsecurity||'/'||relforcerowsecurity from pg_class where relname='documents'")"
done
echo "secuura_app attrs: $($P -d postgres -tAc "select rolsuper||'/'||rolbypassrls from pg_roles where rolname='secuura_app'")"
