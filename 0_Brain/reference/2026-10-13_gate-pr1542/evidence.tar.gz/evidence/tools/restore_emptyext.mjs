// Re-insert the gate's own empty-external_id rows (deleted before the author's-cells mutant runs, which insert their own).
import { createRequire } from 'module';
import fs from 'fs';
const S = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad';
const require = createRequire(S + '/wt/Blockchain/Dev/package.json');
const { Client } = require('pg');
for (const db of ['secuura', 'secuura_one']) {
  const [id, t, h] = fs.readFileSync(`${S}/ev/emptyext_${db}.txt`, 'utf8').trim().split('|');
  const c = new Client({ connectionString: `postgresql://secuura@127.0.0.1:55414/${db}` }); await c.connect();
  const r = await c.query(`INSERT INTO documents (id, tenant_id, external_id, title, document_type, content_hash, status, certified_at, metadata, certification_metadata)
    VALUES ($1::uuid,$2::uuid,'','gate1542 EMPTY-EXT row','DOCUMENT',$3,'certified',NOW(),'{}'::jsonb,'{}'::jsonb)`, [id, t, h]);
  console.log(db, 'inserted', r.rowCount);
  await c.end();
}
