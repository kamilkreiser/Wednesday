// Gate PR1542 — from-scratch probe against the REAL originate service (index.ts), no author harness.
// usage: node probe.mjs seed <L1|L2> <run>        -> seeds data, writes fixtures json
//        node probe.mjs probe <L1|L2> <run> <httpport> <outfile>
import { createRequire } from 'module';
import { randomBytes, createHash, randomUUID } from 'crypto';
import fs from 'fs';
const S = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/423cfd28-246e-4664-aadb-c368c091695b/scratchpad';
const require = createRequire(S + '/wt/Blockchain/Dev/package.json');
const { Client } = require('pg');
const [, , cmd, layout, run, port, outfile] = process.argv;
const TDB = layout === 'L1' ? 'secuura' : 'secuura_one';
const PDB = layout === 'L1' ? 'secuura_platform' : 'secuura_one';
const url = (db) => `postgresql://secuura@127.0.0.1:55414/${db}`;
const FIX = `${S}/ev/fixtures_${layout}_${run}.json`;
const hex = () => randomBytes(32).toString('hex');
const sha = (b) => createHash('sha256').update(b).digest('hex');

async function seed() {
  const t = new Client({ connectionString: url(TDB) }); await t.connect();
  const p = new Client({ connectionString: url(PDB) }); await p.connect();
  const A = randomUUID(), B = randomUUID(), C = randomUUID();
  for (const [id, n] of [[A, 'A'], [B, 'B'], [C, 'C']]) {
    await p.query(`INSERT INTO tenants (id,name,slug,status,created_at,updated_at) VALUES ($1,$2,$2,'active',NOW(),NOW())`, [id, `gate1542-${run}-${n}`]);
  }
  const doc = async (tenant, ext, hash, status = 'certified', certifiedAt = 'NOW()', createdAt = 'NOW()') => {
    const id = randomUUID();
    await t.query(`INSERT INTO documents (id, tenant_id, external_id, title, document_type, content_hash, status, certified_at, created_at, metadata, certification_metadata)
      VALUES ($1::uuid,$2::uuid,$3,$4,'DOCUMENT',$5,$6,${certifiedAt},${createdAt},'{}'::jsonb,'{}'::jsonb)`, [id, tenant, ext, `gate1542 ${ext ?? 'NULL'} ${run}`, hash, status]);
    return id;
  };
  const reg = async (tenant, docId, hash) => {
    await p.query(`INSERT INTO platform_document_registry (id, content_hash, document_id, tenant_id, tenant_slug, document_type, title, status, certified_at, created_at, updated_at)
      VALUES ($1::uuid,$2,$3,$4::uuid,$5,'DOCUMENT',$6,'certified',NOW(),NOW(),NOW())`, [randomUUID(), hash, docId, tenant, 'slug-' + tenant.slice(0, 6), 'reg ' + docId]);
  };
  const F = {};
  F.A = A; F.B = B; F.C = C;
  F.H1 = hex(); F.E1 = `g1542-bare-${run}`; await doc(A, F.E1, F.H1); await reg(A, F.E1, F.H1);
  F.H2 = hex(); F.E2 = `g1542-pref-${run}`; await doc(A, F.E2, 'sha256:' + F.H2); await reg(A, F.E2, 'sha256:' + F.H2);
  F.H3 = hex(); F.E3 = `g1542-tenB-${run}`; await doc(B, F.E3, F.H3); await reg(B, F.E3, F.H3);
  // revoked doc (A), registered
  F.H4 = hex(); F.E4 = `g1542-rev-${run}`; await doc(A, F.E4, F.H4, 'revoked'); await reg(A, F.E4, F.H4);
  // item 5: one hash registered in A (two rows: certified older + draft) and in B (certified newer)
  F.H5 = hex(); F.E5A = `g1542-dupA-${run}`; F.E5A2 = `g1542-dupA2-${run}`; F.E5B = `g1542-dupB-${run}`;
  await doc(A, F.E5A, F.H5, 'certified', "NOW() - interval '2 days'", "NOW() - interval '3 days'");
  await doc(A, F.E5A2, 'sha256:' + F.H5, 'draft', 'NULL', "NOW() - interval '4 days'");
  await doc(B, F.E5B, F.H5, 'certified', 'NOW()', 'NOW()');
  await reg(A, F.E5A, F.H5); await reg(B, F.E5B, F.H5);
  // verify-file / orphan shapes
  F.FILE_OK = `gate1542 ok file ${run}`; F.HF_OK = sha(F.FILE_OK); F.EF_OK = `g1542-file-${run}`;
  await doc(A, F.EF_OK, F.HF_OK); await reg(A, F.EF_OK, 'sha256:' + F.HF_OK);
  F.FILE_ORPH = `gate1542 orphan file ${run}`; F.HF_ORPH = sha(F.FILE_ORPH); await reg(A, `g1542-orph-${run}`, 'sha256:' + F.HF_ORPH);
  F.FILE_ORPH_BARE = `gate1542 orphan bare file ${run}`; F.HF_ORPH_BARE = sha(F.FILE_ORPH_BARE); await reg(A, `g1542-orphbare-${run}`, F.HF_ORPH_BARE);
  F.FILE_REV = `gate1542 revoked file ${run}`; F.HF_REV = sha(F.FILE_REV); F.EF_REV = `g1542-filerev-${run}`;
  await doc(A, F.EF_REV, 'sha256:' + F.HF_REV, 'revoked'); await reg(A, F.EF_REV, 'sha256:' + F.HF_REV);
  // orphan registry row whose document_id names a REAL doc of another hash (registry drift)
  F.FILE_DRIFT = `gate1542 drift file ${run}`; F.HF_DRIFT = sha(F.FILE_DRIFT); await reg(A, F.E1, 'sha256:' + F.HF_DRIFT);
  // empty-external_id row (globally unique, so only if none exists) and NULL-external_id row, both in A, unrelated hashes
  const empty = await t.query(`SELECT count(*)::int n FROM documents WHERE external_id = ''`);
  F.emptyExtPreexisting = empty.rows[0].n;
  if (F.emptyExtPreexisting === 0) { F.HEMPTY = hex(); await doc(A, '', F.HEMPTY); }
  F.HNULL = hex(); await doc(A, null, F.HNULL);
  // a deleted doc whose registration remains
  F.FILE_DEL = `gate1542 deleted file ${run}`; F.HF_DEL = sha(F.FILE_DEL); F.EF_DEL = `g1542-del-${run}`;
  const delId = await doc(A, F.EF_DEL, 'sha256:' + F.HF_DEL); await reg(A, F.EF_DEL, 'sha256:' + F.HF_DEL);
  await t.query(`DELETE FROM documents WHERE id = $1::uuid`, [delId]);
  F.WRONG = hex();
  fs.writeFileSync(FIX, JSON.stringify(F, null, 1));
  await t.end(); await p.end();
  console.log('seeded', FIX);
}

async function probe() {
  const F = JSON.parse(fs.readFileSync(FIX, 'utf8'));
  const base = `http://127.0.0.1:${port}`;
  const callers = { A: { 'x-tenant-id': F.A }, B: { 'x-tenant-id': F.B }, C: { 'x-tenant-id': F.C }, anon: {} };
  const out = [];
  const pick = (j, stored) => ({
    verified: j?.verified, hashValid: j?.checks?.hashValid, integ: j?.checks?.integrityVerified, exists: j?.checks?.documentExists,
    documentId: j?.documentId ?? null, contentHash: j?.contentHash ?? null, storedHandedBack: stored ? (j?.contentHash === stored) : undefined,
    title: j?.title ?? null, err: j?.error ? String(j.error).slice(0, 40) : undefined, warn: j?.warning ? 'byid' : undefined,
  });
  const verify = async (name, who, body, stored) => {
    const r = await fetch(base + '/api/verification/verify', { method: 'POST', headers: { 'content-type': 'application/json', ...callers[who] }, body: JSON.stringify(body) });
    const txt = await r.text(); let j = null; try { j = JSON.parse(txt); } catch {}
    out.push({ cell: name, caller: who, status: r.status, ...pick(j, stored), raw: j ? undefined : txt.slice(0, 80) });
  };
  const verifyFile = async (name, who, bytes) => {
    const r = await fetch(base + '/api/verification/verify-file', { method: 'POST', headers: { 'content-type': 'application/octet-stream', ...callers[who] }, body: Buffer.from(bytes) });
    const txt = await r.text(); let j = null; try { j = JSON.parse(txt); } catch {}
    out.push({ cell: name, caller: who, status: r.status, ...pick(j), raw: j ? undefined : txt.slice(0, 80) });
  };
  const W = Object.keys(callers);
  // ITEM 2: wrong hash, 4 aliases, 3 callers + outsider C, documentId of a bare- and a prefixed-stored doc
  for (const alias of ['hash', 'contentHash', 'providedHash', 'documentHash']) for (const who of W) {
    await verify(`2.wrong.${alias}.bare-doc`, who, { documentId: F.E1, [alias]: F.WRONG }, F.H1);
    await verify(`2.wrong.${alias}.pref-doc`, who, { documentId: F.E2, [alias]: F.WRONG }, 'sha256:' + F.H2);
  }
  // wrong hash in prefixed form, and wrong hash with no documentId
  for (const who of W) {
    await verify('2.wrong.prefixed.bare-doc', who, { documentId: F.E1, contentHash: 'sha256:' + F.WRONG }, F.H1);
    await verify('2.wrong.nodocid', who, { contentHash: F.WRONG });
    await verify('2.wrong.prefix-only("sha256:").bare-doc', who, { documentId: F.E1, contentHash: 'sha256:' }, F.H1);
    await verify('2.wrong.empty-string-hash.bare-doc', who, { documentId: F.E1, contentHash: '' }, F.H1);
    await verify('2.wrong.other-docs-right-hash(E2-hash,E1-docid)', who, { documentId: F.E1, contentHash: F.H2 }, F.H1);
  }
  // ITEM 3: orphan / empty-external_id / drift shapes on /verify (hash only) and /verify-file
  for (const who of W) {
    await verify('3.verify.orphan-prefixed-reg.hashonly', who, { contentHash: 'sha256:' + F.HF_ORPH });
    await verify('3.verify.orphan-prefixed-reg.hashonly.bare-sent', who, { contentHash: F.HF_ORPH });
    await verify('3.verify.orphan-bare-reg.hashonly', who, { contentHash: F.HF_ORPH_BARE });
    await verify('3.verify.drift-reg(docid=E1).hashonly', who, { contentHash: 'sha256:' + F.HF_DRIFT });
    await verify('3.verify.deleted-doc-reg.hashonly', who, { contentHash: 'sha256:' + F.HF_DEL });
    await verify('3.verify.deleted-doc-reg.withdocid', who, { documentId: F.EF_DEL, contentHash: 'sha256:' + F.HF_DEL });
    await verify('3.verify.revoked.right', who, { documentId: F.E4, contentHash: F.H4 });
    await verify('3.verify.revoked.wrong', who, { documentId: F.E4, contentHash: F.WRONG }, F.H4);
    await verifyFile('3.file.ok', who, F.FILE_OK);
    await verifyFile('3.file.orphan-prefixed-reg', who, F.FILE_ORPH);
    await verifyFile('3.file.orphan-bare-reg', who, F.FILE_ORPH_BARE);
    await verifyFile('3.file.revoked', who, F.FILE_REV);
    await verifyFile('3.file.drift-reg(docid=E1)', who, F.FILE_DRIFT);
    await verifyFile('3.file.deleted-doc-reg', who, F.FILE_DEL);
    await verifyFile('3.file.random-unregistered', who, `gate1542 random ${Math.random()}`);
    // by-id strategy: documentId only, must resolve cross-tenant (MT) and report verified:false
    await verify('3.byid.bare-doc', who, { documentId: F.E1 }, F.H1);
    await verify('3.byid.tenantB-doc', who, { documentId: F.E3 }, F.H3);
  }
  // ITEM 4: RIGHT-hash matrix
  const variants = (h) => ({
    bare: h, pref: 'sha256:' + h, UPPER: h.toUpperCase(), 'SHA256:prefix': 'SHA256:' + h, 'pref+UPPER': 'sha256:' + h.toUpperCase(),
    mixed: h.slice(0, 32).toUpperCase() + h.slice(32), lead_space: ' ' + h, trail_space: h + ' ', trail_nl: h + '\n', '0x': '0x' + h,
    zeropad: '00' + h, double_pref: 'sha256:sha256:' + h,
  });
  const stores = [['storedBare', F.E1, F.H1, F.H1], ['storedPref', F.E2, F.H2, 'sha256:' + F.H2]];
  for (const [sl, ext, h, stored] of stores) for (const [vl, sent] of Object.entries(variants(h))) for (const who of W) {
    await verify(`4.right.${sl}.${vl}.own-docid`, who, { documentId: ext, contentHash: sent }, stored);
    await verify(`4.right.${sl}.${vl}.no-docid`, who, { contentHash: sent }, stored);
    await verify(`4.right.${sl}.${vl}.docid-of-tenantB-doc`, who, { documentId: F.E3, contentHash: sent }, stored);
  }
  // tenant B's right hash with tenant A's documentId
  for (const who of W) await verify('4.right.tenantB-hash.docid-of-tenantA-doc', who, { documentId: F.E1, contentHash: F.H3 }, F.H3);
  // ITEM 5: same hash registered in two tenants + two rows in A
  for (const who of W) for (const [dl, d] of [['none', undefined], ['dupA', F.E5A], ['dupA2', F.E5A2], ['dupB', F.E5B]]) {
    for (const sent of [F.H5, 'sha256:' + F.H5]) await verify(`5.dup.${dl}.${sent.startsWith('sha') ? 'pref' : 'bare'}`, who, d ? { documentId: d, contentHash: sent } : { contentHash: sent });
  }
  fs.writeFileSync(outfile, JSON.stringify(out, null, 0).replace(/\},\{/g, '},\n{'));
  console.log('cells', out.length, '->', outfile);
}
if (cmd === 'seed') await seed(); else await probe();
