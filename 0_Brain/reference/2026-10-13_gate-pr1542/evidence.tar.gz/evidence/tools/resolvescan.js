const fs=require('fs'),path=require('path'),Module=require('module');
const [dist,nm]=process.argv.slice(2);
const files=[];(function w(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);e.isDirectory()?w(p):/\.js$/.test(e.name)&&files.push(p)}})(dist);
const specs=new Map();
for(const f of files){const t=fs.readFileSync(f,'utf8');for(const m of t.matchAll(/require\((['"])([^'"]+)\1\)/g)){const s=m[2];if(s.startsWith('.')||s.startsWith('node:')||Module.builtinModules.includes(s))continue;const root=s.startsWith('@')?s.split('/').slice(0,2).join('/'):s.split('/')[0];if(!specs.has(root))specs.set(root,new Set());specs.get(root).add(path.relative(dist,f))}}
let bad=[];for(const [r,fs_] of specs){ if(!fs.existsSync(path.join(nm,r))) bad.push(r+' <- '+[...fs_].slice(0,2).join(','));}
console.log('js files',files.length,'distinct external packages required',specs.size,'unresolvable',bad.length);bad.forEach(b=>console.log('  MISSING',b));
console.log('handlebars required?',specs.has('handlebars'));
