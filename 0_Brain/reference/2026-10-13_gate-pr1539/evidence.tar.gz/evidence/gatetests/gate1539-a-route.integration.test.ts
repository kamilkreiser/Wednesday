/**
 * GATE PR #1539 (KS-1570 PR B), independent cells A: who can call the route, the write itself, the GET,
 * the audit row's fields, KS-1586, the no-revoke property and read/write normaliser agreement.
 * Real HTTP against the real app (index.ts), DB as secuura_app (rolsuper f, rolbypassrls f), state read
 * back as the superuser. Every status is also written to a JSON ledger (GATE_LEDGER) for the verdict.
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import fs from 'fs';
import type { Server } from 'http';
import type { AddressInfo } from 'net';
import { Pool } from 'pg';

process.env.SECURITY_DISABLE_BOOT = '1';

const T = 'a0000000-0000-4000-8000-00000000c139';
const T2 = 'b0000000-0000-4000-8000-00000000c239';
const A1 = 'abcdef00-1539-4539-8539-0000000000a1';
const A2 = 'abcdef00-1539-4539-8539-0000000000a2';
const A3 = 'abcdef00-1539-4539-8539-0000000000a3';
const B1 = 'abcdef00-1539-4539-8539-0000000000b1'; // organisation of T2
const U = crypto.randomUUID();           // ADMIN in T (target)
const U_LOWER = crypto.randomUUID();     // role 'admin' in T
const U_PAD = crypto.randomUUID();       // role ' ADMIN ' in T
const U_DEL = crypto.randomUUID();       // role ADMIN, status 'deleted', in T
const U_ISS = crypto.randomUUID();       // ISSUER_ADMIN in T
const U_ORG = crypto.randomUUID();       // ORG_ADMIN in T
const U_T2 = crypto.randomUUID();        // ADMIN in T2
const U_BULK = crypto.randomUUID();      // GET cap probe (rows seeded directly)
const PLATFORM_ID = crypto.randomUUID();
const NAME = 'gate1539:';
const AUDIT_PROBE = 'gate1539.ks1586';

const SUPER_URL = process.env.TEST_DATABASE_URL;
const APP_URL = process.env.TEST_APP_DATABASE_URL;
const LEDGER: Record<string, unknown> = {};
const note = (k: string, v: unknown): void => { LEDGER[k] = v; };

const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const other = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const PRIVATE_PEM = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const OTHER_PEM = other.privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const PUBLIC_PEM = publicKey.export({ type: 'spki', format: 'pem' }).toString();
const b64url = (b: Buffer): string => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function token(claims: Record<string, unknown>, opts: { key?: string; alg?: string; exp?: number } = {}): string {
  const header = b64url(Buffer.from(JSON.stringify({ alg: opts.alg ?? 'RS256', typ: 'JWT' })));
  const now = Math.floor(Date.now() / 1000);
  const payload = b64url(Buffer.from(JSON.stringify({ sub: 'gate1539', iat: now, exp: opts.exp ?? now + 600, ...claims })));
  if (opts.alg === 'none') return `${header}.${payload}.`;
  return `${header}.${payload}.${b64url(crypto.sign('RSA-SHA256', Buffer.from(`${header}.${payload}`), opts.key ?? PRIVATE_PEM))}`;
}
const PLATFORM = (extra: Record<string, unknown> = {}) => token({ role: 'super_admin', userId: PLATFORM_ID, ...extra });
const ADMIN = () => token({ role: 'ADMIN', tenantId: T, userId: U });

let server: Server;
let base: string;
let su: Pool;

async function call(method: string, path: string, tok: string | null, body?: unknown, headers: Record<string, string> = {}): Promise<{ status: number; json: Record<string, any> }> {
  const h: Record<string, string> = { 'Content-Type': 'application/json', ...headers };
  if (tok !== null) h.Authorization = tok.startsWith('RAW:') ? tok.slice(4) : `Bearer ${tok}`;
  const res = await fetch(`${base}${path}`, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: res.status, json: (await res.json().catch(() => ({}))) as Record<string, any> };
}
const put = (tok: string | null, userId: string, body: unknown, headers: Record<string, string> = {}) => call('PUT', `/api/keys/admin-scopes/${userId}`, tok, body, headers);
const get = (tok: string | null, userId: string, qs: string) => call('GET', `/api/keys/admin-scopes/${userId}${qs}`, tok);
async function rows(userId: string, tenant = T): Promise<string[]> {
  const r = await su.query<{ o: string }>('SELECT organization_id::text AS o FROM admin_organisation_scopes WHERE user_id = $1::uuid AND tenant_id = $2::uuid ORDER BY 1', [userId, tenant]);
  return r.rows.map((x) => x.o);
}
async function allRows(): Promise<number> {
  return Number((await su.query('SELECT count(*) AS n FROM admin_organisation_scopes')).rows[0].n);
}
async function audits(): Promise<number> {
  return Number((await su.query("SELECT count(*) AS n FROM audit_logs WHERE action = 'admin_scope.set'")).rows[0].n);
}
async function lastAudit(target: string): Promise<Record<string, any>> {
  const r = await su.query("SELECT * FROM audit_logs WHERE action = 'admin_scope.set' AND resource_id = $1::uuid ORDER BY created_at DESC LIMIT 1", [target]);
  const a = r.rows[0];
  if (a && typeof a.details === 'string') a.details = JSON.parse(a.details);
  return a;
}
async function mint(tok: string, body: Record<string, unknown>): Promise<{ status: number; json: Record<string, any> }> {
  return call('POST', '/api/keys', tok, { name: `${NAME}${crypto.randomUUID().slice(0, 6)}`, scopes: ['documents:read'], ...body });
}

beforeAll(async () => {
  if (!SUPER_URL || !APP_URL) throw new Error('gate1539 A needs TEST_DATABASE_URL and TEST_APP_DATABASE_URL');
  su = new Pool({ connectionString: SUPER_URL, max: 3 });
  for (const [id, tenant, slug] of [[A1, T, 'a1'], [A2, T, 'a2'], [A3, T, 'a3'], [B1, T2, 'b1']] as const) {
    await su.query(`INSERT INTO organizations (id, name, slug, type, tenant_id) VALUES ($1::uuid, $2, $3, 'issuer', $4::uuid) ON CONFLICT (id) DO NOTHING`,
      [id, `gate1539 ${slug}`, `gate1539-${slug}`, tenant]);
  }
  for (const [id, tenant, r, st] of [[U, T, 'ADMIN', 'active'], [U_LOWER, T, 'admin', 'active'], [U_PAD, T, ' ADMIN ', 'active'], [U_DEL, T, 'ADMIN', 'deleted'],
    [U_ISS, T, 'ISSUER_ADMIN', 'active'], [U_ORG, T, 'ORG_ADMIN', 'active'], [U_T2, T2, 'ADMIN', 'active']] as const) {
    await su.query('INSERT INTO users (id, email, tenant_id, role, status) VALUES ($1::uuid, $2, $3::uuid, $4, $5)', [id, `gate1539-${id}@example.invalid`, tenant, r, st]);
  }
  process.env.DATABASE_URL = APP_URL;
  process.env.JWT_PUBLIC_KEY = Buffer.from(PUBLIC_PEM, 'utf8').toString('base64');
  delete process.env.JWT_JWKS_URL; delete process.env.AUTH_SERVICE_URL;
  const db = await import('../db');
  if (!(await db.initDb()) || !db.isDbAvailable()) throw new Error('initDb() did not connect');
  const mod = await import('../index');
  await new Promise<void>((resolve) => { server = mod.default.listen(0, '127.0.0.1', resolve); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

afterAll(async () => {
  if (process.env.GATE_LEDGER) fs.writeFileSync(process.env.GATE_LEDGER, JSON.stringify(LEDGER, null, 1));
  if (server) await new Promise<void>((resolve) => server.close(() => resolve()));
  if (su) {
    const users = [U, U_LOWER, U_PAD, U_DEL, U_ISS, U_ORG, U_T2, U_BULK];
    await su.query('DELETE FROM admin_organisation_scopes WHERE user_id = ANY($1::uuid[])', [users]);
    await su.query("DELETE FROM audit_logs WHERE (action = 'admin_scope.set' AND resource_id = ANY($1::uuid[])) OR action = $2", [users, AUDIT_PROBE]);
    await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
    await su.query('DELETE FROM users WHERE id = ANY($1::uuid[])', [users]);
    await su.query('DELETE FROM organizations WHERE id = ANY($1::uuid[])', [[A1, A2, A3, B1]]);
    await su.end();
  }
  const db = await import('../db');
  await db.closeDb();
});

// ---------------------------------------------------------------------------------------------------
// ITEM 2: WHO CAN CALL THE PUT
// ---------------------------------------------------------------------------------------------------
const ALLOW: Array<[string, () => string]> = [
  ['super_admin', () => token({ role: 'super_admin', userId: PLATFORM_ID })],
  ['SUPER_ADMIN', () => token({ role: 'SUPER_ADMIN', userId: PLATFORM_ID })],
  ['SYSTEM_ADMIN', () => token({ role: 'SYSTEM_ADMIN', userId: PLATFORM_ID })],
  ['system_admin', () => token({ role: 'system_admin', userId: PLATFORM_ID })],
  ['Super_Admin', () => token({ role: 'Super_Admin', userId: PLATFORM_ID })],
  ['platform with no tenantId and no userId (sub only)', () => token({ role: 'SUPER_ADMIN' })],
];
const DENY: Array<[string, () => string | null, number, Record<string, string>?, Record<string, unknown>?]> = [
  ['ADMIN of T, own scope', () => ADMIN(), 403],
  ['admin (lower) of T, own scope', () => token({ role: 'admin', tenantId: T, userId: U }), 403],
  ['Admin (mixed) of T, own scope', () => token({ role: 'Admin', tenantId: T, userId: U }), 403],
  ['ADMIN of T2', () => token({ role: 'ADMIN', tenantId: T2, userId: U_T2 }), 403],
  ['ORG_ADMIN of T', () => token({ role: 'ORG_ADMIN', tenantId: T, organizationId: A1, userId: U_ORG }), 403],
  ['ISSUER_ADMIN of T', () => token({ role: 'ISSUER_ADMIN', tenantId: T, organizationId: A1, userId: U_ISS }), 403],
  ['provisioning connector', () => token({ role: 'connector', type: 'connector', scopes: ['organizations:register', '*'], tenantId: T, userId: 'connector:x' }), 403],
  ['USER', () => token({ role: 'USER', tenantId: T, userId: U }), 403],
  ['no role claim', () => token({ tenantId: T, userId: U }), 403],
  ['ADMIN with no tenantId/userId', () => token({ role: 'ADMIN' }), 403],
  ['" SUPER_ADMIN" (leading space)', () => token({ role: ' SUPER_ADMIN', userId: PLATFORM_ID }), 403],
  ['"SUPER_ADMIN " (trailing space)', () => token({ role: 'SUPER_ADMIN ', userId: PLATFORM_ID }), 403],
  ['"SUPER_ADMIN\\t"', () => token({ role: 'SUPER_ADMIN\t', userId: PLATFORM_ID }), 403],
  ['SUPER_ADMIN + ZWSP', () => token({ role: 'SUPER_ADMIN​', userId: PLATFORM_ID }), 403],
  ['SUPER-ADMIN', () => token({ role: 'SUPER-ADMIN', userId: PLATFORM_ID }), 403],
  ['PLATFORM_ADMIN', () => token({ role: 'PLATFORM_ADMIN', userId: PLATFORM_ID }), 403],
  ['ADMIN + header x-user-role SUPER_ADMIN', () => ADMIN(), 403, { 'x-user-role': 'SUPER_ADMIN', 'x-role': 'SUPER_ADMIN', 'x-platform-admin': 'true' }],
  ['ADMIN + body role SUPER_ADMIN', () => ADMIN(), 403, {}, { role: 'SUPER_ADMIN', user: { role: 'SUPER_ADMIN' } }],
  ['no token', () => null, 401],
  ['no token + x-user-role SUPER_ADMIN header', () => null, 401, { 'x-user-role': 'SUPER_ADMIN', 'x-tenant-id': T }],
  ['malformed token', () => 'abc.def.ghi', 401],
  ['alg none, role SUPER_ADMIN', () => token({ role: 'SUPER_ADMIN' }, { alg: 'none' }), 401],
  ['signed by another key, role SUPER_ADMIN', () => token({ role: 'SUPER_ADMIN' }, { key: OTHER_PEM }), 401],
  ['expired SUPER_ADMIN', () => token({ role: 'SUPER_ADMIN' }, { exp: Math.floor(Date.now() / 1000) - 60 }), 401],
  ['Basic auth', () => 'RAW:Basic c3VwZXI6YWRtaW4=', 401],
];

describe('gate A item 2: who can call PUT /api/keys/admin-scopes/:userId', () => {
  for (const [label, tok] of ALLOW) {
    it(`ALLOW ${label}: 200 and the row is written`, async () => {
      await su.query('DELETE FROM admin_organisation_scopes WHERE user_id = $1::uuid', [U]);
      const r = await put(tok(), U, { tenantId: T, organizationIds: [A1] });
      note(`put.allow.${label}`, r.status);
      expect(r.status).toBe(200);
      expect(await rows(U)).toEqual([A1]);
    });
  }
  for (const [label, tok, want, headers, extra] of DENY) {
    it(`DENY ${label}: ${want}, nothing written, nothing audited`, async () => {
      await su.query('DELETE FROM admin_organisation_scopes WHERE user_id = $1::uuid', [U]);
      const n0 = await allRows(); const a0 = await audits();
      const t = tok();
      const r = await put(t, U, { tenantId: T, organizationIds: [A1, A2, A3], ...(extra ?? {}) }, headers ?? {});
      note(`put.deny.${label}`, r.status);
      expect(r.status).toBe(want);
      expect(await allRows()).toBe(n0);
      expect(await audits()).toBe(a0);
    });
  }
  it('an API key (sk_) as the bearer, and as x-api-key, is 401', async () => {
    const m = await mint(PLATFORM(), { tenantId: T });
    expect(m.status).toBe(201);
    const sk = m.json.data.key as string;
    const r1 = await put(sk, U, { tenantId: T, organizationIds: [A1] });
    const r2 = await put(null, U, { tenantId: T, organizationIds: [A1] }, { 'x-api-key': sk });
    note('put.deny.apikey-bearer', r1.status); note('put.deny.apikey-header', r2.status);
    expect(r1.status).toBe(401); expect(r2.status).toBe(401);
  });
  // Unicode case-mapping probes of isPlatformRole (toUpperCase): RECORDED, not asserted.
  for (const [label, role] of [['dotless-i super_admın', 'super_admın'], ['long-s ſuper_admin', 'ſuper_admin'], ['array ["SUPER_ADMIN"]', ['SUPER_ADMIN']]] as const) {
    it(`OBSERVE role ${label}`, async () => {
      await su.query('DELETE FROM admin_organisation_scopes WHERE user_id = $1::uuid', [U]);
      const r = await put(token({ role, userId: PLATFORM_ID }), U, { tenantId: T, organizationIds: [A1] });
      note(`put.observe.${label}`, r.status);
      // the same role at the key-admin gate, for comparison
      const m = await mint(token({ role, userId: PLATFORM_ID }), { tenantId: T });
      note(`mint.observe.${label}`, m.status);
      expect([200, 403]).toContain(r.status);
    });
  }
});

// ---------------------------------------------------------------------------------------------------
// ITEM 3: THE WRITE ITSELF
// ---------------------------------------------------------------------------------------------------
describe('gate A item 3: the write', () => {
  it('set / add / remove / empty / duplicates / case: PUT replaces, canonical rows', async () => {
    const seq: Array<[string, string[], string[]]> = [
      ['set', [A1], [A1]], ['add', [A1, A2], [A1, A2]], ['remove', [A2], [A2]], ['empty', [], []],
      ['dup', [A1, A1, A1], [A1]], ['upper', [A2.toUpperCase(), A1.toUpperCase()], [A1, A2]], ['mixdup', [A3, A3.toUpperCase()], [A3]],
    ];
    let prev: string[] | null = null;
    for (const [lbl, ids, want] of seq) {
      const r = await put(PLATFORM(), U, { tenantId: T, organizationIds: ids });
      note(`write.${lbl}`, { status: r.status, before: r.json.data?.before, after: r.json.data?.organizationIds, rows: await rows(U) });
      expect(r.status).toBe(200);
      expect(await rows(U)).toEqual(want);
      expect(r.json.data.organizationIds).toEqual(want);
      if (prev) expect(r.json.data.before).toEqual(prev);
      const a = await lastAudit(U);
      expect(a.details.after).toEqual(want);
      if (prev) expect(a.details.before).toEqual(prev);
      prev = want;
    }
  });

  const KELVIN = A1.slice(0, -1) + 'K'; // last hex char replaced with KELVIN SIGN
  const BAD_ORGS: Array<[string, unknown]> = [
    ['braces', `{${A1}}`], ['padded', ` ${A1} `], ['NBSP-padded', ` ${A1} `], ['tab', `${A1}\t`],
    ['urn:uuid:', `urn:uuid:${A1}`], ['no hyphens', A1.replace(/-/g, '')], ['Kelvin sign', KELVIN],
    ['fullwidth digit', A1.replace('0', '０')], ['default-org', 'default-org'], ['empty string', ''], ['null element', null], ['number', 42],
    ['nil uuid (not an org)', '00000000-0000-0000-0000-000000000000'],
  ];
  for (const [lbl, bad] of BAD_ORGS) {
    it(`organisation id spelling "${lbl}" is 400 and nothing changes`, async () => {
      await put(PLATFORM(), U, { tenantId: T, organizationIds: [A1] });
      const a0 = await audits();
      const r = await put(PLATFORM(), U, { tenantId: T, organizationIds: [A2, bad] });
      note(`write.badorg.${lbl}`, r.status);
      expect(r.status).toBe(400);
      expect(await rows(U)).toEqual([A1]);
      expect(await audits()).toBe(a0);
    });
  }
  it('organizationIds shapes: 1001 ids is 400; a string, null, missing is 400', async () => {
    const many = Array.from({ length: 1001 }, () => crypto.randomUUID());
    const out: Record<string, number> = {};
    out.n1001 = (await put(PLATFORM(), U, { tenantId: T, organizationIds: many })).status;
    out.str = (await put(PLATFORM(), U, { tenantId: T, organizationIds: A1 })).status;
    out.nul = (await put(PLATFORM(), U, { tenantId: T, organizationIds: null })).status;
    out.missing = (await put(PLATFORM(), U, { tenantId: T })).status;
    out.n1000unknown = (await put(PLATFORM(), U, { tenantId: T, organizationIds: many.slice(0, 1000) })).status;
    note('write.shapes', out);
    expect(out).toEqual({ n1001: 400, str: 400, nul: 400, missing: 400, n1000unknown: 400 });
  });
  it('an organisation of ANOTHER tenant is 400, named, nothing written', async () => {
    await put(PLATFORM(), U, { tenantId: T, organizationIds: [A1] });
    const r = await put(PLATFORM(), U, { tenantId: T, organizationIds: [A1, B1] });
    note('write.foreign-org', { status: r.status, body: r.json.error?.details });
    expect(r.status).toBe(400);
    expect(r.json.error.details.unknownOrganizationIds).toEqual([B1]);
    expect(await rows(U)).toEqual([A1]);
  });
  it('tenantId spellings: upper-case accepted and stored canonical; braces/missing/unknown refused', async () => {
    const up = await put(PLATFORM(), U, { tenantId: T.toUpperCase(), organizationIds: [A2] });
    const br = await put(PLATFORM(), U, { tenantId: `{${T}}`, organizationIds: [A1] });
    const unk = await put(PLATFORM(), U, { tenantId: crypto.randomUUID(), organizationIds: [A1] });
    note('write.tenant', { upper: up.status, braces: br.status, unknown: unk.status });
    expect(up.status).toBe(200);
    expect(await rows(U)).toEqual([A2]);
    expect((await su.query('SELECT tenant_id::text t FROM admin_organisation_scopes WHERE user_id = $1::uuid', [U])).rows.map((x) => x.t)).toEqual([T]);
    expect(br.status).toBe(400);
    expect(unk.status).toBe(404);
  });
  it('targets: ISSUER_ADMIN/ORG_ADMIN/T2 ADMIN/no user/" ADMIN " are 404; lowercase admin is 200; userId upper-case path is 200', async () => {
    const out: Record<string, number> = {};
    for (const [k, id] of [['issuer', U_ISS], ['orgadmin', U_ORG], ['t2admin', U_T2], ['nouser', crypto.randomUUID()], ['padrole', U_PAD], ['lower', U_LOWER], ['upperpath', U.toUpperCase()]] as const) {
      out[k] = (await put(PLATFORM(), id, { tenantId: T, organizationIds: [A1] })).status;
    }
    note('write.targets', out);
    expect(out).toMatchObject({ issuer: 404, orgadmin: 404, t2admin: 404, nouser: 404, padrole: 404, lower: 200, upperpath: 200 });
    expect(await rows(U_ISS)).toEqual([]); expect(await rows(U_T2, T)).toEqual([]); expect(await rows(U_T2, T2)).toEqual([]);
    expect(await rows(U_LOWER)).toEqual([A1]);
  });
  it('OBSERVE: an ADMIN whose status is "deleted" can still be given a scope', async () => {
    const r = await put(PLATFORM(), U_DEL, { tenantId: T, organizationIds: [A1] });
    note('write.deleted-status-admin', { status: r.status, rows: await rows(U_DEL) });
    expect([200, 404]).toContain(r.status);
  });
  it('body extras (userId, grantedBy, granted_by, role) are ignored: path decides the target, token decides granted_by', async () => {
    const r = await put(PLATFORM(), U, { tenantId: T, organizationIds: [A3], userId: U_LOWER, grantedBy: 'evil', granted_by: 'evil', role: 'x', tenant_id: T2 });
    expect(r.status).toBe(200);
    const g = await su.query('SELECT user_id::text u, tenant_id::text t, granted_by FROM admin_organisation_scopes WHERE organization_id = $1::uuid', [A3]);
    note('write.extras', g.rows);
    expect(g.rows).toEqual([{ u: U, t: T, granted_by: PLATFORM_ID }]);
  });
  it('x-tenant-id header T2 with body T: the row lands in T only; a platform token carrying tenantId T2 still writes T', async () => {
    const r = await put(PLATFORM(), U, { tenantId: T, organizationIds: [A1] }, { 'x-tenant-id': T2 });
    const r2 = await put(PLATFORM({ tenantId: T2 }), U, { tenantId: T, organizationIds: [A2] });
    const t2rows = await rows(U, T2);
    note('write.context', { headerT2: r.status, tokenT2: r2.status, t2rows, trows: await rows(U) });
    expect(r.status).toBe(200); expect(r2.status).toBe(200);
    expect(t2rows).toEqual([]);
    expect(await rows(U)).toEqual([A2]);
  });
});

// ---------------------------------------------------------------------------------------------------
// ITEM 3b: write-side vs read-side (PR A normaliser) agreement at the real mint
// ---------------------------------------------------------------------------------------------------
describe('gate A item 3b: what the write stores is what the read-side matches', () => {
  it('scope written as UPPER A1: ADMIN mint matches A1 in exact/upper/padded/NBSP, refuses braces and A2', async () => {
    expect((await put(PLATFORM(), U, { tenantId: T, organizationIds: [A1.toUpperCase()] })).status).toBe(200);
    const out: Record<string, number> = {};
    for (const [k, o] of [['exact', A1], ['upper', A1.toUpperCase()], ['padded', ` ${A1} `], ['nbsp', ` ${A1}`], ['braces', `{${A1}}`], ['A2', A2]] as const) {
      out[k] = (await mint(ADMIN(), { tenantId: T, organizationId: o })).status;
    }
    note('agree.mint', out);
    expect(out).toEqual({ exact: 201, upper: 201, padded: 201, nbsp: 201, braces: 403, A2: 403 });
  });
});

// ---------------------------------------------------------------------------------------------------
// ITEM 5: THE AUDIT ROW, and KS-1586
// ---------------------------------------------------------------------------------------------------
describe('gate A item 5: the audit row', () => {
  it('carries who, whom, tenant, before/after; caller cannot steer ip; no key material', async () => {
    await put(PLATFORM(), U, { tenantId: T, organizationIds: [A1] });
    const r = await put(PLATFORM(), U, { tenantId: T, organizationIds: [A2, A3], grantedBy: 'evil', details: { x: 1 } }, { 'x-forwarded-for': '6.6.6.6', 'user-agent': 'gate1539-UA', 'x-real-ip': '6.6.6.6' });
    expect(r.status).toBe(200);
    const a = await lastAudit(U);
    note('audit.row', a);
    expect(a.tenant_id).toBe(T);
    expect(a.user_id).toBe(PLATFORM_ID);
    expect(a.resource_id).toBe(U);
    expect(a.resource_type).toBe('admin_organisation_scope');
    expect(a.details).toEqual({ tenantId: T, targetUserId: U, before: [A1], after: [A2, A3].sort(), grantedBy: PLATFORM_ID });
    expect(a.ip_address).not.toContain('6.6.6.6');
    expect(a.user_agent).toBe('gate1539-UA');
    expect(JSON.stringify(a)).not.toMatch(/sk_[0-9a-f]{8}/);
  });
  it('a platform caller with a non-uuid userId: user_id NULL, grantedBy keeps the string; sub-only caller: grantedBy = sub', async () => {
    await put(token({ role: 'SYSTEM_ADMIN', userId: 'ops-bot' }), U, { tenantId: T, organizationIds: [A1] });
    const a = await lastAudit(U);
    await put(token({ role: 'SYSTEM_ADMIN', sub: 'sub-only-caller' }), U, { tenantId: T, organizationIds: [A2] });
    const b = await lastAudit(U);
    const g = await su.query('SELECT granted_by FROM admin_organisation_scopes WHERE user_id = $1::uuid', [U]);
    note('audit.nonuuid', { a: { user_id: a.user_id, grantedBy: a.details.grantedBy }, b: { user_id: b.user_id, grantedBy: b.details.grantedBy }, granted_by: g.rows });
    expect(a.user_id).toBeNull(); expect(a.details.grantedBy).toBe('ops-bot');
    expect(b.user_id).toBeNull(); expect(b.details.grantedBy).toBe('sub-only-caller');
  });
  it('KS-1586 reproduction: POST /api/audit answers 201 and persists NOTHING (dbSaveAuditLog swallows)', async () => {
    const before = Number((await su.query('SELECT count(*) n FROM audit_logs WHERE action = $1', [AUDIT_PROBE])).rows[0].n);
    const r = await call('POST', '/api/audit', token({ role: 'SUPER_ADMIN', tenantId: T, userId: PLATFORM_ID }), { action: AUDIT_PROBE, resourceType: 'gate', details: { a: 1 } });
    await new Promise((res) => setTimeout(res, 300));
    const after = Number((await su.query('SELECT count(*) n FROM audit_logs WHERE action = $1', [AUDIT_PROBE])).rows[0].n);
    note('ks1586', { status: r.status, before, after });
    expect(r.status).toBe(201);
    expect(after - before).toBe(0);
  });
});

// ---------------------------------------------------------------------------------------------------
// ITEM 6: THE GET
// ---------------------------------------------------------------------------------------------------
describe('gate A item 6: GET /api/keys/admin-scopes/:userId', () => {
  it('platform roles 200; every non-platform role 403; no token / bad token 401', async () => {
    await put(PLATFORM(), U, { tenantId: T, organizationIds: [A1] });
    const out: Record<string, number> = {};
    for (const [l, t] of ALLOW) out[`allow:${l}`] = (await get(t(), U, `?tenantId=${T}`)).status;
    for (const [l, t, want] of DENY) { const tk = t(); out[`deny:${l}`] = (await get(tk, U, `?tenantId=${T}`)).status; expect(out[`deny:${l}`], l).toBe(want); }
    note('get.roles', out);
    for (const [l] of ALLOW) expect(out[`allow:${l}`], l).toBe(200);
  });
  it('returns only that tenant\'s rows; another tenant\'s rows for the same user come back only when that tenant is named', async () => {
    await put(PLATFORM(), U, { tenantId: T, organizationIds: [A1, A2] });
    await su.query("INSERT INTO admin_organisation_scopes (tenant_id, user_id, organization_id, granted_by) VALUES ($1::uuid, $2::uuid, $3::uuid, 'gate fixture') ON CONFLICT DO NOTHING", [T2, U, B1]);
    const gT = await get(PLATFORM(), U, `?tenantId=${T}`);
    const gT2 = await get(PLATFORM(), U, `?tenantId=${T2}`);
    const gUp = await get(PLATFORM(), U.toUpperCase(), `?tenantId=${T.toUpperCase()}`);
    const gMissing = await get(PLATFORM(), U, '');
    const gTwice = await get(PLATFORM(), U, `?tenantId=${T}&tenantId=${T2}`);
    const gNonAdmin = await get(PLATFORM(), U_ISS, `?tenantId=${T}`);
    note('get.data', { T: gT.json, T2: gT2.json, upper: gUp.json, missing: gMissing.status, twice: gTwice.status, nonAdmin: gNonAdmin.json });
    expect(gT.json.data.organizationIds).toEqual([A1, A2]);
    expect(Object.keys(gT.json.data).sort()).toEqual(['organizationIds', 'tenantId', 'userId']);
    expect(gT2.json.data.organizationIds).toEqual([B1]);
    expect(gUp.json.data.organizationIds).toEqual([A1, A2]);
    expect(gMissing.status).toBe(400); expect(gTwice.status).toBe(400);
    await su.query('DELETE FROM admin_organisation_scopes WHERE tenant_id = $1::uuid AND user_id = $2::uuid', [T2, U]);
  });
  it('no cap: 1500 rows seeded directly come back in full, ordered as text ascending', async () => {
    const ids = Array.from({ length: 1500 }, () => crypto.randomUUID());
    await su.query("INSERT INTO admin_organisation_scopes (tenant_id, user_id, organization_id, granted_by) SELECT $1::uuid, $2::uuid, o, 'gate bulk' FROM unnest($3::uuid[]) o", [T, U_BULK, ids]);
    const g = await get(PLATFORM(), U_BULK, `?tenantId=${T}`);
    note('get.cap', { status: g.status, n: g.json.data?.organizationIds?.length });
    expect(g.json.data.organizationIds.length).toBe(1500);
    expect(g.json.data.organizationIds).toEqual([...ids].sort());
  });
});

// ---------------------------------------------------------------------------------------------------
// ITEM 7: NO REVOKE
// ---------------------------------------------------------------------------------------------------
describe('gate A item 7: removing a scope revokes nothing', () => {
  it('keys minted under {A1} (ADMIN, platform, unqualified) stay valid and listed after the scope is emptied; ADMIN default-deny after', async () => {
    expect((await put(PLATFORM(), U, { tenantId: T, organizationIds: [A1] })).status).toBe(200);
    const k1 = await mint(ADMIN(), { tenantId: T, organizationId: A1 });
    const k2 = await mint(PLATFORM(), { tenantId: T, organizationId: A1 });
    const k3 = await mint(ADMIN(), { tenantId: T });
    expect([k1.status, k2.status, k3.status]).toEqual([201, 201, 201]);
    const ids = [k1.json.data.id, k2.json.data.id, k3.json.data.id];
    // usage_count / last_used_at are excluded: POST /api/keys/validate legitimately bumps them (first run of this
    // cell hashed the whole row and s2 differed for exactly that reason; s1 was identical).
    const snap = async () => (await su.query("SELECT md5(string_agg(concat_ws(',', id, is_active, organization_id, tenant_id, expires_at, key_hash, scopes::text, connector_id), '|' ORDER BY id)) h, count(*) FILTER (WHERE is_active) a FROM svc_api_keys k WHERE id = ANY($1)", [ids])).rows[0];
    const s0 = await snap();
    const empt = await put(PLATFORM(), U, { tenantId: T, organizationIds: [] });
    expect(empt.status).toBe(200);
    const s1 = await snap();
    const v = await call('POST', '/api/keys/validate', null, { key: k1.json.data.key });
    const list = await call('GET', `/api/keys?organizationId=${A1}`, PLATFORM());
    const listed = (list.json.data as Array<{ id: string; isActive: boolean }>).filter((k) => ids.includes(k.id));
    const after = {
      adminMintA1: (await mint(ADMIN(), { tenantId: T, organizationId: A1 })).status,
      adminMintUnqualified: (await mint(ADMIN(), { tenantId: T })).status,
      adminRevokeK1: (await call('DELETE', `/api/keys/${k1.json.data.id}`, ADMIN())).status,
    };
    const s2 = await snap();
    const platformRevokeK2 = (await call('DELETE', `/api/keys/${k2.json.data.id}`, PLATFORM())).status;
    note('norevoke', { s0, s1, s2, validate: { status: v.status, json: v.json }, listed, after, platformRevokeK2 });
    expect(s1).toEqual(s0);
    expect(Number(s1.a)).toBe(3);
    expect(v.status).toBe(200);
    expect(JSON.stringify(v.json)).toMatch(/"valid":true/);
    expect(listed.map((k) => k.id).sort()).toEqual([ids[0], ids[1]].sort());
    expect(listed.every((k) => k.isActive)).toBe(true);
    expect(after).toEqual({ adminMintA1: 403, adminMintUnqualified: 201, adminRevokeK1: 403 });
    expect(s2).toEqual(s0);
    expect(platformRevokeK2).toBe(200);
  });
});
