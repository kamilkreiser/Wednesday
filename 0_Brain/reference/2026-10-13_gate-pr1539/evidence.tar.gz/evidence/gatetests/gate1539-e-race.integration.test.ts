/**
 * GATE PR #1539, cell E: two CONCURRENT PUTs for the SAME (tenant, user). PUT is documented as REPLACING the set,
 * and each request writes an audit row whose `after` claims the resulting set. Under READ COMMITTED with no lock,
 * the second request's DELETE does not see rows the first inserted, so the result can be the UNION.
 * Request X (PUT [A2]) is held 1.5 s inside its transaction (BEFORE INSERT trigger on its audit row, i.e. after its
 * DELETE + INSERT ran); request Y (PUT [A3]) starts 300 ms later. Recorded: final rows, both responses, both audit
 * rows. Expected for a true replace: final = the set of whichever committed LAST, and that audit row's `after`.
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import fs from 'fs';
import type { Server } from 'http';
import type { AddressInfo } from 'net';
import { Pool } from 'pg';

process.env.SECURITY_DISABLE_BOOT = '1';
const T = 'a0000000-0000-4000-8000-00000000e139';
const A1 = 'abcdef00-1539-4539-8539-0000000000f1';
const A2 = 'abcdef00-1539-4539-8539-0000000000f2';
const A3 = 'abcdef00-1539-4539-8539-0000000000f3';
const U = crypto.randomUUID();
const SUPER_URL = process.env.TEST_DATABASE_URL;
const APP_URL = process.env.TEST_APP_DATABASE_URL;
const LEDGER: Record<string, unknown> = {};
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const PRIVATE_PEM = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const PUBLIC_PEM = publicKey.export({ type: 'spki', format: 'pem' }).toString();
const b64url = (b: Buffer): string => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function token(claims: Record<string, unknown>): string {
  const header = b64url(Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const now = Math.floor(Date.now() / 1000);
  const payload = b64url(Buffer.from(JSON.stringify({ sub: 'gate1539e', iat: now, exp: now + 600, ...claims })));
  return `${header}.${payload}.${b64url(crypto.sign('RSA-SHA256', Buffer.from(`${header}.${payload}`), PRIVATE_PEM))}`;
}
let server: Server; let base: string; let su: Pool; let db: typeof import('../db');
async function put(ids: string[]): Promise<{ status: number; json: Record<string, any>; at: number }> {
  const res = await fetch(`${base}/api/keys/admin-scopes/${U}`, { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token({ role: 'SUPER_ADMIN', userId: crypto.randomUUID() })}` }, body: JSON.stringify({ tenantId: T, organizationIds: ids }) });
  return { status: res.status, json: (await res.json().catch(() => ({}))) as Record<string, any>, at: Date.now() };
}
const rows = async () => (await su.query<{ o: string }>('SELECT organization_id::text o FROM admin_organisation_scopes WHERE user_id=$1::uuid ORDER BY 1', [U])).rows.map((x) => x.o);

beforeAll(async () => {
  if (!SUPER_URL || !APP_URL) throw new Error('gate1539 E needs TEST_DATABASE_URL and TEST_APP_DATABASE_URL');
  su = new Pool({ connectionString: SUPER_URL, max: 2 });
  for (const id of [A1, A2, A3]) await su.query(`INSERT INTO organizations (id, name, slug, type, tenant_id) VALUES ($1::uuid, $2, $3, 'issuer', $4::uuid) ON CONFLICT (id) DO NOTHING`, [id, `gate1539e ${id.slice(-2)}`, `gate1539e-${id.slice(-2)}`, T]);
  await su.query("INSERT INTO users (id, email, tenant_id, role, status) VALUES ($1::uuid, $2, $3::uuid, 'ADMIN', 'active')", [U, `gate1539e-${U}@example.invalid`, T]);
  process.env.DATABASE_URL = APP_URL;
  process.env.JWT_PUBLIC_KEY = Buffer.from(PUBLIC_PEM, 'utf8').toString('base64');
  delete process.env.JWT_JWKS_URL; delete process.env.AUTH_SERVICE_URL;
  db = await import('../db');
  if (!(await db.initDb())) throw new Error('initDb() did not connect');
  const mod = await import('../index');
  await new Promise<void>((resolve) => { server = mod.default.listen(0, '127.0.0.1', resolve); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
afterAll(async () => {
  if (process.env.GATE_LEDGER) fs.writeFileSync(process.env.GATE_LEDGER, JSON.stringify(LEDGER, null, 1));
  if (server) await new Promise<void>((resolve) => server.close(() => resolve()));
  await su.query('DROP TRIGGER IF EXISTS gate1539e_hold ON audit_logs').catch(() => undefined);
  await su.query('DELETE FROM admin_organisation_scopes WHERE user_id=$1::uuid', [U]);
  await su.query("DELETE FROM audit_logs WHERE action='admin_scope.set' AND resource_id=$1::uuid", [U]);
  await su.query('DELETE FROM users WHERE id=$1::uuid', [U]);
  await su.query('DELETE FROM organizations WHERE id = ANY($1::uuid[])', [[A1, A2, A3]]);
  await su.end(); await db?.closeDb();
});

describe('gate E: concurrent replaces of the same ADMIN scope', () => {
  it('E1 X=PUT[A2] (held) and Y=PUT[A3]: the final set equals the last committed write, and its audit row tells the truth', async () => {
    expect((await put([A1])).status).toBe(200);
    await su.query(`CREATE OR REPLACE FUNCTION gate1539e_hold() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN IF NEW.details::jsonb -> 'after' = '["${A2}"]'::jsonb THEN PERFORM pg_sleep(1.5); END IF; RETURN NEW; END $$`);
    await su.query("CREATE TRIGGER gate1539e_hold BEFORE INSERT ON audit_logs FOR EACH ROW WHEN (NEW.action = 'admin_scope.set') EXECUTE FUNCTION gate1539e_hold()");
    let x; let y;
    try {
      const px = put([A2]);
      await new Promise((r) => setTimeout(r, 300));
      const py = put([A3]);
      [x, y] = await Promise.all([px, py]);
    } finally {
      await su.query('DROP TRIGGER IF EXISTS gate1539e_hold ON audit_logs');
      await su.query('DROP FUNCTION IF EXISTS gate1539e_hold()');
    }
    const final = await rows();
    const aud = (await su.query("SELECT details FROM audit_logs WHERE action='admin_scope.set' AND resource_id=$1::uuid ORDER BY created_at", [U])).rows.map((r) => (typeof r.details === 'string' ? JSON.parse(r.details) : r.details));
    const lastWriter = x!.at > y!.at ? 'X' : 'Y';
    Object.assign(LEDGER, { x: { status: x!.status, data: x!.json.data, at: x!.at }, y: { status: y!.status, data: y!.json.data, at: y!.at }, lastWriter, final, audits: aud.map((d) => ({ before: d.before, after: d.after })) });
    console.log('GATE_E', JSON.stringify(LEDGER));
    expect([x!.status, y!.status]).toEqual([200, 200]);
    const lastAfter = (lastWriter === 'X' ? x! : y!).json.data.organizationIds;
    expect(final, 'a REPLACE: the final set is the last committed write').toEqual(lastAfter);
  });
});
