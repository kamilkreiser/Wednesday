/**
 * GATE PR #1539, cells B: ATOMICITY and the tenant GUC on one connection.
 * Each fault is injected as the superuser and removed in a finally. GATE_POOL_MAX (when the gate's
 * harness patch to db.ts is applied) sets the service pool size; the cell records the size it saw.
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import fs from 'fs';
import type { Server } from 'http';
import type { AddressInfo } from 'net';
import { Pool } from 'pg';

process.env.SECURITY_DISABLE_BOOT = '1';

const T = 'a0000000-0000-4000-8000-00000000d139';
const T2 = 'b0000000-0000-4000-8000-00000000d239';
const A1 = 'abcdef00-1539-4539-8539-0000000000d1';
const A3 = 'abcdef00-1539-4539-8539-0000000000d3';
const B1 = 'abcdef00-1539-4539-8539-0000000000e1';
const U = crypto.randomUUID();
const U2 = crypto.randomUUID();
const PID = crypto.randomUUID();
const SUPER_URL = process.env.TEST_DATABASE_URL;
const APP_URL = process.env.TEST_APP_DATABASE_URL;
const LEDGER: Record<string, unknown> = {};
const note = (k: string, v: unknown): void => { LEDGER[k] = v; };

const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const PRIVATE_PEM = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const PUBLIC_PEM = publicKey.export({ type: 'spki', format: 'pem' }).toString();
const b64url = (b: Buffer): string => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function token(claims: Record<string, unknown>): string {
  const header = b64url(Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const now = Math.floor(Date.now() / 1000);
  const payload = b64url(Buffer.from(JSON.stringify({ sub: 'gate1539b', iat: now, exp: now + 600, ...claims })));
  return `${header}.${payload}.${b64url(crypto.sign('RSA-SHA256', Buffer.from(`${header}.${payload}`), PRIVATE_PEM))}`;
}
const PLATFORM = () => token({ role: 'SUPER_ADMIN', userId: PID });

let server: Server;
let base: string;
let su: Pool;
let db: typeof import('../db');

async function put(userId: string, tenantId: string, ids: string[]): Promise<{ status: number; json: Record<string, any> }> {
  const res = await fetch(`${base}/api/keys/admin-scopes/${userId}`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${PLATFORM()}` }, body: JSON.stringify({ tenantId, organizationIds: ids }),
  });
  return { status: res.status, json: (await res.json().catch(() => ({}))) as Record<string, any> };
}
async function rows(userId: string, tenant: string): Promise<string[]> {
  return (await su.query<{ o: string }>('SELECT organization_id::text o FROM admin_organisation_scopes WHERE user_id=$1::uuid AND tenant_id=$2::uuid ORDER BY 1', [userId, tenant])).rows.map((x) => x.o);
}
async function audits(userId: string): Promise<number> {
  return Number((await su.query("SELECT count(*) n FROM audit_logs WHERE action='admin_scope.set' AND resource_id=$1::uuid", [userId])).rows[0].n);
}
async function faultCell(label: string, inject: string[], remove: string[]): Promise<void> {
  expect((await put(U, T, [A1])).status).toBe(200);
  const r0 = await rows(U, T); const a0 = await audits(U);
  let res: { status: number; json: Record<string, any> } | undefined;
  try {
    for (const s of inject) await su.query(s);
    res = await put(U, T, [A3]);
  } finally {
    for (const s of remove) await su.query(s).catch(() => undefined);
  }
  const r1 = await rows(U, T); const a1 = await audits(U);
  const follow = await put(U, T, [A1]);
  note(label, { status: res?.status, code: res?.json?.error?.code, rowsBefore: r0, rowsAfter: r1, auditDelta: a1 - a0, followUp: follow.status });
  expect(res?.status).toBeGreaterThanOrEqual(500);
  expect(r1).toEqual(r0);
  expect(a1).toBe(a0);
  expect(follow.status).toBe(200);
}

beforeAll(async () => {
  if (!SUPER_URL || !APP_URL) throw new Error('gate1539 B needs TEST_DATABASE_URL and TEST_APP_DATABASE_URL');
  su = new Pool({ connectionString: SUPER_URL, max: 3 });
  for (const [id, tenant] of [[A1, T], [A3, T], [B1, T2]] as const) {
    await su.query(`INSERT INTO organizations (id, name, slug, type, tenant_id) VALUES ($1::uuid, $2, $3, 'issuer', $4::uuid) ON CONFLICT (id) DO NOTHING`, [id, `gate1539b ${id.slice(-2)}`, `gate1539b-${id.slice(-2)}`, tenant]);
  }
  for (const [id, tenant] of [[U, T], [U2, T2]] as const) {
    await su.query("INSERT INTO users (id, email, tenant_id, role, status) VALUES ($1::uuid, $2, $3::uuid, 'ADMIN', 'active')", [id, `gate1539b-${id}@example.invalid`, tenant]);
  }
  process.env.DATABASE_URL = APP_URL;
  process.env.JWT_PUBLIC_KEY = Buffer.from(PUBLIC_PEM, 'utf8').toString('base64');
  delete process.env.JWT_JWKS_URL; delete process.env.AUTH_SERVICE_URL;
  db = await import('../db');
  if (!(await db.initDb()) || !db.isDbAvailable()) throw new Error('initDb() did not connect');
  note('poolMax', (db.getPool() as any).options?.max);
  const mod = await import('../index');
  await new Promise<void>((resolve) => { server = mod.default.listen(0, '127.0.0.1', resolve); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

afterAll(async () => {
  if (process.env.GATE_LEDGER) fs.writeFileSync(process.env.GATE_LEDGER, JSON.stringify(LEDGER, null, 1));
  if (server) await new Promise<void>((resolve) => server.close(() => resolve()));
  if (su) {
    await su.query('GRANT INSERT ON audit_logs TO secuura_app').catch(() => undefined);
    await su.query('GRANT INSERT, DELETE ON admin_organisation_scopes TO secuura_app').catch(() => undefined);
    await su.query('DELETE FROM admin_organisation_scopes WHERE user_id = ANY($1::uuid[])', [[U, U2]]);
    await su.query("DELETE FROM audit_logs WHERE action='admin_scope.set' AND resource_id = ANY($1::uuid[])", [[U, U2]]);
    await su.query('DELETE FROM users WHERE id = ANY($1::uuid[])', [[U, U2]]);
    await su.query('DELETE FROM organizations WHERE id = ANY($1::uuid[])', [[A1, A3, B1]]);
    await su.end();
  }
  await db?.closeDb();
});

describe('gate B item 4: the audit row and the scope change are one transaction', () => {
  it('B1 REVOKE INSERT on audit_logs: 5xx, nothing changes', () => faultCell('B1', ['REVOKE INSERT ON audit_logs FROM secuura_app'], ['GRANT INSERT ON audit_logs TO secuura_app']));
  it('B2 audit_logs renamed away (missing table): 5xx, nothing changes', () => faultCell('B2', ['ALTER TABLE audit_logs RENAME TO audit_logs_gate_away'], ['ALTER TABLE audit_logs_gate_away RENAME TO audit_logs']));
  it('B3 a CHECK constraint refusing the row: 5xx, nothing changes', () => faultCell('B3', ["ALTER TABLE audit_logs ADD CONSTRAINT gate1539_no_scope CHECK (action <> 'admin_scope.set') NOT VALID"], ['ALTER TABLE audit_logs DROP CONSTRAINT gate1539_no_scope']));
  it('B4 a DEFERRED constraint trigger failing at COMMIT (after the audit insert succeeded): 5xx, nothing changes', () => faultCell('B4', [
    "CREATE OR REPLACE FUNCTION gate1539_fail_commit() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'gate1539 commit-time failure'; END $$",
    "CREATE CONSTRAINT TRIGGER gate1539_at_commit AFTER INSERT ON audit_logs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (NEW.action = 'admin_scope.set') EXECUTE FUNCTION gate1539_fail_commit()",
  ], ['DROP TRIGGER IF EXISTS gate1539_at_commit ON audit_logs', 'DROP FUNCTION IF EXISTS gate1539_fail_commit()']));
  it('B5 the SCOPE write fails (REVOKE INSERT on admin_organisation_scopes): 5xx, no audit row, rows unchanged', () => faultCell('B5', ['REVOKE INSERT ON admin_organisation_scopes FROM secuura_app'], ['GRANT INSERT ON admin_organisation_scopes TO secuura_app']));
  it('B5b the DELETE fails (REVOKE DELETE): 5xx, nothing changes', () => faultCell('B5b', ['REVOKE DELETE ON admin_organisation_scopes FROM secuura_app'], ['GRANT DELETE ON admin_organisation_scopes TO secuura_app']));

  it('B6 the connection is KILLED while the audit insert is in flight: 5xx, nothing changes, the pool recovers', async () => {
    expect((await put(U, T, [A1])).status).toBe(200);
    const r0 = await rows(U, T); const a0 = await audits(U);
    await su.query("CREATE OR REPLACE FUNCTION gate1539_sleep() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN PERFORM pg_sleep(3); RETURN NEW; END $$");
    await su.query("CREATE TRIGGER gate1539_slow BEFORE INSERT ON audit_logs FOR EACH ROW WHEN (NEW.action = 'admin_scope.set') EXECUTE FUNCTION gate1539_sleep()");
    let res: { status: number; json: Record<string, any> } | undefined; let killed = 0;
    try {
      const p = put(U, T, [A3]);
      for (let i = 0; i < 40 && killed === 0; i++) {
        await new Promise((r) => setTimeout(r, 100));
        const k = await su.query("SELECT pg_terminate_backend(pid) t FROM pg_stat_activity WHERE usename='secuura_app' AND query ILIKE 'INSERT INTO audit_logs%' AND state='active'");
        killed = k.rows.filter((x) => x.t).length;
      }
      res = await p;
    } finally {
      await su.query('DROP TRIGGER IF EXISTS gate1539_slow ON audit_logs');
      await su.query('DROP FUNCTION IF EXISTS gate1539_sleep()');
    }
    const r1 = await rows(U, T); const a1 = await audits(U);
    const follow = [];
    for (let i = 0; i < 4; i++) follow.push((await put(U, T, [A1])).status);
    note('B6', { killed, status: res?.status, json: res?.json, rowsBefore: r0, rowsAfter: r1, auditDelta: a1 - a0, followUps: follow });
    expect(killed).toBe(1);
    expect(res?.status).toBeGreaterThanOrEqual(500);
    expect(r1).toEqual(r0);
    expect(a1).toBe(a0);
    expect(follow.every((s) => s === 200)).toBe(true);
  });
});

describe('gate B item 4b: the tenant GUC is per transaction and never left behind', () => {
  it('B7 interleaved PUTs for T (held 1.5s inside its transaction) and T2: both land in their own tenant; no GUC left on the pool', async () => {
    // instrument control: a SESSION-level set_config through the same pool IS visible afterwards (pool of 1 => same conn)
    const max = (db.getPool() as any).options?.max;
    let controlSeen: string | null = null;
    if (max === 1) {
      await db.getPool().query("SELECT set_config('app.current_tenant_id', 'gate-leak-control', false)");
      controlSeen = (await db.getPool().query("SELECT current_setting('app.current_tenant_id', true) v")).rows[0].v;
      await db.getPool().query("RESET app.current_tenant_id");
    }
    await su.query("CREATE OR REPLACE FUNCTION gate1539_hold() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN IF NEW.tenant_id = 'a0000000-0000-4000-8000-00000000d139'::uuid THEN PERFORM pg_sleep(1.5); END IF; RETURN NEW; END $$");
    await su.query("CREATE TRIGGER gate1539_hold BEFORE INSERT ON audit_logs FOR EACH ROW WHEN (NEW.action = 'admin_scope.set') EXECUTE FUNCTION gate1539_hold()");
    let a: { status: number } | undefined; let b: { status: number } | undefined; const t0 = Date.now(); let tb = 0;
    try {
      const pa = put(U, T, [A1, A3]);
      await new Promise((r) => setTimeout(r, 200));
      const pb = put(U2, T2, [B1]).then((x) => { tb = Date.now() - t0; return x; });
      [a, b] = await Promise.all([pa, pb]);
    } finally {
      await su.query('DROP TRIGGER IF EXISTS gate1539_hold ON audit_logs');
      await su.query('DROP FUNCTION IF EXISTS gate1539_hold()');
    }
    const settings: Array<string | null> = [];
    for (let i = 0; i < 6; i++) settings.push((await db.getPool().query("SELECT current_setting('app.current_tenant_id', true) v, current_setting('app.tenant_scope_bypass', true) b")).rows[0].v);
    const uRows = await rows(U, T); const u2Rows = await rows(U2, T2);
    const crossU = await rows(U, T2); const crossU2 = await rows(U2, T);
    const aud = (await su.query("SELECT resource_id::text r, tenant_id::text t FROM audit_logs WHERE action='admin_scope.set' AND resource_id = ANY($1::uuid[]) ORDER BY created_at DESC LIMIT 2", [[U, U2]])).rows;
    note(`B7.pool${max}`, { max, a: a?.status, b: b?.status, msUntilT2Answered: tb, controlSeen, settings, uRows, u2Rows, crossU, crossU2, aud });
    expect([a?.status, b?.status]).toEqual([200, 200]);
    expect(uRows).toEqual([A1, A3]); expect(u2Rows).toEqual([B1]);
    expect(crossU).toEqual([]); expect(crossU2).toEqual([]);
    expect(settings.every((s) => s === null || s === '')).toBe(true);
    if (max === 1) { expect(controlSeen).toBe('gate-leak-control'); expect(tb).toBeGreaterThan(1300); }
    if (max === 2) expect(tb).toBeLessThan(1300);
  });
});
