/**
 * GATE PR #1539, cell C: the PRE-EXISTING control for B6's uncaught "Connection terminated unexpectedly".
 * Kill the app backend while an ordinary develop path (POST /api/keys -> dbSaveApiKey -> queryWithTenantGuc,
 * a checked-out pooled client) is in flight. If vitest reports the same uncaught exception here, on develop,
 * the crash class is not introduced by PR B.
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import type { Server } from 'http';
import type { AddressInfo } from 'net';
import { Pool } from 'pg';

process.env.SECURITY_DISABLE_BOOT = '1';
const T = 'a0000000-0000-4000-8000-00000000f139';
const SUPER_URL = process.env.TEST_DATABASE_URL;
const APP_URL = process.env.TEST_APP_DATABASE_URL;
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const PRIVATE_PEM = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const PUBLIC_PEM = publicKey.export({ type: 'spki', format: 'pem' }).toString();
const b64url = (b: Buffer): string => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function token(claims: Record<string, unknown>): string {
  const header = b64url(Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const now = Math.floor(Date.now() / 1000);
  const payload = b64url(Buffer.from(JSON.stringify({ sub: 'gate1539c', iat: now, exp: now + 600, ...claims })));
  return `${header}.${payload}.${b64url(crypto.sign('RSA-SHA256', Buffer.from(`${header}.${payload}`), PRIVATE_PEM))}`;
}
let server: Server; let base: string; let su: Pool; let db: typeof import('../db');

beforeAll(async () => {
  if (!SUPER_URL || !APP_URL) throw new Error('gate1539 C needs TEST_DATABASE_URL and TEST_APP_DATABASE_URL');
  su = new Pool({ connectionString: SUPER_URL, max: 2 });
  process.env.DATABASE_URL = APP_URL;
  process.env.JWT_PUBLIC_KEY = Buffer.from(PUBLIC_PEM, 'utf8').toString('base64');
  delete process.env.JWT_JWKS_URL; delete process.env.AUTH_SERVICE_URL;
  db = await import('../db');
  if (!(await db.initDb())) throw new Error('initDb() did not connect');
  const mod = await import('../index');
  await new Promise<void>((resolve) => { server = mod.default.listen(0, '127.0.0.1', resolve); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
afterAll(async () => {
  if (server) await new Promise<void>((resolve) => server.close(() => resolve()));
  await su.query("DELETE FROM svc_api_keys WHERE name LIKE 'gate1539c:%'");
  await su.end(); await db?.closeDb();
});

describe('gate C: pre-existing kill control on a develop path', () => {
  it('C1 kill during the mint save: the request answers 5xx (the uncaught exception, if any, is reported by vitest)', async () => {
    await su.query("CREATE OR REPLACE FUNCTION gate1539c_sleep() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN PERFORM pg_sleep(3); RETURN NEW; END $$");
    await su.query("CREATE TRIGGER gate1539c_slow BEFORE INSERT ON svc_api_keys FOR EACH ROW WHEN (NEW.name LIKE 'gate1539c:%') EXECUTE FUNCTION gate1539c_sleep()");
    let killed = 0; let status = 0;
    try {
      const p = fetch(`${base}/api/keys`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token({ role: 'SUPER_ADMIN' })}` }, body: JSON.stringify({ name: 'gate1539c:k', tenantId: T }) });
      for (let i = 0; i < 40 && killed === 0; i++) {
        await new Promise((r) => setTimeout(r, 100));
        killed = (await su.query("SELECT pg_terminate_backend(pid) t FROM pg_stat_activity WHERE usename='secuura_app' AND query ILIKE '%svc_api_keys%' AND state='active'")).rows.filter((x) => x.t).length;
      }
      status = (await p).status;
    } finally {
      await su.query('DROP TRIGGER IF EXISTS gate1539c_slow ON svc_api_keys');
      await su.query('DROP FUNCTION IF EXISTS gate1539c_sleep()');
    }
    console.log('GATE_C', JSON.stringify({ killed, status }));
    expect(killed).toBe(1);
    expect(status).toBeGreaterThanOrEqual(500);
  });
});
