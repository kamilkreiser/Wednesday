import subprocess,shutil,sys,re,json,os
S=sys.argv[1]; E=sys.argv[2]
D=S+'/head/Blockchain/Dev'
W=D+'/services/auth/src/routes/wallet.ts'; O=D+'/services/auth/src/auth.openapi.ts'; Y=D+'/docs/openapi/secuura-api.yaml'
T='src/__tests__/ks1009-wallet-status-reveals-only-existence.test.ts'
SEL="`SELECT id FROM auth_find_user_by_wallet($1)`"; SEL3="`SELECT id, role, created_at FROM auth_find_user_by_wallet($1)`"
RES="res.json({ exists: true });"
def sub(a,b,c=1): return (a,b)
M={
 'M1 userId back':(W,[(RES,"res.json({ exists: true, userId: result.rows[0].id });")]),
 'M2 role back':(W,[(SEL,SEL3),(RES,"res.json({ exists: true, role: result.rows[0].role });")]),
 'M3 createdAt back':(W,[(SEL,SEL3),(RES,"res.json({ exists: true, createdAt: result.rows[0].created_at });")]),
 'M4 row spread':(W,[(SEL,SEL3),(RES,"res.json({ exists: true, ...result.rows[0] });")]),
 'M5 unregistered message changed':(W,[("message: 'Wallet not registered'","message: 'Wallet not found'")]),
 'M6 yaml userId property re-added':(Y,[("        message:\n          type: string\n      required:\n        - exists\n    WalletLinkRequest:","        message:\n          type: string\n        userId:\n          type: string\n      required:\n        - exists\n    WalletLinkRequest:")]),
 'M7 yaml description restored':(Y,[("It never carries an account attribute (no user id, role or creation time).","userId, role, createdAt are returned.")]),
 'N1 rename userId->uid':(W,[(RES,"res.json({ exists: true, uid: result.rows[0].id });")]),
 'N2 id under key ref':(W,[(RES,"res.json({ exists: true, ref: result.rows[0].id });")]),
 'N3 id in response header X-User-Id (body unchanged)':(W,[(RES,"res.setHeader('X-User-Id', String(result.rows[0].id)); res.json({ exists: true });")]),
 'N4 only the .ts description restored (yaml untouched)':(O,[("It never carries an account attribute (no user id, role or creation time). '","wallet.ts:369 returns {exists:true, userId, role, createdAt} to an unauthenticated caller. '")]),
 'N5 registered answers status 201':(W,[(RES,"res.status(201).json({ exists: true });")]),
 'N6 exists as string "true"':(W,[(RES,"res.json({ exists: 'true' });")]),
 'N7 yaml adds property uid':(Y,[("        message:\n          type: string\n      required:\n        - exists\n    WalletLinkRequest:","        message:\n          type: string\n        uid:\n          type: string\n      required:\n        - exists\n    WalletLinkRequest:")]),
 'N8 id echoed in the 500 error body (error path)':(W,[("    next(error);\n  }\n});\n\n/**\n * POST /api/auth/wallet/link","    res.status(500).json({ error: String((error as Error).message), who: req.params.walletAddress });\n  }\n});\n\n/**\n * POST /api/auth/wallet/link")]),
 'N9 unregistered branch leaks userId:null':(W,[("res.json({ exists: false, message: 'Wallet not registered' });","res.json({ exists: false, message: 'Wallet not registered', userId: null });")]),
 'N10 equivalent: SELECT still wide, answer narrow':(W,[(SEL,SEL3)]),
 'N11 comment-only control':(W,[("// KS-458: pre-auth","// KS-458 (touched): pre-auth")]),
 'N12 registered also emits role via whitespace-padded key':(W,[(RES,"res.json({ exists: true, ' role': 'x' });")]),
}
res={}
for name,(f,subs) in M.items():
    orig=open(f).read(); new=orig
    for a,b in subs:
        if a not in new: print("PATTERN MISSING",name,a[:50]); new=None; break
        new=new.replace(a,b,1)
    if new is None: res[name]='PATTERN-MISSING'; continue
    open(f,'w').write(new)
    try:
        r=subprocess.run(['npx','vitest','run',T,'--reporter=verbose'],cwd=D+'/services/auth',capture_output=True,text=True)
        out=r.stdout+r.stderr
        fails=sorted(set(re.findall(r'^\s*(?:×|✗)\s+\S+ > .*? > ((?:C?\d+)\.?)\s',out,re.M)))
        fails=sorted(set(re.findall(r'×.*? > ((?:C)?\d)\. ',out)))
        res[name]={'rc':r.returncode,'killed_by_cells':fails}
        open(E+'/mut_'+re.sub(r'\W+','_',name)[:30]+'.log','w').write(out)
    finally:
        open(f,'w').write(orig)
    print(name,res[name])
json.dump(res,open(E+'/mutants.json','w'),indent=1)
