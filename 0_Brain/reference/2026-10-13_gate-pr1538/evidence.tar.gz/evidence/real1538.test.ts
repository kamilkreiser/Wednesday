import { describe, it, expect, beforeAll, afterAll, vi } from 'vitest';
import http from 'node:http';
import { writeFileSync } from 'node:fs';
import type { AddressInfo } from 'node:net';
import express from 'express';
process.env.DATABASE_URL = 'postgres://secuura_app:x@127.0.0.1:54938/postgres';
const silentLogger = { debug: vi.fn(), info: vi.fn(), warn: vi.fn(), error: vi.fn(), log: vi.fn() };
vi.mock('../utils/logger', () => ({ logger: silentLogger, createLogger: () => silentLogger, validateEnv: vi.fn() }));
vi.mock('@secuura/shared/utils/logger', () => ({ logger: silentLogger, createLogger: () => silentLogger }));
vi.mock('../utils/cip8', () => ({ verifyCIP8Signature: vi.fn(async () => ({ valid: true })), isValidCardanoAddress: vi.fn(() => true) }));
vi.mock('../services/accountLockout', () => ({ isLockedOut: vi.fn(async () => false), recordFailure: vi.fn(async () => 1), recordSuccess: vi.fn(async () => undefined) }));
vi.mock('../services/session', () => ({ createSession: vi.fn(async () => ({ id: 's' })), getRedisClient: vi.fn(() => null) }));
vi.mock('../services/jwt', () => ({ generateTokenPair: vi.fn(() => ({ accessToken: 'T', refreshToken: 'R', expiresIn: 900 })) }));
vi.mock('../services/totp', () => ({ verifyTotpCode: vi.fn(() => true), verifyBackupCode: vi.fn(async () => ({ valid: false, index: -1 })) }));
vi.mock('../repositories/userRepo', () => ({ getUserByIdPreAuth: vi.fn(async () => null), createUser: vi.fn(), updateUser: vi.fn(), reencryptMfaSecretIfLegacy: vi.fn(), getUserByEmail: vi.fn(async () => null), getUserById: vi.fn(async () => null) }));
vi.mock('../events', () => ({ publishEvent: vi.fn(async () => undefined), EventTypes: {} }));
vi.mock('../middleware/authenticate', () => { const g = () => (_q: any, r: any) => r.status(401).json({ code: 'UNAUTHORIZED' }); return { authenticate: g, authenticateAccessOrConnector: g, requireRole: g, requireVerificationLevel: g, requireOwnership: g, requireSameOrganization: g }; });
let server: any; let port = 0;
beforeAll(async () => {
  const { walletRoutes } = await import('../routes/wallet');
  const { errorHandler } = await import('../middleware/errorHandler');
  const app = express(); app.use(express.json()); app.use('/api/auth/wallet', walletRoutes); app.use(errorHandler);
  server = app.listen(0, '127.0.0.1'); await new Promise<void>((r) => server.once('listening', () => r()));
  port = (server.address() as AddressInfo).port;
});
afterAll(async () => { await new Promise<void>((r) => server.close(() => r())); });
function raw(method: string, path: string): Promise<any> {
  return new Promise((resolve) => {
    const req = http.request({ host: '127.0.0.1', port, method, path }, (res) => {
      let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => resolve({ method, path: path.length > 80 ? path.slice(0, 60) + `...(${path.length})` : path, status: res.statusCode, headers: res.headers, body: b }));
    });
    req.on('error', (e) => resolve({ method, path, error: String(e) })); req.end();
  });
}
const P = '/api/auth/wallet/status/';
const REG = 'addr_test1qrjjw7rrks1538registered';
describe('real route + real PG', () => {
  it('matrix', async () => {
    const reqs: Array<[string, string]> = [
      ['GET', P + REG], ['GET', P + REG.toUpperCase()], ['GET', P + REG + '%20'], ['GET', P + '%20' + REG],
      ['GET', P + 'ADDR_Mixed_Case_1538'], ['GET', P + 'addr_mixed_case_1538'],
      ['GET', P + REG.replace('a', '%D0%B0')], ['GET', P + 'x'.repeat(9000)], ['GET', P + 'x'.repeat(20000)],
      ["GET", P + "%27%20OR%20%271%27%3D%271"], ['GET', P + encodeURIComponent(REG + "' OR '1'='1")],
      ['GET', P + '%25'], ['GET', P + '%00'], ['GET', P + REG + '%00'], ['GET', P + '%E0%A4%A'], ['GET', P + REG + '/'], ['GET', P + REG + '/extra'],
      ['GET', P + 'unknownwallet'], ['GET', '/api/auth/wallet/status/'],
      ['POST', P + REG], ['PUT', P + REG], ['DELETE', P + REG], ['PATCH', P + REG], ['HEAD', P + REG], ['OPTIONS', P + REG],
    ];
    const out: any[] = [];
    for (const [m, p] of reqs) out.push(await raw(m, p));
    writeFileSync(process.env.OUTFILE as string, JSON.stringify(out, null, 1));
    expect(out.length).toBe(reqs.length);
  }, 60000);
});
