import {readdir,readFile} from 'node:fs/promises'; import {join,relative} from 'node:path';
const devRoot=process.argv[2]; const SEED=/INSERT\s+INTO\s+(users|platform_admins)\b/i, SKIP=/(^|\/)(node_modules|dist|build|coverage|\.git|__tests__|__mocks__)(\/|$)/, SC=/\.(ts|js|mjs|cjs|sql|sh)$/;
let files=0,scanned=0,found=[];const t=Date.now();
async function walk(d){let es;try{es=await readdir(d,{withFileTypes:true})}catch{return}
 for(const e of es){const f=join(d,e.name);const r=relative(devRoot,f);if(SKIP.test(r))continue;if(e.isDirectory()){await walk(f);continue}files++;if(!SC.test(e.name))continue;scanned++;let s;try{s=await readFile(f,'utf8')}catch{continue}if(SEED.test(s))found.push(r)}}
await walk(devRoot);console.log(JSON.stringify({ms:Date.now()-t,files,scanned,found:found.sort()}));
