#!/usr/bin/env python3
"""gate PR1535: init the throwaway PG15 on 55411: repo docker/init/* in order, then scripts/run-migrations.sh.
usage: pgsetup.py <tree-Dev-dir> <dbname> <platformdb> <logprefix>"""
import os, subprocess, sys, glob, secrets
W = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/087c4316-bb15-4161-a5ec-601b737a6e98/scratchpad/g1535'
DEV, DB, PDB, LP = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
PGBIN = '/opt/homebrew/opt/postgresql@15/bin'
env = dict(os.environ, PGHOST='127.0.0.1', PGPORT='55411', PGUSER='secuura', PATH=PGBIN + ':' + os.environ['PATH'])
pwf = W + '/pg/app_pw'
if not os.path.exists(pwf):
    open(pwf, 'w').write(secrets.token_hex(16)); os.chmod(pwf, 0o600)
APP_PW = open(pwf).read().strip()
def run(cmd, **kw):
    return subprocess.run(cmd, env=kw.pop('env', env), capture_output=True, text=True, **kw)
for d in (DB, PDB):
    r = run(['psql', '-v', 'ON_ERROR_STOP=1', '-d', 'postgres', '-c', f'CREATE DATABASE {d}'])
    print('create', d, r.returncode, r.stderr.strip())
ienv = dict(env, POSTGRES_USER='secuura', POSTGRES_DB=DB, APP_DB_PASSWORD=APP_PW)
log = open(f'{W}/pg/{LP}_init.log', 'w')
for f in sorted(glob.glob(DEV + '/docker/init/*')):
    b = os.path.basename(f)
    if b == '00-create-platform-db.sql':
        print('SKIP (dblink; db created by hand):', b); continue
    if f.endswith('.sh'):
        r = run(['bash', f], env=ienv)
    elif f.endswith('.sql'):
        r = run(['psql', '-v', 'ON_ERROR_STOP=1', '-d', DB, '-f', f], env=ienv)
    else:
        continue
    log.write(f'--- {b} rc={r.returncode}\n{r.stdout}\n{r.stderr}\n')
    print('init', b, 'rc', r.returncode)
    if r.returncode != 0:
        print(r.stderr[-2000:]); sys.exit(1)
menv = dict(env, DATABASE_URL=f'postgresql://secuura@127.0.0.1:55411/{DB}')
if len(sys.argv) > 5 and sys.argv[5] == 'platform':
    menv['PLATFORM_DATABASE_URL'] = f'postgresql://secuura@127.0.0.1:55411/{PDB}'
r = subprocess.run(['sh', 'scripts/run-migrations.sh'], cwd=DEV, env=menv, capture_output=True, text=True)
open(f'{W}/pg/{LP}_migrations.log', 'w').write(r.stdout + r.stderr)
print('migrations rc', r.returncode)
print('\n'.join(l for l in r.stdout.splitlines() if '049' in l or 'Summary' in l or 'FAILED' in l or 'finished' in l))
