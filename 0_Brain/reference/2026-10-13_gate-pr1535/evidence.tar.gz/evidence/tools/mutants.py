#!/usr/bin/env python3
"""Gate PR1535 mutant runner (head worktree in the gate scratchpad only).
Each mutant: exact-string replacements (each old string must occur exactly once), rebuild shared when the
policy is touched, run: shared ks1570 cells (policy mutants), security author cells + gate A + gate C.
Records every red cell by name; restores and asserts byte-identical sha256; rebuilds shared after restore."""
import hashlib, json, os, re, subprocess, sys
W = '/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/087c4316-bb15-4161-a5ec-601b737a6e98/scratchpad/g1535'
D = W + '/head/Blockchain/Dev'
SH, SEC = D + '/packages/shared', D + '/services/security'
POL = SH + '/src/security/keyRevokePolicy.ts'
SCO = SEC + '/src/adminScope.ts'
IDX = SEC + '/src/index.ts'
APP_PW = open(W + '/pg/app_pw').read().strip()
ENV = dict(os.environ, TEST_DATABASE_URL='postgresql://secuura@127.0.0.1:55411/secuura',
           TEST_APP_DATABASE_URL=f'postgresql://secuura_app:{APP_PW}@127.0.0.1:55411/secuura', NODE_ENV='test',
           MULTI_TENANCY_ENABLED='false', GATE_MIGRATION_049=D + '/migrations/049_admin_organisation_scopes.sql')
ENV.pop('PLATFORM_DATABASE_URL', None)

SCOPE_SELECT = ("  const result = await runWithTenantId(tenantId, () => query<{ organization_id: string }>(\n"
                "    `SELECT organization_id::text AS organization_id\n       FROM admin_organisation_scopes\n"
                "      WHERE tenant_id = $1::uuid AND user_id = $2::uuid`,\n    [tenantId, userId],\n  ));")
MUT = {
 # ---- the author's ten (re-derived from their tool, applied by this runner) + M1 ----
 'M1 the ADMIN arm removed (shared)': [(POL, "  if (organisationScope && isScopedAdminRole(user.role)) {", "  if (organisationScope && isScopedAdminRole(user.role) && (process.env.__NEVER__ === 'x')) {")],
 'M2 the revoke site does not resolve the scope': [(IDX, "  if (isScopedAdminRole(revokeCaller?.role) && normaliseOrgId(apiKey.organizationId) !== null) {", "  if (isScopedAdminRole(revokeCaller?.role) && normaliseOrgId(apiKey.organizationId) !== null && process.env.__NEVER__ === 'x') {")],
 'M3 raw compare, no normalisation (shared)': [(POL, "    const granted = new Set(scope.map((o) => normaliseOrgId(o ?? null)).filter((o): o is string => o !== null));\n    if (!granted.has(targetOrg)) {",
                                                 "    const granted = new Set(scope.filter((o): o is string => !!o));\n    if (!granted.has(organisationScope.targetOrganizationId as string)) {")],
 'M4 an absent scope treated as ALLOW (shared)': [(POL, "      return { allow: false, status: 403, reason: 'admin organisation scope not resolved' };", "      return { allow: true, reason: 'same-tenant' };")],
 'M5 the scope read without the tenant GUC': [(SCO, "  const result = await runWithTenantId(tenantId, () => query<{ organization_id: string }>(", "  const result = await ((f: () => ReturnType<typeof query<{ organization_id: string }>>) => f())(() => query<{ organization_id: string }>(")],
 'M6 platform bypass AND no tenant WHERE (author compound)': [(SCO, "import { runWithTenantId } from '@secuura/shared';", "import { runWithTenantId, runWithPlatformScope } from '@secuura/shared';"),
     (SCO, "  const result = await runWithTenantId(tenantId, () => query<{ organization_id: string }>(", "  const result = await runWithPlatformScope(() => query<{ organization_id: string }>("),
     (SCO, "      WHERE tenant_id = $1::uuid AND user_id = $2::uuid`,", "      WHERE $1::uuid IS NOT NULL AND user_id = $2::uuid`,")],
 'M7 a case-sensitive role test (shared)': [(POL, "  return SCOPED_ADMIN_ROLES.has(String(role || '').toUpperCase());", "  return SCOPED_ADMIN_ROLES.has(String(role || ''));")],
 'M8 a failed read caught to an empty scope': [(SCO, SCOPE_SELECT, "  let result: { rows: Array<{ organization_id: string }> };\n  try {\n" + SCOPE_SELECT.replace('  const result = ', '    result = ') + "\n  } catch { result = { rows: [] }; }")],
 'M8b a failed revoke-side read proceeds without the scope': [(IDX, "    } catch (err) {\n      return next(err);\n    }\n  }\n  const decision = decideKeyRevoke(", "    } catch (err) {\n      adminOrganisationScope = undefined;\n    }\n  }\n  const decision = decideKeyRevoke(")],
 'M10 an empty scope grants everything (shared)': [(POL, "    if (!granted.has(targetOrg)) {", "    if (granted.size > 0 && !granted.has(targetOrg)) {")],
 'M11 the scope looked up for the wrong user (tenant id twice)': [(IDX, "      ? await getAdminOrganisationScope(mintCaller?.tenantId, mintCaller?.userId ?? mintCaller?.sub)", "      ? await getAdminOrganisationScope(mintCaller?.tenantId, mintCaller?.tenantId)")],
 # ---- the gate's own ----
 'G1 scope read under the platform bypass ONLY (tenant WHERE kept)': [(SCO, "import { runWithTenantId } from '@secuura/shared';", "import { runWithTenantId, runWithPlatformScope } from '@secuura/shared';"),
     (SCO, "  const result = await runWithTenantId(tenantId, () => query<{ organization_id: string }>(", "  const result = await runWithPlatformScope(() => query<{ organization_id: string }>(")],
 'G2 a body field pre-resolves the scope (mint)': [(IDX, "      ...(adminOrganisationScope !== undefined ? { adminOrganisationScope } : {}),\n    });\n    if (!mintDecision.allow) {",
     "      ...(adminOrganisationScope !== undefined ? { adminOrganisationScope: [...adminOrganisationScope, ...(((req.body ?? {}) as any).adminOrganisationScope ?? [])] } : {}),\n    });\n    if (!mintDecision.allow) {")],
 'G3 sub preferred over userId (mint)': [(IDX, "      ? await getAdminOrganisationScope(mintCaller?.tenantId, mintCaller?.userId ?? mintCaller?.sub)", "      ? await getAdminOrganisationScope(mintCaller?.tenantId, mintCaller?.sub ?? mintCaller?.userId)")],
 'G4 the uuid guard on tenant/user removed (adminScope)': [(SCO, "  if (!isDbAvailable() || !tenantId || !userId || !UUID_RE.test(tenantId) || !UUID_RE.test(userId)) return [];", "  if (!isDbAvailable() || !tenantId || !userId) return [];")],
 'G5 a scoped ADMIN skips the tenant floor (shared)': [(POL, "  if (user.tenantId !== targetTenantId) {", "  if (user.tenantId !== targetTenantId && !(isScopedAdminRole(user.role) && (organisationScope?.adminOrganisationScope?.length ?? 0) > 0)) {")],
 'G6 decideKeyRevoke drops the resolved scope (shared)': [(POL, "    ...(opts?.adminOrganisationScope !== undefined ? { adminOrganisationScope: opts.adminOrganisationScope } : {}),", "    ...({}),")],
 'G7 a failed revoke-side read answers 403 (refusal, not 5xx)': [(IDX, "    } catch (err) {\n      return next(err);\n    }\n  }\n  const decision = decideKeyRevoke(", "    } catch (err) {\n      adminOrganisationScope = [];\n    }\n  }\n  const decision = decideKeyRevoke(")],
 'G8 the mint resolves the scope only for upper-case ADMIN (lowercase admin unresolved)': [(IDX, "    const adminOrganisationScope = isScopedAdminRole(mintCaller?.role) && normaliseOrgId(data.organizationId) !== null", "    const adminOrganisationScope = mintCaller?.role === 'ADMIN' && normaliseOrgId(data.organizationId) !== null")],
 'G9 the mint reads the scope only when organizationId is the raw truthy string (not normalised)': [(IDX, "    const adminOrganisationScope = isScopedAdminRole(mintCaller?.role) && normaliseOrgId(data.organizationId) !== null", "    const adminOrganisationScope = isScopedAdminRole(mintCaller?.role) && !!data.organizationId")],
 'C0 comment-only control': [(SCO, " * KS-1570 (Kam's ruling, shape b): the ADMIN ORGANISATION SCOPE of a tenant-level ADMIN.", " * KS-1570 (Kam's ruling, shape b): the ADMIN ORGANISATION SCOPE of a tenant-level ADMIN. (gate mutant comment)")],
}
RUNS = [
  ('shared', SH, ['npx', 'vitest', 'run', '--reporter=verbose', 'src/__tests__/ks1570-admin-organisation-scope.test.ts']),
  ('sec-author', SEC, ['npx', 'vitest', 'run', '--config', 'vitest.integration.config.ts', '--reporter=verbose', 'src/__tests__/ks1570-admin-organisation-scope.integration.test.ts']),
  ('gate-A', SEC, ['npx', 'vitest', 'run', '--config', 'vitest.integration.config.ts', '--reporter=verbose', 'src/__tests__/gate1535-a-adversarial.integration.test.ts']),
  ('gate-C', SEC, ['npx', 'vitest', 'run', '--config', 'vitest.integration.config.ts', '--reporter=verbose', 'src/__tests__/gate1535-c-failclosed.integration.test.ts']),
]
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
def build():
    r = subprocess.run(['npx', 'tsc'], cwd=SH, capture_output=True, text=True); return r.returncode, (r.stdout + r.stderr)[-600:]
def run_all(tag):
    res = {}
    for name, cwd, cmd in RUNS:
        r = subprocess.run(cmd, cwd=cwd, env=ENV, capture_output=True, text=True)
        txt = re.sub(r'\x1b\[[0-9;]*m', '', r.stdout + r.stderr)
        open(f'{W}/ev/mut/{tag}_{name}.log', 'w').write(txt)
        m = re.search(r'Tests\s+(?:(\d+) failed \| )?(\d+) passed \((\d+)\)', txt)
        red = sorted(set(re.findall(r'^\s*[×✗] (?:src/__tests__/\S+ > )?(.+?)(?: \d+ms)?$', txt, re.M)))
        res[name] = {'rc': r.returncode, 'total': int(m.group(3)) if m else None, 'failed': int(m.group(1) or 0) if m else None, 'red': red}
    return res
os.makedirs(W + '/ev/mut', exist_ok=True)
only = os.environ.get('ONLY')
out = {}
base = run_all('BASELINE'); out['BASELINE'] = base
print('BASELINE', {k: (v['total'], v['failed']) for k, v in base.items()}, flush=True)
for name, reps in MUT.items():
    if only and name.split()[0] not in only.split(','): continue
    files = sorted({p for p, _, _ in reps}); orig = {p: open(p).read() for p in files}; before = {p: sha(p) for p in files}
    ok = True
    for p, a, b in reps:
        s = open(p).read(); n = s.count(a)
        if n != 1: print(f'{name}: anchor count {n} in {os.path.basename(p)} -> NOT APPLIED'); ok = False; break
        open(p, 'w').write(s.replace(a, b))
    if not ok:
        for p in files: open(p, 'w').write(orig[p])
        out[name] = {'status': 'NOT APPLIED'}; continue
    brc = None
    if POL in files:
        brc, btxt = build()
        if brc != 0: print(f'  build rc {brc}: {btxt}')
    tag = name.split()[0]
    res = run_all(tag)
    for p in files: open(p, 'w').write(orig[p])
    restored = all(sha(p) == before[p] for p in files)
    if POL in files: build()
    reds = {k: v['red'] for k, v in res.items() if v['red']}
    loadfail = any(v['total'] is None for v in res.values())
    status = 'CONTROL OK' if (tag == 'C0' and not reds) else ('KILLED' if reds else ('LOADFAIL' if loadfail else 'SURVIVED'))
    out[name] = {'status': status, 'build_rc': brc, 'restored': restored, 'red': reds, 'totals': {k: (v['total'], v['failed']) for k, v in res.items()}}
    print(f'{name}: {status} restored={restored} build_rc={brc} totals={out[name]["totals"]}', flush=True)
    for k, v in reds.items():
        for c in v: print(f'   red[{k}]: {c[:150]}')
json.dump(out, open(W + f'/ev/mutants{"_" + only if only else ""}.json', 'w'), indent=1)
