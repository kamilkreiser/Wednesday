#!/usr/bin/env python3
"""runin.py <cwd> <outfile> <cmd...>: run cmd in cwd, write combined output + rc to outfile, print summary lines."""
import subprocess, sys, re, os
cwd, out, cmd = sys.argv[1], sys.argv[2], sys.argv[3:]
r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, env=os.environ)
txt = r.stdout + r.stderr
open(out, 'w').write(txt + f'\nrc={r.returncode}\n')
clean = re.sub(r'\x1b\[[0-9;]*m', '', txt)
for l in clean.splitlines():
    if re.search(r'^\s*(Test Files|Tests)\s', l) or 'FAIL' in l[:12] or re.search(r'^\s*[×✗]', l):
        print(l)
print('rc', r.returncode)
