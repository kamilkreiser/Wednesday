import re,sys,collections
lines=open(sys.argv[1]).read().splitlines()
ev=[]  # (pid, kind, text)
cur=None
for l in lines:
    m=re.match(r'^\S+ \S+ \S+ \[(\d+)\] (LOG|DETAIL):\s+(.*)$',l)
    if m:
        pid,k,t=m.groups(); ev.append([pid,k,t]); continue
    if ev: ev[-1][2]+=' '+l.strip()
state=collections.defaultdict(dict); res=collections.Counter(); bad=[]
pending=collections.defaultdict(lambda: None)
for i,(pid,k,t) in enumerate(ev):
    if k=='LOG' and re.search(r'\bBEGIN\b',t): state[pid]={'guc':None,'bypass':False}
    if k=='LOG' and 'set_config' in t:
        pending[pid]=('bypass' if 'tenant_scope_bypass' in t else 'tenant')
        if pending[pid]=='bypass': state[pid]['bypass']=True
    if k=='DETAIL' and pending[pid]=='tenant':
        m=re.search(r"\$1 = '([^']*)'",t); state[pid]['guc']=m.group(1) if m else None; pending[pid]=None
    if k=='LOG' and 'FROM admin_organisation_scopes' in t:
        nxt=ev[i+1] if i+1<len(ev) else None
        m=re.search(r"\$1 = '([^']*)'",nxt[2]) if nxt and nxt[1]=='DETAIL' else None
        wt=m.group(1) if m else None
        s=state.get(pid,{})
        key=('guc==where_tenant' if s.get('guc')==wt and wt else 'MISMATCH', 'bypass' if s.get('bypass') else 'nobypass')
        res[key]+=1
        if key!=('guc==where_tenant','nobypass'): bad.append((pid,s,wt))
    if k=='LOG' and re.search(r'\b(COMMIT|ROLLBACK)\b',t): state[pid]={'guc':None,'bypass':False}
print('scope reads by (guc vs WHERE tenant, bypass):',dict(res)); print('bad:',bad[:5])
print('distinct backend pids that ran a scope read:',len({p for p,k,t in ev if 'FROM admin_organisation_scopes' in t}))
