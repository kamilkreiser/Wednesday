#!/bin/bash
# sec.sh <tree> <outfile> <mt:false|true> [vitest args...]  run the security integration config
W=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/087c4316-bb15-4161-a5ec-601b737a6e98/scratchpad/g1535
T=$1; OUT=$2; MT=$3; shift 3
export TEST_DATABASE_URL="postgresql://secuura@127.0.0.1:55411/${DBN:-secuura}"
export TEST_APP_DATABASE_URL="postgresql://secuura_app:$(cat $W/pg/app_pw)@127.0.0.1:55411/${DBN:-secuura}"
export NODE_ENV=test MULTI_TENANCY_ENABLED=$MT
if [ "$MT" = true ]; then export PLATFORM_DATABASE_URL="postgresql://secuura@127.0.0.1:55411/secuura_platform"; else unset PLATFORM_DATABASE_URL; fi
exec python3 -I $W/bin/runin.py $W/$T/Blockchain/Dev/services/security $OUT npx vitest run --config vitest.integration.config.ts --reporter=verbose "$@"
