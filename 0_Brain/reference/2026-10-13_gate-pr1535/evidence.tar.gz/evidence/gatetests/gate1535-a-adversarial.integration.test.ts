/**
 * GATE PR1535 (independent, Opus tier 1): adversarial cells at the REAL HTTP routes, real PG15 as secuura_app.
 * Every cell records the observed status in a JSON ledger (GATE_LEDGER) as well as asserting the expected
 * value, so the same file run on develop shows exactly which cells change.
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import fs from 'fs';
import type { Server } from 'http';
import type { AddressInfo } from 'net';
import { Pool } from 'pg';

process.env.SECURITY_DISABLE_BOOT = '1';

const T = 'a0000000-0000-4000-8000-0000000f1535';
const T2 = 'b0000000-0000-4000-8000-0000000f1535';
const A1 = 'abcdef00-1535-4535-8535-0000000000a1';
const A2 = 'abcdef00-1535-4535-8535-0000000000a2';
const NAME = 'g1535a:';
const SUPER_URL = process.env.TEST_DATABASE_URL as string;
const APP_URL = process.env.TEST_APP_DATABASE_URL as string;
const LEDGER = process.env.GATE_LEDGER as string;
const ledger: Record<string, unknown> = {};
const rec = (k: string, v: unknown) => { ledger[k] = v; return v; };

const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const PRIVATE_PEM = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const PUBLIC_PEM = publicKey.export({ type: 'spki', format: 'pem' }).toString();
const b64url = (b: Buffer): string => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function token(claims: Record<string, unknown>): string {
  const header = b64url(Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const now = Math.floor(Date.now() / 1000);
  const payload = b64url(Buffer.from(JSON.stringify({ iat: now, exp: now + 600, ...claims })));
  const signature = b64url(crypto.sign('RSA-SHA256', Buffer.from(`${header}.${payload}`), PRIVATE_PEM));
  return `${header}.${payload}.${signature}`;
}
const U_A1 = crypto.randomUUID();      // scope {A1} in T, {A2} in T2
const U_NONE = crypto.randomUUID();    // no rows
const U_ISS = crypto.randomUUID();     // ISSUER_ADMIN with claim A1, but a scope row {A2} in T
const U_SUBONLY = crypto.randomUUID(); // scope {A1} in T, token carries only `sub`
const adm = (userId: string, role = 'ADMIN', extra: Record<string, unknown> = {}) => token({ role, tenantId: T, userId, sub: 'x', ...extra });

let server: Server; let base: string; let su: Pool;

async function mintRaw(tok: string, body: Record<string, unknown>, headers: Record<string, string> = {}) {
  const res = await fetch(`${base}/api/keys`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}`, ...headers },
    body: JSON.stringify({ name: `${NAME}${crypto.randomUUID().slice(0, 8)}`, scopes: ['documents:read'], ...body }),
  });
  const text = await res.text();
  let id: string | null = null;
  try { id = (JSON.parse(text) as { data?: { id?: string } }).data?.id ?? null; } catch { /* */ }
  return { status: res.status, id, text };
}
const mint = (tok: string, body: Record<string, unknown>) => mintRaw(tok, { tenantId: T, ...body });
async function revoke(tok: string, id: string): Promise<number> {
  const res = await fetch(`${base}/api/keys/${encodeURIComponent(id)}`, { method: 'DELETE', headers: { Authorization: `Bearer ${tok}` } });
  return res.status;
}
async function storedOrg(id: string): Promise<string | null | undefined> {
  const r = await su.query('SELECT organization_id FROM svc_api_keys WHERE id = $1', [id]);
  return r.rows[0] ? r.rows[0].organization_id : undefined;
}
async function active(id: string): Promise<boolean | undefined> {
  const r = await su.query('SELECT is_active FROM svc_api_keys WHERE id = $1', [id]);
  return r.rows[0]?.is_active;
}
async function count(): Promise<number> {
  const r = await su.query('SELECT count(*)::int AS n FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  return r.rows[0].n;
}
/** A legacy key row written directly (a pre-#1521 mint or a direct write), with an exact stored organisation id. */
async function legacyKey(tenant: string, org: string | null): Promise<string> {
  const id = `key_${crypto.randomUUID()}`;
  await su.query(
    `INSERT INTO svc_api_keys (id, organization_id, tenant_id, name, key_hash, key_prefix, scopes, rate_limit, rate_limit_window, usage_count, is_active, created_at)
     VALUES ($1,$2,$3::uuid,$4,$5,'sk_legacy',$6::jsonb,1000,3600,0,true,now())`,
    [id, org, tenant, `${NAME}legacy`, crypto.randomBytes(32).toString('hex'), JSON.stringify(['documents:read'])],
  );
  return id;
}

beforeAll(async () => {
  su = new Pool({ connectionString: SUPER_URL, max: 2 });
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  await su.query(
    `INSERT INTO admin_organisation_scopes (tenant_id, user_id, organization_id, granted_by) VALUES
      ($1::uuid,$3::uuid,$5::uuid,'g1535'), ($2::uuid,$3::uuid,$6::uuid,'g1535'),
      ($1::uuid,$4::uuid,$6::uuid,'g1535'), ($1::uuid,$7::uuid,$5::uuid,'g1535')`,
    [T, T2, U_A1, U_ISS, A1, A2, U_SUBONLY],
  );
  process.env.DATABASE_URL = APP_URL;
  process.env.JWT_PUBLIC_KEY = Buffer.from(PUBLIC_PEM, 'utf8').toString('base64');
  delete process.env.JWT_JWKS_URL; delete process.env.AUTH_SERVICE_URL;
  const db = await import('../db');
  if (!(await db.initDb()) || !db.isDbAvailable()) throw new Error('no DB');
  const app = (await import('../index')).default;
  await new Promise<void>((r) => { server = app.listen(0, '127.0.0.1', r); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
afterAll(async () => {
  if (LEDGER) fs.writeFileSync(LEDGER, JSON.stringify(ledger, null, 1));
  if (server) await new Promise<void>((r) => server.close(() => r()));
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  await su.query('DELETE FROM admin_organisation_scopes WHERE user_id = ANY($1::uuid[])', [[U_A1, U_ISS, U_SUBONLY, U_NONE]]);
  await su.end();
  const db = await import('../db'); await db.closeDb();
});

const NBSP = ' ';
const FULLWIDTH_A1 = A1.replace(/a/g, 'ａ'); // fullwidth a: lower-cases to itself, never to ASCII a
const KELVIN_A2 = A2.replace('abcdef', 'Kbcdef').slice(0, A2.length + 1); // Kelvin sign prefixed: not a uuid

describe('G-A1 mint: ADMIN scoped {A1} naming A2 in every spelling is refused', () => {
  const spellings: Array<[string, string]> = [
    ['exact', A2], ['upper', A2.toUpperCase()], ['padded', `  ${A2}  `], ['nbsp', `${NBSP}${A2}${NBSP}`],
    ['tab', `\t${A2}\n`], ['braces', `{${A2}}`], ['kelvin', KELVIN_A2], ['default-org', 'default-org'],
    ['urn', `urn:uuid:${A2}`], ['no-hyphens', A2.replace(/-/g, '')],
  ];
  for (const [label, org] of spellings) {
    it(`A2 ${label} -> 403, nothing minted`, async () => {
      const before = await count();
      const m = await mint(adm(U_A1), { organizationId: org });
      rec(`mint.U_A1.A2.${label}`, m.status);
      expect(m.status).toBe(403);
      expect(await count()).toBe(before);
    });
  }
});

describe('G-A2 mint: ADMIN scoped {A1} naming A1 in accepted spellings mints, stored normalised', () => {
  const spellings: Array<[string, string, number]> = [
    ['exact', A1, 201], ['upper', A1.toUpperCase(), 201], ['nbsp', `${NBSP}${A1}${NBSP}`, 201], ['tab', `\t${A1}\n`, 201],
    ['braces', `{${A1}}`, 403], ['fullwidth', FULLWIDTH_A1, 403], ['no-hyphens', A1.replace(/-/g, ''), 403],
  ];
  for (const [label, org, want] of spellings) {
    it(`A1 ${label} -> ${want}`, async () => {
      const m = await mint(adm(U_A1), { organizationId: org });
      rec(`mint.U_A1.A1.${label}`, m.status);
      expect(m.status).toBe(want);
      if (want === 201) expect(await storedOrg(m.id as string)).toBe(A1);
    });
  }
});

describe('G-A3 mint: unscoped ADMIN', () => {
  const spellings: Array<[string, string]> = [['exact', A1], ['upper', A1.toUpperCase()], ['nbsp', `${NBSP}${A1}`], ['default-org', 'default-org']];
  for (const [label, org] of spellings) {
    it(`U_NONE naming A1 ${label} -> 403`, async () => {
      const m = await mint(adm(U_NONE), { organizationId: org });
      rec(`mint.U_NONE.${label}`, m.status);
      expect(m.status).toBe(403);
    });
  }
  it('U_NONE unqualified (absent, empty, whitespace, null-ish) -> 201, stored org NULL', async () => {
    for (const [label, body] of [['absent', {}], ['empty', { organizationId: '' }], ['ws', { organizationId: `  ${NBSP}` }]] as const) {
      const m = await mint(adm(U_NONE), body as Record<string, unknown>);
      rec(`mint.U_NONE.unqualified.${label}`, m.status);
      expect(m.status).toBe(201);
      expect(await storedOrg(m.id as string)).toBeNull();
    }
  });
  it('a body field naming a pre-resolved scope is ignored (403)', async () => {
    const m = await mint(adm(U_NONE), { organizationId: A1, adminOrganisationScope: [A1], organisationScope: { adminOrganisationScope: [A1] } });
    rec('mint.U_NONE.bodyScopeInjection', m.status);
    expect(m.status).toBe(403);
  });
  it('a header naming a scope is ignored (403)', async () => {
    const m = await mintRaw(adm(U_NONE), { tenantId: T, organizationId: A1 }, { 'x-admin-organisation-scope': A1, 'x-organization-id': A1 });
    rec('mint.U_NONE.headerScopeInjection', m.status);
    expect(m.status).toBe(403);
  });
});

describe('G-A4 mint: role spellings and token shapes', () => {
  for (const role of ['ADMIN', 'admin', 'Admin', 'aDmIn']) {
    it(`role ${JSON.stringify(role)} scoped {A1}: A2 403, A1 201`, async () => {
      const a = await mint(adm(U_A1, role), { organizationId: A2 });
      const b = await mint(adm(U_A1, role), { organizationId: A1 });
      rec(`mint.role.${role}`, [a.status, b.status]);
      expect([a.status, b.status]).toEqual([403, 201]);
    });
  }
  for (const role of [' ADMIN', 'ADMIN ', '\tADMIN', 'ADMIN​']) {
    it(`role ${JSON.stringify(role)} is refused at the role gate (403), nothing minted`, async () => {
      const before = await count();
      const a = await mint(adm(U_NONE, role), { organizationId: A2 });
      const b = await mint(adm(U_NONE, role), {});
      rec(`mint.role.${JSON.stringify(role)}`, [a.status, b.status, a.text.slice(0, 80)]);
      expect([a.status, b.status]).toEqual([403, 403]);
      expect(await count()).toBe(before);
    });
  }
  it('no tenantId on the token: naming A1 -> 403; unqualified -> 403', async () => {
    const tok = token({ role: 'ADMIN', userId: U_A1 });
    const a = await mint(tok, { organizationId: A1 });
    const b = await mint(tok, {});
    const c = await mintRaw(tok, { organizationId: A1 });
    rec('mint.noTenant', [a.status, b.status, c.status]);
    expect(a.status).toBe(403); expect(b.status).toBe(403); expect(c.status).toBe(403);
  });
  it('no userId and no sub: naming A1 -> 403; unqualified -> 201', async () => {
    const tok = token({ role: 'ADMIN', tenantId: T });
    const a = await mint(tok, { organizationId: A1 });
    const b = await mint(tok, {});
    rec('mint.noUser', [a.status, b.status]);
    expect([a.status, b.status]).toEqual([403, 201]);
  });
  it('userId absent, sub = a scoped user: the sub fallback resolves the scope (A1 201, A2 403)', async () => {
    const tok = token({ role: 'ADMIN', tenantId: T, sub: U_SUBONLY });
    const a = await mint(tok, { organizationId: A1 });
    const b = await mint(tok, { organizationId: A2 });
    rec('mint.subOnly', [a.status, b.status]);
    expect([a.status, b.status]).toEqual([201, 403]);
  });
  it('userId non-uuid ("../x"), sub scoped: userId wins and grants nothing (403)', async () => {
    const tok = token({ role: 'ADMIN', tenantId: T, userId: "x' OR 1=1 --", sub: U_SUBONLY });
    const a = await mint(tok, { organizationId: A1 });
    rec('mint.userIdInjection', a.status);
    expect(a.status).toBe(403);
  });
  it('userId upper-case form of a scoped user still resolves (uuid cast) A1 201', async () => {
    const a = await mint(adm(U_A1.toUpperCase()), { organizationId: A1 });
    rec('mint.userIdUpper', a.status);
    expect(a.status).toBe(201);
  });
  it('tenantId on the token in upper case: cross-tenant against the body tenant, 403 (fail closed)', async () => {
    const a = await mint(token({ role: 'ADMIN', tenantId: T.toUpperCase(), userId: U_A1 }), { organizationId: A1 });
    rec('mint.tenantUpper', a.status);
    expect(a.status).toBe(403);
  });
  it('ADMIN of T scoped {A2} only in T2 naming A2 with tenant T: 403; with tenant T2 as an ADMIN of T2: 201', async () => {
    const a = await mint(adm(U_A1), { organizationId: A2 });
    const b = await mintRaw(token({ role: 'ADMIN', tenantId: T2, userId: U_A1 }), { tenantId: T2, organizationId: A2 });
    const c = await mintRaw(adm(U_A1), { tenantId: T2, organizationId: A2 });
    const d = await mintRaw(adm(U_A1), { organizationId: A1 }, { 'x-tenant-id': T2 });
    rec('mint.crossTenant', [a.status, b.status, c.status, d.status]);
    expect([a.status, b.status, c.status, d.status]).toEqual([403, 201, 403, 403]);
  });
  it('ISSUER_ADMIN (claim A1) with a stray scope row {A2}: the row does not widen it (A2 403, A1 201)', async () => {
    const tok = token({ role: 'ISSUER_ADMIN', tenantId: T, organizationId: A1, userId: U_ISS });
    const a = await mint(tok, { organizationId: A2 });
    const b = await mint(tok, { organizationId: A1 });
    rec('mint.issuerStrayScope', [a.status, b.status]);
    expect([a.status, b.status]).toEqual([403, 201]);
  });
  it('ORG_ADMIN claim A1: A2 403, A1 201 (unchanged)', async () => {
    const tok = token({ role: 'ORG_ADMIN', tenantId: T, organizationId: A1, userId: crypto.randomUUID() });
    const r = [(await mint(tok, { organizationId: A2 })).status, (await mint(tok, { organizationId: A1 })).status];
    rec('mint.orgAdmin', r); expect(r).toEqual([403, 201]);
  });
  it('platform roles keep cross-organisation reach: super_admin, SYSTEM_ADMIN, SUPER_ADMIN naming A2 -> 201', async () => {
    const r = [] as number[];
    for (const role of ['super_admin', 'SYSTEM_ADMIN', 'SUPER_ADMIN']) r.push((await mint(token({ role, userId: crypto.randomUUID() }), { organizationId: A2 })).status);
    rec('mint.platform', r); expect(r).toEqual([201, 201, 201]);
  });
  it('a connector principal (no provisioning scope) is refused (403)', async () => {
    const a = await mint(token({ role: 'connector', tenantId: T, organizationId: A1, scopes: ['documents:read'] }), { organizationId: A1 });
    rec('mint.connector', a.status); expect(a.status).toBe(403);
  });
  it('a scoped ADMIN cannot name a connectorId or rotate (403)', async () => {
    const a = await mint(adm(U_A1), { organizationId: A1, connectorId: 'conn_x', rotate: true });
    rec('mint.adminConnectorId', a.status); expect(a.status).toBe(403);
  });
});

describe('G-A5 revoke at DELETE /api/keys/:id', () => {
  let platformTok: string;
  beforeAll(() => { platformTok = token({ role: 'super_admin', userId: crypto.randomUUID() }); });
  const pk = async (org?: string) => (await mint(platformTok, org === undefined ? {} : { organizationId: org })).id as string;

  it("{A1} revoking A2's key: 403, stays active", async () => {
    const k = await pk(A2); const s = await revoke(adm(U_A1), k);
    rec('revoke.U_A1.A2', s); expect(s).toBe(403); expect(await active(k)).toBe(true);
  });
  it("{A1} revoking A1's key: 200, inactive", async () => {
    const k = await pk(A1); const s = await revoke(adm(U_A1), k);
    rec('revoke.U_A1.A1', s); expect(s).toBe(200); expect(await active(k)).toBe(false);
  });
  it('{A1} revoking an already-revoked A1 key: 200 again (idempotent), still inactive', async () => {
    const k = await pk(A1); await revoke(adm(U_A1), k); const s = await revoke(adm(U_A1), k);
    rec('revoke.U_A1.A1.again', s); expect(s).toBe(200); expect(await active(k)).toBe(false);
  });
  it('{A1} revoking an already-revoked A2 key: 403', async () => {
    const k = await pk(A2); await revoke(platformTok, k); const s = await revoke(adm(U_A1), k);
    rec('revoke.U_A1.A2.revoked', s); expect(s).toBe(403);
  });
  it('org-less key: revocable by scoped and by unscoped ADMIN (200)', async () => {
    const k1 = await pk(); const k2 = await pk();
    const r = [await revoke(adm(U_A1), k1), await revoke(adm(U_NONE), k2)];
    rec('revoke.orgless', r); expect(r).toEqual([200, 200]);
  });
  it("unscoped ADMIN revoking A1's key: 403", async () => {
    const k = await pk(A1); const s = await revoke(adm(U_NONE), k);
    rec('revoke.U_NONE.A1', s); expect(s).toBe(403); expect(await active(k)).toBe(true);
  });
  it("lowercase 'admin' {A1}: A2 403, A1 200", async () => {
    const k2 = await pk(A2); const k1 = await pk(A1);
    const r = [await revoke(adm(U_A1, 'admin'), k2), await revoke(adm(U_A1, 'admin'), k1)];
    rec('revoke.lower', r); expect(r).toEqual([403, 200]);
  });
  it('a key of ANOTHER tenant (T2, org A2; U_A1 holds A2 in T2): ADMIN of T -> 403', async () => {
    const k = await legacyKey(T2, A2); const s = await revoke(adm(U_A1), k);
    rec('revoke.otherTenant', s); expect(s).toBe(403); expect(await active(k)).toBe(true);
  });
  it('legacy stored forms: upper-case A1 200, padded A1 200, upper-case A2 403, blank org 200 (KS-1577), default-org 403', async () => {
    const r = [
      await revoke(adm(U_A1), await legacyKey(T, A1.toUpperCase())),
      await revoke(adm(U_A1), await legacyKey(T, `  ${A1} `)),
      await revoke(adm(U_A1), await legacyKey(T, A2.toUpperCase())),
      await revoke(adm(U_NONE), await legacyKey(T, '   ')),
      await revoke(adm(U_A1), await legacyKey(T, 'default-org')),
    ];
    rec('revoke.legacy', r); expect(r).toEqual([200, 200, 403, 200, 403]);
  });
  it('platform revokes A2 key (200); ISSUER_ADMIN with stray scope row {A2} cannot (403)', async () => {
    const k = await pk(A2);
    const a = await revoke(token({ role: 'ISSUER_ADMIN', tenantId: T, organizationId: A1, userId: U_ISS }), k);
    const b = await revoke(platformTok, k);
    rec('revoke.issuer_platform', [a, b]); expect([a, b]).toEqual([403, 200]);
  });
  it('role with whitespace refused at the role gate (403)', async () => {
    const k = await pk(A1); const s = await revoke(adm(U_A1, ' ADMIN'), k);
    rec('revoke.roleWs', s); expect(s).toBe(403); expect(await active(k)).toBe(true);
  });
  it('unknown key id: 404', async () => {
    const s = await revoke(adm(U_A1), 'key_does-not-exist'); rec('revoke.unknown', s); expect(s).toBe(404);
  });
});

describe('G-A6 no update route turns an unqualified key into an organisation key', () => {
  it('PATCH and PUT /api/keys/:id do not exist (404), and a re-POST with the same id is impossible (server-chosen id)', async () => {
    const m = await mint(adm(U_NONE), {});
    const p = await fetch(`${base}/api/keys/${m.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${adm(U_NONE)}` }, body: JSON.stringify({ organizationId: A1 }) });
    const q = await fetch(`${base}/api/keys/${m.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${adm(U_NONE)}` }, body: JSON.stringify({ organizationId: A1 }) });
    const r = await mint(adm(U_NONE), { id: m.id, organizationId: A1 });
    rec('update.routes', [p.status, q.status, r.status]);
    expect(p.status).toBe(404); expect(q.status).toBe(404); expect(r.status).toBe(403);
    expect(await storedOrg(m.id as string)).toBeNull();
  });
  it('the list does not show an unqualified key under any organisation query (KS-1581, recorded)', async () => {
    const m = await mint(adm(U_NONE), {});
    const res = await fetch(`${base}/api/keys?organizationId=${A1}`, { headers: { Authorization: `Bearer ${adm(U_NONE)}` } });
    const body = await res.json() as { data?: Array<{ id: string }> };
    const listed = (body.data ?? []).some((k) => k.id === m.id);
    const resOther = await fetch(`${base}/api/keys?organizationId=${A2}`, { headers: { Authorization: `Bearer ${adm(U_A1)}` } });
    rec('list', { status: res.status, unqualifiedListed: listed, scopedAdminListsOtherOrg: resOther.status });
    expect(listed).toBe(false);
  });
});
