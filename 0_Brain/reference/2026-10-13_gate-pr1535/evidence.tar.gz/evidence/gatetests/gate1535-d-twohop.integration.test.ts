/**
 * GATE PR1535 (d): the TWO-HOP path. An ADMIN outside (or without) a scope mints a key carrying the
 * provisioning scope `organizations:register` (decideMint's KEY_ADMIN early return allows any scope), then
 * uses that key as the provisioning connector it now is to mint a key NAMING ANOTHER ORGANISATION, bound to
 * that organisation's connector id. The connector principal is built exactly as the platform builds it:
 * the key is validated at this service's own /api/keys/validate, and the bearer carries the claims of
 * auth's generateConnectorToken (services/auth/src/services/jwt.ts:281-297) from that metadata.
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import fs from 'fs';
import type { Server } from 'http';
import type { AddressInfo } from 'net';
import { Pool } from 'pg';

process.env.SECURITY_DISABLE_BOOT = '1';
const T = 'a0000000-0000-4000-8000-0000000fd535';
const A1 = 'abcdef00-1535-4535-8535-0000000000d1';
const A2 = 'abcdef00-1535-4535-8535-0000000000d2';
const NAME = 'g1535d:';
const U_NONE = crypto.randomUUID();
const U_A1 = crypto.randomUUID();
const LEDGER = process.env.GATE_LEDGER as string;
const ledger: Record<string, unknown> = {};
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const PRIVATE_PEM = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const b64url = (b: Buffer): string => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function token(claims: Record<string, unknown>): string {
  const h = b64url(Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const now = Math.floor(Date.now() / 1000);
  const p = b64url(Buffer.from(JSON.stringify({ iat: now, exp: now + 600, ...claims })));
  return `${h}.${p}.${b64url(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), PRIVATE_PEM))}`;
}
let server: Server; let base: string; let su: Pool;
async function post(path: string, tok: string | null, body: Record<string, unknown>) {
  const r = await fetch(`${base}${path}`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(tok ? { Authorization: `Bearer ${tok}` } : {}) }, body: JSON.stringify(body) });
  const text = await r.text(); let j: any = {}; try { j = JSON.parse(text); } catch { /* */ }
  return { status: r.status, j, text };
}
/** auth's generateConnectorToken claims, from the key's validated metadata. */
function connectorTokenFor(meta: { connectorId?: string | null; organizationId?: string; tenantId?: string; scopes?: string[] }): string {
  return token({
    userId: `connector:${meta.connectorId || 'api-key'}`, email: 'connector@secuura.io', role: 'connector',
    ...(meta.organizationId ? { organizationId: meta.organizationId } : {}), verificationLevel: 'api_key', type: 'connector',
    ...(meta.tenantId ? { tenantId: meta.tenantId } : {}), scopes: meta.scopes || [],
  });
}
beforeAll(async () => {
  su = new Pool({ connectionString: process.env.TEST_DATABASE_URL, max: 2 });
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  await su.query(`INSERT INTO admin_organisation_scopes (tenant_id,user_id,organization_id,granted_by) VALUES ($1,$2,$3,'g')`, [T, U_A1, A1]).catch(() => undefined);
  process.env.DATABASE_URL = process.env.TEST_APP_DATABASE_URL;
  process.env.JWT_PUBLIC_KEY = Buffer.from(publicKey.export({ type: 'spki', format: 'pem' }).toString(), 'utf8').toString('base64');
  delete process.env.JWT_JWKS_URL; delete process.env.AUTH_SERVICE_URL;
  const db = await import('../db'); if (!(await db.initDb())) throw new Error('no db');
  const app = (await import('../index')).default;
  await new Promise<void>((r) => { server = app.listen(0, '127.0.0.1', r); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
afterAll(async () => {
  if (LEDGER) fs.writeFileSync(LEDGER, JSON.stringify(ledger, null, 1));
  if (server) await new Promise<void>((r) => server.close(() => r()));
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  await su.query('DELETE FROM admin_organisation_scopes WHERE user_id = ANY($1::uuid[])', [[U_NONE, U_A1]]).catch(() => undefined);
  await su.end(); const db = await import('../db'); await db.closeDb();
});

for (const [label, uid, hop1Org, role] of [['UNSCOPED ADMIN, unqualified hop-1 key', U_NONE, undefined, 'ADMIN'], ['ADMIN scoped {A1}, A1 hop-1 key', U_A1, A1, 'ADMIN'], ['ISSUER_ADMIN claim A1, A1 hop-1 key', U_A1, A1, 'ISSUER_ADMIN']] as const) {
  describe(`GATE-D two-hop: ${label}`, () => {
    it('hop 1: the ADMIN mints a key carrying organizations:register (RECORDED; the bound expects no path to A2 from here)', async () => {
      const m = await post('/api/keys', token({ role, tenantId: T, userId: uid, ...(role === 'ISSUER_ADMIN' ? { organizationId: A1 } : {}) }),
        { name: `${NAME}hop1`, tenantId: T, scopes: ['organizations:register'], ...(hop1Org ? { organizationId: hop1Org } : {}) });
      ledger[`${label}.hop1`] = m.status;
      expect(m.status).toBe(201);
      const v = await post('/api/keys/validate', null, { key: m.j.data.key });
      ledger[`${label}.validate`] = { status: v.status, valid: v.j?.data?.valid, scopes: v.j?.data?.scopes, organizationId: v.j?.data?.organizationId ?? null };
      expect(v.j?.data?.valid).toBe(true);
      const conn = connectorTokenFor({ connectorId: v.j.data.connectorId, organizationId: v.j.data.organizationId, tenantId: v.j.data.tenantId, scopes: v.j.data.scopes });
      // hop 2: the provisioning connector names A2 and binds the key to A2's connector id.
      const h2 = await post('/api/keys', conn, { name: `${NAME}hop2`, tenantId: T, organizationId: A2, scopes: ['documents:read'], connectorId: 'conn_of_A2' });
      const row = h2.j?.data?.id ? (await su.query('SELECT organization_id, connector_id, tenant_id::text AS t FROM svc_api_keys WHERE id=$1', [h2.j.data.id])).rows[0] : null;
      ledger[`${label}.hop2`] = { status: h2.status, stored: row, text: h2.status === 201 ? '' : h2.text.slice(0, 160) };
      // The ruled bound says an ADMIN outside A2's scope cannot obtain a key carrying A2. Assert it.
      expect(h2.status, 'two-hop: an ADMIN outside A2 obtained an A2 key through a provisioning key').toBe(403);
    });
  });
}
