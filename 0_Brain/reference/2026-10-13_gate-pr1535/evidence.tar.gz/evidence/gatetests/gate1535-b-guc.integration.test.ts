/**
 * GATE PR1535 (b): RLS + GUC. The service pool is forced to GATE_POOL_MAX connections (vi.mock of pg.Pool), so
 * interleaved requests for two tenants share one or two server connections. Then the GUC is read back on the
 * pool outside any scope: nothing may be left behind.
 */
import { describe, it, expect, beforeAll, afterAll, vi } from 'vitest';
import crypto from 'crypto';
import type { Server } from 'http';
import type { AddressInfo } from 'net';

vi.mock('pg', async (orig) => {
  const m = await orig<typeof import('pg')>();
  const max = Number(process.env.GATE_POOL_MAX || 10);
  class P extends m.Pool { constructor(o: any) { super({ ...(o || {}), max }); } }
  return { ...m, Pool: P, default: { ...(m as any).default, Pool: P } };
});
import { Pool } from 'pg';

process.env.SECURITY_DISABLE_BOOT = '1';
const T = 'a0000000-0000-4000-8000-0000000fb535';
const T2 = 'b0000000-0000-4000-8000-0000000fb535';
const A1 = 'abcdef00-1535-4535-8535-0000000000b1';
const A2 = 'abcdef00-1535-4535-8535-0000000000b2';
const NAME = 'g1535b:';
const X = crypto.randomUUID(); // ADMIN of T, scope {A1}
const Y = crypto.randomUUID(); // ADMIN of T2, scope {A2}
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const PRIVATE_PEM = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const b64url = (b: Buffer): string => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function token(claims: Record<string, unknown>): string {
  const h = b64url(Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const now = Math.floor(Date.now() / 1000);
  const p = b64url(Buffer.from(JSON.stringify({ iat: now, exp: now + 600, ...claims })));
  return `${h}.${p}.${b64url(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), PRIVATE_PEM))}`;
}
let server: Server; let base: string; let su: Pool; let db: typeof import('../db');

beforeAll(async () => {
  su = new Pool({ connectionString: process.env.TEST_DATABASE_URL, max: 2 });
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  await su.query(`INSERT INTO admin_organisation_scopes (tenant_id,user_id,organization_id,granted_by) VALUES ($1,$2,$3,'g'),($4,$5,$6,'g')`, [T, X, A1, T2, Y, A2]);
  process.env.DATABASE_URL = process.env.TEST_APP_DATABASE_URL;
  process.env.JWT_PUBLIC_KEY = Buffer.from(publicKey.export({ type: 'spki', format: 'pem' }).toString(), 'utf8').toString('base64');
  delete process.env.JWT_JWKS_URL; delete process.env.AUTH_SERVICE_URL;
  db = await import('../db');
  if (!(await db.initDb())) throw new Error('no db');
  const app = (await import('../index')).default;
  await new Promise<void>((r) => { server = app.listen(0, '127.0.0.1', r); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
afterAll(async () => {
  if (server) await new Promise<void>((r) => server.close(() => r()));
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  await su.query('DELETE FROM admin_organisation_scopes WHERE user_id = ANY($1::uuid[])', [[X, Y]]);
  await su.end(); await db.closeDb();
});

async function mint(tok: string, tenantId: string, organizationId: string): Promise<number> {
  const r = await fetch(`${base}/api/keys`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` },
    body: JSON.stringify({ name: `${NAME}${crypto.randomUUID().slice(0, 6)}`, scopes: ['documents:read'], tenantId, organizationId }) });
  await r.text(); return r.status;
}

describe(`GATE-B pool max=${process.env.GATE_POOL_MAX}`, () => {
  it('the pool really is the forced size', () => {
    expect((db.getPool() as any).options.max).toBe(Number(process.env.GATE_POOL_MAX || 10));
  });
  it('80 interleaved mints for two tenants: every verdict is the scope verdict of ITS OWN tenant', async () => {
    const tx = token({ role: 'ADMIN', tenantId: T, userId: X });
    const ty = token({ role: 'ADMIN', tenantId: T2, userId: Y });
    const plan: Array<[string, string, string, number]> = [];
    for (let i = 0; i < 20; i++) plan.push([tx, T, A1, 201], [ty, T2, A2, 201], [tx, T, A2, 403], [ty, T2, A1, 403]);
    const got = await Promise.all(plan.map(([t, tn, o]) => mint(t, tn, o)));
    const wrong = plan.map((p, i) => [p[1], p[2], p[3], got[i]]).filter((r) => r[2] !== r[3]);
    expect(wrong).toEqual([]);
  });
  it('no GUC is left behind on the pool connection(s) after the scope reads', async () => {
    const seen = new Set<string>();
    for (let i = 0; i < 6; i++) {
      const r = await db.getPool().query("SELECT coalesce(current_setting('app.current_tenant_id', true),'<null>') AS t, coalesce(current_setting('app.tenant_scope_bypass', true),'<null>') AS b");
      seen.add(`${r.rows[0].t}|${r.rows[0].b}`);
    }
    for (const s of seen) expect(s).toMatch(/^(<null>|)\|(<null>|)$/);
  });
});
