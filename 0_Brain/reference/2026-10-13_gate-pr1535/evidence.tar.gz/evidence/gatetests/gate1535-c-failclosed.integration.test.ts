/**
 * GATE PR1535 (c): FAIL-CLOSED. The scope read is made to fail four ways (table dropped, the app role locked
 * out and its connections killed, a lock that never releases inside the client's patience, SELECT revoked on
 * a revoke of an in-memory key). Every outcome must be "no allow": 5xx (or a hang the client abandons) and
 * nothing minted or revoked. The table is restored from the migration file itself at the end.
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import crypto from 'crypto';
import fs from 'fs';
import type { Server } from 'http';
import type { AddressInfo } from 'net';
import { Pool } from 'pg';

process.env.SECURITY_DISABLE_BOOT = '1';
const T = 'a0000000-0000-4000-8000-0000000fc535';
const A1 = 'abcdef00-1535-4535-8535-0000000000c1';
const A2 = 'abcdef00-1535-4535-8535-0000000000c2';
const NAME = 'g1535c:';
const U = crypto.randomUUID();
const MIGRATION = process.env.GATE_MIGRATION_049 as string;
const LEDGER = process.env.GATE_LEDGER as string;
const ledger: Record<string, unknown> = {};
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const PRIVATE_PEM = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
const b64url = (b: Buffer): string => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
function token(claims: Record<string, unknown>): string {
  const h = b64url(Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const now = Math.floor(Date.now() / 1000);
  const p = b64url(Buffer.from(JSON.stringify({ iat: now, exp: now + 600, ...claims })));
  return `${h}.${p}.${b64url(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), PRIVATE_PEM))}`;
}
const ADMIN = () => token({ role: 'ADMIN', tenantId: T, userId: U });
const PLATFORM = () => token({ role: 'super_admin', userId: crypto.randomUUID() });
let server: Server; let base: string; let su: Pool; let db: typeof import('../db');

async function mint(tok: string, organizationId?: string, timeoutMs = 15000): Promise<{ status: number | string; id?: string }> {
  const ac = new AbortController(); const t = setTimeout(() => ac.abort(), timeoutMs);
  try {
    const r = await fetch(`${base}/api/keys`, { method: 'POST', signal: ac.signal, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` },
      body: JSON.stringify({ name: `${NAME}${crypto.randomUUID().slice(0, 6)}`, scopes: ['documents:read'], tenantId: T, ...(organizationId ? { organizationId } : {}) }) });
    const j = await r.json().catch(() => ({})) as any; return { status: r.status, id: j?.data?.id };
  } catch (e: any) { return { status: e?.name === 'AbortError' ? 'ABORTED' : `ERR:${e?.message}` }; } finally { clearTimeout(t); }
}
async function revoke(tok: string, id: string, timeoutMs = 15000): Promise<number | string> {
  const ac = new AbortController(); const t = setTimeout(() => ac.abort(), timeoutMs);
  try { const r = await fetch(`${base}/api/keys/${id}`, { method: 'DELETE', signal: ac.signal, headers: { Authorization: `Bearer ${tok}` } }); await r.text(); return r.status; }
  catch (e: any) { return e?.name === 'AbortError' ? 'ABORTED' : `ERR:${e?.message}`; } finally { clearTimeout(t); }
}
const count = async () => (await su.query('SELECT count(*)::int n FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`])).rows[0].n as number;
const active = async (id: string) => (await su.query('SELECT is_active FROM svc_api_keys WHERE id=$1', [id])).rows[0]?.is_active;
const seed = () => su.query(`INSERT INTO admin_organisation_scopes (tenant_id,user_id,organization_id,granted_by) VALUES ($1,$2,$3,'g') ON CONFLICT DO NOTHING`, [T, U, A1]);

beforeAll(async () => {
  su = new Pool({ connectionString: process.env.TEST_DATABASE_URL, max: 3 });
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  await seed();
  process.env.DATABASE_URL = process.env.TEST_APP_DATABASE_URL;
  process.env.JWT_PUBLIC_KEY = Buffer.from(publicKey.export({ type: 'spki', format: 'pem' }).toString(), 'utf8').toString('base64');
  delete process.env.JWT_JWKS_URL; delete process.env.AUTH_SERVICE_URL;
  db = await import('../db');
  if (!(await db.initDb())) throw new Error('no db');
  const app = (await import('../index')).default;
  await new Promise<void>((r) => { server = app.listen(0, '127.0.0.1', r); });
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
afterAll(async () => {
  if (LEDGER) fs.writeFileSync(LEDGER, JSON.stringify(ledger, null, 1));
  await su.query('ALTER ROLE secuura_app CONNECTION LIMIT -1').catch(() => undefined);
  await su.query(fs.readFileSync(MIGRATION, 'utf8')).catch(() => undefined);
  await su.query('GRANT SELECT, INSERT, UPDATE, DELETE ON admin_organisation_scopes TO secuura_app').catch(() => undefined);
  if (server) await new Promise<void>((r) => server.close(() => r()));
  await su.query('DELETE FROM svc_api_keys WHERE name LIKE $1', [`${NAME}%`]);
  await su.query('DELETE FROM admin_organisation_scopes WHERE user_id=$1', [U]);
  await su.end(); await db.closeDb();
});

describe('GATE-C fail-closed', () => {
  it('CONTROL: healthy, the scoped ADMIN mints A1 (201) and is refused A2 (403)', async () => {
    const a = await mint(ADMIN(), A1); const b = await mint(ADMIN(), A2);
    ledger.control = [a.status, b.status]; expect([a.status, b.status]).toEqual([201, 403]);
  });

  it('TABLE DROPPED: mint naming A1 is 5xx, nothing minted; revoke of an A1 key is 5xx, key active; unqualified mint unaffected', async () => {
    const k = (await mint(PLATFORM(), A1)).id as string;
    const before = await count();
    await su.query('DROP TABLE admin_organisation_scopes');
    try {
      const m = await mint(ADMIN(), A1);
      const after = await count();
      const r = await revoke(ADMIN(), k);
      const u = await mint(ADMIN());
      ledger.dropped = { mint: m.status, minted: after - before, revoke: r, keyActive: await active(k), unqualified: u.status };
      expect(typeof m.status === 'number' && m.status >= 500).toBe(true);
      expect(after).toBe(before);
      expect(typeof r === 'number' && r >= 500).toBe(true);
      expect(await active(k)).toBe(true);
      expect(u.status).toBe(201);
    } finally {
      await su.query(fs.readFileSync(MIGRATION, 'utf8'));
      await seed();
    }
  });

  it('DATABASE UNREACHABLE for the app role (connection limit 0, its backends terminated): mint A1 never 201, revoke never 200', async () => {
    const k = (await mint(PLATFORM(), A1)).id as string;
    const before = await count();
    await su.query('ALTER ROLE secuura_app CONNECTION LIMIT 0');
    await su.query("SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE usename='secuura_app'");
    await new Promise((r) => setTimeout(r, 300));
    let m: any; let r: any;
    try {
      m = await mint(ADMIN(), A1);
      r = await revoke(ADMIN(), k);
    } finally {
      await su.query('ALTER ROLE secuura_app CONNECTION LIMIT -1');
    }
    ledger.unreachable = { mint: m.status, revoke: r, minted: (await count()) - before, keyActive: await active(k), dbAvailableAfter: db.isDbAvailable() };
    expect(m.status).not.toBe(201);
    expect(typeof m.status === 'number' && m.status >= 500).toBe(true);
    expect(r).not.toBe(200);
    expect(await count()).toBe(before);
    expect(await active(k)).toBe(true);
  });

  it('A LOCK that outlasts the client (ACCESS EXCLUSIVE held 4s, client gives up at 2s): no allow before release; after release the in-flight A2 mint is refused', async () => {
    const before = await count();
    const c = await su.connect();
    await c.query('BEGIN'); await c.query('LOCK TABLE admin_organisation_scopes IN ACCESS EXCLUSIVE MODE');
    const p = mint(ADMIN(), A2, 2000);
    const q = mint(ADMIN(), A1, 2000);
    const [pa, qa] = await Promise.all([p, q]);
    const during = (await count()) - before;
    await new Promise((r) => setTimeout(r, 2000));
    await c.query('ROLLBACK'); c.release();
    await new Promise((r) => setTimeout(r, 1500));
    const after = (await count()) - before;
    ledger.lock = { a2: pa.status, a1: qa.status, mintedWhileLocked: during, mintedAfterRelease: after };
    expect(pa.status).toBe('ABORTED'); expect(qa.status).toBe('ABORTED');
    expect(during).toBe(0);
    // After release the server finishes both: A2 refused (nothing), A1 legitimately minted (1).
    expect(after).toBe(1);
  });

  it('SELECT revoked: revoke of a key that the service holds IN MEMORY (minted by this process) is 5xx and the key stays active in both stores', async () => {
    const id = (await mint(PLATFORM(), A1)).id as string;
    await su.query('REVOKE SELECT ON admin_organisation_scopes FROM secuura_app');
    let r: any;
    try { r = await revoke(ADMIN(), id); } finally { await su.query('GRANT SELECT ON admin_organisation_scopes TO secuura_app'); }
    ledger.revokedSelect = { revoke: r, dbActive: await active(id) };
    expect(typeof r === 'number' && r >= 500).toBe(true);
    expect(await active(id)).toBe(true);
  });
});
