
// ===== GATE C probe (not part of any PR): 3 tenants, the MIDDLE one throws; the loop must continue.
import { writeFileSync as __gateWrite } from 'fs';
const gateMockDb = jest.requireMock('../db') as { getTenantManager: () => unknown };
const gateShared = jest.requireMock('@secuura/shared') as { queryWithTenantGuc: jest.Mock };
const GATE_CTX = 'Admin config tenant step failed (POST /api/admin/migrate-tenant-data)';
const TENANTS = [
  { id: 'a0000000-0000-4000-8000-00000000000a', slug: 'gate-a', db_name: 'a' },
  { id: 'a0000000-0000-4000-8000-00000000000b', slug: 'gate-b', db_name: 'b' },
  { id: 'a0000000-0000-4000-8000-00000000000c', slug: 'gate-c', db_name: 'c' },
];
class GateThing { secretField = 'SECRET-VALUE-gate-3'; }
const nullProto = Object.create(null) as Record<string, unknown>; nullProto.password = 'SECRET-VALUE-gate-4';
const VARIANTS: Array<[string, () => unknown, string]> = [
  ['Error', () => new Error('gate err msg'), 'gate err msg'],
  ['TypeError', () => new TypeError('gate type err'), 'gate type err'],
  ['string', () => 'gate thrown string', 'gate thrown string'],
  ['plain object', () => ({ code: 'ECONNREFUSED', connectionString: 'postgres://u:SECRET-VALUE-gate-1@h/db' }), 'thrown Object with fields [code, connectionString]'],
  ['empty object', () => ({}), 'thrown Object with fields []'],
  ['array', () => ['SECRET-VALUE-gate-2'], 'thrown Array with fields [0]'],
  ['class instance', () => new GateThing(), 'thrown GateThing with fields [secretField]'],
  ['null-proto object', () => nullProto, 'thrown object with fields [password]'],
  ['null', () => null, 'thrown object'],
  ['undefined', () => undefined, 'thrown undefined'],
  ['number', () => 42, 'thrown number'],
];
const outcomes: Record<string, unknown> = {};
afterAll(() => { if (process.env.GATE_PROBE_OUT) __gateWrite(process.env.GATE_PROBE_OUT, JSON.stringify(outcomes, null, 1)); });

describe('GATE C probe KS-1462: middle tenant throws, loop continues, describer shape', () => {
  afterEach(() => { gateMockDb.getTenantManager = () => null; gateShared.queryWithTenantGuc.mockReset(); });
  for (const [label, make, expected] of VARIANTS) {
    it('probe ' + label, async () => {
      process.env.NODE_ENV = 'development';
      mockLoggerError.mockClear();
      gateShared.queryWithTenantGuc.mockResolvedValue({ rows: [] });
      const pool = { query: jest.fn().mockResolvedValue({ rows: [] }) };
      const getPoolCalls: string[] = [];
      gateMockDb.getTenantManager = () => ({
        getPlatformPool: () => ({ query: jest.fn().mockResolvedValue({ rows: TENANTS }) }),
        getDefaultPool: () => ({}),
        getPool: (id: string) => { getPoolCalls.push(id); if (id === TENANTS[1].id) throw make(); return pool; },
      });
      const res = await fetch(baseUrl + '/api/admin/migrate-tenant-data', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
      const body = await res.json();
      outcomes[label] = { status: res.status, body, getPoolCalls, logs: mockLoggerError.mock.calls };
      expect(res.status).toBe(200);
      expect(getPoolCalls).toEqual(TENANTS.map((t) => t.id));
      expect(body.success).toBe(true);
      expect(body.results.map((r: { tenant: string; error?: string }) => [r.tenant, r.error ?? null])).toEqual([
        ['gate-a', null], ['gate-b', 'TENANT_COPY_FAILED'], ['gate-c', null],
      ]);
      expect(body.results[0]).toEqual(body.results[2] && { ...body.results[2], tenant: 'gate-a' });
      expect(JSON.stringify(mockLoggerError.mock.calls)).not.toContain('SECRET-VALUE');
      expect(mockLoggerError.mock.calls).toEqual([[GATE_CTX, { tenant: 'gate-b', error: expected }]]);
    });
  }
});

void readFileSync; void path; void LEAK; void NODE_ENVS; void CONSTANT_BODY;
