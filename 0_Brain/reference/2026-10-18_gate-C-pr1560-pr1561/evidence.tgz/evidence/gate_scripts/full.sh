#!/bin/bash
set -u
source /private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/scripts/common.sh
R=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/runs-$(date +%s)
mkdir -p $R
OTS=$R/tsconfig.originate-tests.json
cat > $OTS <<JSON
{ "extends": "$O/tsconfig.json", "compilerOptions": { "noEmit": true }, "include": ["$O/src/**/*"], "exclude": ["$O/node_modules", "$O/dist"] }
JSON
echo "tsc: $($TSC --version)  runs dir: $R"
for state in DEVELOP HEAD; do
  if [ $state = DEVELOP ]; then reset_dev; else apply_head; fi
  echo "################ STATE $state  (V=$(git -C $W rev-parse --short HEAD:$V) wt-V=$(git -C $W hash-object $W/$V | cut -c1-9) A-wt=$(git -C $W hash-object $W/$A | cut -c1-9) T2 present=$([ -e $W/$T2 ] && echo y || echo n))"
  echo "=== api-gateway full vitest"
  vgw > $R/gw_$state.txt; echo "rc=$?"; grep -E "Test Files|Tests  |FAIL" $R/gw_$state.txt | sort -u | head -30
  echo "=== api-gateway tsc -p tsconfig.test.json"
  $TSC -p $G/tsconfig.test.json --noEmit > $R/tscgw_$state.txt 2>&1; echo "rc=$? errors=$(grep -c 'error TS' $R/tscgw_$state.txt)"; head -5 $R/tscgw_$state.txt
  echo "program includes ks1543 files: $($TSC -p $G/tsconfig.test.json --listFilesOnly | grep -c 'ks1543-')"
  echo "=== api-gateway tsc -p tsconfig.json (build program)"
  $TSC -p $G/tsconfig.json --noEmit > $R/tscgwb_$state.txt 2>&1; echo "rc=$? errors=$(grep -c 'error TS' $R/tscgwb_$state.txt)"
  echo "=== originate full jest"
  jo > $R/or_$state.txt; echo "rc=$?"; grep -E "^Tests:|^Test Suites:|^FAIL" $R/or_$state.txt | head -30
  echo "=== originate tsc incl tests (scratch tsconfig)"
  $TSC -p $OTS > $R/tscor_$state.txt 2>&1; echo "rc=$? errors=$(grep -c 'error TS' $R/tscor_$state.txt)"; head -5 $R/tscor_$state.txt
  echo "program includes ks730c: $($TSC -p $OTS --listFilesOnly | grep -c 'ks730c-adminconfig')"
  echo "=== eslint verification.ts (+ planted control)"
  node $(dirname $0)/lint.js $D $W/$V
  echo "=== eslint adminConfig.ts"
  node $(dirname $0)/lint.js $D $W/$A | head -12
done
echo "################ PLANTED tsc controls at HEAD"
printf '\nconst __gatePlanted: number = "not a number"; void __gatePlanted;\n' >> $W/$T2
$TSC -p $G/tsconfig.test.json --noEmit > $R/tsc_planted_gw.txt 2>&1; echo "gw rc=$? errors=$(grep -c 'error TS' $R/tsc_planted_gw.txt)"; grep ks1543 $R/tsc_planted_gw.txt
git -C $W checkout pr/1560 -- $T2; git -C $W reset -q -- $T2
printf '\nconst __gatePlanted: number = "not a number"; void __gatePlanted;\n' >> $W/$T3
$TSC -p $OTS > $R/tsc_planted_or.txt 2>&1; echo "originate rc=$? errors=$(grep -c 'error TS' $R/tsc_planted_or.txt)"; grep ks730c $R/tsc_planted_or.txt
git -C $W checkout pr/1561 -- $T3; git -C $W reset -q -- $T3
echo "post-control: T2==pr $([ "$(git -C $W hash-object $W/$T2)" = "$(git -C $W rev-parse pr/1560:$T2)" ] && echo y) T3==pr $(git -C $W diff --quiet pr/1561 -- $T3 && echo y)"
mkdir -p $EV/runs; cp $R/*.txt $R/*.json $EV/runs/
