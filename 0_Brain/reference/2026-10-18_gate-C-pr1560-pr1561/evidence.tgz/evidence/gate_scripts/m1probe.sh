#!/bin/bash
set -u
source /private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/scripts/common.sh
SC=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/scripts
P1=$G/src/__tests__/gate-probe-1560.test.ts
for id in M1a_drain_removed M1b_listener_throws M1c_listener_pauses M1z_comment_only; do
  apply_head; cp $SC/gate-probe-1560.test.ts $P1
  echo "================ $id against the gate drain probe (P1 4 MB, P2 chunked)"
  python3 -I $SC/mutate.py $W/$V $SC/mutants.json $id || continue
  $VT run --root $G $P1 -t 'drain listener' --reporter=verbose 2>&1 | grep -E "✓|×|↓|Tests  |AssertionError|gate-mutant|Unhandled Errors|Test timed out" | sort | uniq -c | cut -c1-220
  mv $P1 $S_PARK/gate-probe-1560.$(date +%s%N).ts
done
apply_head
echo "product == heads: V $(git -C $W diff --quiet pr/1560 -- $V && echo y)"
