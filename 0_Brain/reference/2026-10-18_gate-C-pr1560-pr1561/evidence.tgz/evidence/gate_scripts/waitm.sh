#!/bin/bash
F=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-C-pr1560-pr1561/evidence/mutants.txt
for i in $(seq 1 110); do
  grep -q "^final worktree" $F && { echo DONE; exit 0; }
  sleep 5
done
echo "STILL RUNNING: $(grep -c '^================' $F) mutants started"
