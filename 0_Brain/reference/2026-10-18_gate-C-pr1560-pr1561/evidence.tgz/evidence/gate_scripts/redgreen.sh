#!/bin/bash
set -u
source /private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/scripts/common.sh
git -C $W log -1 --format='worktree base %H'
echo "######## RED #1560: PR tests, develop verification.ts"
apply_head
git -C $W checkout origin/develop -- $V; git -C $W reset -q -- $V
echo "verification.ts == develop: $(git -C $W diff --quiet origin/develop -- $V && echo yes)"
vgw $W/$T1 $W/$T2 --reporter=verbose
echo "######## GREEN #1560: PR tests, PR verification.ts"
apply_head
echo "verification.ts == pr/1560: $(git -C $W diff --quiet pr/1560 -- $V && echo yes)"
vgw $W/$T1 $W/$T2 --reporter=verbose
echo "######## RED #1561: PR test, develop adminConfig.ts"
git -C $W checkout origin/develop -- $A; git -C $W reset -q -- $A
echo "adminConfig.ts == develop: $(git -C $W diff --quiet origin/develop -- $A && echo yes)"
jo $W/$T3 --verbose
echo "######## GREEN #1561: PR test, PR adminConfig.ts"
apply_head
echo "adminConfig.ts == pr/1561: $(git -C $W diff --quiet pr/1561 -- $A && echo yes)"
jo $W/$T3 --verbose
