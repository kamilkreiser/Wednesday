#!/bin/bash
set -u
C=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/gateC-clone-1792310931
W=$C-wt
git -C $C worktree add --detach $W origin/develop -q || exit 1
git -C $W log -1 --format='worktree %H'
echo "== files changed on develop since base that either PR touches:"
git -C $C diff --name-only 76698952a d0c5d2e0e > $W.devmoved.txt; wc -l < $W.devmoved.txt
git -C $C diff --name-only 76698952a...pr/1560 > $W.f1560.txt
git -C $C diff --name-only 76698952a...pr/1561 > $W.f1561.txt
cat $W.f1560.txt $W.f1561.txt | sort > $W.fall.txt
echo "overlap develop-moved vs PR files: $(sort $W.devmoved.txt | comm -12 - $W.fall.txt | wc -l)"
echo "overlap 1560 vs 1561: $(sort $W.f1560.txt | comm -12 - <(sort $W.f1561.txt) | wc -l)"
echo "control develop vs itself: $(sort $W.devmoved.txt | comm -12 - <(sort $W.devmoved.txt) | wc -l)"
time npm --prefix $W/Blockchain/Dev ci --no-audit --no-fund --ignore-scripts 2>&1 | tail -4
npm --prefix $W/Blockchain/Dev run build -w packages/shared 2>&1 | tail -3
ls $W/Blockchain/Dev/packages/shared/dist | head -3
ls $W/Blockchain/Dev/services/api-gateway/node_modules $W/Blockchain/Dev/services/originate/node_modules 2>&1 | head
