// usage: node lint.js <DevDir> <file>  -- lints the real file, then the same text with a planted unused var
const [, , DEV, FILE] = process.argv;
const fs = require('fs');
const { ESLint } = require(DEV + '/node_modules/eslint');
(async () => {
  const eslint = new ESLint({ cwd: DEV });
  const cfg = await eslint.calculateConfigForFile(FILE);
  console.log('config applies to file:', !!cfg, 'rules count:', cfg ? Object.keys(cfg.rules || {}).length : 0);
  const [r] = await eslint.lintFiles([FILE]);
  console.log('REAL FILE errors=' + r.errorCount + ' warnings=' + r.warningCount);
  for (const m of r.messages) console.log('  ' + m.line + ':' + m.column + ' ' + m.ruleId + ' ' + m.message);
  const src = fs.readFileSync(FILE, 'utf8');
  const planted = src + '\nexport function __gatePlanted(): void {\n  const __unusedGate = 1;\n  try { void 0; } catch (err) { return; }\n}\n';
  const [p] = await eslint.lintText(planted, { filePath: FILE });
  console.log('PLANTED CONTROL errors=' + p.errorCount + ' warnings=' + p.warningCount);
  for (const m of p.messages) console.log('  ' + m.line + ':' + m.column + ' ' + m.ruleId + ' ' + m.message);
})().catch((e) => { console.error(e); process.exit(2); });
