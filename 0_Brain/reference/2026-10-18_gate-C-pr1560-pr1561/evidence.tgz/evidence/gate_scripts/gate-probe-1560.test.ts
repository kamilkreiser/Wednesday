// GATE C probe (not part of any PR). Copied into the gate's own worktree only.
import { describe, it, expect, beforeAll, afterAll, afterEach, vi } from 'vitest';
import express from 'express';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { writeFileSync } from 'node:fs';
import * as verification from '../routes/verification';

const DOC_ID = 'doc-gate';
const WFI_ID = 'wfi-gate';
type Behaviour = (req: IncomingMessage, res: ServerResponse) => void;
let behave: Behaviour = (_req, res) => res.end();
let originate: http.Server;
let originatePort = 0;
let finishes = 0;
const outcomes: Record<string, unknown> = {};
const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

beforeAll(async () => {
  originate = http.createServer((req, res) => { req.resume(); res.on('finish', () => { finishes++; }); behave(req, res); });
  originate.listen(0, '127.0.0.1');
  await new Promise<void>((r) => originate.once('listening', () => r()));
  originatePort = (originate.address() as AddressInfo).port;
});
afterAll(async () => {
  originate.closeAllConnections();
  await new Promise<void>((r) => originate.close(() => r()));
  if (process.env.GATE_PROBE_OUT) writeFileSync(process.env.GATE_PROBE_OUT, JSON.stringify(outcomes, null, 1));
});
const open: http.Server[] = [];
afterEach(async () => { for (const s of open.splice(0)) { s.closeAllConnections(); await new Promise<void>((r) => s.close(() => r())); } });

async function gateway(log: (...a: unknown[]) => void, redis: Record<string, unknown>): Promise<number> {
  const app = express();
  app.use(verification.createVerificationRoutes({
    authenticateToken: () => (_req, _res, next) => next(),
    mockBodyParser: express.json({ limit: '1mb' }),
    query: vi.fn(async () => ({ rows: [] })) as never,
    isDbAvailable: () => false,
    redisService: redis as never,
    services: { originate: { url: `http://127.0.0.1:${originatePort}` }, anchoring: { url: '' } } as never,
    log: log as never,
    memWorkflowToDocumentMap: new Map(),
    memRejectedDocuments: new Map(),
    dbSaveRejection: vi.fn(async () => undefined),
    ADMIN_ROLES: ['ADMIN'],
    enforceDocumentTypeRules: vi.fn(async () => ({ ok: true, docType: {} })) as never,
    createWorkflowInstanceIfRequired: vi.fn(async () => ({ gated: false })) as never,
    meetsVerificationLevel: () => true,
    originateForwardTimeoutMs: 1_000,
  }));
  const s = app.listen(0, '127.0.0.1');
  open.push(s);
  await new Promise<void>((r) => s.once('listening', () => r()));
  return (s.address() as AddressInfo).port;
}

function wfRedis() {
  let instance: Record<string, unknown> = { status: 'pending_approval', documentId: DOC_ID, steps: [{ name: 'Approve' }], currentStepIndex: 0 };
  const store = { deletes: 0 };
  return { store, redis: {
    getWorkflowInstance: vi.fn(async (id: string) => (id === WFI_ID ? structuredClone(instance) : null)),
    getAllWorkflowInstances: vi.fn(async () => [structuredClone(instance)]),
    setWorkflowInstance: vi.fn(async (_id: string, v: Record<string, unknown>) => { instance = structuredClone(v); }),
    getPendingDocument: vi.fn(async () => ({ title: 't', contentHash: 'h', createdBy: 'u' })),
    deletePendingDocument: vi.fn(async () => { store.deletes++; }),
  } };
}

describe('GATE C probe KS-1543 part 2: the drain listener', () => {
  it('P1 a 4 MB originate reply: route 200, pending deleted, reply fully drained (end logged, originate finish)', { timeout: 15_000 }, async () => {
    const big = 'x'.repeat(4 * 1024 * 1024);
    behave = (_req, res) => { res.writeHead(201, { 'Content-Type': 'application/json' }); res.end(big); };
    const log = vi.fn();
    const { store, redis } = wfRedis();
    const f0 = finishes;
    const t0 = Date.now();
    const r = await fetch(`http://127.0.0.1:${await gateway(log, redis)}/api/workflow-instances/${WFI_ID}/approve`, { method: 'POST' });
    const text = await r.text();
    const ms = Date.now() - t0;
    await sleep(1_500);
    const msgs = log.mock.calls.map((c) => c[1]);
    const body = JSON.parse(text);
    outcomes.P1 = { status: r.status, keys: Object.keys(body).sort(), success: body.success, statusField: body.status, deletes: store.deletes, finishes: finishes - f0, msgs, answeredUnder1s: ms < 1000 };
    expect(r.status).toBe(200);
    expect(store.deletes).toBe(1);
    expect(finishes - f0).toBe(1);
    expect(msgs).toContain('Workflow approved — document forwarded to originate');
  });

  it('P2 a slow chunked 201 reply: the route answers on the status line, BEFORE the body ends; end is logged after', { timeout: 15_000 }, async () => {
    behave = (_req, res) => {
      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.write('{"id":');
      setTimeout(() => res.write('"x"'), 300);
      setTimeout(() => res.end('}'), 600);
    };
    const log = vi.fn();
    const { store, redis } = wfRedis();
    const t0 = Date.now();
    const r = await fetch(`http://127.0.0.1:${await gateway(log, redis)}/api/workflow-instances/${WFI_ID}/approve`, { method: 'POST' });
    await r.text();
    const ms = Date.now() - t0;
    const endLoggedAtAnswer = log.mock.calls.some((c) => c[1] === 'Workflow approved — document forwarded to originate');
    await sleep(1_000);
    const endLoggedLater = log.mock.calls.some((c) => c[1] === 'Workflow approved — document forwarded to originate');
    outcomes.P2 = { status: r.status, answeredBeforeBodyEnd: ms < 550, endLoggedAtAnswer, endLoggedLater, deletes: store.deletes, errors: log.mock.calls.filter((c) => c[0] === 'error').length };
    expect(r.status).toBe(200);
    expect(ms).toBeLessThan(550);
    expect(endLoggedAtAnswer).toBe(false);
    expect(endLoggedLater).toBe(true);
  });
});

describe('GATE C probe KS-1543 part 3: what the document-types log line carries', () => {
  const SECRET = 'SECRET-gate-token-abc123';
  const CONSTANT = { success: false, error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch document types' } };
  for (const [label, thrown] of [['Error', new Error('redis down')], ['string', 'boom'], ['plain object', { code: 'X', detail: 'SECRET-gate-in-thrown-object' }], ['null', null]] as Array<[string, unknown]>) {
    it('P3 thrown ' + label + ': 500 constant body; log meta has only {error}; no request data in the log', async () => {
      const log = vi.fn();
      const port = await gateway(log, { getAllDocumentTypes: vi.fn(async () => { throw thrown; }) });
      const r = await fetch(`http://127.0.0.1:${port}/api/document-types?token=${SECRET}`, { headers: { authorization: 'Bearer ' + SECRET, cookie: 'sid=' + SECRET } });
      const body = await r.json();
      outcomes['P3 ' + label] = { status: r.status, body, logs: log.mock.calls, headers: { ct: r.headers.get('content-type') } };
      expect(r.status).toBe(500);
      expect(body).toEqual(CONSTANT);
      expect(JSON.stringify(log.mock.calls)).not.toContain(SECRET);
      const errs = log.mock.calls.filter((c) => c[0] === 'error');
      expect(errs.length).toBe(1);
      expect(Object.keys(errs[0][2] as object)).toEqual(['error']);
    });
  }
});
