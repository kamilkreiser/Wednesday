C=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/gateC-clone-1792310931
W=$C-wt
D=$W/Blockchain/Dev
G=$D/services/api-gateway
O=$D/services/originate
VT=$D/node_modules/.bin/vitest
JEST=$D/node_modules/.bin/jest
TSC=$D/node_modules/.bin/tsc
ESL=$D/node_modules/.bin/eslint
V=Blockchain/Dev/services/api-gateway/src/routes/verification.ts
T1=Blockchain/Dev/services/api-gateway/src/__tests__/ks1543-five-pre-existing-eslint-warnings-in.test.ts
T2=Blockchain/Dev/services/api-gateway/src/__tests__/ks1543-document-types-catch-logs-the-error.test.ts
A=Blockchain/Dev/services/originate/src/routes/adminConfig.ts
T3=Blockchain/Dev/services/originate/src/__tests__/ks730c-adminconfig-500-never-answers-err-message.test.ts
EV=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-18_gate-C-pr1560-pr1561/evidence
S_PARK=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/parked
mkdir -p $S_PARK
reset_dev() {
  git -C $W checkout origin/develop -- $V $T1 $A $T3
  git -C $W reset -q -- $T2 2>/dev/null
  [ -e $W/$T2 ] && mv $W/$T2 $S_PARK/ks1543-doc-types.$(date +%s%N).ts
  echo "reset_dev porcelain: [$(git -C $W status --porcelain -- Blockchain/Dev/services | tr '\n' ' ')]"
}
apply_head() {
  git -C $W checkout pr/1560 -- $V $T1 $T2
  git -C $W checkout pr/1561 -- $A $T3
  git -C $W reset -q -- $V $T1 $T2 $A $T3
}
vgw() { $VT run --root $G "$@" 2>&1; }
jo() { $JEST --config $O/jest.config.js --rootDir $O "$@" 2>&1; }
