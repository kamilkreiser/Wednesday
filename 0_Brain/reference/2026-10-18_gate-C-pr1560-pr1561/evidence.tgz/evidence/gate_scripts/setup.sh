#!/bin/bash
set -u
S=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad
C=$S/gateC-clone-$(date +%s)
SSHC='ssh -i "/Volumes/DevMASTER/!CODING/Secuura/Blockchain/3_Access_Keys/github_deploy_rw" -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new -o ServerAliveInterval=30'
git clone --shared --no-checkout "/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files" "$C" || exit 1
git -C "$C" remote set-url origin git@github.com:Secuura/Distributed_Secuura.git
git -C "$C" config core.sshCommand "$SSHC"
git -C "$C" fetch origin develop '+refs/pull/1560/head:refs/remotes/pr/1560' '+refs/pull/1561/head:refs/remotes/pr/1561' '+refs/heads/develop:refs/remotes/origin/develop' 2>&1 | tail -5
echo CLONE=$C
git -C "$C" rev-parse origin/develop pr/1560 pr/1561
