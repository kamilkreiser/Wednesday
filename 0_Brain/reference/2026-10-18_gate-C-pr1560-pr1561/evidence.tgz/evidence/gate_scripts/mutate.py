import sys, json
# usage: mutate.py <file> <mutants.json> <id>
path, spec, mid = sys.argv[1], sys.argv[2], sys.argv[3]
m = json.load(open(spec))[mid]
src = open(path, encoding='utf-8').read()
for o, n in [(m['old'], m['new'])] + ([(m['old2'], m['new2'])] if 'old2' in m else []):
    c = src.count(o)
    if c != 1:
        print('MUTANT-NOT-APPLIED count=%d' % c); sys.exit(3)
    src = src.replace(o, n)
open(path, 'w', encoding='utf-8').write(src)
print('applied ' + mid)
