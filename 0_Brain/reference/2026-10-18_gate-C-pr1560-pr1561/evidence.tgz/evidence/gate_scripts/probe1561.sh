#!/bin/bash
set -u
source /private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/scripts/common.sh
SC=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/scripts
R=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/probes1561-$(date +%s)
mkdir -p $R
P2=$O/src/__tests__/gate-probe-1561.test.ts
apply_head
{ sed -n 1,86p $W/$T3; cat $SC/probe1561_body.ts; } > $P2
for state in DEVELOP HEAD; do
  apply_head
  if [ $state = DEVELOP ]; then git -C $W checkout origin/develop -- $A; git -C $W reset -q -- $A; fi
  echo "################ PRODUCT=$state  A=$(git -C $W hash-object $W/$A | cut -c1-9)"
  GATE_PROBE_OUT=$R/p1561_$state.json $JEST --config $O/jest.config.js --rootDir $O $P2 --verbose > $R/jest_$state.txt 2>&1
  grep -E "✓|✕|^Tests:|Expected|Received|^\s+[-+] |error TS|Cannot|●" $R/jest_$state.txt | head -60
done
echo "################ outcome diff DEVELOP vs HEAD (1561 probe)"
diff $R/p1561_DEVELOP.json $R/p1561_HEAD.json
apply_head
mv $P2 $S_PARK/gate-probe-1561.$(date +%s).ts
mkdir -p $EV/probes; cp $R/* $EV/probes/
