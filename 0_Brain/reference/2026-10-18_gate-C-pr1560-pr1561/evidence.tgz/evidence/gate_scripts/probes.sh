#!/bin/bash
set -u
source /private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/scripts/common.sh
SC=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/scripts
R=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/probes-$(date +%s)
mkdir -p $R
P1=$G/src/__tests__/gate-probe-1560.test.ts
P2=$O/src/__tests__/gate-probe-1561.test.ts
cp $SC/gate-probe-1560.test.ts $P1
{ sed -n 1,86p $W/$T3; cat $SC/probe1561_body.ts; } > $P2
for state in DEVELOP HEAD; do
  apply_head
  if [ $state = DEVELOP ]; then git -C $W checkout origin/develop -- $V $A; git -C $W reset -q -- $V $A; fi
  echo "################ PRODUCT=$state  V=$(git -C $W hash-object $W/$V | cut -c1-9) A=$(git -C $W hash-object $W/$A | cut -c1-9)"
  GATE_PROBE_OUT=$R/p1560_$state.json $VT run --root $G $P1 --reporter=verbose 2>&1 | grep -E "✓|×|Tests  |AssertionError|^\s+[-+] " | head -40
  GATE_PROBE_OUT=$R/p1561_$state.json $JEST --config $O/jest.config.js --rootDir $O $P2 --verbose 2>&1 | grep -E "✓|✕|^Tests:|Expected|Received|^\s+[-+] " | head -60
done
echo "################ outcome diff DEVELOP vs HEAD (1560 probe)"
diff $R/p1560_DEVELOP.json $R/p1560_HEAD.json
echo "################ outcome diff DEVELOP vs HEAD (1561 probe)"
diff $R/p1561_DEVELOP.json $R/p1561_HEAD.json
apply_head
mv $P1 $S_PARK/gate-probe-1560.$(date +%s).ts; mv $P2 $S_PARK/gate-probe-1561.$(date +%s).ts
mkdir -p $EV/probes; cp $R/*.json $EV/probes/; cp $SC/gate-probe-1560.test.ts $SC/probe1561_body.ts $EV/probes/
echo "worktree porcelain after: [$(git -C $W status --porcelain | tr '\n' ' ')]"
