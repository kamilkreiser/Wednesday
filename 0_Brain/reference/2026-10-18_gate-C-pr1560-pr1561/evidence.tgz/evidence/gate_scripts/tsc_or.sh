#!/bin/bash
set -u
source /private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/scripts/common.sh
R=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/runs-or-$(date +%s)
mkdir -p $R
OTS=$R/tsconfig.originate-tests.json
cat > $OTS <<JSON
{ "extends": "$O/tsconfig.json", "compilerOptions": { "noEmit": true, "types": ["jest", "node"], "typeRoots": ["$D/node_modules/@types"] }, "include": ["$O/src/**/*"], "exclude": ["$O/node_modules", "$O/dist"] }
JSON
for state in DEVELOP HEAD; do
  if [ $state = DEVELOP ]; then reset_dev; else apply_head; fi
  $TSC -p $OTS > $R/tscor_$state.txt 2>&1; echo "$state originate tsc incl tests rc=$? errors=$(grep -c 'error TS' $R/tscor_$state.txt) ks730c-in-program=$($TSC -p $OTS --listFilesOnly | grep -c ks730c-adminconfig)"
  grep -o 'src/[^(]*([0-9]*,[0-9]*): error TS[0-9]*' $R/tscor_$state.txt | sed -E 's/\(([0-9]+),[0-9]+\)/(L)/' | sort > $R/orerr_$state.sorted
  echo "  error files: $(grep -o 'src/[^(]*' $R/tscor_$state.txt | sort | uniq -c | tr '\n' ';')"
done
echo "error sets (line numbers normalised) identical: $(diff -q $R/orerr_DEVELOP.sorted $R/orerr_HEAD.sorted >/dev/null && echo yes || echo NO)"
diff $R/orerr_DEVELOP.sorted $R/orerr_HEAD.sorted | head
echo "ks730c errors at HEAD: $(grep -c ks730c $R/tscor_HEAD.txt)"
printf '\nconst __gatePlanted: number = "not a number"; void __gatePlanted;\n' >> $W/$T3
$TSC -p $OTS > $R/tsc_planted_or.txt 2>&1; echo "PLANTED originate rc=$? errors=$(grep -c 'error TS' $R/tsc_planted_or.txt)"; grep ks730c $R/tsc_planted_or.txt
git -C $W checkout pr/1561 -- $T3; git -C $W reset -q -- $T3
echo "T3 restored == pr: $(git -C $W diff --quiet pr/1561 -- $T3 && echo y)"
mkdir -p $EV/runs-or; cp $R/* $EV/runs-or/
