#!/bin/bash
set -u
source /private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/scripts/common.sh
SC=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/scripts
R=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/mutants-$(date +%s)
mkdir -p $R
P2=$O/src/__tests__/gate-probe-1561.test.ts
IDS=$(python3 -I -c "import json;print(' '.join(json.load(open('$SC/mutants.json'))))")
for id in $IDS; do
  f=$(python3 -I -c "import json;print(json.load(open('$SC/mutants.json'))['$id']['f'])")
  apply_head
  echo "================ $id  (file $f)"
  if [ "$f" = V ]; then
    python3 -I $SC/mutate.py $W/$V $SC/mutants.json $id || continue
    git -C $W diff --stat -- $V | tail -1
    $VT run --root $G --reporter=default --reporter=json --outputFile.json=$R/$id.json > $R/$id.out 2>&1; echo "  vitest rc=$?  unhandled-errors-lines=$(grep -ci 'unhandled' $R/$id.out)"
    python3 -I $SC/summ.py vitest $R/$id.json
    grep -iE "gate-mutant|Unhandled (error|rejection)" $R/$id.out | sort | uniq -c | head -4
    $TSC -p $G/tsconfig.json --noEmit > $R/$id.tsc 2>&1; echo "  tsc build-program rc=$? errors=$(grep -c 'error TS' $R/$id.tsc) $(grep 'error TS' $R/$id.tsc | head -2 | sed 's#.*/src/#src/#')"
    node $SC/lint.js $D $W/$V | grep -E "REAL FILE|^  [0-9]" | grep -v -E "^  (2|3)[0-9]{3}:" | head -4
  else
    { sed -n 1,86p $W/$T3; cat $SC/probe1561_body.ts; } > $P2
    python3 -I $SC/mutate.py $W/$A $SC/mutants.json $id || { mv $P2 $S_PARK/probe.$(date +%s%N).ts; continue; }
    git -C $W diff --stat -- $A | tail -1
    $JEST --config $O/jest.config.js --rootDir $O --json --outputFile=$R/$id.json > $R/$id.out 2>&1; echo "  jest (full originate suite + gate probe) rc=$?"
    python3 -I $SC/summ.py jest $R/$id.json
    mv $P2 $S_PARK/probe.$(date +%s%N).ts
  fi
done
apply_head
echo "final worktree product == heads: V $(git -C $W diff --quiet pr/1560 -- $V && echo y) A $(git -C $W diff --quiet pr/1561 -- $A && echo y)"
mkdir -p $EV/mutants; cp $R/*.json $EV/mutants/ 2>/dev/null; cp $SC/mutants.json $EV/mutants/_mutants_spec.json
