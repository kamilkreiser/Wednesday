#!/bin/bash
set -u
C=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/gateC-clone-1792310931
X=/private/tmp/claude-501/-Volumes-DevMASTER-WEDNESDAY/59f676bc-e3a9-4b9a-8b25-64e572c78937/scratchpad/merge-$(date +%s)
mkdir -p $X
V=Blockchain/Dev/services/api-gateway/src/routes/verification.ts
echo "=== live remote re-read $(date '+%Y-%m-%d %H:%M:%S %Z')"
git -C $C ls-remote origin refs/heads/develop refs/pull/1560/head refs/pull/1561/head
git -C $C fetch -q origin '+refs/heads/develop:refs/remotes/origin/develop'
DEV=$(git -C $C rev-parse origin/develop); echo "develop tip used: $DEV"
export GIT_AUTHOR_NAME=gate GIT_AUTHOR_EMAIL=gate@invalid GIT_COMMITTER_NAME=gate GIT_COMMITTER_EMAIL=gate@invalid
mt() { git -C $C merge-tree --write-tree --name-only "$1" "$2" > $X/mt.txt 2>&1; local rc=$?; echo "  merge-tree $3: rc=$rc tree=$(head -1 $X/mt.txt)"; sed -n '2,8p' $X/mt.txt | sed 's/^/    /'; return $rc; }
for p in 1560 1561; do
  echo "=== PR $p alone on $DEV"
  echo "  merge-base: $(git -C $C merge-base $DEV pr/$p)  develop commits since base: $(git -C $C rev-list --count $(git -C $C merge-base $DEV pr/$p)..$DEV)"
  git -C $C diff --name-only $(git -C $C merge-base $DEV pr/$p) $DEV | sort > $X/devmoved.txt
  git -C $C diff --name-only $(git -C $C merge-base $DEV pr/$p) pr/$p | sort > $X/pr$p.txt
  echo "  overlap PR files vs develop-moved files: $(comm -12 $X/devmoved.txt $X/pr$p.txt | wc -l | tr -d ' ')  (control: PR files vs themselves: $(comm -12 $X/pr$p.txt $X/pr$p.txt | wc -l | tr -d ' '))"
  mt $DEV pr/$p "develop+$p"
  T=$(head -1 $X/mt.txt); echo "  merged tree vs PR head, PR files identical: $(git -C $C diff --quiet pr/$p $T -- $(cat $X/pr$p.txt) && echo yes)"
  echo "  merged tree vs develop, only PR files differ: $(git -C $C diff --name-only $DEV $T | sort | diff -q - $X/pr$p.txt >/dev/null && echo yes)"
done
echo "=== overlap 1560 vs 1561: $(comm -12 $X/pr1560.txt $X/pr1561.txt | wc -l | tr -d ' ')"
for order in "1560 1561" "1561 1560"; do
  set -- $order
  mt $DEV pr/$1 "develop+$1"; T1=$(head -1 $X/mt.txt)
  K1=$(git -C $C commit-tree $T1 -p $DEV -p pr/$1 -m "gate sim merge $1")
  mt $K1 pr/$2 "(develop+$1)+$2"; T2=$(head -1 $X/mt.txt); echo "  final tree order $1->$2: $T2"
done
echo "=== PLANTED conflicting control: a develop-side commit editing verification.ts at the drain line"
git -C $C show $DEV:$V | sed "s#proxyRes.on('data', (chunk: string) => { body += chunk; });#proxyRes.on('data', (chunk: string) => { body += chunk; /* gate planted */ });#" > $X/v_planted.ts
echo "  planted blob differs from develop: $(git -C $C show $DEV:$V | diff -q - $X/v_planted.ts >/dev/null && echo NO || echo yes)"
B=$(git -C $C hash-object -w $X/v_planted.ts)
export GIT_INDEX_FILE=$X/index
git -C $C read-tree $DEV
git -C $C update-index --cacheinfo 100644,$B,$V
PT=$(git -C $C write-tree); unset GIT_INDEX_FILE
PC=$(git -C $C commit-tree $PT -p $DEV -m "gate planted conflict")
mt $PC pr/1560 "planted+1560 (expect CONFLICT)"
mt $PC pr/1561 "planted+1561 (expect clean: disjoint file)"
