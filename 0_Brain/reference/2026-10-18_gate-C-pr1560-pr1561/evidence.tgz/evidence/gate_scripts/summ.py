import sys, json
# usage: summ.py vitest|jest <json>
kind, p = sys.argv[1], sys.argv[2]
try:
    d = json.load(open(p))
except Exception as e:
    print('  NO-JSON ' + str(e)); sys.exit(0)
fails = []
for f in d.get('testResults', []):
    name = f.get('name', '').split('/src/')[-1]
    ar = f.get('assertionResults', [])
    bad = [a for a in ar if a.get('status') == 'failed']
    for a in bad:
        fails.append(name + ' :: ' + a.get('title', a.get('fullName', '')))
    if not ar and f.get('status') == 'failed':
        fails.append(name + ' :: SUITE FAILED TO RUN: ' + (f.get('message') or '')[:200].replace('\n', ' '))
print('  totals: tests=%s failed=%s passed=%s suitesFailed=%s' % (d.get('numTotalTests'), d.get('numFailedTests'), d.get('numPassedTests'), d.get('numFailedTestSuites')))
for x in fails[:12]:
    print('  KILLED-BY ' + x[:230])
if len(fails) > 12:
    print('  ... %d more' % (len(fails) - 12))
