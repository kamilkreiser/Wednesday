#!/bin/bash
set -u
S=/private/tmp/claude-501/gateB1556-r1
C=$S/clone
D=$C/Blockchain/Dev
GW=$D/services/api-gateway
EV=$S/ev
TREL=Blockchain/Dev/services/api-gateway/src/__tests__/ks1543-five-pre-existing-eslint-warnings-in.test.ts
TSC=$D/node_modules/.bin/tsc
git -C "$C" status --short
echo "== tsc -p tsconfig.test.json (head)"
$TSC -p "$GW/tsconfig.test.json" --listFilesOnly > "$EV/tsc_files.txt" 2>&1
echo "program files: $(wc -l < "$EV/tsc_files.txt")"; /usr/bin/grep -ic 'ks1543-five-pre-existing' "$EV/tsc_files.txt"; /usr/bin/grep -ic 'routes/verification.ts' "$EV/tsc_files.txt"
$TSC -p "$GW/tsconfig.test.json" > "$EV/tsc_head.log" 2>&1; echo "tsc head rc=$? errors=$(/usr/bin/grep -c 'error TS' "$EV/tsc_head.log")"
/usr/bin/grep -i 'ks1543\|verification.ts' "$EV/tsc_head.log" | head
echo "== tsc -p tsconfig.json (build program, head)"
$TSC -p "$GW/tsconfig.json" --noEmit > "$EV/tsc_build_head.log" 2>&1; echo "tsc build rc=$? errors=$(/usr/bin/grep -c 'error TS' "$EV/tsc_build_head.log")"
echo "== planted error in the test file"
printf '\nconst __planted: number = "not a number";\n' >> "$C/$TREL"
$TSC -p "$GW/tsconfig.test.json" > "$EV/tsc_planted.log" 2>&1; echo "tsc planted rc=$? errors=$(/usr/bin/grep -c 'error TS' "$EV/tsc_planted.log")"
/usr/bin/grep -i 'ks1543' "$EV/tsc_planted.log" | head -3
git -C "$C" checkout -- "$TREL"; git -C "$C" status --short; echo "(restored)"
echo "== full api-gateway suite (head)"
t0=$(date +%s)
npm --prefix "$GW" run test -- run --reporter=json --outputFile="$EV/suite_head.json" > "$EV/suite_head.log" 2>&1
echo "suite rc=$? secs=$(( $(date +%s) - t0 ))"
python3 -I -c 'import json,sys
d=json.load(open(sys.argv[1]))
print("files",d["numTotalTestSuites"],"passedFiles",d["numPassedTestSuites"],"failedFiles",d["numFailedTestSuites"],"tests",d["numTotalTests"],"passed",d["numPassedTests"],"failed",d["numFailedTests"],"pending",d["numPendingTests"],"todo",d.get("numTodoTests"))
print("files in run:",len(d["testResults"]), "ks1543 present:", any("ks1543-five" in f["name"] for f in d["testResults"]))
for f in d["testResults"]:
  for a in f["assertionResults"]:
    if a["status"]=="failed": print("  FAIL",f["name"].split("/")[-1],"|",a["title"][:120])
  if f.get("status")=="failed" and not f["assertionResults"]: print("  FILE-FAIL",f["name"].split("/")[-1],f.get("message","")[:300].replace("\n"," "))' "$EV/suite_head.json"
ls -d /Volumes/DevMASTER/WEDNESDAY/node_modules 2>&1
