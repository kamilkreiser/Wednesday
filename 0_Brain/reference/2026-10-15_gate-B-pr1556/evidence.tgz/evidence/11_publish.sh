#!/bin/bash
set -u
S=/private/tmp/claude-501/gateB1556-r1
R=/Volumes/DevMASTER/WEDNESDAY/0_Brain/reference/2026-10-15_gate-B-pr1556
B=$S/verdict_body.md
H=$(cat "$B" | shasum -a 256 | cut -c1-16)
{ head -n 1 "$B"; echo "sha256/16 (this file minus line 2): $H"; tail -n +2 "$B"; } > "$R/verdict.md"
echo "hash=$H"
# verify: delete line 2, sha256 the rest
echo "verify=$(sed '2d' "$R/verdict.md" | shasum -a 256 | cut -c1-16)"
mkdir -p "$R/evidence"
cp "$S"/ev/* "$R/evidence/"
cp "$S"/scripts/* "$R/evidence/"
ls "$R" "$R/evidence" | head -60
ls -d /Volumes/DevMASTER/WEDNESDAY/node_modules 2>&1
