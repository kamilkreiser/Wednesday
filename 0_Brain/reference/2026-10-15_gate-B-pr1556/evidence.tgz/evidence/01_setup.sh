#!/bin/bash
set -u
S=/private/tmp/claude-501/gateB1556-r1
SRC="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files"
SSHC='ssh -i "/Volumes/DevMASTER/!CODING/Secuura/Blockchain/3_Access_Keys/github_deploy_rw" -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new'
echo "== ls-remote"
git -C "$SRC" ls-remote origin refs/pull/1556/head refs/heads/develop refs/heads/main
git clone --shared --no-checkout "$SRC" "$S/clone" 2>&1 | tail -2
git -C "$S/clone" config core.sshCommand "$SSHC"
git -C "$S/clone" remote set-url origin git@github.com:Secuura/Distributed_Secuura.git
git -C "$S/clone" fetch origin "+refs/pull/1556/head:refs/remotes/pr/1556" "+refs/heads/develop:refs/remotes/origin/develop" 2>&1 | tail -3
echo "== heads"
git -C "$S/clone" rev-parse refs/remotes/pr/1556 refs/remotes/origin/develop
git -C "$S/clone" merge-base --is-ancestor refs/remotes/origin/develop refs/remotes/pr/1556 && echo "develop IS ancestor of head" || echo "develop NOT ancestor"
echo "== mb"; git -C "$S/clone" merge-base refs/remotes/origin/develop refs/remotes/pr/1556
echo "== log"; git -C "$S/clone" log --oneline refs/remotes/origin/develop..refs/remotes/pr/1556
echo "== stat"; git -C "$S/clone" diff --stat refs/remotes/origin/develop...refs/remotes/pr/1556
