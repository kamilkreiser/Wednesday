// usage: node lint.mjs <eslint-cwd> <file> [label]
import { createRequire } from 'module';
const D = '/private/tmp/claude-501/gateB1556-r1/clone/Blockchain/Dev';
const require = createRequire(D + '/services/api-gateway/package.json');
const { ESLint } = require('eslint');
const [cwd, file, label = ''] = process.argv.slice(2);
const t0 = Date.now();
const eslint = new ESLint({ cwd });
const [r] = await eslint.lintFiles([file]);
const cfg = await eslint.calculateConfigForFile(file).catch((e) => 'ERR ' + e.message);
console.log(`[${label}] cwd=${cwd} errors=${r.errorCount} warnings=${r.warningCount} ms=${Date.now() - t0} configHasNoUnused=${typeof cfg === 'object' && cfg.rules ? JSON.stringify(cfg.rules['@typescript-eslint/no-unused-vars']) : cfg}`);
for (const m of r.messages) console.log(`  ${m.line}:${m.column} ${m.severity === 2 ? 'E' : 'W'} ${m.ruleId} ${m.message}`);
