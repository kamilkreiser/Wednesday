#!/bin/bash
set -u
S=/private/tmp/claude-501/gateB1556-r1
C=$S/clone
D=$C/Blockchain/Dev
REL=Blockchain/Dev/services/api-gateway/src/routes/verification.ts
TREL=Blockchain/Dev/services/api-gateway/src/__tests__/ks1543-five-pre-existing-eslint-warnings-in.test.ts
SRC="/Volumes/DevMASTER/!CODING/Secuura/Blockchain/2_Project_Files"
echo "== leg 16 ratchet, api-gateway (head)"
/bin/bash "$D/scripts/preflight/test-types-ratchet.sh" services/api-gateway 2>&1 | tail -4; echo "rc=${PIPESTATUS[0]}"
echo "== leg 16 planted control"
printf '\nconst __planted: number = "x";\nvoid __planted;\n' >> "$C/$TREL"
/bin/bash "$D/scripts/preflight/test-types-ratchet.sh" services/api-gateway 2>&1 | tail -4; echo "rc=${PIPESTATUS[0]}"
git -C "$C" checkout -- "$TREL"; git -C "$C" status --short; echo "(restored)"
echo "== live tip re-read"
git -C "$SRC" ls-remote origin refs/heads/develop refs/pull/1556/head
git -C "$C" fetch -q origin "+refs/heads/develop:refs/remotes/origin/develop"
TIP=$(git -C "$C" rev-parse refs/remotes/origin/develop); echo "tip=$TIP"
git -C "$C" merge-base --is-ancestor "$TIP" refs/remotes/pr/1556 && echo "tip is ancestor of head -> merge is a fast-forward/no-conflict"
MT=$(git -C "$C" merge-tree --write-tree "$TIP" refs/remotes/pr/1556); echo "merge-tree rc=$? tree=$MT"
echo "head tree=$(git -C "$C" rev-parse refs/remotes/pr/1556^{tree})"
echo "== planted conflicting control: commit on tip that edits line 661 differently"
W=$S/wt_conflict
git -C "$C" worktree add -q --detach "$W" "$TIP"
python3 -I -c 'import sys
p=sys.argv[1]; s=open(p).read(); assert s.count("} catch (_err) {\n        // Network/timeout")==1
s=s.replace("} catch (_err) {\n        // Network/timeout","} catch (_e) {\n        // Network/timeout"); open(p,"w").write(s)' "$W/$REL"
git -C "$W" -c user.name=gate -c user.email=gate@invalid commit -q -am "planted conflict"
P=$(git -C "$W" rev-parse HEAD)
git -C "$C" merge-tree --write-tree --name-only "$P" refs/remotes/pr/1556; echo "planted merge-tree rc=$? (1 = conflict expected)"
echo "== overlap: recent PR heads touching verification.ts"
git -C "$C" fetch -q origin "+refs/pull/154*/head:refs/remotes/pr/154x/*" "+refs/pull/155*/head:refs/remotes/pr/155x/*" 2>&1 | tail -2
for r in $(git -C "$C" for-each-ref --format='%(refname)' refs/remotes/pr/154x refs/remotes/pr/155x); do
  mb=$(git -C "$C" merge-base "$TIP" "$r" 2>/dev/null) || continue
  if git -C "$C" diff --quiet "$mb" "$r" -- "$REL"; then :; else
    contained=no; git -C "$C" merge-base --is-ancestor "$r" "$TIP" && contained=merged
    echo "  $r touches verification.ts (in develop: $contained)"
  fi
done
echo "  (control: refs/remotes/pr/1556 is the PR under gate)"
ls -d /Volumes/DevMASTER/WEDNESDAY/node_modules 2>&1
