#!/bin/bash
set -u
S=/private/tmp/claude-501/gateB1556-r1
C=$S/clone
D=$C/Blockchain/Dev
GW=$D/services/api-gateway
F=$GW/src/routes/verification.ts
REL=Blockchain/Dev/services/api-gateway/src/routes/verification.ts
T=src/__tests__/ks1543-five-pre-existing-eslint-warnings-in.test.ts
EV=$S/ev; mkdir -p "$EV"
runtest() { # label
  local t0=$(date +%s)
  npm --prefix "$GW" run test -- run "$T" --reporter=json --outputFile="$EV/vt_$1.json" > "$EV/vt_$1.log" 2>&1
  echo "[$1] vitest rc=$? secs=$(( $(date +%s) - t0 ))"
  python3 -I -c 'import json,sys
d=json.load(open(sys.argv[1]))
print("  tests",d["numTotalTests"],"passed",d["numPassedTests"],"failed",d["numFailedTests"])
for f in d["testResults"]:
  for a in f["assertionResults"]:
    print("   ",a["status"],"|",a["title"][:90],"|",(a.get("failureMessages") or [""])[0][:220].replace("\n"," "))' "$EV/vt_$1.json"
}
echo "== HEAD state"; git -C "$C" status --short
echo "== RED: develop's verification.ts at HEAD tree"
git -C "$C" show refs/remotes/origin/develop:$REL > "$F"
git -C "$C" diff --stat
node "$S/scripts/lint.mjs" "$D" "$F" before-dev
runtest red
echo "== GREEN: restore head file"
git -C "$C" checkout -- "$REL"
git -C "$C" status --short
node "$S/scripts/lint.mjs" "$D" "$F" after-head
node "$S/scripts/lint.mjs" "$GW" "$F" after-head-cwdGW
node "$S/scripts/lint.mjs" "/private/tmp" "$F" after-head-cwdTMP
runtest green
ls -d /Volumes/DevMASTER/WEDNESDAY/node_modules 2>&1
