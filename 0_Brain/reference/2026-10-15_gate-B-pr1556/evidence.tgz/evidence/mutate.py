import sys
path, mode = sys.argv[1], sys.argv[2]
src = open(path, encoding='utf8').read()
lines = src.split('\n')
A1 = '// Network/timeout — fall through to persisted state.'
A2 = '// Ignore DB errors - fallback to in-memory only'
def idx(s):
    hits = [i for i, l in enumerate(lines) if s in l]
    assert len(hits) == 1, (s, hits)
    return hits[0]
i1, i2 = idx(A1), idx(A2)
assert lines[i1 - 1].strip() == '} catch {' and lines[i2 - 1].strip() == '} catch {', 'precondition'
if mode == 'M1_restore_err_661':
    lines[i1 - 1] = lines[i1 - 1].replace('} catch {', '} catch (_err) {')
elif mode == 'M1b_restore_err_any_1503':
    lines[i2 - 1] = lines[i2 - 1].replace('} catch {', '} catch (err: any) {')
elif mode == 'M2_delete_anchor_body_line_1504':
    del lines[i2]
elif mode == 'M2b_delete_nonanchor_body_line_663':
    assert 'remains honest' in lines[i1 + 1], lines[i1 + 1]
    del lines[i1 + 1]
elif mode == 'CTRL_comment_only_shift':
    lines.insert(1, '// gate control: comment-only line, shifts every line by one')
elif mode == 'CTRL_reword_anchor_661':
    lines[i1] = lines[i1].replace('Network/timeout', 'Network or timeout')
elif mode == 'M3_catch_used_binding_661':
    # binding restored AND used: lint-clean but text pin should kill it
    lines[i1 - 1] = lines[i1 - 1].replace('} catch {', '} catch (_err) { void _err;')
else:
    raise SystemExit('unknown mode ' + mode)
open(path, 'w', encoding='utf8').write('\n'.join(lines))
print('applied', mode, 'anchor lines (1-based):', i1 + 1, i2 + 1)
