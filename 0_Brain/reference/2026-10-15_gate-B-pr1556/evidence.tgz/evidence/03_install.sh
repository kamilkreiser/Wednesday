#!/bin/bash
set -u
C=/private/tmp/claude-501/gateB1556-r1/clone
D=$C/Blockchain/Dev
ls -d /Volumes/DevMASTER/WEDNESDAY/node_modules 2>&1
time npm --prefix "$D" ci --no-audit --no-fund --ignore-scripts 2>&1 | tail -5
grep -n '"build"' "$D/packages/shared/package.json"
npm --prefix "$D" run build -w packages/shared 2>&1 | tail -3
ls "$D/node_modules/.bin/" | grep -E '^(eslint|vitest|tsc)$'
ls -la "$D/node_modules/@secuura/" | head
ls -d "$D/services/api-gateway/node_modules" 2>&1
ls -d /Volumes/DevMASTER/WEDNESDAY/node_modules 2>&1
