#!/bin/bash
set -u
S=/private/tmp/claude-501/gateB1556-r1
N=$S/noconfig-$(date +%s)
mkdir -p "$N"
cp "$S/clone/Blockchain/Dev/services/api-gateway/src/routes/verification.ts" "$N/verification.ts"
node "$S/scripts/lint.mjs" "$N" "$N/verification.ts" outside-tree 2>&1 | head -3
echo "rc=${PIPESTATUS[0]}"
git -C "$S/clone" status --short; echo "(clone clean)"
ls -d /Volumes/DevMASTER/WEDNESDAY/node_modules 2>&1
