#!/bin/bash
set -u
S=/private/tmp/claude-501/gateB1556-r1
C=$S/clone
D=$C/Blockchain/Dev
GW=$D/services/api-gateway
F=$GW/src/routes/verification.ts
REL=Blockchain/Dev/services/api-gateway/src/routes/verification.ts
T=src/__tests__/ks1543-five-pre-existing-eslint-warnings-in.test.ts
EV=$S/ev
summ() {
python3 -I -c 'import json,sys
d=json.load(open(sys.argv[1]))
print("  tests",d["numTotalTests"],"passed",d["numPassedTests"],"failed",d["numFailedTests"])
for f in d["testResults"]:
  if not f["assertionResults"]: print("  FILE-FAIL", f.get("message","")[:250].replace("\n"," "))
  for a in f["assertionResults"]:
    print("   ",a["status"],"|",a["title"][:24],"|",(a.get("failureMessages") or [""])[0][:200].replace("\n"," "))' "$1"
}
for m in M1_restore_err_661 M1b_restore_err_any_1503 M2_delete_anchor_body_line_1504 M2b_delete_nonanchor_body_line_663 M3_catch_used_binding_661 CTRL_comment_only_shift CTRL_reword_anchor_661; do
  echo "== $m"
  python3 -I "$S/scripts/mutate.py" "$F" "$m"
  git -C "$C" diff --stat | tail -1
  node "$S/scripts/lint.mjs" "$D" "$F" "$m" | head -1
  npm --prefix "$GW" run test -- run "$T" --reporter=json --outputFile="$EV/mut_$m.json" > "$EV/mut_$m.log" 2>&1
  echo "  vitest rc=$?"; summ "$EV/mut_$m.json"
  git -C "$C" checkout -- "$REL"
done
echo "== MOVE control: verification.ts moved aside"
mv "$F" "$S/moved_verification.ts"
npm --prefix "$GW" run test -- run "$T" --reporter=json --outputFile="$EV/mut_MOVE.json" > "$EV/mut_MOVE.log" 2>&1
echo "  vitest rc=$?"; summ "$EV/mut_MOVE.json"
mv "$S/moved_verification.ts" "$F"
git -C "$C" status --short; echo "(status above must be empty)"
ls -d /Volumes/DevMASTER/WEDNESDAY/node_modules 2>&1
