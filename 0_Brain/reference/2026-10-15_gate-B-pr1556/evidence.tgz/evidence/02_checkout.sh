#!/bin/bash
set -u
C=/private/tmp/claude-501/gateB1556-r1/clone
git -C "$C" checkout -q --detach refs/remotes/pr/1556 && git -C "$C" rev-parse HEAD
echo "== merge-tree check: develop + 7b7d patch == head ?"
diff <(git -C "$C" diff 7b7d40329^ 7b7d40329) <(git -C "$C" diff refs/remotes/origin/develop refs/remotes/pr/1556) && echo "IDENTICAL patch"
echo "== 7b7d parent ancestry"; git -C "$C" log --oneline -3 7b7d40329
ls "$C/Blockchain/Dev" "$C/Blockchain/Dev/services/api-gateway"
ls "$C/Blockchain/Dev"/eslint.config.* "$C/Blockchain/Dev"/package*.json 2>&1
ls "$C/Blockchain/Dev/services/api-gateway"/package-lock.json "$C/Blockchain/Dev/services/api-gateway"/eslint.config.* 2>&1
