#!/bin/bash
set -u
C=/private/tmp/claude-501/gateB1556-r1/clone
REL=Blockchain/Dev/services/api-gateway/src/routes/verification.ts
git -C "$C" for-each-ref --format='%(refname) %(objectname)' refs/remotes/pr/
P=refs/remotes/pr/155x/4
git -C "$C" log --oneline -3 $P
MB=$(git -C "$C" merge-base refs/remotes/origin/develop $P); echo "mb=$MB"
git -C "$C" diff --stat "$MB" $P -- "$REL"
git -C "$C" diff "$MB" $P -- "$REL" | head -60
echo "== merge-tree 1554-head x 1556-head"
git -C "$C" merge-tree --write-tree --name-only $P refs/remotes/pr/1556; echo "rc=$?"
echo "== merge-tree develop+1556 then 1554 (sequential prediction)"
git -C "$C" merge-tree --write-tree --name-only refs/remotes/pr/1556 $P; echo "rc=$?"
