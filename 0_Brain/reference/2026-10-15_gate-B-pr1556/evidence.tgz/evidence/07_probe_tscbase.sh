#!/bin/bash
set -u
S=/private/tmp/claude-501/gateB1556-r1
C=$S/clone
D=$C/Blockchain/Dev
GW=$D/services/api-gateway
F=$GW/src/routes/verification.ts
REL=Blockchain/Dev/services/api-gateway/src/routes/verification.ts
TREL=Blockchain/Dev/services/api-gateway/src/__tests__/ks1543-five-pre-existing-eslint-warnings-in.test.ts
T=src/__tests__/ks1543-five-pre-existing-eslint-warnings-in.test.ts
EV=$S/ev
TSC=$D/node_modules/.bin/tsc
echo "== PROBE: is the messages assertion live? strip the text pins, lint develop's file"
python3 -I -c 'import sys
p=sys.argv[1]; s=open(p).read(); n=s.count("expect(text).toBe(\x27} catch {\x27);")
s=s.replace("expect(text).toBe(\x27} catch {\x27);","void text;"); open(p,"w").write(s); print("pins stripped:",n)' "$C/$TREL"
git -C "$C" show refs/remotes/origin/develop:$REL > "$F"
npm --prefix "$GW" run test -- run "$T" --reporter=json --outputFile="$EV/probe_msgs.json" > "$EV/probe_msgs.log" 2>&1
echo "  vitest rc=$?"
python3 -I -c 'import json,sys
d=json.load(open(sys.argv[1]))
for f in d["testResults"]:
  for a in f["assertionResults"]:
    print("   ",a["status"],"|",a["title"][:24],"|",(a.get("failureMessages") or [""])[0][:260].replace("\n"," "))' "$EV/probe_msgs.json"
git -C "$C" checkout -- "$REL" "$TREL"; git -C "$C" status --short; echo "(restored)"
echo "== tsc test-program baseline on develop tree (verification.ts = develop, new test moved aside)"
git -C "$C" show refs/remotes/origin/develop:$REL > "$F"
mv "$C/$TREL" "$S/moved_test.ts"
$TSC -p "$GW/tsconfig.test.json" > "$EV/tsc_dev.log" 2>&1; echo "tsc develop rc=$? errors=$(/usr/bin/grep -c 'error TS' "$EV/tsc_dev.log")"
mv "$S/moved_test.ts" "$C/$TREL"
git -C "$C" checkout -- "$REL"; git -C "$C" status --short; echo "(restored)"
diff <(sed -E 's/\([0-9]+,[0-9]+\)//' "$EV/tsc_dev.log" | sort) <(sed -E 's/\([0-9]+,[0-9]+\)//' "$EV/tsc_head.log" | sort) && echo "tsc error SET identical develop vs head"
/usr/bin/grep -o '^[^(]*' "$EV/tsc_head.log" | sort | uniq -c | sort -rn | head -12
